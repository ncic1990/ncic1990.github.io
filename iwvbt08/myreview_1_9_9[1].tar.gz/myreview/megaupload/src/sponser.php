<html>
 <body  bgcolor="#eeeeee">
  <table border=0 width=400 align="center">
   <tr><td bgcolor="#336699">
	  <a href="http://www.radinks.com/upload/?mg" style="font-size :larger; color: white">Rad Upload</a>
   </td></tr>
   <tr><td>Visit our sponser <a href="http://www.radinks.com/upload/?mg">Rad Upload</a> - 
   A Drag and Drop File uploader with progress bar. Works with both FTP and HTTP. Supports
   recursive upload of folders.</td></tr>
  </tabble>
 </body>
</html>

  
