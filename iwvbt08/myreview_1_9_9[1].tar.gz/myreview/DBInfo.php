<?php
// File written by Setup.php
// Constants that define how to connect the DB

// The standard user: can do anything 
  define ("NAME","adminReview");
  define ("PASS", "mdpAdmin");
  define ("SERVER", "localhost");
  define ("BASE", "Review");

// The SQL user: can only submit SELECT queries
  define ("SQLUser", "SQLUser");
  define ("pwdSQL", "pwdSQL");
?>
