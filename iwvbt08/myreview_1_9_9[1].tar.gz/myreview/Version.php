<?php
require("Constant.php");
echo "Version: " . VERSION;
?>