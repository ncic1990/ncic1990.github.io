/* Pipeline Trace
 * added by zhangwl
*/

#include "pplstat.h"

PPLSTAT::PPLSTAT()
{
	trace_start = false;
//	pplstat_info.stagesinfo->next = NULL;
//	pplstat_info.stagesinfo->prev = NULL;
}

void 
PPLSTAT::TraceStart()
{
	 trace_start = true;
}

int
PPLSTAT::SetTraceMask(uint8 mask)
{
	int count = 0;

	ppl_mask = mask;
	if(mask & StagesMask)
	{	
		printf("The stage info in current clock:\n");
	 	printf("           IF          ID          EX          MEM          WB     ");
		count += 20;
	}
	if(mask & NinstrMask)
		count += 4;
	if(mask & NcycleMask)
		count += 4;
	if(mask & NstallMask)
		count += 4;
	if(mask & NrawMask )
		count += 4;
	
	buf = (uint8*)malloc(count);
	return count;
}

void 
PPLSTAT::ShowTrace()
{
	CLKTRACE_INFO *p = pplstat_info.stagesinfo;
	uint32 q = pplstat_info.stagesinfo->stagestate;

	if(trace_start)
	{
		// Show the real time info of each stage
		if(ppl_mask & StagesMask)
		{	
			printf("%8x:", p->pc);
			//int pipeline
			if (q & IFMask)
				printf("  %8x  ", p->instr);
			else
				printf("    stall   ");
			
			if ((p = p->prev) != NULL)
			{
				if (q & IDMask){
					while (((p->instr) == 0xffffffff) && ((p->prev) != NULL))
						p = p->prev;
					if ((p->instr) != 0xffffffff)
						printf("  %8x  ", p->instr);
				}else
					printf("  stall   ");
			}
			
			if ((p = p->prev) != NULL)
			{
				if (q & EXMask){
					while (((p->instr) == 0xffffffff) && ((p->prev) != NULL))
						p = p->prev;
					if ((p->instr) != 0xffffffff)
						printf("  %8x  ", p->instr);
				}else
					printf("  stall   ");
			}
			
			if ((p = p->prev) != NULL)
			{
				if (q & MEMMask){
					while (((p->instr) == 0xffffffff) && ((p->prev) != NULL))
						p = p->prev;
					if ((p->instr) != 0xffffffff)
						printf("  %8x  ", p->instr);
				}else
					printf("  stall   ");
			}
			
			if ((p = p->prev) != NULL)
			{
				if (q & WBMask){
					while (((p->instr) == 0xffffffff) && ((p->prev) != NULL))
						p = p->prev;
					if ((p->instr) != 0xffffffff)
						printf("  %8x  ", p->instr);
				}else
					printf("  stall   ");
			}
			
			//fp pipeline
			if (q & FEX1Mask){
				p = p->prev;
				printf("  %8x<fEX1>", p->instr);
			}
			
			if (q & FEX2Mask){
				p = p->prev;
				printf("  %8x<fEX2>", p->instr);
			}

			if (q & FEX3Mask){
				p = p->prev;
				printf("  %8x<fEX3>", p->instr);
			}

			if (q & FWBMask){
				p = p->prev;
				printf("  %8x<fWB>", p->instr);
			}

			printf("\n");

			}
	}
	else{
       	//Show the statistical info
       	printf("The pipeline statistical  info during this trace:\n");
		if(ppl_mask & NinstrMask)
			printf("  The traced instruction counts = %4d\n", pplstat_info.instr_count);			
		if(ppl_mask & NcycleMask)
			printf("  The traced cycles = %4d\n", pplstat_info.cycle_count);	
		if((ppl_mask & NinstrMask) && (ppl_mask & NcycleMask))
			printf("  The CPI = %4.2f\n", (pplstat_info.cycle_count * 1.0)/(pplstat_info.instr_count));	
		if (ppl_mask & NstallMask)			
			printf("  The stall counts during trace = %4d\n", pplstat_info.stall_count);
		if (ppl_mask & NrawMask)
			printf("  The raw count during trace = %4d\n", pplstat_info.nraw);
	}
}

void 
PPLSTAT::TraceEnd()
{
	trace_start = false;
	ShowTrace();
}

/*void
PPLSTAT::RefreshStages()
{
	if (trace_start)
		boolval = 0x0000;
	
	p = new CLKTRACE_INFO;
//	pplstat_info.stagesinfo->instr = -1;
}

inline void 
PPLSTAT::SetPc(uint32 pc)
{
	if (trace_start && (ppl_mask & StagesMask))
		pplstat_info.stagesinfo->pc = pc;

}

inline void 
PPLSTAT::SetInstr(uint32 instr)
{
	if (trace_start && (ppl_mask & StagesMask))
		pplstat_info.stagesinfo->instr = instr;
}

inline void 
PPLSTAT::SetStage(uint32 set_mask)
{
	if (trace_start)
		boolval = boolval & set_mask;
}

 inline void
 PPLSTAT::SetClkStages(uint32 instr)
{
	if (trace_start)
	{
		CLKTRACE_INFO *p = new CLKTRACE_INFO;
		pplstat_info.stagesinfo->next = p;
		p->next = NULL;
	 	if (pplstat_info.stagesinfo->prev != NULL)
	 		p->prev = pplstat_info.stagesinfo;
	 // 	pplstat_info.stagesinfo->instr = instr;
	 //	pplstat_info.stagesinfo->pc = pc;
	}
 }
 
inline void 
PPLSTAT::SetnInst(int instr_count)
{
	if (trace_start && (ppl_mask & NinstrMask))
		pplstat_info.instr_count = instr_count;
}

inline void 
PPLSTAT::SetnCycle(int cycle_count)
{
	if (trace_start && (ppl_mask & NcycleMask))
		pplstat_info.cycle_count = cycle_count;
}

inline void 
PPLSTAT::SetnStall(int stall_count)
{
	if (trace_start && (ppl_mask & NstallMask))
		pplstat_info.stall_count = stall_count;
}

inline void 
PPLSTAT::SetnRaw(int nraw)
{
	if (trace_start && (ppl_mask & NrawMask))
		pplstat_info.nraw = nraw;
}
*/
void
PPLSTAT::GetTracebuf(uint8*  data)
{
	uint8* p = buf;
	if(trace_start)
	{
		if(ppl_mask & StagesMask)//????
			{	
			*(uint32*)p = pplstat_info.stagesinfo->pc;
			p += 4;
			*(uint32*)p = pplstat_info.stagesinfo->instr;
			p += 4;
			*(uint32*)p = pplstat_info.stagesinfo->stagestate;
			p += 4;
			*(uint32*)p = *(uint32*)(pplstat_info.stagesinfo->next);
			p += 4;
			*(uint32*)p = *(uint32*)(pplstat_info.stagesinfo->prev);					
			p += 4;
			}
		if(ppl_mask & NinstrMask)
			{
			*(int*)p = pplstat_info.instr_count;
			p += 4;
			}
		if(ppl_mask & NcycleMask)
			{
			*(uint16*)p = pplstat_info.cycle_count;
			p += 4;
			}
		if (ppl_mask & NstallMask )
			{
			*(uint32*)p = pplstat_info.stall_count;
			p += 4;
			}
		if (ppl_mask & NrawMask)
			{
			*(uint32*)p = pplstat_info.nraw;
			p += 4;
			}		
		}
	data = buf;
}

PPLSTAT_INFO
PPLSTAT::RecoverTrace(uint8 mask, uint8* data)
{
	PPLSTAT_INFO  result;
	uint8* p = data;

	if(mask & StagesMask)
		{
		result.stagesinfo->pc = *(uint32*)p;
		p += 4;		
		result.stagesinfo->instr = *(uint32*)p;
		p += 4;
		result.stagesinfo->stagestate= *(uint32*)p;
		p += 4;
		result.stagesinfo->next = (CLKTRACE_INFO*)p;//????
		p += 4;
		result.stagesinfo->prev = (CLKTRACE_INFO*)p;
		p += 4;
		}
	if(mask & NinstrMask)
		{
		result.instr_count = *(int* ) p;
		p += 4;
		}
	if(mask & NcycleMask)
		{
		result.cycle_count = *(int* ) p;
		p += 4;
		}
	if(mask & NstallMask)
		{
		result.stall_count = *(int* ) p;
		p += 4;
		}
	if(mask & NrawMask)
		{
		result.nraw = *(int* ) p;
		p += 4;
		}	
	return result;
}
PPLSTAT::~PPLSTAT()
{
}
