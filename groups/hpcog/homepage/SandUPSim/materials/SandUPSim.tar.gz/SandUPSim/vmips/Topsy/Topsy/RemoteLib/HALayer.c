//hardware layer
char* NetWorkCardBuf=(char*)RemoteServBufBase;

#define ACCESS_NETWORKCARD_CTLPORT(type,service)\
do{\
__asm__ __volatile__(\
		".set\tnoreorder\n\t"\
		".set\tnoat\n\t"\
		"li\t$26,%0\n"\
		"li\t$27,%1\n"\
		"sw\t$27,($26)\n"\
		".set\tat\n\t"\
		".set\treorder"\
		:\
		:"i"(type), "i"(service)\
		);\
}while(0)

void ConnectToServer( )
{
	ACCESS_NETWORKCARD_CTLPORT(PORT_S_R_PHYS,CONNECT);
}

bool SendPackage( )
{
	ACCESS_NETWORKCARD_CTLPORT(PORT_S_R_PHYS,SEND_PACKAGE);
	return true;
}

bool RecvPackage( )
{
	ACCESS_NETWORKCARD_CTLPORT(PORT_S_R_PHYS,RECV_PACKAGE);
	return true;
}

void DisConnectFromServer( )
{
	ACCESS_NETWORKCARD_CTLPORT(PORT_S_R_PHYS,DISCONNECT);
}

