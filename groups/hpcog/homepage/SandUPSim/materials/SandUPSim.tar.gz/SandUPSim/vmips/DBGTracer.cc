/***
 * A combine of debugger and tracer
 * An bridge between the simulator runner and the simulated machine.
 *  
 *
 * $Header: /work/cvs/cvsroot/vmips/DBGTracer.cc,v 1.21.6.1 2004/09/21 09:53:39 xjw Exp $
 * cmy
 */ 
#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <netinet/tcp.h>
#include "DBGTracer.h"
#include "vmips.h"
#include <assert.h>


/*added by xjw for compress begin*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


int DBGTracer::count = 0;
int64 DBGTracer::trcVar[64];
int DBGTracer::oraSock = 0;
int DBGTracer::pid = 0;



DBGTrcPool DBGTracer::pctrace(16);
//#define __CMP_DEBUG__ //for changed register value's auto compare

int DBGTracer::trigger(int cmd) {
	switch(cmd) {
		case DBG_INSTDUMP_ON:
			cpulist[0]->opt_instdump = 1;
			break;
		case DBG_INSTDUMP_OFF:
			cpulist[0]->opt_instdump = 0;
			break;
		case DBG_TRACE_ON:
			traceon(cpulist[0]);
			break;
		case DBG_TRACE_OFF:
			traceoff(cpulist[0]);
			break;
		case DBG_CLKSTEP_ON:
			cpulist[0]->machine->opt_clkcpu = 1;
			break;
		case DBG_CLKSTEP_OFF:
			cpulist[0]->machine->opt_clkcpu = 0;
			break;
		default:
			break;
	}
	DBGTracer::pause();
	return 0;
}
int DBGTracer::attachCPU(CPU * cpu, uint no) {
	assert(no < 16);
	cpulist[no] = cpu;
	return 0;
}

int DBGTracer::pause(void) {
	count ++;
	return 0; 
};

#define BARRIER_PORT 6677
int DBGTracer::initOraSocket(int port) {

    int                 sockfd;
    struct sockaddr_in  servaddr;
    int rc = 0;

    sockfd = socket(AF_INET, SOCK_STREAM, 0);

    bzero(&servaddr, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons((unsigned short) port);
    inet_pton(AF_INET, "127.0.0.1", &servaddr.sin_addr);

    int  option = 1;
    setsockopt(sockfd, IPPROTO_TCP, TCP_NODELAY, &option, sizeof(option));

    rc = connect(sockfd, (struct sockaddr *) &servaddr, sizeof(servaddr));
    if(rc < 0) {
   	   printf("Barrier server connect failed.\n");
	   exit(-3);
	  
   }
   oraSock = sockfd;
   pid = getpid();
   printf("Barrier server connected.\n");
   return rc;
}

int DBGTracer::barrier(void) {
	char buf[16];
	size_t  nleft;
        ssize_t nread;
        char    *ptr;
	int numbytes;

	if ( oraSock == 0 ) initOraSocket();
	pid++;
	write(oraSock, &pid,sizeof(pid));
   	
      ptr = buf;
      nleft = 16;
      while (nleft > 0) {
        if ( (nread = read(oraSock, ptr, nleft)) < 0) {
            if (errno == EINTR)
                nread = 0;      /* and call read() again */
            else{
			printf("read socket error\n");
			exit(-1);
            	}
        } else if (nread == 0)
            break;              /* EOF */    
        nleft -= nread;
        ptr   += nread;
    }

#ifdef __CMP_DEBUG__
	fclose(stderr);
#endif
    return  0;	
}
void 
DBGTracer::  dumpregs(CPU * cpu)
{
	cpu->machine->virtualservers->dumpregserver((DeviceExc*)cpu);
}

void DBGTrcPool::dump(void) {
		fprintf(stderr,"dumping trace start: -------\n");
		for(uint i=0;i<poolsize; i++, poolhead = (++ poolhead) %poolsize) {
			if(type == 0) {
				fprintf(stderr,"\t%2d: %08x\t", i, pool[poolhead]);
				call_disassembler(pool[poolhead],pooldata[poolhead]);
			}
			else
				fprintf(stderr,"\t%2d: %08x %08x\n", i, pool[poolhead],pooldata[poolhead]);
		}
		fprintf(stderr,"dumping trace end : -------\n");
	};

