/*libc functions*/
#define LIBCCOMMONDECLARE\
	uint32 tmp32;\
	COMMONDECLARE

#define LIBCCOMMONRET(paramsdesptr,tmp32)\
do{\
	SetParamDescNum(paramsdesptr, 2);\
	SetParamDescParameter(paramsdesptr,0,(uint32)&tmp32,true,0,0);\
	SetParamDescParameter(paramsdesptr,1,(uint32)&rmt_errno,true,0,0);\
	WAITFORREPLY(paramsdesptr);\
	RELEASE( );\
	return tmp32;\
}while(0)

#define LIBCCOMMONRET_1BUF(paramsdesptr,tmp32,buf,bufsize)\
do{\
	SetParamDescNum(paramsdesptr, 3);\
	SetParamDescParameter(paramsdesptr,0,(uint32)&tmp32,true,0,0);\
	SetParamDescParameter(paramsdesptr,1,(uint32)&rmt_errno,true,0,0);\
	SetParamDescParameter(paramsdesptr,2,(uint32)buf,false,0,bufsize);\
	WAITFORREPLY(paramsdesptr);\
	RELEASE();\
	return tmp32;\
}while(0)

FILE* rslibcfopen(const char* filename,const char* filemode)
{
	#ifdef DEBUGLIBC
	OUTPUTMSG("client msg:libc:fopen");
	#endif
	CHECKPTR_2_RETVAL((char*)filename,"rslibcfopen:filename",(char*)filemode,"rslibcfopen:filemode",NULL);
	
	FILE* fp;
	uint32 tmp32;
	ParamsDesc_t* paramsdesptr=&localservinfo.paramdesc;
	
	SetParamDescNum(paramsdesptr, 2);
	SetParamDescParameter(paramsdesptr,0,(uint32)filename,false,CHARALIGN,stringlen((char*)filename)+1);
	SetParamDescParameter(paramsdesptr,1,(uint32)filemode,false,CHARALIGN,stringlen((char*)filemode)+1);
	REMOTECALL(LIBCREQ,fopenservno,paramsdesptr);
	
	SetParamDescNum(paramsdesptr, 2);
	SetParamDescParameter(paramsdesptr,0,(uint32)&tmp32,true,0,0);
	SetParamDescParameter(paramsdesptr,1,(uint32)&rmt_errno,true,0,0);
	WAITFORREPLY(paramsdesptr);
	fp=(FILE*)tmp32;
	
	RELEASE();
	return fp;
}
uint32 rslibcfread(char* buf,uint32 size,uint32 num,FILE* fp)
{
	#ifdef DEBUGLIBC
	OUTPUTMSG("client msg:libc:fread");
	#endif
	CHECKPTR_2_RETVAL(buf,"rslibcfread:buf",fp,"rslibcfread:fp",0);

	LIBCCOMMONDECLARE

	SetParamDescNum(paramsdesptr, 3);
	SetParamDescParameter(paramsdesptr,0,size,true,0,0);
	SetParamDescParameter(paramsdesptr,1,num,true,0,0);
	SetParamDescParameter(paramsdesptr,2,(uint32)fp,true,0,0);
	REMOTECALL(LIBCREQ,freadservno,paramsdesptr);

	LIBCCOMMONRET_1BUF(paramsdesptr,tmp32,buf,PARAMCHECKING_DEFAULTLEN);
}
uint32 rslibcfwrite(char* buf,uint32 size,uint32 num,FILE* fp)
{
	#ifdef DEBUGLIBC
	OUTPUTMSG("client msg:libc:fwrite");
	#endif
	CHECKPTR_2_RETVAL(buf,"rslibcfwrite:buf",fp,"rslibcfwrite:fp",0);
	
	LIBCCOMMONDECLARE

	SetParamDescNum(paramsdesptr, 4);
	SetParamDescParameter(paramsdesptr,0,(uint32)buf,false,CHARALIGN,size*num);
	SetParamDescParameter(paramsdesptr,1,size,true,0,0);
	SetParamDescParameter(paramsdesptr,2,num,true,0,0);
	SetParamDescParameter(paramsdesptr,3,(uint32)fp,true,0,0);
	REMOTECALL(LIBCREQ,fwriteservno,paramsdesptr);
	
	LIBCCOMMONRET(paramsdesptr,tmp32);
}
uint32 rslibcfclose(FILE* fp)
{
	#ifdef DEBUGLIBC
	OUTPUTMSG("client msg:libc:fclose");
	#endif
	CHECKPTR_1_RETVAL(fp,"rslibcfclose:fp",EOF);
	
	LIBCCOMMONDECLARE

	SetParamDescNum(paramsdesptr, 1);
	SetParamDescParameter(paramsdesptr,0,(uint32)fp,true,0,0);
	REMOTECALL(LIBCREQ,fcloseservno,paramsdesptr);
	
	LIBCCOMMONRET(paramsdesptr,tmp32);
}
uint32 rslibcfseek(FILE* fp,uint32 offset,uint32 whence)
{
	#ifdef DEBUGLIBC
	OUTPUTMSG("client msg:libc:fseek");
	#endif
	CHECKPTR_1_RETVAL(fp,"rslibcfseek:fp",EOF);

	LIBCCOMMONDECLARE

	SetParamDescNum(paramsdesptr, 3);
	SetParamDescParameter(paramsdesptr,0,(uint32)fp,true,0,0);
	SetParamDescParameter(paramsdesptr,1,offset,true,0,0);
	SetParamDescParameter(paramsdesptr,2,whence,true,0,0);
	REMOTECALL(LIBCREQ,fseekservno,paramsdesptr);

	LIBCCOMMONRET(paramsdesptr,tmp32);
}
uint32 rslibcftell(FILE* fp)
{
	#ifdef DEBUGLIBC
	OUTPUTMSG("client msg:libc:ftell");
	#endif
	CHECKPTR_1_RETVAL(fp,"rslibcftell:fp",EOF);

	LIBCCOMMONDECLARE

	SetParamDescNum(paramsdesptr, 1);
	SetParamDescParameter(paramsdesptr,0,(uint32)fp,true,0,0);
	REMOTECALL(LIBCREQ,ftellservno,paramsdesptr);
	
	LIBCCOMMONRET(paramsdesptr,tmp32);
}
void rslibcrewind(FILE* fp)
{
	#ifdef DEBUGLIBC
	OUTPUTMSG("client msg:libc:rewind");
	#endif
	CHECKPTR_1_NORETVAL(fp,"rslibrewind:fp");

	ParamsDesc_t* paramsdesptr=&localservinfo.paramdesc;

	SetParamDescNum(paramsdesptr, 1);
	SetParamDescParameter(paramsdesptr,0,(uint32)fp,true,0,0);
	REMOTECALL(LIBCREQ,rewindservno,paramsdesptr);

	RELEASE();
}
uint32 rslibcfeof(FILE* fp)
{
	#ifdef DEBUGLIBC
	OUTPUTMSG("client msg:libc:feof");
	#endif
	CHECKPTR_1_RETVAL(fp,"rslibcfeof:fp",0);

	LIBCCOMMONDECLARE

	SetParamDescNum(paramsdesptr, 1);
	SetParamDescParameter(paramsdesptr,0,(uint32)fp,true,0,0);
	REMOTECALL(LIBCREQ,feofservno,paramsdesptr);
	
	LIBCCOMMONRET(paramsdesptr,tmp32);
}
uint32 rslibcfgetc(FILE* fp)
{
	#ifdef DEBUGLIBC
	OUTPUTMSG("client msg:libc:fgetc");
	#endif
	CHECKPTR_1_RETVAL(fp,"rslibcfgetc:fp",EOF);

	LIBCCOMMONDECLARE

	SetParamDescNum(paramsdesptr, 1);
	SetParamDescParameter(paramsdesptr,0,(uint32)fp,true,0,0);
	REMOTECALL(LIBCREQ,fgetcservno,paramsdesptr);

	LIBCCOMMONRET(paramsdesptr,tmp32);
}
char* rslibcfgets(char* s,int n,FILE* fp)
{
	#ifdef DEBUGLIBC
	OUTPUTMSG("client msg:libc:fgets");
	#endif
	CHECKPTR_2_RETVAL(s,"rslibcfgets:s",fp,"rslibcfgets:fp",NULL);

	uint32 tmp32;
	ParamsDesc_t* paramsdesptr=&localservinfo.paramdesc;

	SetParamDescNum(paramsdesptr, 2);
	SetParamDescParameter(paramsdesptr,0,n,true,0,0);
	SetParamDescParameter(paramsdesptr,1,(uint32)fp,true,0,0);
	REMOTECALL(LIBCREQ,fgetsservno,paramsdesptr);
	
	SetParamDescNum(paramsdesptr, 3);
	SetParamDescParameter(paramsdesptr,0,(uint32)&tmp32,true,0,0);
	SetParamDescParameter(paramsdesptr,1,(uint32)&rmt_errno,true,0,0);
	SetParamDescParameter(paramsdesptr,2,(uint32)s,false,0,PARAMCHECKING_DEFAULTLEN);
	WAITFORREPLY(paramsdesptr);
	
	RELEASE();
	return (char*)tmp32;
}
uint32 rslibcfputc(uint32 c,FILE* fp)
{
	#ifdef DEBUGLIBC
	OUTPUTMSG("client msg:libc:fputc");
	#endif
	CHECKPTR_1_RETVAL(fp,"rslibcfputc:fp",EOF);

	LIBCCOMMONDECLARE

	SetParamDescNum(paramsdesptr, 2);
	SetParamDescParameter(paramsdesptr,0,c,true,0,0);
	SetParamDescParameter(paramsdesptr,1,(uint32)fp,true,0,0);
	REMOTECALL(LIBCREQ,fputcservno,paramsdesptr);

	LIBCCOMMONRET(paramsdesptr,tmp32);
}
uint32 rslibcfputs(const char* s,FILE* fp)
{
	#ifdef DEBUGLIBC
	OUTPUTMSG("client msg:libc:fputs");
	#endif
	CHECKPTR_2_RETVAL((char*)s,"rslibcfputs:s",fp,"rslibcfputs:fp",EOF);

	LIBCCOMMONDECLARE

	SetParamDescNum(paramsdesptr, 2);
	SetParamDescParameter(paramsdesptr,0,(uint32)s,false,CHARALIGN,stringlen((char*)s)+1);
	SetParamDescParameter(paramsdesptr,1,(uint32)fp,true,0,0);
	REMOTECALL(LIBCREQ,fputsservno,paramsdesptr);

	LIBCCOMMONRET(paramsdesptr,tmp32);
}
char* rslibcgetcwd(char* buf, long size)
{
	#ifdef DEBUGLIBC
	OUTPUTMSG("client msg:libc:rslibcgetcwd");
	#endif
	CHECKPTR_1_RETVAL(buf,"rslibcgetcwd:buf",NULL);

	uint32 tmp32;
	ParamsDesc_t* paramsdesptr=&localservinfo.paramdesc;

	SetParamDescNum(paramsdesptr, 1);
	SetParamDescParameter(paramsdesptr,0,size,true,0,0);
	REMOTECALL(LIBCREQ,libcgetcwdservno,paramsdesptr);
	
	SetParamDescNum(paramsdesptr, 3);
	SetParamDescParameter(paramsdesptr,0,(uint32)&tmp32,true,0,0);
	SetParamDescParameter(paramsdesptr,1,(uint32)&rmt_errno,true,0,0);
	SetParamDescParameter(paramsdesptr,2,(uint32)buf,false,0,PARAMCHECKING_DEFAULTLEN);
	WAITFORREPLY(paramsdesptr);
	
	RELEASE();
	return (char*)tmp32;
}
int rslibcchdir(const char* path)
{
	#ifdef DEBUGLIBC
	OUTPUTMSG("client msg:libc:chdir");
	#endif
	CHECKPTR_1_RETVAL((char*)path,"rslibcchdir:path",-1);

	LIBCCOMMONDECLARE

	SetParamDescNum(paramsdesptr, 1);
	SetParamDescParameter(paramsdesptr,0,(uint32)path,false,CHARALIGN,stringlen((char*)path)+1);
	REMOTECALL(LIBCREQ,libcchdirservno,paramsdesptr);

	LIBCCOMMONRET(paramsdesptr,tmp32);
}

