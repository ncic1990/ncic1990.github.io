#include "servlib.h"
#include "VirtServEntry.h"
#include "localtoremote.h"
#include "LinuxSyscallErrno.h"

extern long virt_errno;
extern long rmt_errno;
extern long sys_errno;

//through virtserv or remoteserv
#define TLCOMMONCALL(virtfunc,remotefunc)\
do{\
	long retval;\
	if(COMMONVIRTSERVFLAG){\
		retval=virtfunc;\
		serv_errno=virt_errno;\
		return retval;\
	}else{\
		retval=remotefunc;\
		serv_errno=rmt_errno;\
		return retval;\
	}\
}while(0)

//through virtserv or remoteserv
#define TLCOMMONCALL_NORMT(virtfunc,rmtmsg)\
do{\
	long retval;\
	if(COMMONVIRTSERVFLAG){\
		retval=virtfunc;\
		serv_errno=virt_errno;\
		return retval;\
	}else{\
		ioConsolePutString(rmtmsg);\
	}\
}while(0)

//through linux syscall
#define TLCOMMONCALL_SYSCALL(sysfunc)\
do{\
	long retval;\
	retval=sysfunc;\
	serv_errno=sys_errno;\
	return retval;\
}while(0)\


/*libc*/
FILE* Tfopen(const char * filename,const char * mode)
{
	FILE* fp;
	if(COMMONVIRTSERVFLAG){
		fp=vslibcfopen(filename,mode);
		serv_errno=virt_errno;
		return fp;
	}else{
		fp=rslibcfopen(filename,mode);
		serv_errno=rmt_errno;
		return fp;
	}
}

long Tfread( void *buffer, long size, long count, FILE *stream )
{
	TLCOMMONCALL(vslibcfread(buffer,size,count,stream),
		rslibcfread(buffer,size,count,stream));
}

long Tfwrite( const void *buffer, long size, long count, FILE *stream )
{
	TLCOMMONCALL(vslibcfwrite(buffer,size,count,stream),
		rslibcfwrite((char*)buffer,size,count,stream));
}

int Tfclose( FILE *stream )
{
	TLCOMMONCALL(vslibcfclose(stream),rslibcfclose(stream));
}

int Tfseek( FILE *stream, long offset, int origin )
{
	TLCOMMONCALL(vslibcfseek(stream,offset,origin),
		rslibcfseek(stream,offset,origin));
}

long int Tftell(FILE* stream)
{
	TLCOMMONCALL(vslibcftell(stream),rslibcftell(stream));
}

void Trewind(FILE* stream)
{
	long retval;
	if(COMMONVIRTSERVFLAG){
		vslibcrewind(stream);
	}else{
		rslibcrewind(stream);
	}
}

int Tfeof(FILE* stream)
{
	TLCOMMONCALL(vslibcfeof(stream),rslibcfeof(stream));
}

int Tfgetc(FILE* stream)
{
	TLCOMMONCALL(vslibcfgetc(stream),rslibcfgetc(stream));
}

char* Tfgets(char* s,int n,FILE* stream)
{
	TLCOMMONCALL(vslibcfgets(s,n,stream),rslibcfgets(s,n,stream));
}

int Tfputc(int c,FILE* stream)
{
	TLCOMMONCALL(vslibcfputc(c,stream),rslibcfputc(c,stream));
}

int Tfputs(const char* s,FILE*stream)
{
	TLCOMMONCALL(vslibcfputs(s,stream),rslibcfputs(s,stream));
}

char* Tgetcwd(char* buf, long size)
{
	TLCOMMONCALL(vslibcgetcwd(buf,size),rslibcgetcwd(buf,size));
}

int Tchdir(const char* path)
{
	TLCOMMONCALL(vslibcchdir(path),rslibcchdir(path));
}


/*Linux*/
void TLexit(int exitcode)//v0==4001
{
	sys_exit(exitcode);
}

int TLread(unsigned int fd, char * buf, long count)//v0==4003
{
	TLCOMMONCALL(vslinuxread(fd, buf, count),rslinuxread(fd, buf, count));
}

int TLwrite(unsigned int fd, const char * buf, long count)//v0==4004
{
	TLCOMMONCALL(vslinuxwrite(fd, buf, count),rslinuxwrite(fd, buf, count));
}

long TLopen(const char * filename, int flags, int mode)//v0==4005
{
	TLCOMMONCALL(vslinuxopen(filename, flags, mode),
		rslinuxopen(filename, flags, mode));
}

long TLclose(unsigned int fd)//v0==4006
{
	TLCOMMONCALL(vslinuxclose(fd),rslinuxclose(fd));
}

long TLunlink(const char* pathname)//v0==4010
{
	TLCOMMONCALL(vslinuxunlink(pathname),rslinuxunlink(pathname));
}

long TLtime(int* tloc)//v0==4013
{
	TLCOMMONCALL(vslinuxtime(tloc),rslinuxtime(tloc));
}

long TLlseek(unsigned int fd, long offset, unsigned int origin)//v0==4019
{
	TLCOMMONCALL(vslinuxlseek(fd,offset,origin),rslinuxlseek(fd,offset,origin));
}

long TLgetpid(void)//v0==4020
{
	TLCOMMONCALL(vslinuxgetpid(),rslinuxgetpid());
}

long TLgetuid(void)//v0==4024
{
	TLCOMMONCALL(vslinuxgetuid( ),rslinuxgetuid( ));
}

long TLaccess(const char * filename, int mode)//v0==4033
{
	TLCOMMONCALL(vslinuxaccess(filename,mode),rslinuxaccess(filename,mode));
}

long TLrename(const char * oldname, const char * newname)//v0==4038
{
	TLCOMMONCALL(vslinuxrename(oldname,newname),
		rslinuxrename(oldname,newname));
}

long TLtimes(struct tms* tbuf)//v0==4043
{
	TLCOMMONCALL(vslinuxtimes(tbuf),rslinuxtimes(tbuf));
}

unsigned long TLbrk(unsigned long brk)//v0==4045
{
	TLCOMMONCALL_SYSCALL(sys_brk(brk));
}
long TLgetgid(void)//v0==4047
{
	TLCOMMONCALL(vslinuxgetgid( ),rslinuxgetgid( ));
}

long TLgeteuid(void)//v0==4049
{
	TLCOMMONCALL(vslinuxgeteuid( ),rslinuxgeteuid( ));
}

long TLgetegid(void)//v0==4050
{
	TLCOMMONCALL(vslinuxgetegid( ),rslinuxgetegid( ));
}

long TLioctl(unsigned int fd, unsigned int cmd, unsigned long arg)//v0==4054
{
	TLCOMMONCALL(vslinuxioctl(fd,cmd,arg),rslinuxioctl(fd,cmd,arg));
}

long TLfcntl(unsigned int fd, unsigned int cmd, unsigned long arg)//v0==4055
{
	TLCOMMONCALL(vslinuxfcntl(fd,cmd,arg),rslinuxfcntl(fd,cmd,arg));
}

long TLsetrlimit(unsigned int resource, struct rlimitformips*rlim)//v0==4075
{
	TLCOMMONCALL_SYSCALL(sys_setrlimit(resource,rlim));
}

long TLgetrlimit(unsigned int resource, struct rlimitformips *rlim)//v0==4076
{
	TLCOMMONCALL(vslinuxgetrlimit(resource,rlim),rslinuxgetrlimit(resource,rlim));
}

long TLgetrusage(int who, struct rusageformips*ru)//v0==4077
{
	TLCOMMONCALL(vslinuxgetrusage(who,ru),rslinuxgetrusage(who,ru));
}

unsigned long TLmmap(unsigned long addr, unsigned long len, unsigned long prot,
         unsigned long flags, unsigned long fd, unsigned long offset)//v0==4090
{
	TLCOMMONCALL_SYSCALL(sys_mmap(addr,len,prot,flags,fd,offset));
}

long TLmunmap(unsigned long addr, unsigned long len)//v0==4091
{
	TLCOMMONCALL_SYSCALL(sys_munmap(addr,len));
}

long TLftruncate(unsigned int fd, unsigned long length)//v0==4093
{
	TLCOMMONCALL(vslinuxftruncate(fd,length),rslinuxftruncate(fd,length));
}

long TLstat(char * filename, struct statformips* statbuf)//v0==4106
{
	TLCOMMONCALL(vslinuxstat(filename,statbuf),rslinuxstat(filename,statbuf));
}

long TLlstat(char * filename, struct statformips* statbuf)//v0==4107
{
	TLCOMMONCALL(vslinuxlstat(filename,statbuf),rslinuxlstat(filename,statbuf));
}

long TLfstat(unsigned int fd, struct statformips* statbuf)//v0==4108
{
	TLCOMMONCALL(vslinuxfstat(fd,statbuf),rslinuxfstat(fd,statbuf));
}

long TLnewuname(new_utsname_formips * name)//v0==4122
{	
	TLCOMMONCALL(vslinuxnewuname(name),rslinuxnewuname(name));
}

long TLmprotect(unsigned long start, size_t len, unsigned long prot)//v0==4125
{
	TLCOMMONCALL_SYSCALL(sys_mprotect(start,len,prot));
}

long TLllseek(unsigned int fd, unsigned long offset_high, 
	unsigned long offset_low, loff_t * result, unsigned int origin)//v0==4140
{
	TLCOMMONCALL(vslinuxllseek(fd,offset_high,offset_low,result,origin),
		rslinuxllseek(fd,offset_high,offset_low,result,origin));
}

long TLnewselect(int n, fd_set *inp, fd_set *outp, fd_set *exp, struct timeval *tvp)//v0==4142
{
	TLCOMMONCALL(vslinuxnewselect(n,inp,outp,exp,tvp),
		rslinuxselect(n,inp,outp,exp,tvp));
}

long TLnanosleep(struct timespecformips *rqtp, struct timespecformips *rmtp)//v0==4166
{
	TLCOMMONCALL_SYSCALL(sys_nanosleep(rqtp,rmtp));
}

long TLrt_sigaction(int sig, const struct sigactioninvalid *act, 
	struct sigactioninvalid *oact, long sigsetsize)//v0==4194
{
	TLCOMMONCALL_SYSCALL(sys_rt_sigaction(sig,act,oact,sigsetsize));
}

long TLrt_sigprocmask(int how, sigsetinvalid_t *set, sigsetinvalid_t *oset, 
	size_t sigsetsize)//v0==4195
{
	TLCOMMONCALL_SYSCALL(sys_rt_sigprocmask(how,set,oset,sigsetsize));
}

long TLmmap2(unsigned long addr, unsigned long len, unsigned long prot,
          unsigned long flags, unsigned long fd, unsigned long pgoff)//v0==4210
{
	TLCOMMONCALL_SYSCALL(sys_mmap2(addr,len,prot,flags,fd,pgoff));
}

long TLftruncate64(unsigned int fd, loff_t length)//v0==4212
{
	TLCOMMONCALL(vslinuxftruncate64(fd,length),rslinuxftruncate64(fd,length));
}

#define COMMONSTAT64(vsfunc,vsbuf,rsfunc)\
do{\
	long retval;\
	if(COMMONVIRTSERVFLAG){\
		if(!vsbuf){\
			serv_errno=virt_errno=ENOMEM;\
			retval=-1;\
			goto out;\
		}\
		retval=vsfunc;\
		serv_errno=virt_errno;\
		if(retval==-1) goto out;\
		CopyStat64Local(vsbuf,(long long *)VirtualServerBufBase);\
	}else{\
		retval=rsfunc;\
		serv_errno=rmt_errno;\
	}\
\
out:\
	return retval;\
}while(0)
#define COMMONSTAT64_NOREMOTE(vsfunc,vsbuf,rsmsg)\
do{\
	long retval;\
	if(COMMONVIRTSERVFLAG){\
		if(!vsbuf){\
			serv_errno=virt_errno=ENOMEM;\
			retval=-1;\
			goto out;\
		}\
		retval=vsfunc;\
		serv_errno=virt_errno;\
		if(retval==-1) goto out;\
		CopyStat64Local(vsbuf,(long long *)VirtualServerBufBase);\
	}else{\
		ioConsolePutString(rsmsg);\
	}\
\
out:\
	return retval;\
}while(0)
long TLstat64(char * filename, struct stat64formips * statbuf, long flags)//v0==4213
{
	COMMONSTAT64(vslinuxstat64(filename,statbuf,flags),statbuf,
		rslinuxstat64(filename,statbuf,flags));
}
long TLlstat64(char * filename, struct stat64formips * statbuf, long flags)//v0==4214
{
	COMMONSTAT64(vslinuxlstat64(filename,statbuf,flags),statbuf,
		rslinuxlstat64(filename,statbuf,flags));
}
long TLfstat64(unsigned long fd, struct stat64formips * statbuf, long flags)//v0==4215
{
	COMMONSTAT64(vslinuxfstat64(fd,statbuf,flags),statbuf,
		rslinuxfstat64(fd,statbuf,flags));
}

long TLfcntl64(long fd,long cmd,long arg)//v0==4220
{
	TLCOMMONCALL(vslinuxfcntl64(fd,cmd,arg),rslinuxfcntl64(fd,cmd,arg));
}

