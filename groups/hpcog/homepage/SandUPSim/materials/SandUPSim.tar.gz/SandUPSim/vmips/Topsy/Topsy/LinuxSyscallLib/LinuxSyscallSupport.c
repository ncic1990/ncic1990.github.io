#include "LibcLinuxTypes.h"
#include "SoftIOConsole.h"

//#define DEBUGLINUX

void CopyStat64Local(struct stat64formips* statlocalptr,long long * buf)
{
	if((statlocalptr==NULL)||(buf==NULL)){
		ioConsolePutString("test err:SyscallError:when copying fstat64!\n");
		return;
	}

	(unsigned long)statlocalptr->st_dev=(*(unsigned long*)(buf++));
	(unsigned long long)statlocalptr->st_ino=(*(unsigned long long*)(buf++));
	(unsigned int)statlocalptr->st_mode=(*(unsigned int*)(buf++));
	(int)statlocalptr->st_nlink=(*(int*)(buf++));
	(int)statlocalptr->st_uid=(*(int*)(buf++));
	(int)statlocalptr->st_gid=(*(int*)(buf++));
	(unsigned long)statlocalptr->st_rdev=(*(unsigned long*)(buf++));
	(long long)statlocalptr->st_size=(*(long long*)(buf++));
	(long)statlocalptr->st_accesstime=(*(long*)(buf++));
	(long)statlocalptr->st_modifytime=(*(long*)(buf++));
	(long)statlocalptr->st_createtime=(*(long*)(buf++));
	(unsigned long)statlocalptr->st_blksize=(*(unsigned long*)(buf++));
	(long long)statlocalptr->st_blocks=(*(long long*)(buf++));
	
	#ifdef DEBUGLINUX
	ioConsolePutString("local fstat64...\n");
	ioConsolePutHexInt(statlocalptr->st_dev);
	ioConsolePutHexInt(statlocalptr->st_ino);
	ioConsolePutHexInt(statlocalptr->st_mode);
	ioConsolePutHexInt(statlocalptr->st_nlink);
	ioConsolePutHexInt(statlocalptr->st_uid);
	ioConsolePutHexInt(statlocalptr->st_gid);
	ioConsolePutHexInt(statlocalptr->st_rdev);
	ioConsolePutHexInt(statlocalptr->st_size);
	ioConsolePutHexInt(statlocalptr->st_accesstime);
	ioConsolePutHexInt(statlocalptr->st_modifytime);
	ioConsolePutHexInt(statlocalptr->st_createtime);
	ioConsolePutHexInt(statlocalptr->st_blksize);
	ioConsolePutHexInt(statlocalptr->st_blocks);
	#endif
} 

