/*This is the Addr module of sand simulator, which is developed by
ASL group of NCIC;
Copyright 2003 by ASL NCIC */
#include "addr.h"
#include "cpu.h"
#include "mapper.h"
#include "cache.h"
#include "tlb.h"
#include "cpzero.h"
#include "accesstypes.h"
#include "excnames.h"
#include "memstat.h"
#include "memstatreg.h"
#include "config.h"
#include "error.h"
#include "vmips.h"

//#define DEBUGCACHE
void showdata(uint32 phys, uint32 data)
{
#ifdef DEBUGCACHE
	if( phys >= 0x400000 && phys <= 0x10000000)
		fprintf(stderr, "phys->0x%x, data ->0x%x\n", phys, data);
#endif
}
Addr::Addr()
{		

}
Addr::~Addr()
{	
}
/*
inline
bool
Addr::inmem(uint32 addr)
{
	if(addr >= 0 && addr <= memsize)
		return true;
	return false;
}
*/
/*slfsmm031207_add>for tlb short cut*/
#ifdef TLBSHORTCUT
inline
uint32
Addr::AddrTlbTransShortCut(uint32 vaddr, int mode, bool *cacheable)
{
	if((vaddr<USERVIRTBASE)||(vaddr>USERVIRTEND))
		return TLBSHORTCUTFAILED;
	
	char* local_pagetalbebase=mem->mem_localbase+PAGETABLEOFF;
	TLB_ENTRY_LO tlblow=((TLB_ENTRY_LO*)local_pagetalbebase)[vaddr>>PAGESHIFT];
	if(!tlblow.entrylo.v) return TLBSHORTCUTFAILED;
	if(!tlblow.entrylo.d && mode==DATASTORE) return TLBSHORTCUTFAILED;
	
	*cacheable = !tlblow.entrylo.n;
	return ((tlblow.entrylo.pfn) << PAGESHIFT) | (vaddr & ~EntryHi_VPN_MASK);
}
#endif
/*slfsmm031207_add<*/

uint32 swl(uint32 regval, uint32 memval, uint8 offset)
{
	if (TARGET_BIG_ENDIAN) {
		switch (offset) {
		case 0: return regval; 
		case 1: return (memval & 0xff000000) | (regval >> 8 & 0xffffff); 
		case 2: return (memval & 0xffff0000) | (regval >> 16 & 0xffff); 
		case 3: return (memval & 0xffffff00) | (regval >> 24 & 0xff); 
		}
	} else if (TARGET_LITTLE_ENDIAN) {
		switch (offset) {
		case 0: return (memval & 0xffffff00) | (regval >> 24 & 0xff); 
		case 1: return (memval & 0xffff0000) | (regval >> 16 & 0xffff); 
		case 2: return (memval & 0xff000000) | (regval >> 8 & 0xffffff); 
		case 3: return regval; 
		}
	}
	fatal_error("Invalid offset %x passed to swl\n", offset);
}

uint32 swr(uint32 regval, uint32 memval, uint8 offset)
{
	if (TARGET_BIG_ENDIAN) {
		switch (offset) {
		case 0: return ((regval << 24) & 0xff000000) | (memval & 0xffffff); 
		case 1: return ((regval << 16) & 0xffff0000) | (memval & 0xffff); 
		case 2: return ((regval << 8) & 0xffffff00) | (memval & 0xff); 
		case 3: return regval; 
		}
	} else if (TARGET_LITTLE_ENDIAN) {
		switch (offset) {
		case 0: return regval; 
		case 1: return ((regval << 8) & 0xffffff00) | (memval & 0xff); 
		case 2: return ((regval << 16) & 0xffff0000) | (memval & 0xffff); 
		case 3: return ((regval << 24) & 0xff000000) | (memval & 0xffffff); 
		}
	}
	fatal_error("Invalid offset %x passed to swr\n", offset);
}
uint32 lwr(uint32 regval, uint32 memval, uint8 offset)
{
	if (TARGET_BIG_ENDIAN) {
		switch (offset)
		{
		case 0: return (regval & 0xffffff00) |
					((unsigned)(memval & 0xff000000) >> 24);
		case 1: return (regval & 0xffff0000) |
					((unsigned)(memval & 0xffff0000) >> 16);
		case 2: return (regval & 0xff000000) |
					((unsigned)(memval & 0xffffff00) >> 8);
		case 3: return memval;
		}
	} else if (TARGET_LITTLE_ENDIAN) {
		switch (offset)
		{
		/* The SPIM source claims that "The description of the
		* little-endian case in Kane is totally wrong." The fact
		* that I ripped off the LWR algorithm from them could be
		* viewed as a sort of passive assumption that their claim
		* is correct.
			*/
		case 0: /* 3 in book */
			return memval;
		case 1: /* 0 in book */
			return (regval & 0xff000000) | ((memval & 0xffffff00) >> 8);
		case 2: /* 1 in book */
			return (regval & 0xffff0000) | ((memval & 0xffff0000) >> 16);
		case 3: /* 2 in book */
			return (regval & 0xffffff00) | ((memval & 0xff000000) >> 24);
		}
	}
	fatal_error("Invalid offset %x passed to lwr\n", offset);
}

uint32 lwl(uint32 regval, uint32 memval, uint8 offset)
{
	if (TARGET_BIG_ENDIAN) {
		switch (offset)
		{
		case 0: return memval;
		case 1: return (memval & 0xffffff) << 8 | (regval & 0xff);
		case 2: return (memval & 0xffff) << 16 | (regval & 0xffff);
		case 3: return (memval & 0xff) << 24 | (regval & 0xffffff);
		}
	} else if (TARGET_LITTLE_ENDIAN) {
		switch (offset)
		{
		case 0: return (memval & 0xff) << 24 | (regval & 0xffffff);
		case 1: return (memval & 0xffff) << 16 | (regval & 0xffff);
		case 2: return (memval & 0xffffff) << 8 | (regval & 0xff);
		case 3: return memval;
		}
	}
	fatal_error("Invalid offset %x passed to lwl\n", offset);
}
void 
Addr::attach(CPU* p, Mapper* m, CACHE *c, Memstat* ms, ClkMem *cm)
{
	cpu = p;
	mem = m;
	if(cpu ->opt_cacheable)
		cache = c;
	memstat = ms;
	clkmem = cm;
	memsize = clkmem ->getmemsize();
	/*slfsmm031207_add>for tlb short cut*/
	#ifdef TLBSHORTCUT
	opt_tlbshortcut=cpu->machine->opt->option("tlbshortcut")->flag;
	#endif
	/*slfsmm031207_add<*/

}


void 
Addr::fetch_instr(uint32 vaddr, uint32* data, uint8 * delay_time)
{	
	*data = 0xffffffffUL;
	if (vaddr % 4 != 0) 
	{
		cpu -> exception(AdES,INSTFETCH);
		return;
	}
	
	/* Translate virtual address to physical address. */
	/*slfsmm031207_add>for tlb short cut*/
	#ifdef TLBSHORTCUT
	if(opt_tlbshortcut){
		phys=AddrTlbTransShortCut(vaddr, INSTFETCH, &cacheable);
		if(phys==TLBSHORTCUTFAILED)
			phys = cpu ->cpzero->address_trans(vaddr, INSTFETCH, &cacheable, cpu);
	}else
	#endif
	/*slfsmm031207_add<*/
		phys = cpu ->cpzero->address_trans(vaddr, INSTFETCH, &cacheable, cpu);
	memstat ->SetStatBool(CacheableMask,cacheable);
	memstat ->SetStatBool(PBufHitMask, true);
	memstat ->SetStatBool(ReadOrWrite, true);
	memstat ->SetStatBool(InstOrData, true);
	memstat ->SetAddr(phys);	

	if (phys == 0xffffffffUL && cpu ->exception_pending) 
	{
		if (cpu ->opt_excmsg) 
			fprintf(stderr,
			"** PC address translation caused the exception! **\n");
		
		return;
	}
	/* Store word. */
	if(cacheable && cpu ->opt_cacheable)
	{
		cache ->read(phys, INSTFETCH, data, delay_time);
		memstat ->SetHitTime(*delay_time);
		showdata(phys, *data);	
		return;
	}
	if(clkmem ->getdramstart() && inmem(phys))
	{
		clkmem ->fetchword(phys, data, delay_time);
		memstat ->SetHitTime(*delay_time);
		showdata(phys, *data);
		return;
	}
	*data = mem->fetch_word(phys, INSTFETCH, cacheable, cpu);	
	showdata(phys, *data);
	*delay_time = 0;
	memstat ->SetHitTime(*delay_time);	
}

void
Addr::fetch_word(uint32 vaddr, uint32* data, uint8* delay_time)
{
	*data = 0xffffffffUL;
	if (vaddr % 4 != 0) 
	{
		cpu -> exception(AdEL,DATALOAD);
		return;
	}
	
	/* Translate virtual address to physical address. */
	/*slfsmm031207_add>for tlb short cut*/
	#ifdef TLBSHORTCUT
	if(opt_tlbshortcut){
		phys=AddrTlbTransShortCut(vaddr, DATALOAD, &cacheable);
		if(phys==TLBSHORTCUTFAILED)
			phys = cpu ->cpzero->address_trans(vaddr, DATALOAD, &cacheable, cpu);
	}else
	#endif
	/*slfsmm031207_add<*/
		phys = cpu ->cpzero->address_trans(vaddr, DATALOAD, &cacheable, cpu);	
	memstat ->SetStatBool(CacheableMask,cacheable);
	memstat ->SetAddr(phys);
	memstat ->SetStatBool(PBufHitMask, true);
	memstat ->SetStatBool(ReadOrWrite, true);
	memstat ->SetStatBool(InstOrData, false);

	//	stat_info.data_addr = phys;
	if (phys == 0xffffffff && cpu ->exception_pending) return;
	
	/* Fetch word. */
	if(cacheable && cpu ->opt_cacheable)
	{
		cache ->read(phys, DATALOAD, data, delay_time);
		memstat ->SetHitTime(*delay_time);
		showdata(phys, *data);	
		return;
	}
	if(clkmem ->getdramstart() && inmem(phys))
	{
		clkmem ->fetchword(phys, data, delay_time);
		memstat ->SetHitTime(*delay_time);
		showdata(phys, *data);
		return;
	}
	*data = mem->fetch_word(phys, DATALOAD, cacheable, cpu);
	showdata(phys, *data);
	*delay_time = 0;
	memstat ->SetHitTime(*delay_time);
}
void
Addr::fetch_wordl(uint32 vaddr, uint32 regdata,uint32 * data, uint8 * delay_time)
{
	uint32 memword;
	uint8  which_byte;
	
	*data = 0xffffffffUL;
	/*slfsmm031027_add_bug>*/
	which_byte=vaddr & 0x03UL;
	vaddr=vaddr&~0x03UL;
	/*slfsmm031027_add_bug>*/
	/*slfsmm031027_del_bug>*/
	/*
	if (vaddr % 4 != 0) 
	{
	cpu -> exception(AdEL,DATALOAD);
	return;
	}
	*/
	/*slfsmm031027_del_bug<*/
	
	/* Translate virtual address to physical address. */
	/*slfsmm031207_add>for tlb short cut*/
	#ifdef TLBSHORTCUT
	if(opt_tlbshortcut){
		phys=AddrTlbTransShortCut(vaddr, DATALOAD, &cacheable);
		if(phys==TLBSHORTCUTFAILED)
			phys = cpu ->cpzero->address_trans(vaddr, DATALOAD, &cacheable, cpu);
	}else
	#endif
	/*slfsmm031207_add<*/
		phys = cpu ->cpzero->address_trans(vaddr, DATALOAD, &cacheable, cpu);
	memstat ->SetStatBool(CacheableMask,cacheable);
	memstat ->SetAddr(phys);
	memstat ->SetStatBool(PBufHitMask, true);
	memstat ->SetStatBool(ReadOrWrite, true);
	memstat ->SetStatBool(InstOrData, false);

	//	stat_info.data_addr = phys;
	if (phys == 0xffffffff && cpu ->exception_pending) return;
	
	/* Fetch word. */
	if(cacheable && cpu ->opt_cacheable)	
	{
		cache ->read(phys, DATALOAD, &memword, delay_time);
		memstat ->SetHitTime(*delay_time);
		showdata(phys, memword);
	}
	else
	{
		if(clkmem ->getdramstart() && inmem(phys))
		{
			clkmem ->fetchword(phys, &memword, delay_time);
			memstat ->SetHitTime(*delay_time);
			showdata(phys, memword);
		}
		else
		{
			memword = mem->fetch_word(phys, DATALOAD, cacheable, cpu);
			showdata(phys, memword);
			*delay_time = 0;
			memstat ->SetHitTime(*delay_time);
		}
	}
	if (memword == 0xffffffff && cpu ->exception_pending) return;
	
	/* Insert bytes into the left side of the register. */
	/*slfsmm031027_del_bug>*/
	//which_byte = vaddr & 0x03;
	/*slfsmm031027_del_bug<*/
	*data = lwl(regdata, memword, which_byte);
}
void 
Addr::fetch_wordr(uint32 vaddr, uint32 regdata,uint32 * data, uint8 * delay_time)
{
	uint32 memword;
	uint8 which_byte;
	
	*data = 0xffffffffUL;
	/*slfsmm031027_add_bug>*/
	which_byte=vaddr & 0x03UL;
	vaddr=vaddr&~0x03UL;
	//printf("fetch_wordr:vaddr->0x%x, whitch->0x%x\n",vaddr,which_byte);
	/*slfsmm031027_add_bug>*/
	/*slfsmm031027_del_bug>*/
	/*
	if (vaddr % 4 != 0) 
	{
	cpu -> exception(AdEL,DATALOAD);
	return;
	}
	*/
	/*slfsmm031027_del_bug<*/
	
	/* Translate virtual address to physical address. */
	/*slfsmm031207_add>for tlb short cut*/
	#ifdef TLBSHORTCUT
	if(opt_tlbshortcut){
		phys=AddrTlbTransShortCut(vaddr, DATALOAD, &cacheable);
		if(phys==TLBSHORTCUTFAILED)
			phys = cpu ->cpzero->address_trans(vaddr, DATALOAD, &cacheable, cpu);
	}else
	#endif
	/*slfsmm031207_add<*/
		phys = cpu ->cpzero->address_trans(vaddr, DATALOAD, &cacheable, cpu);
	memstat ->SetStatBool(CacheableMask,cacheable);
	memstat ->SetAddr(phys);
	memstat ->SetStatBool(PBufHitMask, true);
	memstat ->SetStatBool(ReadOrWrite, true);
	memstat ->SetStatBool(InstOrData, false);

	//	stat_info.data_addr = phys;
	if (phys == 0xffffffff && cpu ->exception_pending) return;
	
	/* Fetch word. */
	if(cacheable && cpu ->opt_cacheable)	
	{
		cache ->read(phys, DATALOAD, &memword, delay_time);
		memstat ->SetHitTime(*delay_time);
		showdata(phys, memword);
	}
	else
	{
		if(clkmem ->getdramstart() && inmem(phys))
		{
			clkmem ->fetchword(phys, &memword, delay_time);
			memstat ->SetHitTime(*delay_time);
			showdata(phys, memword);		
		}
		else
		{
			memword = mem->fetch_word(phys, DATALOAD, cacheable, cpu);
			memstat ->SetHitTime(*delay_time);
			showdata(phys, memword);
			*delay_time = 0;
		}
	}
	if (memword == 0xffffffff && cpu ->exception_pending) return;
	
	/* Insert bytes into the left side of the register. */
	/*slfsmm031027_del_bug>*/
	//which_byte = vaddr & 0x03;
	/*slfsmm031027_del_bug<*/
	*data = lwr(regdata, memword, which_byte);	
}
void
Addr::fetch_half_word(uint32 vaddr, uint16* data, uint8* delay_time)
{
	*data = 0xffffU;
	if (vaddr % 2 != 0) 
	{
		cpu ->exception(AdEL,DATALOAD);
		return;
	}
	
	/* Translate virtual address to physical address. */
	/*slfsmm031207_add>for tlb short cut*/
	#ifdef TLBSHORTCUT
	if(opt_tlbshortcut){
		phys=AddrTlbTransShortCut(vaddr, DATALOAD, &cacheable);
		if(phys==TLBSHORTCUTFAILED)
			phys =cpu ->cpzero->address_trans(vaddr, DATALOAD, &cacheable, cpu);
	}else
	#endif
	/*slfsmm031207_add<*/
		phys =cpu ->cpzero->address_trans(vaddr, DATALOAD, &cacheable, cpu);
	memstat ->SetStatBool(CacheableMask,cacheable);
	memstat ->SetAddr(phys);
	memstat ->SetStatBool(PBufHitMask, true);
	memstat ->SetStatBool(ReadOrWrite, true);
	memstat ->SetStatBool(InstOrData, false);

	if (phys == 0xffffffffUL && cpu ->exception_pending) return;
	
	/* Fetch halfword.
	* Because it is assigned to a signed variable (int32 halfword)
	* it will be sign-extended.
	*/
	if(cacheable && cpu ->opt_cacheable)
	{
		uint32 readdata,tmpaddr;
		uint16 *halfword;
		tmpaddr = phys & 0xfffffffcUL;
		cache ->read(tmpaddr, DATALOAD, &readdata, delay_time);	
		halfword = (uint16*)(&readdata);
		//*data = *( halfword + (phys% 4));
	        *data = *( halfword + ((phys% 4) >> 1));
		memstat ->SetHitTime(*delay_time);
		showdata(phys, *data);		
		return;
	}
	if(clkmem ->getdramstart() && inmem(phys))
	{
		clkmem ->fetchhword(phys, data, delay_time);
		memstat ->SetHitTime(*delay_time);
		showdata(phys, *data);
		return;
	}
	*data =mem->fetch_halfword(phys, cacheable, cpu);
	showdata(phys, *data);
	*delay_time = 0;
	memstat ->SetHitTime(*delay_time);
}
void 
Addr::fetch_byte(uint32 vaddr, uint8* data, uint8* delay_time)
{
	*data = 0xffU;
	/*slfsmm031207_add>for tlb short cut*/
	#ifdef TLBSHORTCUT
	if(opt_tlbshortcut){
		phys=AddrTlbTransShortCut(vaddr, DATALOAD, &cacheable);
		if(phys==TLBSHORTCUTFAILED)
			phys = cpu ->cpzero->address_trans(vaddr, DATALOAD, &cacheable, cpu);
	}else
	#endif
	/*slfsmm031207_add<*/
		phys = cpu ->cpzero->address_trans(vaddr, DATALOAD, &cacheable, cpu);
	memstat ->SetStatBool(CacheableMask,cacheable);
	memstat ->SetAddr(phys);
	memstat ->SetStatBool(PBufHitMask, true);
	memstat ->SetStatBool(ReadOrWrite, true);
	memstat ->SetStatBool(InstOrData, false);

	if (phys == 0xffffffffUL && cpu ->exception_pending) return;
	
	/* Fetch byte.
	* Because it is assigned to a signed variable (int32 byte)
	* it will be sign-extended.
	*/
	if(cacheable && cpu ->opt_cacheable)
	{
		uint32 readdata, tmpaddr;
		uint8 *byte;
		tmpaddr = phys & 0xfffffffcUL;
		cache ->read(tmpaddr, DATALOAD, &readdata, delay_time);	
		byte = (uint8*)(&readdata);
		*data = *( byte + phys % 4);
		memstat ->SetHitTime(*delay_time);
		showdata(phys, *data);		
		return;
	}
	if(clkmem ->getdramstart() && inmem(phys))
	{
		clkmem ->fetchbyte(phys, data, delay_time);
		memstat ->SetHitTime(*delay_time);
		showdata(phys, *data);
		return;
	}
	*data = mem->fetch_byte(phys, cacheable, cpu);
	showdata(phys, *data);
	*delay_time = 0;
	memstat ->SetHitTime(*delay_time);
}
void
Addr::store_word(uint32 vaddr, uint32 data, uint8* delay_time)
{
	if (vaddr % 4 != 0)
	{
		cpu ->exception(AdES,DATASTORE);
		return;
	}
	
	/* Translate virtual address to physical address. */
	/*slfsmm031207_add>for tlb short cut*/
	#ifdef TLBSHORTCUT
	if(opt_tlbshortcut){
		phys=AddrTlbTransShortCut(vaddr, DATALOAD, &cacheable);
		if(phys==TLBSHORTCUTFAILED)
			phys = cpu ->cpzero->address_trans(vaddr, DATASTORE, &cacheable, cpu);
	}else
	#endif
	/*slfsmm031207_add<*/
		phys = cpu ->cpzero->address_trans(vaddr, DATASTORE, &cacheable, cpu);
	memstat ->SetStatBool(CacheableMask,cacheable);
	memstat ->SetAddr(phys);
	memstat ->SetStatBool(PBufHitMask, true);
	memstat ->SetStatBool(ReadOrWrite, false);
	memstat ->SetStatBool(InstOrData, false);
	if (phys == 0xffffffffUL && cpu ->exception_pending) return;
	
	/* Store word. */
	if(cacheable && cpu ->opt_cacheable)
	{
		cache ->write(phys, DATASTORE, data, delay_time);		
		memstat ->SetHitTime(*delay_time);
		return;
	}
	if(clkmem ->getdramstart() && inmem(phys))
	{
		clkmem ->storeword(phys, data, delay_time);	
		memstat ->SetHitTime(*delay_time);
		return;
	}
	mem->store_word(phys, data, cacheable, cpu);
	*delay_time = 0;
	memstat ->SetHitTime(*delay_time);
}
void 
Addr::store_wordl(uint32 vaddr, uint32 regdata, uint8 * delay_time)
{
	uint32 wordvirt,memdata;
	uint8 which_byte;
	uint8 delaytime1, delaytime2;
	wordvirt = vaddr & ~0x03UL;
	
	/* Translate virtual address to physical address. */
	/*slfsmm031207_add>for tlb short cut*/
	#ifdef TLBSHORTCUT
	if(opt_tlbshortcut){
		phys=AddrTlbTransShortCut(wordvirt, DATASTORE, &cacheable);
		if(phys==TLBSHORTCUTFAILED)
			phys = cpu ->cpzero->address_trans(wordvirt, DATASTORE, &cacheable, cpu);
	}else
	#endif
	/*slfsmm031207_add<*/
		phys = cpu ->cpzero->address_trans(wordvirt, DATASTORE, &cacheable, cpu);
	if (phys == 0xffffffffUL && cpu ->exception_pending) return;
	memstat ->SetStatBool(CacheableMask,cacheable);
	memstat ->SetAddr(phys);
	memstat ->SetStatBool(PBufHitMask, true);
	memstat ->SetStatBool(ReadOrWrite, false);
	memstat ->SetStatBool(InstOrData, false);
	/* Read data from memory. */
	
	if (wordvirt == 0xffffffffUL && cpu ->exception_pending) return;
	
	/* Write back the left side of the register. */
	which_byte = vaddr & 0x03UL;
	if(cacheable && cpu ->opt_cacheable)
	{
		cache ->read(phys, DATASTORE, &memdata, &delaytime1);
		cache ->write(phys, DATASTORE, swl(regdata, memdata, which_byte), &delaytime2);
		*delay_time = delaytime1 + delaytime2;
		memstat ->SetHitTime(*delay_time);
		return;
	}
	if(clkmem ->getdramstart() && inmem(phys))
	{
		clkmem ->fetchword(phys, &memdata, &delaytime1);
		clkmem ->storeword(phys, swl(regdata, memdata, which_byte), &delaytime2);	
		*delay_time = delaytime1 + delaytime2;
		memstat ->SetHitTime(*delay_time);
		return;
	}
	memdata = mem->fetch_word(phys, DATASTORE, cacheable, cpu);
	mem->store_word(phys, swl(regdata, memdata, which_byte), cacheable, cpu);
	*delay_time = 0;
	memstat ->SetHitTime(*delay_time);
}
void 
Addr::store_wordr(uint32 vaddr, uint32 regdata,  uint8 * delay_time)
{
	uint32 wordvirt,memdata;
	uint8 which_byte;	
	uint8 delaytime1, delaytime2;
	wordvirt = vaddr & ~0x03UL;
	
	/* Translate virtual address to physical address. */
	/*slfsmm031207_add>for tlb short cut*/
	#ifdef TLBSHORTCUT
	if(opt_tlbshortcut){
		phys=AddrTlbTransShortCut(wordvirt, DATASTORE, &cacheable);
		if(phys==TLBSHORTCUTFAILED)
			phys = cpu ->cpzero->address_trans(wordvirt, DATASTORE, &cacheable, cpu);
	}else
	#endif
	/*slfsmm031207_add<*/
		phys = cpu ->cpzero->address_trans(wordvirt, DATASTORE, &cacheable, cpu);
	if (phys == 0xffffffffUL && cpu ->exception_pending) return;
	memstat ->SetStatBool(CacheableMask,cacheable);
	memstat ->SetAddr(phys);
	memstat ->SetStatBool(PBufHitMask, true);
	memstat ->SetStatBool(ReadOrWrite, false);
	memstat ->SetStatBool(InstOrData, false);
	if (wordvirt == 0xffffffffUL && cpu ->exception_pending) return;
	which_byte = vaddr & 0x03UL;
	/* Read data */
	
	if(cacheable && cpu ->opt_cacheable)
	{
		cache ->read(phys, DATASTORE, &memdata, &delaytime1);
		cache ->write(phys, DATASTORE, swr(regdata, memdata, which_byte), &delaytime2);
		*delay_time = delaytime1 + delaytime2;
		memstat ->SetHitTime(*delay_time);
		return;
	}
	if(clkmem ->getdramstart() && inmem(phys))
	{
		clkmem ->fetchword(phys, &memdata, &delaytime1);
		clkmem ->storeword(phys, swr(regdata, memdata, which_byte), &delaytime2);
		*delay_time = delaytime1 + delaytime2;
		memstat ->SetHitTime(*delay_time);
		return;
	}
	memdata = mem->fetch_word(phys, DATASTORE, cacheable, cpu);
	mem->store_word(phys, swr(regdata, memdata, which_byte), cacheable, cpu);
	*delay_time = 0;
	memstat ->SetHitTime(*delay_time);
}
void 
Addr::store_half_word(uint32 vaddr, uint16 data, uint8* delay_time)
{
	uint8 delaytime1, delaytime2;
	if (vaddr % 2 != 0)
	{
		cpu ->exception(AdES,DATASTORE);
		return;
	}
	
	/* Translate virtual address to physical address. */
	/*slfsmm031207_add>for tlb short cut*/
	#ifdef TLBSHORTCUT
	if(opt_tlbshortcut){
		phys=AddrTlbTransShortCut(vaddr, DATASTORE, &cacheable);
		if(phys==TLBSHORTCUTFAILED)
			phys = cpu ->cpzero->address_trans(vaddr, DATASTORE, &cacheable, cpu);
	}else
	#endif
	/*slfsmm031207_add<*/
		phys = cpu ->cpzero->address_trans(vaddr, DATASTORE, &cacheable, cpu);
	memstat ->SetStatBool(CacheableMask,cacheable);
	memstat ->SetAddr(phys);
	memstat ->SetStatBool(PBufHitMask, true);
	memstat ->SetStatBool(ReadOrWrite, false);
	memstat ->SetStatBool(InstOrData, false);
	if (phys == 0xffffffffUL && cpu ->exception_pending) return;
	
	/* Store word. */
	if(cacheable && cpu ->opt_cacheable)
	{
		uint32 read_data,tmpaddr;
		uint16 *halfword;
		tmpaddr = phys & 0xfffffffcUL;
		cache ->read(tmpaddr, DATALOAD, &read_data, &delaytime1);
		halfword = (uint16*)(&read_data);
		*( halfword + ((phys % 4)>>1)) =data ;
		cache ->write( phys, DATASTORE, read_data, &delaytime2);
		*delay_time = delaytime1 + delaytime2;
		memstat ->SetHitTime(*delay_time);
		return;
	}
	if(clkmem ->getdramstart() && inmem(phys))
	{		
		clkmem ->storehword(phys, data, delay_time);	
		memstat ->SetHitTime(*delay_time);
		return;
	}
	mem->store_halfword(phys, data, cacheable, cpu);
	*delay_time = 0;
	memstat ->SetHitTime(*delay_time);
	
}
void
Addr::store_byte(uint32 vaddr, uint8 data, uint8* delay_time)
{
	uint8 delaytime1, delaytime2;
	/*slfsmm031207_add>for tlb short cut*/
	#ifdef TLBSHORTCUT
	if(opt_tlbshortcut){
		phys=AddrTlbTransShortCut(vaddr, DATASTORE, &cacheable);
		if(phys==TLBSHORTCUTFAILED)
			phys = cpu ->cpzero->address_trans(vaddr, DATASTORE, &cacheable, cpu);
	}else
	#endif
	/*slfsmm031207_add<*/
		phys = cpu ->cpzero->address_trans(vaddr, DATASTORE, &cacheable, cpu);
	memstat ->SetStatBool(CacheableMask,cacheable);
	memstat ->SetAddr(phys);
	memstat ->SetStatBool(PBufHitMask, true);
	memstat ->SetStatBool(ReadOrWrite, false);
	memstat ->SetStatBool(InstOrData, false);
	if (phys == 0xffffffffUL && cpu ->exception_pending) return;
	
	/* Store byte. */
	if(cacheable && cpu ->opt_cacheable)
	{
		uint32 read_data,tmpaddr;
		uint8 *byte;
		tmpaddr = phys & 0xfffffffcUL;
		cache ->read(tmpaddr, DATALOAD, &read_data, &delaytime1);
		byte = (uint8*)(&read_data);
		*( byte + phys % 4) =data ;
		cache ->write( phys, DATASTORE, read_data, &delaytime2);
		*delay_time = delaytime1 + delaytime2;
		memstat ->SetHitTime(*delay_time);
		return;
	}
	if(clkmem ->getdramstart() && inmem(phys))
	{		
		clkmem ->storebyte(phys, data, delay_time);	
		memstat ->SetHitTime(*delay_time);
		return;
	}
	
	mem->store_byte(phys, data, cacheable, cpu);
	*delay_time = 0;
	memstat ->SetHitTime(*delay_time);
}

