#ifndef LINUXSYSCALLUNISTD_H
#define LINUXSYSCALLUNISTD_H

#ifndef _ASM_UNISTD_H
#define _ASM_UNISTD_H

#define __NR_sys_Linux			4000
#define __NR_sys_syscall			(__NR_sys_Linux +   0)
#define __NR_sys_exit			(__NR_sys_Linux +   1)
#define __NR_sys_fork			(__NR_sys_Linux +   2)
#define __NR_sys_read			(__NR_sys_Linux +   3)
#define __NR_sys_write			(__NR_sys_Linux +   4)
#define __NR_sys_open			(__NR_sys_Linux +   5)
#define __NR_sys_close			(__NR_sys_Linux +   6)
#define __NR_sys_waitpid			(__NR_sys_Linux +   7)
#define __NR_sys_creat			(__NR_sys_Linux +   8)
#define __NR_sys_link			(__NR_sys_Linux +   9)
#define __NR_sys_unlink			(__NR_sys_Linux +  10)
#define __NR_sys_execve			(__NR_sys_Linux +  11)
#define __NR_sys_chdir			(__NR_sys_Linux +  12)
#define __NR_sys_time			(__NR_sys_Linux +  13)
#define __NR_sys_mknod			(__NR_sys_Linux +  14)
#define __NR_sys_chmod			(__NR_sys_Linux +  15)
#define __NR_sys_lchown			(__NR_sys_Linux +  16)
#define __NR_sys_break			(__NR_sys_Linux +  17)
#define __NR_sys_oldstat			(__NR_sys_Linux +  18)
#define __NR_sys_lseek			(__NR_sys_Linux +  19)
#define __NR_sys_getpid			(__NR_sys_Linux +  20)
#define __NR_sys_mount			(__NR_sys_Linux +  21)
#define __NR_sys_umount			(__NR_sys_Linux +  22)
#define __NR_sys_setuid			(__NR_sys_Linux +  23)
#define __NR_sys_getuid			(__NR_sys_Linux +  24)
#define __NR_sys_stime			(__NR_sys_Linux +  25)
#define __NR_sys_ptrace			(__NR_sys_Linux +  26)
#define __NR_sys_alarm			(__NR_sys_Linux +  27)
#define __NR_sys_oldfstat			(__NR_sys_Linux +  28)
#define __NR_sys_pause			(__NR_sys_Linux +  29)
#define __NR_sys_utime			(__NR_sys_Linux +  30)
#define __NR_sys_stty			(__NR_sys_Linux +  31)
#define __NR_sys_gtty			(__NR_sys_Linux +  32)
#define __NR_sys_access			(__NR_sys_Linux +  33)
#define __NR_sys_nice			(__NR_sys_Linux +  34)
#define __NR_sys_ftime			(__NR_sys_Linux +  35)
#define __NR_sys_sync			(__NR_sys_Linux +  36)
#define __NR_sys_kill			(__NR_sys_Linux +  37)
#define __NR_sys_rename			(__NR_sys_Linux +  38)
#define __NR_sys_mkdir			(__NR_sys_Linux +  39)
#define __NR_sys_rmdir			(__NR_sys_Linux +  40)
#define __NR_sys_dup			(__NR_sys_Linux +  41)
#define __NR_sys_pipe			(__NR_sys_Linux +  42)
#define __NR_sys_times			(__NR_sys_Linux +  43)
#define __NR_sys_prof			(__NR_sys_Linux +  44)
#define __NR_sys_brk			(__NR_sys_Linux +  45)
#define __NR_sys_setgid			(__NR_sys_Linux +  46)
#define __NR_sys_getgid			(__NR_sys_Linux +  47)
#define __NR_sys_signal			(__NR_sys_Linux +  48)
#define __NR_sys_geteuid			(__NR_sys_Linux +  49)
#define __NR_sys_getegid			(__NR_sys_Linux +  50)
#define __NR_sys_acct			(__NR_sys_Linux +  51)
#define __NR_sys_umount2			(__NR_sys_Linux +  52)
#define __NR_sys_lock			(__NR_sys_Linux +  53)
#define __NR_sys_ioctl			(__NR_sys_Linux +  54)
#define __NR_sys_fcntl			(__NR_sys_Linux +  55)
#define __NR_sys_mpx			(__NR_sys_Linux +  56)
#define __NR_sys_setpgid			(__NR_sys_Linux +  57)
#define __NR_sys_ulimit			(__NR_sys_Linux +  58)
#define __NR_sys_unused59			(__NR_sys_Linux +  59)
#define __NR_sys_umask			(__NR_sys_Linux +  60)
#define __NR_sys_chroot			(__NR_sys_Linux +  61)
#define __NR_sys_ustat			(__NR_sys_Linux +  62)
#define __NR_sys_dup2			(__NR_sys_Linux +  63)
#define __NR_sys_getppid			(__NR_sys_Linux +  64)
#define __NR_sys_getpgrp			(__NR_sys_Linux +  65)
#define __NR_sys_setsid			(__NR_sys_Linux +  66)
#define __NR_sys_sigaction			(__NR_sys_Linux +  67)
#define __NR_sys_sgetmask			(__NR_sys_Linux +  68)
#define __NR_sys_ssetmask			(__NR_sys_Linux +  69)
#define __NR_sys_setreuid			(__NR_sys_Linux +  70)
#define __NR_sys_setregid			(__NR_sys_Linux +  71)
#define __NR_sys_sigsuspend			(__NR_sys_Linux +  72)
#define __NR_sys_sigpending			(__NR_sys_Linux +  73)
#define __NR_sys_sethostname		(__NR_sys_Linux +  74)
#define __NR_sys_setrlimit			(__NR_sys_Linux +  75)
#define __NR_sys_getrlimit			(__NR_sys_Linux +  76)
#define __NR_sys_getrusage			(__NR_sys_Linux +  77)
#define __NR_sys_gettimeofday		(__NR_sys_Linux +  78)
#define __NR_sys_settimeofday		(__NR_sys_Linux +  79)
#define __NR_sys_getgroups			(__NR_sys_Linux +  80)
#define __NR_sys_setgroups			(__NR_sys_Linux +  81)
#define __NR_sys_reserved82			(__NR_sys_Linux +  82)
#define __NR_sys_symlink			(__NR_sys_Linux +  83)
#define __NR_sys_oldlstat			(__NR_sys_Linux +  84)
#define __NR_sys_readlink			(__NR_sys_Linux +  85)
#define __NR_sys_uselib			(__NR_sys_Linux +  86)
#define __NR_sys_swapon			(__NR_sys_Linux +  87)
#define __NR_sys_reboot			(__NR_sys_Linux +  88)
#define __NR_sys_readdir			(__NR_sys_Linux +  89)
#define __NR_sys_mmap			(__NR_sys_Linux +  90)
#define __NR_sys_munmap			(__NR_sys_Linux +  91)
#define __NR_sys_truncate			(__NR_sys_Linux +  92)
#define __NR_sys_ftruncate			(__NR_sys_Linux +  93)
#define __NR_sys_fchmod			(__NR_sys_Linux +  94)
#define __NR_sys_fchown			(__NR_sys_Linux +  95)
#define __NR_sys_getpriority		(__NR_sys_Linux +  96)
#define __NR_sys_setpriority		(__NR_sys_Linux +  97)
#define __NR_sys_profil			(__NR_sys_Linux +  98)
#define __NR_sys_statfs			(__NR_sys_Linux +  99)
#define __NR_sys_fstatfs			(__NR_sys_Linux + 100)
#define __NR_sys_ioperm			(__NR_sys_Linux + 101)
#define __NR_sys_socketcall			(__NR_sys_Linux + 102)
#define __NR_sys_syslog			(__NR_sys_Linux + 103)
#define __NR_sys_setitimer			(__NR_sys_Linux + 104)
#define __NR_sys_getitimer			(__NR_sys_Linux + 105)
#define __NR_sys_stat			(__NR_sys_Linux + 106)
#define __NR_sys_lstat			(__NR_sys_Linux + 107)
#define __NR_sys_fstat			(__NR_sys_Linux + 108)
#define __NR_sys_unused109			(__NR_sys_Linux + 109)
#define __NR_sys_iopl			(__NR_sys_Linux + 110)
#define __NR_sys_vhangup			(__NR_sys_Linux + 111)
#define __NR_sys_idle			(__NR_sys_Linux + 112)
#define __NR_sys_vm86			(__NR_sys_Linux + 113)
#define __NR_sys_wait4			(__NR_sys_Linux + 114)
#define __NR_sys_swapoff			(__NR_sys_Linux + 115)
#define __NR_sys_sysinfo			(__NR_sys_Linux + 116)
#define __NR_sys_ipc			(__NR_sys_Linux + 117)
#define __NR_sys_fsync			(__NR_sys_Linux + 118)
#define __NR_sys_sigreturn			(__NR_sys_Linux + 119)
#define __NR_sys_clone			(__NR_sys_Linux + 120)
#define __NR_sys_setdomainname		(__NR_sys_Linux + 121)
#define __NR_sys_uname			(__NR_sys_Linux + 122)
#define __NR_sys_modify_ldt			(__NR_sys_Linux + 123)
#define __NR_sys_adjtimex			(__NR_sys_Linux + 124)
#define __NR_sys_mprotect			(__NR_sys_Linux + 125)
#define __NR_sys_sigprocmask		(__NR_sys_Linux + 126)
#define __NR_sys_create_module		(__NR_sys_Linux + 127)
#define __NR_sys_init_module		(__NR_sys_Linux + 128)
#define __NR_sys_delete_module		(__NR_sys_Linux + 129)
#define __NR_sys_get_kernel_syms		(__NR_sys_Linux + 130)
#define __NR_sys_quotactl			(__NR_sys_Linux + 131)
#define __NR_sys_getpgid			(__NR_sys_Linux + 132)
#define __NR_sys_fchdir			(__NR_sys_Linux + 133)
#define __NR_sys_bdflush			(__NR_sys_Linux + 134)
#define __NR_sys_sysfs			(__NR_sys_Linux + 135)
#define __NR_sys_personality		(__NR_sys_Linux + 136)
#define __NR_sys_afs_syscall		(__NR_sys_Linux + 137) /* Syscall for Andrew File System */
#define __NR_sys_setfsuid			(__NR_sys_Linux + 138)
#define __NR_sys_setfsgid			(__NR_sys_Linux + 139)
#define __NR_sys__llseek			(__NR_sys_Linux + 140)
#define __NR_sys_getdents			(__NR_sys_Linux + 141)
#define __NR_sys__newselect			(__NR_sys_Linux + 142)
#define __NR_sys_flock			(__NR_sys_Linux + 143)
#define __NR_sys_msync			(__NR_sys_Linux + 144)
#define __NR_sys_readv			(__NR_sys_Linux + 145)
#define __NR_sys_writev			(__NR_sys_Linux + 146)
#define __NR_sys_cacheflush			(__NR_sys_Linux + 147)
#define __NR_sys_cachectl			(__NR_sys_Linux + 148)
#define __NR_sys_sysmips			(__NR_sys_Linux + 149)
#define __NR_sys_unused150			(__NR_sys_Linux + 150)
#define __NR_sys_getsid			(__NR_sys_Linux + 151)
#define __NR_sys_fdatasync			(__NR_sys_Linux + 152)
#define __NR_sys__sysctl			(__NR_sys_Linux + 153)
#define __NR_sys_mlock			(__NR_sys_Linux + 154)
#define __NR_sys_munlock			(__NR_sys_Linux + 155)
#define __NR_sys_mlockall			(__NR_sys_Linux + 156)
#define __NR_sys_munlockall			(__NR_sys_Linux + 157)
#define __NR_sys_sched_setparam		(__NR_sys_Linux + 158)
#define __NR_sys_sched_getparam		(__NR_sys_Linux + 159)
#define __NR_sys_sched_setscheduler		(__NR_sys_Linux + 160)
#define __NR_sys_sched_getscheduler		(__NR_sys_Linux + 161)
#define __NR_sys_sched_yield		(__NR_sys_Linux + 162)
#define __NR_sys_sched_get_priority_max	(__NR_sys_Linux + 163)
#define __NR_sys_sched_get_priority_min	(__NR_sys_Linux + 164)
#define __NR_sys_sched_rr_get_interval	(__NR_sys_Linux + 165)
#define __NR_sys_nanosleep			(__NR_sys_Linux + 166)
#define __NR_sys_mremap			(__NR_sys_Linux + 167)
#define __NR_sys_accept			(__NR_sys_Linux + 168)
#define __NR_sys_bind			(__NR_sys_Linux + 169)
#define __NR_sys_connect			(__NR_sys_Linux + 170)
#define __NR_sys_getpeername		(__NR_sys_Linux + 171)
#define __NR_sys_getsockname		(__NR_sys_Linux + 172)
#define __NR_sys_getsockopt			(__NR_sys_Linux + 173)
#define __NR_sys_listen			(__NR_sys_Linux + 174)
#define __NR_sys_recv			(__NR_sys_Linux + 175)
#define __NR_sys_recvfrom			(__NR_sys_Linux + 176)
#define __NR_sys_recvmsg			(__NR_sys_Linux + 177)
#define __NR_sys_send			(__NR_sys_Linux + 178)
#define __NR_sys_sendmsg			(__NR_sys_Linux + 179)
#define __NR_sys_sendto			(__NR_sys_Linux + 180)
#define __NR_sys_setsockopt			(__NR_sys_Linux + 181)
#define __NR_sys_shutdown			(__NR_sys_Linux + 182)
#define __NR_sys_socket			(__NR_sys_Linux + 183)
#define __NR_sys_socketpair			(__NR_sys_Linux + 184)
#define __NR_sys_setresuid			(__NR_sys_Linux + 185)
#define __NR_sys_getresuid			(__NR_sys_Linux + 186)
#define __NR_sys_query_module		(__NR_sys_Linux + 187)
#define __NR_sys_poll			(__NR_sys_Linux + 188)
#define __NR_sys_nfsservctl			(__NR_sys_Linux + 189)
#define __NR_sys_setresgid			(__NR_sys_Linux + 190)
#define __NR_sys_getresgid			(__NR_sys_Linux + 191)
#define __NR_sys_prctl			(__NR_sys_Linux + 192)
#define __NR_sys_rt_sigreturn		(__NR_sys_Linux + 193)
#define __NR_sys_rt_sigaction		(__NR_sys_Linux + 194)
#define __NR_sys_rt_sigprocmask		(__NR_sys_Linux + 195)
#define __NR_sys_rt_sigpending		(__NR_sys_Linux + 196)
#define __NR_sys_rt_sigtimedwait		(__NR_sys_Linux + 197)
#define __NR_sys_rt_sigqueueinfo		(__NR_sys_Linux + 198)
#define __NR_sys_rt_sigsuspend		(__NR_sys_Linux + 199)
#define __NR_sys_pread			(__NR_sys_Linux + 200)
#define __NR_sys_pwrite			(__NR_sys_Linux + 201)
#define __NR_sys_chown			(__NR_sys_Linux + 202)
#define __NR_sys_getcwd			(__NR_sys_Linux + 203)
#define __NR_sys_capget			(__NR_sys_Linux + 204)
#define __NR_sys_capset			(__NR_sys_Linux + 205)
#define __NR_sys_sigaltstack		(__NR_sys_Linux + 206)
#define __NR_sys_sendfile			(__NR_sys_Linux + 207)
#define __NR_sys_getpmsg			(__NR_sys_Linux + 208)
#define __NR_sys_putpmsg			(__NR_sys_Linux + 209)
#define __NR_sys_mmap2			(__NR_sys_Linux + 210)
#define __NR_sys_truncate64			(__NR_sys_Linux + 211)
#define __NR_sys_ftruncate64		(__NR_sys_Linux + 212)
#define __NR_sys_stat64			(__NR_sys_Linux + 213)
#define __NR_sys_lstat64			(__NR_sys_Linux + 214)
#define __NR_sys_fstat64			(__NR_sys_Linux + 215)
#define __NR_sys_pivot_root			(__NR_sys_Linux + 216)
#define __NR_sys_mincore			(__NR_sys_Linux + 217)
#define __NR_sys_madvise			(__NR_sys_Linux + 218)
#define __NR_sys_getdents64			(__NR_sys_Linux + 219)
#define __NR_sys_fcntl64			(__NR_sys_Linux + 220)
#define __NR_sys_security			(__NR_sys_Linux + 221)
#define __NR_sys_gettid			(__NR_sys_Linux + 222)
#define __NR_sys_readahead			(__NR_sys_Linux + 223)
#define __NR_sys_setxattr			(__NR_sys_Linux + 224)
#define __NR_sys_lsetxattr			(__NR_sys_Linux + 225)
#define __NR_sys_fsetxattr			(__NR_sys_Linux + 226)
#define __NR_sys_getxattr			(__NR_sys_Linux + 227)
#define __NR_sys_lgetxattr			(__NR_sys_Linux + 228)
#define __NR_sys_fgetxattr			(__NR_sys_Linux + 229)
#define __NR_sys_listxattr			(__NR_sys_Linux + 230)
#define __NR_sys_llistxattr			(__NR_sys_Linux + 231)
#define __NR_sys_flistxattr			(__NR_sys_Linux + 232)
#define __NR_sys_removexattr		(__NR_sys_Linux + 233)
#define __NR_sys_lremovexattr		(__NR_sys_Linux + 234)
#define __NR_sys_fremovexattr		(__NR_sys_Linux + 235)
#define __NR_sys_tkill			(__NR_sys_Linux + 236)
#define __NR_sys_sendfile64			(__NR_sys_Linux + 237)
#define __NR_sys_futex			(__NR_sys_Linux + 238)
#define __NR_sys_sched_setaffinity		(__NR_sys_Linux + 239)
#define __NR_sys_sched_getaffinity		(__NR_sys_Linux + 240)

/*
 * Offset of the last Linux flavoured syscall
 */
#define __NR_Linux_syscalls		240

#ifndef __ASSEMBLY__

/* XXX - _foo needs to be __foo, while __NR_bar could be _NR_bar. */
#define _syscall0(type,name) \
type name(void) \
{ \
	register unsigned long __v0 asm("$2") = __NR_##name; \
	register unsigned long __a3 asm("$7"); \
	\
	__asm__ volatile ( \
	".set\tnoreorder\n\t" \
	"li\t$2, %2\t\t\t# " #name "\n\t" \
	"syscall\n\t" \
	".set\treorder" \
	: "=&r" (__v0), "=r" (__a3) \
	: "i" (__NR_##name) \
	: "$8", "$9", "$10", "$11", "$12", "$13", "$14", "$15", "$24"); \
	\
	if (__a3 == 0) \
		return (type) __v0; \
	sys_errno = __v0; \
	return -1; \
}

/*
 * DANGER: This macro isn't usable for the pipe(2) call
 * which has a unusual return convention.
 */
#define _syscall1(type,name,atype,a) \
type name(atype a) \
{ \
	register unsigned long __v0 asm("$2") = __NR_##name; \
	register unsigned long __a0 asm("$4") = (unsigned long) a; \
	register unsigned long __a3 asm("$7"); \
	\
	__asm__ volatile ( \
	".set\tnoreorder\n\t" \
	"li\t$2, %3\t\t\t# " #name "\n\t" \
	"syscall\n\t" \
	".set\treorder" \
	: "=&r" (__v0), "=r" (__a3) \
	: "r" (__a0), "i" (__NR_##name) \
	: "$8", "$9", "$10", "$11", "$12", "$13", "$14", "$15", "$24"); \
	\
	if (__a3 == 0) \
		return (type) __v0; \
	sys_errno = __v0; \
	return -1; \
}

#define _syscall2(type,name,atype,a,btype,b) \
type name(atype a, btype b) \
{ \
	register unsigned long __v0 asm("$2") = __NR_##name; \
	register unsigned long __a0 asm("$4") = (unsigned long) a; \
	register unsigned long __a1 asm("$5") = (unsigned long) b; \
	register unsigned long __a3 asm("$7"); \
	\
	__asm__ volatile ( \
	".set\tnoreorder\n\t" \
	"li\t$2, %4\t\t\t# " #name "\n\t" \
	"syscall\n\t" \
	".set\treorder" \
	: "=&r" (__v0), "=r" (__a3) \
	: "r" (__a0), "r" (__a1), "i" (__NR_##name) \
	: "$8", "$9", "$10", "$11", "$12", "$13", "$14", "$15", "$24"); \
	\
	if (__a3 == 0) \
		return (type) __v0; \
	sys_errno = __v0; \
	return -1; \
}

#define _syscall3(type,name,atype,a,btype,b,ctype,c) \
type name(atype a, btype b, ctype c) \
{ \
	register unsigned long __v0 asm("$2") = __NR_##name; \
	register unsigned long __a0 asm("$4") = (unsigned long) a; \
	register unsigned long __a1 asm("$5") = (unsigned long) b; \
	register unsigned long __a2 asm("$6") = (unsigned long) c; \
	register unsigned long __a3 asm("$7"); \
	\
	__asm__ volatile ( \
	".set\tnoreorder\n\t" \
	"li\t$2, %5\t\t\t# " #name "\n\t" \
	"syscall\n\t" \
	".set\treorder" \
	: "=&r" (__v0), "=r" (__a3) \
	: "r" (__a0), "r" (__a1), "r" (__a2), "i" (__NR_##name) \
	: "$8", "$9", "$10", "$11", "$12", "$13", "$14", "$15", "$24"); \
	\
	if (__a3 == 0) \
		return (type) __v0; \
	sys_errno = __v0; \
	return -1; \
}

#define _syscall4(type,name,atype,a,btype,b,ctype,c,dtype,d) \
type name(atype a, btype b, ctype c, dtype d) \
{ \
	register unsigned long __v0 asm("$2") = __NR_##name; \
	register unsigned long __a0 asm("$4") = (unsigned long) a; \
	register unsigned long __a1 asm("$5") = (unsigned long) b; \
	register unsigned long __a2 asm("$6") = (unsigned long) c; \
	register unsigned long __a3 asm("$7") = (unsigned long) d; \
	\
	__asm__ volatile ( \
	".set\tnoreorder\n\t" \
	"li\t$2, %5\t\t\t# " #name "\n\t" \
	"syscall\n\t" \
	".set\treorder" \
	: "=&r" (__v0), "+r" (__a3) \
	: "r" (__a0), "r" (__a1), "r" (__a2), "i" (__NR_##name) \
	: "$8", "$9", "$10", "$11", "$12", "$13", "$14", "$15", "$24"); \
	\
	if (__a3 == 0) \
		return (type) __v0; \
	sys_errno = __v0; \
	return -1; \
}

/*
 * Using those means your brain needs more than an oil change ;-)
 */

#define _syscall5(type,name,atype,a,btype,b,ctype,c,dtype,d,etype,e) \
type name(atype a, btype b, ctype c, dtype d, etype e) \
{ \
	register unsigned long __v0 asm("$2") = __NR_##name; \
	register unsigned long __a0 asm("$4") = (unsigned long) a; \
	register unsigned long __a1 asm("$5") = (unsigned long) b; \
	register unsigned long __a2 asm("$6") = (unsigned long) c; \
	register unsigned long __a3 asm("$7") = (unsigned long) d; \
	\
	__asm__ volatile ( \
	".set\tnoreorder\n\t" \
	"lw\t$2, %6\n\t" \
	"subu\t$29, 32\n\t" \
	"sw\t$2, 16($29)\n\t" \
	"li\t$2, %5\t\t\t# " #name "\n\t" \
	"syscall\n\t" \
	"addiu\t$29, 32\n\t" \
	".set\treorder" \
	: "=&r" (__v0), "+r" (__a3) \
	: "r" (__a0), "r" (__a1), "r" (__a2), "i" (__NR_##name), \
	  "m" ((unsigned long)e) \
	: "$8", "$9", "$10", "$11", "$12", "$13", "$14", "$15", "$24"); \
	\
	if (__a3 == 0) \
		return (type) __v0; \
	sys_errno = __v0; \
	return -1; \
}

#define _syscall6(type,name,atype,a,btype,b,ctype,c,dtype,d,etype,e,ftype,f) \
type name(atype a, btype b, ctype c, dtype d, etype e, ftype f) \
{ \
	register unsigned long __v0 asm("$2") = __NR_##name; \
	register unsigned long __a0 asm("$4") = (unsigned long) a; \
	register unsigned long __a1 asm("$5") = (unsigned long) b; \
	register unsigned long __a2 asm("$6") = (unsigned long) c; \
	register unsigned long __a3 asm("$7") = (unsigned long) d; \
	\
	__asm__ volatile ( \
	".set\tnoreorder\n\t" \
	"lw\t$2, %6\n\t" \
	"lw\t$8, %7\n\t" \
	"subu\t$29, 32\n\t" \
	"sw\t$2, 16($29)\n\t" \
	"sw\t$8, 20($29)\n\t" \
	"li\t$2, %5\t\t\t# " #name "\n\t" \
	"syscall\n\t" \
	"addiu\t$29, 32\n\t" \
	".set\treorder" \
	: "=&r" (__v0), "+r" (__a3) \
	: "r" (__a0), "r" (__a1), "r" (__a2), "i" (__NR_##name), \
	  "m" ((unsigned long)e), "m" ((unsigned long)f) \
	: "$8", "$9", "$10", "$11", "$12", "$13", "$14", "$15", "$24"); \
	\
	if (__a3 == 0) \
		return (type) __v0; \
	sys_errno = __v0; \
	return -1; \
}

#define _syscall7(type,name,atype,a,btype,b,ctype,c,dtype,d,etype,e,ftype,f,gtype,g) \
type name(atype a, btype b, ctype c, dtype d, etype e, ftype f, gtype g) \
{ \
	register unsigned long __v0 asm("$2") = __NR_##name; \
	register unsigned long __a0 asm("$4") = (unsigned long) a; \
	register unsigned long __a1 asm("$5") = (unsigned long) b; \
	register unsigned long __a2 asm("$6") = (unsigned long) c; \
	register unsigned long __a3 asm("$7") = (unsigned long) d; \
	\
	__asm__ volatile ( \
	".set\tnoreorder\n\t" \
	"lw\t$2, %6\n\t" \
	"lw\t$8, %7\n\t" \
	"lw\t$9, %8\n\t" \
	"subu\t$29, 32\n\t" \
	"sw\t$2, 16($29)\n\t" \
	"sw\t$8, 20($29)\n\t" \
	"sw\t$9, 24($29)\n\t" \
	"li\t$2, %5\t\t\t# " #name "\n\t" \
	"syscall\n\t" \
	"addiu\t$29, 32\n\t" \
	".set\treorder" \
	: "=&r" (__v0), "+r" (__a3) \
	: "r" (__a0), "r" (__a1), "r" (__a2), "i" (__NR_##name), \
	  "m" ((unsigned long)e), "m" ((unsigned long)f), \
	  "m" ((unsigned long)g), \
	: "$8", "$9", "$10", "$11", "$12", "$13", "$14", "$15", "$24"); \
	\
	if (__a3 == 0) \
		return (type) __v0; \
	sys_errno = __v0; \
	return -1; \
}

#endif /* !__ASSEMBLY__ */

#endif /* _ASM_UNISTD_H */

#endif

