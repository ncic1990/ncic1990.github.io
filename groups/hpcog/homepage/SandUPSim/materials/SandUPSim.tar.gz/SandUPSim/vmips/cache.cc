/* system include file,this is part of sand simulator
Copyright 2003,2005 HPCOG. NCIC. ICT
Date:2003.9.15   */
#include <math.h>
#include <zlib.h>

#include "sysinclude.h"
#include "cache.h"
#include "mapper.h"
#include "accesstypes.h"
#include "range.h"
#include "cpu.h"

#include "excnames.h"
#include "vmips.h"
#include "memstat.h"
#include "memstatreg.h"
#define lru_set( addr,  mode, lev, number)   do {     		\
	uint32  index;	\
	uint32 *lru = NULL;		\
	int N = -1;				\
	if(!cache[lev].next || mode == INSTFETCH)	\
	{				\
		if (cache[lev].content.organize_policy == 0 && cache[lev].content.replace_policy == 1)	\
		{				\
			index = (addr & cache[lev].content.prof.indexmask) >> cache[lev].content.prof.offset_width;   \
			lru = cache[lev].content.cache_lru;	\
			lru += index * cache[lev].content.associative_number;	\
			N = cache[lev].content.associative_number;	\			
		}				\
	}					\
	else					\
	{					\
		if (cache[lev].next ->content.organize_policy == 0 && cache[lev].next ->content.replace_policy == 1)	\
		{				\
			index = (addr & cache[lev].next ->content.prof.indexmask) >> cache[lev].next ->content.prof.offset_width;   \
			lru = cache[lev].next ->content.cache_lru;		\
			lru += index * cache[lev].next ->content.associative_number;		\
			N = cache[lev].next ->content.associative_number;			\
		}				\
	}					\
	for (int j = 0;j < N; j ++)		\
		*(lru + j) >>= 1;			\
	*(lru + number) &= 0x80000000UL;	\
} while (0)
/*
#define addr_parse(addr, mode, lev, tag, index, offset)  do { \
uint32 index_width, offset_width, tag_width;    \
	if(!cache[lev].next || mode == INSTFETCH)   \
	{    \
		offset_width =log2(cache[lev].content.entry_size);   \
		if (cache[lev].content.organize_policy == 0)			\
			index_width = log2(cache[lev].content.entry_number / cache[lev].content.associative_number);   \
		else		\
			index_width = log2(cache[lev].content.entry_number / 2);   \
	}    			\
	else    		\
	{			\
		offset_width =log2(cache[lev].next ->content.entry_size);   \
		if (cache[lev].next ->content.organize_policy == 0)			\
			index_width = log2(cache[lev].next ->content.entry_number / cache[lev].next ->content.associative_number); \
		else		\
			index_width = log2(cache[lev].next ->content.entry_number / 2);	  \
	}												\
	tag_width = 32 - offset_width - index_width;	 \
	offset = addr & ((1 << offset_width)- 1);  \
	index  = (addr & (( (1 << index_width )- 1) << offset_width)) >> offset_width ;	\
	tag    = (addr & (~( (1 << (32 - tag_width)) - 1))) >> (32 - tag_width); \
} while (0)	
*/

/*
#define n_ass_probe(addr, mode, lev, pdata, ptable)   do  {   \
	uint32 offset, index, tag;		\
	uint32  * pd;					\
	cache_union* pt;				\
	uint32 N, datagap;			\
	addr_parse( addr,mode, lev, tag, index, offset);			\
	if(!cache[lev].next || mode == INSTFETCH)				\
	{													\
		pd = cache[lev].content.cache_data;				\
		pt = cache[lev].content.cache_table;				\		
		N = cache[lev].content.associative_number;			\
		datagap = cache[lev].content.entry_size / 4;			\
	}													\
	else													\
	{													\
		pd = cache[lev].next ->content.cache_data;			\
		pt = cache[lev].next ->content.cache_table;			\
		N = cache[lev].next ->content.associative_number;	\
		datagap = cache[lev].next ->content.entry_size / 4;	\
	}									\
	pd += index * N * datagap;				\
	pt += index * N;						\
	uint32 i = 0;							\
	while(i < N)							\
	{									\
		if (pt ->lut.tag == tag && pt ->lut.v)			\
		{										\
			lru_set(addr, mode, lev,  i);			\
			*pdata = pd;							\
			*ptable = pt;							\
			return true;							\
		}						\
		pt ++;						\
		pd += datagap;				\
		i ++;							\
	}					\
	*ptable = NULL;					\
	*pdata = NULL;					\
	return false;						\
}while (0)
*/
CACHE::CACHE()
{
	config_from_file("cache_config_file");
	initialize();
}
CACHE::CACHE(char * configdir)
{
	char fname[512+32];
	strncpy(fname,configdir,512);
	strcat(fname,"cache_config_file");
	fprintf(stderr,"Using %s \n",fname);
	config_from_file(fname);
	initialize();
}
int
CACHE::log2(int N)
{
	int i = 0;
	if (N == 0 || (N % 2 != 0))
		fatal_error("entry number is wrong?");
    while ( N % 2 == 0)
	{
      		N = N >> 1;
       	i ++;
	}
    return i;
}
void 
CACHE::fast_mem_start()
{
	fastmem = true;	
}
void 
CACHE::fast_mem_end()
{
	fastmem = false;
}
void 
CACHE::attach(CPU* p , Mapper* m, Memstat* ms , ClkMem* c)
{
	cpu = p;
	mapper = m;
	memstat = ms;
	clkmem = c;
	memstat ->getcachelev(level);
	memsize = clkmem ->getmemsize();
}
bool 
CACHE::inmem(uint32 addr)
{
	if(addr >= 0 && addr <= memsize)
		return true;
	return false;
}
void
CACHE::initialize()
{
	cache_one_level * next_cache;
	int num;
	for(int i = 0; i < level; i ++)
	{
		cache[i].content.cache_data= (uint32*)malloc (cache[i].content.entry_number * cache[i].content.entry_size );
		if(!cache[i].content.cache_data)
			fatal_error("There isn't enough room to malloc cache %d, program aborted", i);
		cache[i].content.cache_table   = (cache_union*)malloc (cache[i].content.entry_number * sizeof(cache_union));
		cache[i].content.prof.offset_width = log2(cache[i].content.entry_size);
		if( cache[i].content.organize_policy == 0)				
		{
			num = cache[i].content.entry_number /  cache[i].content.associative_number;
			if ( cache[i].content.replace_policy == 2)     //LILO									
			{				
				cache[i].content.cache_counter =(uint32*) malloc (num * 4);							
				for (int j = 0; j < num; j ++)
					cache[i].content.cache_counter[j] = 0;
			}		
			if ( cache[i].content.replace_policy == 1 )    //LRU					
			{
				cache[i].content.cache_lru  = (uint32*)malloc ( cache[i].content.entry_number * 4);
				for (int j = 0; j <  cache[i].content.entry_number; j ++)
					cache[i].content.cache_lru[j] = 0;
			}
			cache[i].content.prof.index_width = log2(num);			
		}
		else
			cache[i].content.prof.index_width = log2(cache[i].content.entry_number/ 2);		
		cache[i].content.prof.tag_width = 32 - cache[i].content.prof.offset_width - cache[i].content.prof.index_width;
		
		cache[i].content.prof.tagmask = ~(1 << (32 - cache[i].content.prof.tag_width)- 1);
		cache[i].content.prof.indexmask =  ((1 << cache[i].content.prof.index_width )- 1) << cache[i].content.prof.offset_width;
		cache[i].content.prof.offsetmask = (1 << cache[i].content.prof.offset_width) - 1;
		
		if(cache[i].next)            // instr and data cache is separated,the following initalizes the data cache
		{
			next_cache = cache[i].next;
			next_cache ->content.cache_data=(uint32*) malloc (next_cache ->content.entry_number * next_cache ->content.entry_size);
			next_cache ->content.cache_table   =(cache_union*) malloc (next_cache ->content.entry_number * sizeof(cache_union));
			cache[i].next ->content.prof.offset_width = log2(next_cache ->content.entry_size);
			if( next_cache ->content.organize_policy == 0)				
			{
				num = next_cache ->content.entry_number / next_cache ->content.associative_number;
				if ( next_cache ->content.replace_policy == 2)     //LILO									
				{
					next_cache ->content.cache_counter =(uint32*) malloc ( num * 4);							
					for (int j = 0; j < num; j ++)
						next_cache ->content.cache_counter[j] = 0;
				}	
				
				if ( next_cache ->content.replace_policy == 1 )    //LRU					
				{
					next_cache ->content.cache_lru     = (uint32*)malloc ( next_cache ->content.entry_number * 4);
					for (int j = 0; j < next_cache ->content.entry_number; j ++)
						next_cache ->content.cache_lru[j] = 0;
				}
				cache[i].next ->content.prof.index_width = log2(num);	
			}
			else
				cache[i].next ->content.prof.index_width = log2(next_cache ->content.entry_number / 2);
			cache[i].next ->content.prof.tag_width = 32 - cache[i].next ->content.prof.offset_width - cache[i].next ->content.prof.index_width;
			
			cache[i].next ->content.prof.tagmask = ~(1 << (32 - cache[i].next ->content.prof.tag_width)- 1);
			cache[i].next ->content.prof.indexmask =  ((1 << cache[i].next ->content.prof.index_width )- 1) << cache[i].next ->content.prof.offset_width;
			cache[i].next ->content.prof.offsetmask = (1 << cache[i].next ->content.prof.offset_width) - 1;
		}	
	}
	delaytime = (uint8**)malloc(level * 4);
	for(int m = 0; m < level; m ++)
		delaytime[m] = (uint8*)malloc(2);
	
	memcache.data = (uint32*)calloc( PAGESIZE , memcache.entry_num);
	memcache.barray = (uint32*)calloc( 4 , memcache.entry_num );
	memcache.table = (memcache_entry *) calloc(sizeof(memcache_entry) , memcache.entry_num);
	memcache_entry *p;
	p = (memcache_entry *)malloc(sizeof(memcache_entry));
	p->prev = p->next = p;
	memcache.hd = p;
	
	p= (memcache_entry *)malloc(sizeof(memcache_entry));
	p->next = &(memcache.table[0]);
	p->prev = &(memcache.table[memcache.entry_num - 1]);
	memcache.freehd  = p;
	
	for(uint32 index = 0; index < memcache.entry_num; index ++)
	{
		memcache.table[index].prev = (index == 0)? memcache.freehd : &(memcache.table[index - 1]);
		memcache.table[index].next = (index == memcache.entry_num - 1)? memcache.freehd : &(memcache.table[index + 1]);
		memcache.table[index].revindex = index;
		memcache.barray[index] = index;
	}	
	
	reset();
}
void 
CACHE::reset()
{
	cache_union * ptable;	
	int index;
	fastmem = false;
	for(int i = 0; i < level; i ++)
	{
		ptable = cache[i].content.cache_table;
		for (index = 0; index < cache[i].content.entry_number; index ++)
		{
			(ptable + index) ->lut.v = 0;  	   
			(ptable + index) ->lut.w = 0;
			(ptable + index) ->lut.d = 0;
		}
		if (cache[i].next)
		{
			ptable = cache[i].next ->content.cache_table;
			for (index = 0; index <cache[i].next ->content.entry_number; index ++)
			{
				(ptable + index) ->lut.w = 0;
				(ptable + index) ->lut.d = 0;
				(ptable + index) ->lut.v = 0;
			}
		}		
		if(!cache[i].content.onchip)
		{
			delaytime[i][0] = HITOFFCHIP;
			delaytime[i][1] = HITOFFCHIP;
		}
		else
			switch(i)
			{
				case 0:
					delaytime[0][0] = HITLEV1DLI;
					delaytime[0][1] = HITLEV1DLD;
					break;
				case 1:
					delaytime[1][0] = HITLEV2DL;
					delaytime[1][1] = HITLEV2DL;
					break;
				case 2:
					delaytime[2][0] = HITLEV3DL;
					delaytime[2][1] = HITLEV3DL;
					break;
				default:
					fatal_error("more than 3 level onchip cache? modify source file \n");
			}
	}  	
}
void
CACHE::config_from_file(char* path_name)
{
	FILE *fp;
	char *p, *header, buf[256];
	int val,index;  
	bool start = false,dcache;
	char sep[] = " =:;\t";
	char num,tmp[20];
	val = -1;
	index = -1;
	dcache = false;
	if((fp = fopen(path_name,"r")) == NULL)
		fatal_error("can't open input cache file");
	/*  the following read configure parameter from the input cache config file, and 
	set the cahce referenced variable */
	while(!feof(fp))
	{
		fgets(buf,256,fp);
		buf[strlen(buf)-1] = '\0';	
		if((p = strchr(buf, '=')) != NULL)    
			/* val record the numberable value after the char '=' of the string */
			val = atoi( ++ p);
		header = strtok(buf,sep);
		if(!header)
		   	continue;
		if (!strcmp(header,"cache_begin"))        // the cache part of the file;
      		{
			start = true;
			continue;
      		}
		if(!strcmp(header, "/*"))
		{
			start = false;
			continue;
		}
		if(!strcmp(header,"*/"))
		{
			start = true;
			continue;
		}
	       
		if (start)
      		{
			
			/*header records the part of the string before the "=" */
			if (!strcmp(header, "level"))      // config the level
			{
				level = val;
				cache = (cache_one_level *)malloc(level * sizeof( cache_one_level));
				continue;
			}
			strcpy(tmp,header);
			num = tmp[strlen(tmp) - 1];
			tmp[strlen(tmp) - 1] = '\0';
			if(!strcmp(tmp,"level")) 
			{
				/*   index records the current cachel level*/
				index =num - 49;
				continue;
			}
			if (!strcmp(header,"separated"))
			{
				if(val == 0)
					cache[index].next = NULL;
				else
       	       			{
					cache_one_level *next_cache = (cache_one_level*)calloc(1,sizeof(cache_one_level));
					next_cache ->next = NULL;
					cache[index].next = next_cache;
       	       			}
				continue;
			}
			if(!strcmp(header,"onchip"))
			{
				cache[index].content.onchip = val;
				if (cache[index].next)
					cache[index].next -> content.onchip = val;
				continue;
			}       	
			/* the following records whether the current cache is data cache*/
			if(!strcmp(header,"icache"))       		 
				dcache = false;
			if(!strcmp(header,"dcache"))       		 
				dcache = true;
			if(!strcmp(header,"ucache"))       		 
				dcache = false;
			if(!strcmp(header, "write_allocated"))
			{
				if(dcache)
					cache[index].next -> content.write_allocated = val;
				else
					cache[index].content.write_allocated = val;
				continue;
			}
			if(!strcmp(header, "back_or_through"))
			{
				if(dcache)
					cache[index].next -> content.back_or_through= val;
				else
					cache[index].content.back_or_through= val;
				continue;
			}
			if(!strcmp(header, "virtual_indexed"))
			{
				if(dcache)
					cache[index].next -> content.virtual_indexed= val;
				else
					cache[index].content.virtual_indexed= val;
				continue;
			}
			if(!strcmp(header, "virtual_taged"))
			{
				if(dcache)
					cache[index].next -> content.virtual_tagged = val;
				else
					cache[index].content.virtual_tagged = val;
				continue;
			}
			if(!strcmp(header, "virtual_taged"))
			{
				if(dcache)
					cache[index].next -> content.virtual_tagged = val;
				else
					cache[index].content.virtual_tagged = val;
				continue;
			}
			if(!strcmp(header, "organize_policy"))
			{
				if(dcache)
					cache[index].next -> content.organize_policy= val;
				else
					cache[index].content.organize_policy= val;
				continue;
			}
			if(!strcmp(header, "associative_number"))
			{
				if(dcache)
					cache[index].next -> content.associative_number= val;
				else
					cache[index].content.associative_number= val;
				continue;
			}
			if(!strcmp(header, "replace_policy"))
			{
				if(dcache)
					cache[index].next -> content.replace_policy= val;
				else
					cache[index].content.replace_policy= val;
				continue;
			}
			if(!strcmp(header, "entry_number"))
			{
				if(dcache)
					cache[index].next -> content.entry_number= val;
				else
					cache[index].content.entry_number= val;       		
				continue;
			}
			if(!strcmp(header, "entry_size"))
			{
				if(dcache)
					cache[index].next -> content.entry_size = val;
				else
					cache[index].content.entry_size = val;
				continue;
			}
			if (! strcmp(header,"cache_end"))			
				start = false;					       
		}
	
		if(!strcmp(header, "memcache_entry_num"))
			memcache.entry_num = val;
	}
	fclose(fp);
/*
	for ( int k = 0; k < level; k ++)
	{
		  printf("This cache configure is:\n");
		  printf("levle %d:\n", k);
		  printf("onchip = %d\n",cache[k].content.onchip);
		  printf("separated = %d\n\n", cache[k].next);
		  printf("associative number = %d\n",cache[k].content.associative_number);
		  printf("organize policy = %d\n", cache[k].content.organize_policy);
		  printf("replace policy = %d\n", cache[k].content.replace_policy);
		  printf("entry number = %d\n",cache[k].content.entry_number);
		  printf("entry size = %d\n", cache[k].content.entry_size);
		  printf("write or through = %d \n ",cache[k].content.back_or_through);
		  printf("write allocated = %d\n\n", cache[k].content.write_allocated);
		  if(cache[k].next)
	  	 {
	  	  printf("associative number = %d\n",cache[k].next ->content.associative_number);
		  printf("organize policy = %d\n", cache[k].next ->content.organize_policy);
		  printf("replace policy = %d\n", cache[k].next ->content.replace_policy);
		  printf("entry number = %d\n",cache[k].next ->content.entry_number);
		  printf("entry size = %d\n", cache[k].next ->content.entry_size);
		  printf("write or through = %d \n ",cache[k].next ->content.back_or_through);
		  printf("write allocated = %d\n\n", cache[k].next ->content.write_allocated);
	  	 }
	}
*/
}


/*
void 
CACHE::addr_parse(uint32 addr, int32 mode, int lev, uint32 *tag, uint32 *index, uint32 *offset)
{
	
}
*/
uint32
CACHE::raddr_parse(uint32 tag, uint32 index,  int32 mode, int lev)
{
	uint32 tag_width, offset_width;
	uint32 tmpaddr;
	if(!cache[lev].next || mode == INSTFETCH)
	{
		offset_width = cache[lev].content.prof.offset_width;
		tag_width = cache[lev].content.prof.tag_width;
	}
	else
	{
		offset_width = cache[lev].next ->content.prof.offset_width;
		tag_width = cache[lev].next ->content.prof.tag_width;
	}
	tmpaddr = (tag << (32 - tag_width)) | (index << offset_width);
	return tmpaddr;
}

inline 
bool
CACHE::n_ass_probe(uint32 addr, int32 mode, int lev, uint32 ** pdata, cache_union** ptable)
{
	uint32 index, tag;
	uint32  * pd;
	cache_union* pt;	
	uint32 N, datagap;	
	bool lru_org = false;
	
	if(!cache[lev].next || mode == INSTFETCH)
	{
		pd = cache[lev].content.cache_data;
		pt = cache[lev].content.cache_table;

		index = (addr & cache[lev].content.prof.indexmask) >> cache[lev].content.prof.offset_width;
		tag = (addr & cache[lev].content.prof.tagmask) >> (32 - cache[lev].content.prof.tag_width);
		
		N = cache[lev].content.associative_number;		
		datagap = cache[lev].content.entry_size / 4;
		if(cache[lev].content.replace_policy == 1)
			lru_org = true;
	}
	else
	{
		pd = cache[lev].next ->content.cache_data;
		pt = cache[lev].next ->content.cache_table;

		index = (addr & cache[lev].next ->content.prof.indexmask) >> cache[lev].next ->content.prof.offset_width;
		tag = (addr & cache[lev].next ->content.prof.tagmask) >> (32 - cache[lev].next ->content.prof.tag_width);

		N = cache[lev].next ->content.associative_number;
		datagap = cache[lev].next ->content.entry_size / 4;
		if(cache[lev].next ->content.replace_policy == 1)
			lru_org = true;
	}
	pd += index * N * datagap;		
	pt += index * N;
	uint32 i = 0;
	while(i < N)
	{
		if (  pt->lut.v && pt ->lut.tag == tag )
		{
			if(lru_org)
				lru_set(addr, mode, lev,  i);
			*pdata = pd;
			*ptable = pt;
			return true;
		}
		pt ++;
		pd += datagap;
		i ++;
	}
	*ptable = NULL;
	*pdata = NULL;
	return false;
}


bool
CACHE::	pseudo_ass_probe(uint32 addr, int32 mode, int lev, uint32 ** pdata, cache_union ** ptable)
{
	uint32  index, tag;
	cache_union* pt;
	uint32 * pd;
	int index_width, datagap;

	if(!cache[lev].next || mode == INSTFETCH)
	{
		index_width = cache[lev].content.prof.index_width;
		datagap = cache[lev].content.entry_size / 4;

		index = (addr & cache[lev].content.prof.indexmask) >> cache[lev].content.prof.offset_width;
		tag = (addr & cache[lev].content.prof.tagmask) >> (32 - cache[lev].content.prof.tag_width);
		
		pt = cache[lev].content.cache_table;
		pd = cache[lev].content.cache_data;
	}
	else
	{
		index_width = cache[lev].next ->content.prof.index_width;
		datagap = cache[lev].next ->content.entry_size / 4;

		index = (addr & cache[lev].next ->content.prof.indexmask) >> cache[lev].next ->content.prof.offset_width;
		tag = (addr & cache[lev].next ->content.prof.tagmask) >> (32 - cache[lev].next ->content.prof.tag_width);
		
		pt = cache[lev].next ->content.cache_table;
		pd = cache[lev].next ->content.cache_data;
	}
	index |= 1 << index_width;
	
	if ((pt + index) ->lut.tag == tag && (pt + index ) ->lut.v)
	{
		*pdata = pd + index * datagap;
		*ptable = pt + index;
		return true;
	}
	
	index ^= 1 << index_width ;

	if ((pt + index) ->lut.tag == tag && (pt + index) ->lut.v)
	{
		*pdata = pd + index * datagap;
		*ptable = pt + index;
		return true;
	}	
	*ptable = NULL;
	*pdata= NULL;
	return false;	
}


bool
CACHE::	way_predict_probe(uint32 addr, int32 mode, int lev, uint32 ** pdata, cache_union ** ptable)
{
	uint32 tag, index;
	cache_union  * pt;
	uint32* pd;
	int another_way;
	int datagap;
	
	if(!cache[lev].next || mode == INSTFETCH)
	{		
		datagap = cache[lev].content.entry_size / 4;
		tag = (addr & cache[lev].content.prof.tagmask) >> (32 - cache[lev].content.prof.tag_width);
		index = (addr & cache[lev].content.prof.indexmask) >> cache[lev].content.prof.offset_width;
		
		pt = cache[lev].content.cache_table;
		pd = cache[lev].content.cache_data;		
	}
	else
	{
		
		datagap = cache[lev].next ->content.entry_size / 4;
		tag = (addr & cache[lev].next ->content.prof.tagmask) >> (32 - cache[lev].next ->content.prof.tag_width);
		index = (addr & cache[lev].next ->content.prof.indexmask) >>  cache[lev].next ->content.prof.offset_width;
		
		pt = cache[lev].next ->content.cache_table;
		pd = cache[lev].next ->content.cache_data;
	}	

	pt += index * 2;	
	
	int way = (int)(pt ->lut.w);

	if((pt + way) ->lut.tag == tag && (pt + way) ->lut.v)
	{
		*pdata = pd +( index * 2 + way) * datagap;
		*ptable = pt + way;
		return true;
	}
	//way prediction not hitted
	
	another_way = (way == 1) ? 0 : 1; 
	if((pt + another_way) ->lut.tag == tag && (pt + another_way) ->lut.v)
	{
		*pdata = pd + (index * 2 +another_way) * datagap;
		*ptable = pt + another_way;
		
		pt ->lut.w = another_way;
		return true;
	}
	*ptable = NULL;
	*pdata = NULL;
	return false;
}


bool
CACHE::probe_one_level(uint32 addr, int32 mode, int lev, uint32 ** pdata, cache_union ** ptable)
{
	int organize_policy;
	if(!cache[lev].next || mode == INSTFETCH)
		organize_policy = cache[lev].content.organize_policy;
	else
		organize_policy = cache[lev].next ->content.organize_policy;
	switch(organize_policy)
	{
		case 0:
			if( n_ass_probe(addr, mode, lev, pdata, ptable))
				return true;
			break;
		case 1:
			if( pseudo_ass_probe(addr, mode, lev, pdata, ptable))
				return true;
			break;
		case 2:
			if( way_predict_probe(addr, mode, lev, pdata, ptable))
				return true;
			break;					
	}	
	return false;
}

inline 
bool
CACHE::probe(uint32 addr, int32 mode, uint32 **pdata, cache_union ** ptable, int *hit_lev)
{
	int i = 0;	
	while ( i < level)
	{
		int organize_policy;
		if(!cache[i].next || mode == INSTFETCH)
			organize_policy = cache[i].content.organize_policy;
		else
			organize_policy = cache[i].next ->content.organize_policy;
		switch(organize_policy)
		{
			case 0:
				if( n_ass_probe(addr, mode, i, pdata, ptable))
				{
					*hit_lev = i;
					return true;
				}
				break;
			case 1:
				if( pseudo_ass_probe(addr, mode,i, pdata, ptable))
				{
					*hit_lev = i;
					return true;
				}
				break;
			case 2:
				if( way_predict_probe(addr, mode,i, pdata, ptable))
				{
					*hit_lev = i;
					return true;
				}
				break;					
		}	
/*		if(probe_one_level( addr, mode, i, pdata,  ptable))
		{
			*hit_lev = i;
			return true;
		}
*/
		i ++;			
	}	
	return false;  
}
int 
CACHE::my_random(int upper_bound)
{	
	srand( (unsigned)time( NULL ) );
	return ( rand() % upper_bound);
}

void 
CACHE::downfill_one_level(uint32 addr, int mode, int cur_lev, uint8 *delay_time)
 {
 	uint32 coffset_width, noffset_width;
 	cache_union * cpt, *npt;
 	uint32 *cpd, *npd;
 	int off,mask, N;
	*delay_time = 0;
 	if(cur_lev == level - 1)
 	{
 		cache_to_memcache( addr,  mode, delay_time);
 		return;
 	}	
 	if(!probe_one_level(addr,  mode, cur_lev, &cpd, &cpt) 
 				|| !probe_one_level(addr,  mode, cur_lev + 1, &npd, &npt))
 		fatal_error("want to down fill, but there isn't an entry in current level or next level\n");

 	
 	if(!cache[cur_lev].next || mode == INSTFETCH)
 	{
		coffset_width = cache[cur_lev].content.prof.offset_width;
 		N = cache[cur_lev].content.entry_size / 4;
 	}
 	else
 	{
		coffset_width = cache[cur_lev].next ->content.prof.offset_width;
 		N = cache[cur_lev].next ->content.entry_size / 4;
 	}
 	if(!cache[cur_lev + 1].next || mode == INSTFETCH) 	
		noffset_width = cache[cur_lev + 1].content.prof.offset_width;
 	else
		noffset_width = cache[cur_lev + 1].next ->content.prof.offset_width;
 	mask = ( (1 << (noffset_width - coffset_width)) - 1)  << coffset_width;
 	off = (addr & mask) >> coffset_width;

	npd += off * N;
 	for(int i = 0; i < N; i ++) 	
 		*(npd ++) = *(cpd ++);
 	cpt ->lut.d = 0;
 	npt ->lut.d = 1;
 	bool write_throught;
 	if(!cache[cur_lev + 1].next || mode == INSTFETCH)
 		write_throught=(cache[cur_lev + 1].content.back_or_through == 1)?0 : 1;
 	else
 		write_throught=(cache[cur_lev + 1].next->content.back_or_through == 1)? 0 : 1;
 	if(write_throught) 	
		downfill_one_level(addr, mode, cur_lev + 1, delay_time); 	 		
 }

/* This function downfill the entry from the fisrt level to the current level, not include current level*/
void 
CACHE::upperdownfill(uint32 addr, int mode, int cur_lev, uint8* delay_time)
{	
	uint32 pentrysize, centrysize;
	uint32 start_addr, end_addr, tmpaddr;	
	uint32 * pd;
	cache_union* pt;	
	*delay_time = 0;
	if(!cache[cur_lev].next || mode == INSTFETCH)
		pentrysize = cache[cur_lev].content.entry_size;
	else
		pentrysize = cache[cur_lev].next ->content.entry_size;	
	start_addr = addr & (~( pentrysize - 1));
	
	int i = 0;
	while(i < cur_lev)
	{
		/*first , invalidate the instr cache*/	
		
		centrysize = cache[i].content.entry_size;		
		end_addr = start_addr | (pentrysize - centrysize);
		tmpaddr = start_addr;		
		while( tmpaddr <= end_addr)
		{
			if(probe_one_level(tmpaddr, INSTFETCH, i, &pd, &pt))
			{
				if(pt ->lut.d == 1)
					downfill_one_level(tmpaddr, INSTFETCH, i, delay_time);
				pt ->lut.v = 0;					
			}
			tmpaddr += centrysize;
		}
		/*next, invalidate the data cache*/
		if(cache[i].next)		
		{			
			centrysize = cache[i].next ->content.entry_size;		
			end_addr = start_addr | (pentrysize - centrysize);
			tmpaddr = start_addr;	
			while( tmpaddr <= end_addr)
			{
				if(probe_one_level(tmpaddr, DATALOAD, i, &pd, &pt))
				{
					if(pt ->lut.d == 1)
						downfill_one_level(tmpaddr, DATALOAD, i, delay_time);
					pt ->lut.v = 0;					
				}
				tmpaddr += centrysize;
			}
		}		
		i ++;	
	}				
}
void
CACHE::random_replace(uint32 addr, int mode, int lev, uint32* data, uint8 * delay_time)
{
	int rand_value;
	cache_union * pt ;
	uint32 *pd;
	int N, datagap;
	uint32 index, tag;
	*delay_time = 0;
	if(!cache[lev].next || mode == INSTFETCH)
	{
		pt = cache[lev].content.cache_table;
		pd = cache[lev].content.cache_data;

		index = (addr & cache[lev].content.prof.indexmask) >> cache[lev].content.prof.offset_width;
		tag = (addr & cache[lev].content.prof.tagmask) >> (32 - cache[lev].content.prof.tag_width);

		rand_value = my_random(cache[lev].content.associative_number);
		N = cache[lev].content.associative_number;
		datagap = cache[lev].content.entry_size / 4;
	}
	else
	{
		pt = cache[lev].next ->content.cache_table;
		pd = cache[lev].next ->content.cache_data;

		index = (addr & cache[lev].next ->content.prof.indexmask) >> cache[lev].next ->content.prof.offset_width;
		tag = (addr & cache[lev].next ->content.prof.tagmask) >> (32 - cache[lev].next ->content.prof.tag_width);

		rand_value = my_random(cache[lev].next ->content.associative_number);
		N = cache[lev].next ->content.associative_number;
		datagap = cache[lev].next ->content.entry_size / 4;
		
	}
	
	pt += index * N + rand_value;
	pd += datagap * (N *  index + rand_value);	

	if(pt ->lut.v == 1)
	{
		uint32 tmpaddr = raddr_parse(pt ->lut.tag, index,  mode, lev);
		upperdownfill(tmpaddr, mode, lev, delay_time);
		if (pt ->lut.d == 1 )              // DIRTY	
			// write to the next level	
			{
			downfill_one_level(tmpaddr, mode, lev, delay_time);
			pt ->lut.d = 0;
			}
	}		
	// write data to the according line	
	if(!fastmem)
		for ( int i = 0; i < datagap;  i ++)
			*(pd ++ ) = *(data ++);
	pt ->lut.v = 1;
	pt ->lut.d = 0;	
	pt ->lut.tag = tag;
}
void 
CACHE::lilo_replace(uint32 addr, int mode, int lev, uint32* data, uint8 * delay_time)
{
	cache_union *pt;
	uint32 *pd;
	uint32 *counter, N;
	int datagap;
	uint32 tag, index;
	*delay_time = 0;

	if(!cache[lev].next || mode == INSTFETCH)
	{
		counter = cache[lev].content.cache_counter;
		datagap = cache[lev].content.entry_size / 4;
		N = cache[lev].content.associative_number;

		index = (addr & cache[lev].content.prof.indexmask) >> cache[lev].content.prof.offset_width;
		tag = (addr & cache[lev].content.prof.tagmask) >> (32 - cache[lev].content.prof.tag_width);
		
		pd = cache[lev].content.cache_data;
		pt = cache[lev].content.cache_table;		
	}
	else
	{
		counter = cache[lev].next ->content.cache_counter;
		datagap = cache[lev].next ->content.entry_size / 4;
		N = cache[lev].next ->content.associative_number;

		index = (addr & cache[lev].next ->content.prof.indexmask) >> cache[lev].next ->content.prof.offset_width;
		tag = (addr & cache[lev].next ->content.prof.tagmask) >> (32 - cache[lev].next ->content.prof.tag_width);
		
		pd = cache[lev].next ->content.cache_data;
		pt = cache[lev].next ->content.cache_table;	
	}
	if(++ (*counter) >= N)
		*counter = 0;
	pd += (index * N + *counter) * datagap;
	pt += index * N + *counter;

	if(pt ->lut.v == 1)
	{
		uint32 tmpaddr = raddr_parse(pt ->lut.tag, index,  mode, lev);
		upperdownfill(tmpaddr, mode, lev, delay_time);
		if (pt ->lut.d == 1 )              // DIRTY	
			// write to the next level			
			downfill_one_level(tmpaddr, mode, lev, delay_time);
	}		
	// write data to the according line	
	if(!fastmem)
		for ( int i = 0; i < datagap; i ++)
			*(pd ++ ) = * (data ++);
	pt ->lut.v = 1;
	pt ->lut.d = 0;	
	pt ->lut.tag = tag;	
}
int 
CACHE::lru_search(uint32 *lru,  int N)
{
	int find = 0;
	int i;
	for (i = 1; i < N ; i ++)	
		if (* (lru + i) < * (lru + find))
			find = i;
	for(i = 0; i < N; i ++)
		*(lru + i) >>= 1;     
	* (lru + find)  &=  0x80000000;
	return find;
}
void
CACHE::lru_replace(uint32 addr, int mode, int lev, uint32* data, uint8 *delay_time)
{
	int number;
	cache_union * pt ;
	uint32 *pd;
	int N, datagap;
	uint32 tag, index;
	*delay_time = 0;
	if(!cache[lev].next || mode == INSTFETCH)
	{
		pt = cache[lev].content.cache_table;
		pd = cache[lev].content.cache_data;

		index = (addr & cache[lev].content.prof.indexmask) >> cache[lev].content.prof.offset_width;
		tag = (addr & cache[lev].content.prof.tagmask) >> (32 - cache[lev].content.prof.tag_width);
		
		N = cache[lev].content.associative_number;
		number = lru_search(cache[lev].content.cache_lru,  N);
		datagap = cache[lev].content.entry_size / 4;
	}
	else
	{
		pt = cache[lev].next ->content.cache_table;
		pd = cache[lev].next ->content.cache_data;

		index = (addr & cache[lev].next ->content.prof.indexmask) >> cache[lev].next ->content.prof.offset_width;
		tag = (addr & cache[lev].next ->content.prof.tagmask) >> (32 - cache[lev].next ->content.prof.tag_width);
		
		N = cache[lev].next ->content.associative_number;
		number = lru_search(cache[lev].next ->content.cache_lru,  N);
		datagap = cache[lev].next ->content.entry_size / 4;
		
	}
	
	pt += index * N + number;
	pd += datagap * (N *  index + number);	

	if(pt ->lut.v == 1)
	{
		uint32 tmpaddr = raddr_parse(pt ->lut.tag, index,  mode, lev);
		upperdownfill(tmpaddr, mode, lev, delay_time);
		if (pt ->lut.d == 1 )              // DIRTY	
			// write to the next level			
			downfill_one_level(tmpaddr, mode, lev, delay_time);
	}		
	// write data to the according line	
	if(!fastmem)
		for ( int i = 0; i < datagap; i ++)
			*(pd ++ ) = * (data ++);
	pt ->lut.v = 1;
	pt ->lut.d = 0;	
	pt ->lut.tag = tag;		
}
void 
CACHE::pseudo_replace(uint32 addr, int mode, int lev, uint32* data, uint8 *delay_time)
{	
	cache_union * pt , *pt1, *pt2;
	uint32 *pd,*pd1, *pd2;
	uint32 index1, index2;
	int  datagap;
	int index_width;
	uint32 tag, index;
	*delay_time = 0;
	if(!cache[lev].next || mode == INSTFETCH)
	{
		pt = cache[lev].content.cache_table;
		pd = cache[lev].content.cache_data;

		index = (addr & cache[lev].content.prof.indexmask) >> cache[lev].content.prof.offset_width;
		tag = (addr & cache[lev].content.prof.tagmask) >> (32 - cache[lev].content.prof.tag_width);
		
		datagap = cache[lev].content.entry_size / 4;
		index_width = cache[lev].content.prof.index_width;

	}
	else
	{
		pt = cache[lev].next ->content.cache_table;
		pd = cache[lev].next ->content.cache_data;		

		index = (addr & cache[lev].next ->content.prof.indexmask) >> cache[lev].next ->content.prof.offset_width;
		tag = (addr & cache[lev].next ->content.prof.tagmask) >> (32 - cache[lev].next ->content.prof.tag_width);
		
		datagap = cache[lev].next ->content.entry_size / 4;
		index_width = cache[lev].next ->content.prof.index_width;
	}
	
	index1 = index | (1 << index_width);	
	index2 = index & (~(1 << index_width));
	pt1 = pt + index1;
	pt2 = pt + index2;	
	pd1 = pd + datagap * index1;
	pd2 = pd + datagap * index2;
	
	if(pt2 ->lut.v == 1)
	{
		uint32 tmpaddr = raddr_parse(pt2 ->lut.tag, index2,  mode, lev);
		upperdownfill(tmpaddr, mode, lev, delay_time);
		if (pt2 ->lut.d == 1 )              // DIRTY	
			// write to the next level			
			downfill_one_level(tmpaddr, mode, lev, delay_time);
	}		
	// write data to the according line	
	if(!fastmem)
		for ( int i = 0; i < datagap;i ++)
		{
			*(pd2 ++) = *pd1;
			*(pd1 ++ ) = * (data ++);
		}
	pt2 ->lut.v = pt1 ->lut.v;
	pt2 ->lut.d = pt1 ->lut.d;
	pt2 ->lut.tag = pt1 ->lut.tag;
	pt1 ->lut.v = 1;
	pt1 ->lut.d = 0;	
	pt1 ->lut.tag = tag;		
}
void 
CACHE::way_predict_replace(uint32 addr, int mode, int lev, uint32* data, uint8 *delay_time)
{
	cache_union * pt , *next_pt;
	uint32 *pd, *next_pd;
	int  datagap;
	uint32 tag, index;
	*delay_time = 0;
	if(!cache[lev].next || mode == INSTFETCH)
	{
		pt = cache[lev].content.cache_table;
		pd = cache[lev].content.cache_data;

		index = (addr & cache[lev].content.prof.indexmask) >> cache[lev].content.prof.offset_width;
		tag = (addr & cache[lev].content.prof.tagmask) >> (32 - cache[lev].content.prof.tag_width);
		
		datagap = cache[lev].content.entry_size / 4;
	}
	else
	{
		pt = cache[lev].next ->content.cache_table;
		pd = cache[lev].next ->content.cache_data;

		index = (addr & cache[lev].next ->content.prof.indexmask) >> cache[lev].next ->content.prof.offset_width;
		tag = (addr & cache[lev].next ->content.prof.tagmask) >> (32 - cache[lev].next ->content.prof.tag_width);
		
		datagap = cache[lev].next ->content.entry_size / 4;		
	}	

	
	pt += index * 2;
	pd += datagap * index * 2;	
	
	if (pt ->lut.w == 1)
	{ 
		next_pt = pt;
		next_pd = pd;
		pt ++;
		pd += datagap;
	}
	else
	{
		next_pt =  pt + 1;
		next_pd = pd + datagap;
	}	
	if(next_pt ->lut.v == 1)
	{
		uint32 tmpaddr = raddr_parse(next_pt ->lut.tag, index,  mode, lev);
		upperdownfill(tmpaddr, mode, lev,delay_time);
		if (next_pt ->lut.d == 1 )              // DIRTY	
			// write to the next level			
			downfill_one_level(tmpaddr, mode, lev, delay_time);
	}		
	// write data to the according line	
	if(!fastmem)
		for ( int i = 0; i < datagap;i ++)
		{
			*(next_pd ++) = *pd;
			*(pd ++ ) = * (data ++);
		}
	next_pt ->lut.v = pt ->lut.v;
	next_pt ->lut.d = pt ->lut.d;
	next_pt ->lut.tag = pt ->lut.tag;
	pt ->lut.v = 1;
	pt ->lut.d = 0;	
	pt ->lut.tag = tag;
}
void 
CACHE::replace_one_level(uint32 addr, int mode, int lev, uint32* data,uint8 *delay_time)
{
	int organize_policy,replace_policy;
	if(!cache[lev].next || mode == INSTFETCH)
	{
		organize_policy = cache[lev].content.organize_policy;
		replace_policy = cache[lev].content.replace_policy;
	}
	else
	{
		organize_policy = cache[lev].next ->content.organize_policy;
		replace_policy = cache[lev].next ->content.replace_policy;
	}
	switch(organize_policy)
	{
		case 0:
			switch(replace_policy)
			{
			 	case 0:
			 		random_replace(addr, mode,  lev,  data, delay_time);
			 		break;
			 	case 1:
			 		lru_replace(addr, mode,  lev,  data, delay_time);
			 		break;
			 	case 2:
			 		lilo_replace(addr, mode,  lev,  data, delay_time);
			 		break;
			}				
			break;
		case 1:
			pseudo_replace(addr, mode, lev, data, delay_time);			
			break;
		case 2:
			way_predict_replace(addr, mode, lev, data, delay_time);			
			break;					
	}	
}
/* upfill the cache entry from current level to level 0*/
void 
CACHE::upfill(uint32 addr, int mode, int cur_lev, uint8 *delay_time)
{	
	uint32 *pd;
	cache_union* pt;
	int tmptime;
	int i = cur_lev;
	
	if (cur_lev == level)
	{		
		memcache_to_cache(addr,  mode, delay_time);
		tmptime = *delay_time;
		i --;	
	}
	else
		tmptime = 0;

	if(!probe_one_level(addr, mode, i, &pd, &pt))		
		fatal_error("cache upfill error, start level  probe failed" );		
	
	uint32 cur_size,up_size,mask,off;
	
	while (i > 0)
	{
		if (!cache[i].next  || mode == INSTFETCH)
       	 	cur_size = cache[i].content.entry_size;
		else 
			cur_size = cache[i].next ->content.entry_size;	       	 
		if (!cache[i - 1].next  || mode == INSTFETCH)
			up_size = cache[i - 1] .content.entry_size;
		else
			up_size = cache[i - 1].next ->content.entry_size;	       	
		mask = cur_size - up_size;
		off = (addr & mask) >> log2(up_size);			
		pd += off * up_size / 4;
		replace_one_level(addr, mode, i -1, pd, delay_time);
		if(probe_one_level( addr, mode, i -1, &pd, &pt))					
			i --;		
		else
			fatal_error("cache upfill error after replaced , probe failed");
	}
	*delay_time = tmptime;
}

uint32 
CACHE:: adjust(uint32 addr)
{
	int32 index;
	memcache_entry *p;
	uint8 delay_time;
	uint32 tmptag = addr & PAGEMASK;
	if(memcache.freehd ->next != memcache.freehd)
	{
		p = memcache.freehd->next;
		index = p - memcache.table;
		p ->next->prev = memcache.freehd;
		memcache.freehd->next = p ->next;
	}
	else
	{
		p = memcache.hd->prev;
		index = p - memcache.table;
		if(p ->d)
			memcache_to_mem(index, &delay_time);
		p->prev->next = p->next;
		p->next->prev = p->prev;
	}
	p ->next = memcache.hd->next;
	p ->prev = memcache.hd;
	memcache.hd ->next = p;
	p ->next->prev = p;
	p ->d = 0;
	p ->v = 1;
//	p ->tag = addr & PAGEMASK;

	uint32 *q = memcache.barray;
	memcache_entry *tb = memcache.table;
	uint32 in = p->revindex;
	if(in > 0 &&  tb[q[in - 1]].tag > tmptag)
		while(in > 0 && tb[q[in - 1]].tag > tmptag)
		{
			q[in] = q[in-1];
			tb[q[in]].revindex = in ;
			in --;
		}
	else
		while(in < memcache.entry_num - 1  && tb[q[in + 1]].tag < tmptag)
		{
			q[in] = q[in + 1];
			tb[q[in]].revindex = in ;
			in ++;
		}
	q[in] = index;
	p->revindex = in;
	p ->tag = tmptag;
	return index;
}
uint32 
CACHE::mem_to_memcache(uint32 addr, int mode, uint8 * delay_time)
{
	uint32 index= adjust(addr);
	memstat ->SetStatBool(PBufHitMask, false);
	if(fastmem)
	{
		memstat ->SetAddr(addr);
		memstat ->SetStatBool(CacheableMask,true);
		if(mode == INSTFETCH)
		{
			memstat ->SetStatBool(InstOrData, true);
			memstat ->SetStatBool(ReadOrWrite,true);
		}
		else
		{
			memstat ->SetStatBool(InstOrData, false);
			if(mode == DATALOAD)
				memstat ->SetStatBool(ReadOrWrite, true);
			else
				memstat ->SetStatBool(ReadOrWrite, false);
		}
//		DBGTracer::recMissTrace(cpu);
		return index;
	}
	uint32 * data = memcache.data + index * PAGESIZE / 4;
	uint32 vaddr = addr & PAGEMASK;
	
	if(clkmem ->getdramstart() && inmem(vaddr))
	{
		int len = clkmem ->getbslen();
		int number = PAGESIZE / (8 * len);			
		if(number  == 0)
			fatal_error("The cache line is less than the burst length\n");		 
		for(int i = 0; i < number; i ++)		
			clkmem ->readdram(vaddr + i * 8 * len , (uint64*)data + i * len, delay_time);		
		memdelay = (clkmem ->getfreq()) * (*delay_time);
	}
	else
	{
		Range *l = NULL;
		uint32 offset1, offset2;
		l = mapper ->find_mapping_range(vaddr);		
		if (!l)
		{
			cpu->exception(mode == INSTFETCH ? IBE : DBE,mode);			
			return 0xffffffff;	
		}		
		offset1 = vaddr - l->getBase();		
		offset2 = vaddr + PAGESIZE - l ->getBase();
		if (!(l && l->canRead(offset1) && l->canRead(offset2))) 
		{			
				/* Reads from nonexistent or write-only ranges return ones */	
			return 0xffffffff;		
		}
		for (int i = 0; i < PAGESIZE / 4; i ++)
			*(data + i) = mapper ->host_to_mips_word(l->fetch_word(offset1 + i * 4, 
																mode, cpu));
//			*(data + i) = mapper->fetch_word(vaddr + i * 4, mode, 0, cpu);	
		*delay_time = 0;
	}
	return index;
}
void
CACHE::memcache_to_mem(uint32 index, uint8 * delay_time)
{
	uint32 vaddr = memcache.table[index].tag;
	uint32 * data = memcache.data + index * PAGESIZE / 4;
	if(clkmem ->getdramstart() && inmem(vaddr))
	{
		int len = clkmem ->getbslen();
		int number =PAGESIZE / (8 * len);
		if(number  == 0)
			fatal_error("The cache line is less than the burst length\n");
		for(int i = 0; i < number; i ++)
			clkmem ->writedram(vaddr + i * 8 *len, (uint64*)(data + i * 2 * len), delay_time);
	}
	else
	{
		Range *l = NULL;
		uint32 offset1, offset2;
		l = mapper ->find_mapping_range(vaddr);
		if (!l) 
		{
			cpu->exception(DBE,DATASTORE);
			return;
		}
		offset1 = vaddr - l->getBase();
		offset2 = vaddr + PAGESIZE - l ->getBase();
		if (!(l && l->canWrite(offset1) && l ->canWrite(offset2)))
		{
			fprintf(stderr, "Writing bad memory: 0x%08x\n", vaddr);
			return;
		}
		for (int i = 0; i < PAGESIZE / 4; i ++)	
			l->store_word(offset1 + i * 4,mapper ->mips_to_host_word(*(data + i)),cpu);
		*delay_time = 0;
	}	
	memcache.table[index].d = 0;
}
void
CACHE::flush_memcache(uint32 addr)
{
	uint32 tmpaddr = addr & PAGEMASK;
	uint32 index;
	uint8 delay_time;
	if(probe_memcache(tmpaddr, &delay_time, &index))	
		if(memcache.table[index].d)
			memcache_to_mem(index, &delay_time);				
}
void 
CACHE::inv_memcache(uint32 addr, uint8 * delay_time, bool flushable)
{
	uint32 index;
	if(probe_memcache(addr, delay_time, &index))
	{
		memcache.table[index].v = 0;
		memcache.table[index].prev ->next = memcache.table[index].next;
		memcache.table[index].next ->prev = memcache.table[index].prev;
		
		memcache.table[index].next = memcache.freehd->next;
		memcache.table[index].prev = memcache.freehd;
		memcache.freehd->next = &(memcache.table[index]);
		memcache.table[index].next->prev = &(memcache.table[index]);

		if(memcache.table[index].d)
			if(flushable)
				memcache_to_mem(index, delay_time);
			else
				fatal_error("dirty in memcache, but invalidate directly\n");
	}		
}
bool
CACHE::probe_memcache(uint32 addr,  uint8 * delay_time, uint32* index)
{	
	uint32 tmpaddr = addr & PAGEMASK;
	uint32 *p = memcache.barray;
	memcache_entry *tb = memcache.table;
	if(tb[last_memcache].tag == tmpaddr &&  tb[last_memcache].v)
	{
		*index = last_memcache;
		return true;
	}
	int low, hig, mid;	
	low = 0;
	hig =  memcache.entry_num - 1;	
	
	
	while( low <= hig)
	{
		mid = (low + hig) /2 ;
		if (tb[p[mid]].tag <  tmpaddr)
			low = mid + 1;
		else
			hig = mid - 1;
	}	
	while(tb[p[low]].tag == tmpaddr && low < (int)memcache.entry_num)
	{
		if(tb[p[low]].v)
		{
			*index = p[low];
			last_memcache = p[low];
			memstat ->SetStatBool(CacheInvMask,false);
			return true;
		}
		else
			memstat ->SetStatBool(CacheInvMask,true);
		low ++ ;
	}	
	memstat ->pbuf_miss_times ++;
	return false;
}
void 
CACHE::cache_to_memcache(uint32 addr, int mode, uint8 *delay_time)
{
//	Range * l = NULL;
	uint32 vaddr;	
	int entry_size,mask;
//	int32 offset1, offset2;
	uint32 *pd;
	cache_union *pt;
	uint32 index;
	if(!cache[level - 1].next || mode == INSTFETCH)		
		entry_size = cache[level - 1].content.entry_size;
	else
		entry_size = cache[level - 1].next->content.entry_size;
	
	mask = ~(entry_size - 1);	
	vaddr = addr & mask;
	if(!probe_one_level( addr,  mode,  level - 1 , &pd, &pt))
		fatal_error("cache to memcache, but there isn't an entry in cache");
	if(!probe_memcache(addr, delay_time, &index))
		index = mem_to_memcache(addr, mode, delay_time);	
	uint32 start_addr = (index * PAGESIZE + vaddr % PAGESIZE) / 4;  // start_addr is correct? devide by 4 or not?
	if(!fastmem)
		for(int i = 0; i < entry_size / 4; i ++)
			memcache.data[start_addr + i] = *(pd + i);
	
	memcache.table[index].d = pt ->lut.d;
	pt->lut.d = 0;	
	
}
void 
CACHE::memcache_to_cache(uint32 addr,int32 mode, uint8 *delay_time)
{
	
//	Range *l = NULL;
//	uint32 offset1, offset2;
	int mask ,entry_size;
	uint32 vaddr;

	if(!cache[level - 1].next || mode == INSTFETCH)		
		entry_size = cache[level - 1].content.entry_size;
	else
		entry_size = cache[level - 1].next->content.entry_size;
	
	mask = ~(entry_size - 1);	
	vaddr = addr & mask;	

	uint32 *data;
	uint32 index;
	if(probe_memcache(addr, delay_time, &index))
	{
		if(memcache.hd ->next != &(memcache.table[index]))
		{
			memcache.table[index].prev ->next = memcache.table[index].next;
			memcache.table[index].next ->prev = memcache.table[index].prev;
		
			memcache.table[index].next = memcache.hd ->next;
			memcache.table[index].prev = memcache.hd;
			memcache.hd ->next = &(memcache.table[index]);
			memcache.table[index].next->prev = &(memcache.table[index]);
		}
	}
	else
		index = mem_to_memcache( addr, mode, delay_time);	
	data = memcache.data + (index * PAGESIZE + vaddr % PAGESIZE) / 4;  // start_addr is correct? devide by 4 or not?

	replace_one_level(addr, mode, level - 1,  data, delay_time);
	if(mode == INSTFETCH)
		*delay_time = memdelay + delaytime[level - 1][0];
	else
		*delay_time = memdelay + delaytime[level - 1][1];
	uint32 * pd;
	cache_union *pt;
	if(!probe_one_level(addr,  mode, level - 1,&pd, &pt ))
		fatal_error("CACHE error, affter memory to cache, cache probe failed");	 
}

void
CACHE::read(uint32 addr, int32 mode, uint32 *data, uint8 *delay_time)
{		
	int hit_level;
	uint32 * pd;
	cache_union *pt;			
	uint8 tmptime =0;
	
	if(!probe(addr, mode, &pd,&pt, &hit_level) )	
	{
		memstat ->SetStatBool(CacheHitMask,false);		
		hit_level = level;
		upfill(addr, mode, hit_level,delay_time);		
		tmptime = *delay_time;
	}
	else
	{
		memstat ->SetStatBool(CacheHitMask,true);	
		if(mode == INSTFETCH)
			tmptime = delaytime[hit_level][0];
		else
			tmptime = delaytime[hit_level][1];
		if(hit_level !=  0)
			upfill(addr, mode, hit_level,delay_time);			
	}
	memstat ->SetHitLev((uint8)hit_level, mode);	
	if(!probe_one_level(addr, mode, 0, &pd, &pt))
		fatal_error("cache error in upfill, can't find the entry in level 0");
	if(!fastmem)
	{
		int mask;
		if(!cache[0].next  || mode == INSTFETCH)
			mask = cache[0].content.prof.offsetmask;
		else
			mask = cache[0].next ->content.prof.offsetmask;
		int off = (addr & mask) >> 2;
		*data = * (pd + off) ;			
		*delay_time = tmptime;
	}
/*	
	uint32 tmpaddr = addr & 0xfffffffcUL;
	uint32 tmpdata = mapper ->fetch_word(tmpaddr, mode, 0, cpu);
	if((pt->lut.d == 0) && (tmpdata  != *data))	
		fatal_error("read the different data from cahce\n");
*/
}
void
CACHE::write(uint32 addr, int32 mode, uint32 data,uint8 *delay_time)
{
	int hit_level;
	cache_union * pt;
	uint32 * pd;	
	int8 tmptime;
	
	if (! probe(addr, mode, &pd, &pt, &hit_level))		
	{
	       memstat ->SetStatBool(CacheHitMask,false);	
		hit_level = level;
		upfill(addr, mode,  hit_level, delay_time);
		tmptime = *delay_time;
	}
	else
	{
		memstat ->SetStatBool(CacheHitMask,true);	
		if(mode == INSTFETCH)
			tmptime = delaytime[hit_level][0];
		else
			tmptime = delaytime[hit_level][1];
		if(hit_level !=  0)
			upfill(addr, mode, hit_level,delay_time);			
	}
	memstat ->SetHitLev((uint8)hit_level, mode);
	if(!probe_one_level(addr, mode, 0, &pd, &pt))
		fatal_error("after upfill, can't find in level 0\n");	
	/*Now we can sure the first level cache contian the address that we want to write*/
	int offset_width;
	if(!cache[0].next || mode == INSTFETCH)
		offset_width= log2(cache[0].content.entry_size / 4);
	else
		offset_width = log2(cache[0].next ->content.entry_size/4);
	int mask = ((1 << offset_width) -1) << 2;
	int off = (addr & mask) >> 2;
	*(pd + off) = data;
	if(!fastmem)
		pt ->lut.d = 1;
	pt ->lut.v = 1;
	
	bool write_through ;
	if (!cache[0].next || mode == INSTFETCH)
		write_through = cache[0].content.back_or_through? 0 : 1;
	else
		write_through = cache[0].next ->content.back_or_through? 0 : 1;
	if(write_through)					
		downfill_one_level(addr, mode, 0, delay_time);			
	*delay_time = tmptime;				
}
void 
CACHE::flush(uint32 start_addr, uint32 len)
{	
	uint32 *pd;
	cache_union * pt;		
	uint32 tmp_saddr, tmp_eaddr,end_addr;

	uint8 delay_time;   //may be modified in the future   jwxu
	
	end_addr = start_addr + len - 1;
	int i = 0;	
	while(i < level)
	{
		if(cache[i].next)
		{		
			/*the following flush the separated instr cache*/				
			tmp_saddr = start_addr;	
			tmp_eaddr = end_addr |(cache[i].content.entry_size - 1);
			while(tmp_saddr <= tmp_eaddr)
			{				
				if (probe_one_level(tmp_saddr, INSTFETCH, i, &pd,  &pt))				
					if (pt ->lut.d == 1)
						fatal_error("flush %d instr cache , but its diry, addr ->0x%x\n", i,tmp_saddr);	
				tmp_saddr += cache[i].content.entry_size;					
			}		
			
			/*the following flush the separated data cache*/				
			tmp_saddr = start_addr;
			tmp_eaddr = end_addr |(cache[i].next ->content.entry_size -1);
			while(tmp_saddr <= tmp_eaddr)
			{				
				if (probe_one_level(tmp_saddr, DATALOAD, i, &pd,  &pt))		
				{
					if (pt ->lut.d == 1 )
					{						
						downfill_one_level(tmp_saddr, DATALOAD, i , &delay_time);						
						pt ->lut.d = 0;						
					}					
				}
				tmp_saddr += cache[i].next ->content.entry_size;
			}			
		}
		/*the united cache*/
		else
		{
			
			tmp_saddr = start_addr;
			tmp_eaddr = end_addr | (cache[i].content.entry_size -1);
			while(tmp_saddr <= tmp_eaddr)
			{				
				if (probe_one_level(tmp_saddr, DATALOAD, i, &pd ,  &pt ))						
				{
					if (pt  ->lut.d == 1)
					{						 
						downfill_one_level(tmp_saddr,DATALOAD, i , &delay_time);						
						pt ->lut.d = 0;						
					}					
				}
				tmp_saddr += cache[i].content.entry_size;
			}	
		}
		i ++;						
	}
	tmp_saddr = start_addr;
	tmp_eaddr = end_addr | (PAGESIZE - 1);
	while(tmp_saddr <= tmp_eaddr)
	{				
		flush_memcache(tmp_saddr);
		tmp_saddr += PAGESIZE;
	}
	
}

void
CACHE::flush(int mode)
{
	cache_union * pt;
	uint8 delay_time;
	uint32 index, tmpaddr;
	int i = 0;
	if(mode == INSTFETCH)
	{
		while ( i < level)
		{
			if(cache[i].next)
			{
				pt = cache[i].next ->content.cache_table;
				for (int j = 0; j < cache[i].next ->content.entry_number; j ++)
					if((pt + j) ->lut.d)
					{
						if(cache[i].next ->content.organize_policy == 0)
							index = j / cache[i].next ->content.associative_number;
						else
							index = j / 2;
						tmpaddr = raddr_parse((pt + j) ->lut.tag, index, DATALOAD, i);
						downfill_one_level(tmpaddr, DATALOAD, i , &delay_time);					
					}
			}
			pt = cache[i].content.cache_table;
			for (int j = 0; j < (cache[i].content.entry_number); j ++)
				if((pt + j) ->lut.d)
				{
					if(cache[i].content.organize_policy == 0)
						index = j / cache[i].content.associative_number;
					else
						index = j / 2;
					tmpaddr = raddr_parse((pt + j) ->lut.tag, index, INSTFETCH, i);
					downfill_one_level(tmpaddr, INSTFETCH, i , &delay_time);		
				}
			i ++;
		}
	}
	else
	{
		while ( i < level)
		{			
			pt = cache[i].content.cache_table;
			for (int j = 0; j < (cache[i].content.entry_number); j ++)
				if((pt + j) ->lut.d)
				{
					if(cache[i].content.organize_policy == 0)
						index = j / cache[i].content.associative_number;
					else
						index = j / 2;
					tmpaddr = raddr_parse((pt + j) ->lut.tag, index, INSTFETCH, i);
					downfill_one_level(tmpaddr, INSTFETCH, i , &delay_time);		
				}			
			if(cache[i].next)
			{
				pt = cache[i].next ->content.cache_table;
				for (int j = 0; j < cache[i].next ->content.entry_number; j ++)
					if((pt + j) ->lut.d)
					{
						if(cache[i].next ->content.organize_policy == 0)
							index = j / cache[i].next ->content.associative_number;
						else
							index = j / 2;
						tmpaddr = raddr_parse((pt + j) ->lut.tag, index, DATALOAD, i);
						downfill_one_level(tmpaddr, DATALOAD, i , &delay_time);					
					}				
			}
			i ++;
		}
	}

	for(uint32 s = 0; s < memcache.entry_num;s++)		
		flush_memcache(memcache.table[s].tag);  
}

void 
CACHE::invalidate()
{
	cache_union * pt;
	int i = 0;
	while ( i < level)
	{
		if(cache[i].next)
		{
			pt = cache[i].next ->content.cache_table;
			for (int j = 0; j < cache[i].next ->content.entry_number; j ++)
				(pt + j) ->lut.v = 0;
		}
		pt = cache[i].content.cache_table;
		for (int j = 0; j < (cache[i].content.entry_number); j ++)
			(pt + j) ->lut.v = 0;		
		i ++;
	}

	uint8 delay_time;
	for(uint32 j = 0; j < memcache.entry_num; j ++)
		inv_memcache(memcache.table[j].tag, &delay_time, true);

}
void 
CACHE::invalidate(uint32 start_addr, uint32 len, bool flushable)
{
	uint32 * pd;
	cache_union * pt;		
	uint32 tmp_saddr, tmp_eaddr, end_addr;
	uint8 delay_time;
	int i = 0;	
	end_addr = start_addr + len -1;	
	while(i < level)
	{
		/*if the separated cache, do following */
		if(cache[i].next)
		{	
			/*the following invalidate the instr cahce */				
			tmp_saddr = start_addr;
			tmp_eaddr = end_addr | (cache[i].content.entry_size -1);
			while(tmp_saddr <= tmp_eaddr)
			{				
				if (probe_one_level(tmp_saddr, INSTFETCH, i, &pd, &pt ))							
				{					
					if (pt ->lut.d == 1 && ! flushable)							
						fatal_error("invalidate the dirty entry in %d instr cache , but its diry. addr ->0x%x\n", i,tmp_saddr);							
										
					upperdownfill( tmp_saddr, INSTFETCH,i , &delay_time);
					if(pt ->lut.d == 1)
					{
						downfill_one_level(tmp_saddr, INSTFETCH, i, &delay_time);
						pt ->lut.d = 0;
					}						
					pt ->lut.v = 0;
					pt ->lut.w = 0;							
						
				}
				tmp_saddr += cache[i].content.entry_size;
			}			
			
			/*the following invalidate the data cache*/			
			tmp_saddr = start_addr;
			tmp_eaddr = end_addr | (cache[i].next ->content.entry_size -1);
			while(tmp_saddr <= tmp_eaddr)
			{				
				if (probe_one_level(tmp_saddr, DATALOAD, i, &pd,  &pt))
				{									

					upperdownfill( tmp_saddr, DATALOAD, i, &delay_time);						
					if (pt ->lut.d == 1 )
					{
						downfill_one_level(tmp_saddr, DATALOAD, i , &delay_time);							
						pt ->lut.d = 0;	
					}
					pt ->lut.v = 0;	
					pt ->lut.w = 0;
				}
				tmp_saddr += cache[i].next ->content.entry_size;
			}	
		}	
		/*if the united cahce, do following*/
		else
		{			
			tmp_saddr = start_addr;
			tmp_eaddr = end_addr | (cache[i].content.entry_size -1);
			while(tmp_saddr <= tmp_eaddr)
			{				
				if (probe_one_level(tmp_saddr, DATALOAD, i, &pd,  &pt))	
				{					
					
					upperdownfill( tmp_saddr, DATALOAD,i , &delay_time);
					
					if (pt ->lut.d == 1 )
					{
						downfill_one_level(tmp_saddr, DATALOAD, i , &delay_time);						
						pt ->lut.d = 0;		
					}
						
					pt ->lut.v = 0;	
					pt ->lut.w = 0;
						
				}
				tmp_saddr += cache[i].content.entry_size;
			}	
		}			
		i ++;				
	}	
	tmp_saddr = start_addr;
	tmp_eaddr = end_addr | (PAGESIZE - 1);
	while(tmp_saddr <= tmp_eaddr)
	{				
		inv_memcache(tmp_saddr, &delay_time, true);
		tmp_saddr += PAGESIZE;
	}

}

CACHE::~CACHE()
{
	for ( int i = 0; i < level; i ++)
	{
		if(cache[i].next)
		{
			if(cache[i].next ->content.replace_policy == 2)
				free(cache[i].next ->content.cache_counter);
			if(cache[i].next ->content.replace_policy == 1)
				free(cache[i].next ->content.cache_lru);
			free(cache[i].next ->content.cache_data);
			free(cache[i].next ->content.cache_table);
			free(cache[i].next);
		}
		if(cache[i].content.replace_policy == 2)
			free(cache[i].content.cache_counter);
		if(cache[i].content.replace_policy == 1)
			free(cache[i].content.cache_lru);
		free(cache[i].content.cache_data);
		free(cache[i].content.cache_table);
		//free(cache);
	}
	free (cache);
	free(memcache.barray);
	free(memcache.data);
	free(memcache.table);
	free(memcache.freehd);
	free(memcache.hd);
}
