#ifndef LOCALTOREMOET_H
#define LOCALTOREMOET_H

#include "LibcLinuxTypes.h"
#include "RemoteServConst.h"

/*Initialization*/
void InitRemoteServ( );

/*libc functions*/
FILE* rslibcfopen(const char* filename,const char* filemode);
long rslibcfread(char* buf,long size,long num,FILE* fp);
long rslibcfwrite(char* buf,long size,long num,FILE* fp);
long rslibcfclose(FILE* fp);
long rslibcfseek(FILE* fp,long offset,long whence);
long rslibcftell(FILE* fp);
void rslibcrewind(FILE* fp);
long rslibcfeof(FILE* fp);
long rslibcfgetc(FILE* fp);
char* rslibcfgets(char* s,int n,FILE* fp);
long rslibcfputc(long c,FILE* fp);
long rslibcfputs(const char* s,FILE* fp);
char* rslibcgetcwd(char* buf, long size);
int rslibcchdir(const char* path);

/*Linux syscall*/
long rslinuxread(long fd,char * buf,long count);//v0==4003
long rslinuxwrite(long fd,const char * buf,long count);//v0==4004
long rslinuxopen(const char* filename,long flag,long mode);//v0==4005
long rslinuxclose(long fd);//v0==4006
long rslinuxunlink(const char* pathname);//v0==4010
long rslinuxtime(int* tloc);//v0==4013
long rslinuxlseek(long fd,long offset,long origin);//v0==4019
long rslinuxgetpid(void);//v0==4020
long rslinuxgetuid( );//v0==4024
long rslinuxaccess(const char * filename, int mode);//v0==4033
long rslinuxrename(const char * oldname, const char * newname);//v0==4038
long rslinuxtimes(struct tms* tbuf);//v0==4043
long rslinuxgetgid( );//v0==4047
long rslinuxgeteuid( );//v0==4049
long rslinuxgetegid( );//v0==4050
long rslinuxioctl(unsigned int fd, unsigned int cmd, unsigned long arg);//v0==4054
long rslinuxfcntl(long fd,long cmd,long arg);//v0==4055
long rslinuxgetrlimit(unsigned int resource, struct rlimitformips *rlim);//v0==4076
long rslinuxgetrusage(int who, struct rusageformips* ru);//v0==4077
long rslinuxftruncate(unsigned int fd, unsigned long length);//v0==4093
long rslinuxstat(char * filename, struct statformips* statbuf);//v0==4106
long rslinuxlstat(char * filename, struct statformips* statbuf);//v0==4107
long rslinuxfstat(unsigned int fd, struct statformips* statbuf);//v0==4108
long rslinuxnewuname(new_utsname_formips* name);//v0==4122
long rslinuxllseek(unsigned int fd, unsigned long offset_high,
	unsigned long offset_low, loff_t * result, unsigned int origin);//v0==4140
long rslinuxselect(int n, fd_set *inp, fd_set *outp, fd_set *exp, struct timeval *tvp);//v0==4142
long rslinuxftruncate64(unsigned int fd, loff_t length);//v0==4212
long rslinuxstat64(char * filename, struct stat64formips* statbuf, long flags);//v0==4213
long rslinuxlstat64(char * filename, struct stat64formips* statbuf, long flags);//v0==4214
long rslinuxfstat64(long fd,struct stat64formips* statbuf,long flags);//v0==4215
long rslinuxfcntl64(long fd,long cmd,long arg);//v0==4220

/*TopsyAssistantServer:some assistant functions used in Topsy*/
void rsTAioConsolePutString(char* buf);
void rsTAioConsolePutHexInt(long num);
void rsTAstringout(char* buf);
char* rsTAstringin(char* buf,long maxcount);
//when returning 0:failed  1:ok
long rsTARedirectStdIO(long stdinto, long stdoutto, long stderrto);
void rsTADeRedirectStdIO( );
//when returning 0:failed  1:ok
long rsTAChangeCWD(const char* pathname);
void rsTARecoverCWD( );
void rsTAprintfnull(const char* str); //to stdout
void rsTAprintfstr(const char* mode, const char* str); //to stdout
void rsTAprintfnum(const char* mode, long num); //to stdout
long rsTAgetcwd(char* buf, long size, long mode);
void rsTAlssimulation(char* format);
char* rsTAgetenv(char* envname,char* buf,long maxlen);
long rsTAchstdiobyname(char* stdinname,char* stdoutname,
	char* stderrname,bool inheritflag);

#endif

