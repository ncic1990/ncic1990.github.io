#include "hwparaforos.h"
#include "Klocaltoremoteinit.h"
#include "Support.h"
#include "cpu.h"

//#define DEBUGHWCONFIG

/*slfsmm031031_add>memory*/
long totalmemory;
long PHYSMEM;
long USERMEM;
long PAGETABLEPHYSBASE;
/*slfsmm031031_add<*/

/*slfsmm031107_add>*/
//tlb
long TLB_SIZE;
long TLB_SAFE_SIZE;
long TLB_USER_BASE;
long TLB_USER_SIZE;

//if true start virtserv,otherwise remoteserv
long VIRTSERVFLAG;

struct hwparalayout_t hwparalayout;

//some assistant functions
void stdio_convert(stdio_t* stdioinfoptr)
{
	stdioinfoptr->stdinname+=K1SEG_BASE;
	stdioinfoptr->stdoutname+=K1SEG_BASE;
	stdioinfoptr->stderrname+=K1SEG_BASE;
}
void stdio_zeromem(stdio_t* stdioinfoptr)
{
	long len;

	len=stringlen(stdioinfoptr->stdinname);
	zeroOut(stdioinfoptr->stdinname,len);
	len=stringlen(stdioinfoptr->stdoutname);
	zeroOut(stdioinfoptr->stdoutname,len);
	len=stringlen(stdioinfoptr->stderrname);
	zeroOut(stdioinfoptr->stderrname,len);
}

//note:should be done before any IO/Libc/LinuxSyscall
void gethwparaforos( )
{
	struct hwparalayout_t zerolayout={0,0,0,0,{0,0,0,0}};//set other parameters to zero when added
	hwparalayout=*((struct hwparalayout_t*)(K1SEG_BASE+HWPARABASE));
	*((struct hwparalayout_t*)(K1SEG_BASE+HWPARABASE))=zerolayout;

	//start virtserv or remoteserv:note:should be done before any IO/Libc/LinuxSyscall
	VIRTSERVFLAG=hwparalayout.virtservflag;
	VIRTSERVFLAG=(VIRTSERVFLAG==0)?0:1;
	/*slfsmm031125_add>Initialiazation of remote server*/
	stdio_convert(&hwparalayout.stdioinfo);
	InitRemoteServ(&hwparalayout.stdioinfo);
	stdio_zeromem(&hwparalayout.stdioinfo);
	/*slfsmm031125_add<*/
	if(VIRTSERVFLAG)
	ioConsolePutString("start virtserv.\n");
	else
	ioConsolePutString("start remoteserv.\n");
	#ifndef DEBUGHWCONFIG
	ioConsolePutString("\n");
	#endif

	#ifdef DEBUGHWCONFIG
	ioConsolePutString("get hardware parameters for os begins...\n");
	#endif
	/*slfsmm031031_add>*/
	totalmemory=hwparalayout.memsize;
	PHYSMEM=totalmemory;
	#ifdef DEBUGHWCONFIG
	ioConsolePutString("total memory size:0x");
	ioConsolePutHexInt(PHYSMEM);
	#endif
	USERMEM=PHYSMEM-KERNELMEM-PAGETABLEMEM;
	PAGETABLEPHYSBASE=PHYS_BASE+KERNELMEM;
	/*slfsmm031031_add<*/

	//tlb
	TLB_SIZE=hwparalayout.tlbentrynum;
	#ifdef DEBUGHWCONFIG
	ioConsolePutString("tlb entry number:0x");
	ioConsolePutHexInt(TLB_SIZE);
	#endif
	TLB_SAFE_SIZE=hwparalayout.tlbentrynumreserved;
	#ifdef DEBUGHWCONFIG
	ioConsolePutString("tlb entry number reserved:0x");
	ioConsolePutHexInt(TLB_SAFE_SIZE);
	#endif
	TLB_USER_BASE=TLB_SAFE_SIZE;
	TLB_USER_SIZE=TLB_SIZE-TLB_SAFE_SIZE;

	#ifdef DEBUGHWCONFIG
	ioConsolePutString("get hardware parameters for os ends!\n\n");
	#endif
	
}
/*slfsmm031107_add<*/

