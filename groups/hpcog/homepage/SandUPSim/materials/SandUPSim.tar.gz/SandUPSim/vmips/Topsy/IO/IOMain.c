/*
	Copyright (c) 1996-1997 Swiss Federal Institute of Technology, 
	Computer Engineering and Networks Laboratory. All rights reserved.

	TOPSY - A Teachable Operating System. 
		Implementation of a tiny and simple micro kernel for
		teaching purposes.

	Permission to use, copy, modify, and distribute this software and its
	documentation for any purpose, without fee, and without written 
	agreement is hereby granted, provided that the above copyright notice 
	and the following two paragraphs appear in all copies of this software.


	
	File:                  $Source: /work/cvs/cvsroot/Topsy/IO/IOMain.c,v $
 	Author(s):             George Fankhauser
 	Affiliation:           ETH Zuerich, TIK
 	Version:               $Revision: 1.1.1.1 $
 	Creation Date:         
 	Last Date of Change:   $Date: 2003/09/22 08:43:46 $      by: $Author: sgz $
	
	
*/

#include "IO.h"
#include "IOMain.h"
#include "IODevice.h"
#include "Syscall.h"
#include "Threads.h"
#include "Exception.h"

static void ioLoadDriver(int number, IODevice dev);

/* static device table with all the driver entry points
 * (similar to Unix' device switching table)
 * this could be replaced/enhanced later by a dynamic 
 * driver loader mechanism
 */ 
static IODeviceDesc ioDeviceTable[IO_DEVCOUNT] = {

#ifndef SIMOS

	{ "ttya", (Address)UART_A_BASE, 
		NULL, /* buffer must be allocated by driver */
		DUART, /* interrupt */
		(InterruptHandler)devSCN2681_interruptHandler, /* ttya and b */
		devSCN2681_read, devSCN2681_write, 
		devSCN2681_close, devSCN2681_init, 
		NULL /* private msg handler */,
	        FALSE, NULL /* data extension */ },
		
	{ "ttyb", (Address)UART_B_BASE, NULL, 
		-1, NULL, 
		devSCN2681_read, devSCN2681_write, 
		devSCN2681_close, devSCN2681_init, 
		NULL /* private msg handler */,
	        FALSE, NULL /* data extension */ }

#else

	{ "tty", (Address)0, NULL, DUART,
	  (InterruptHandler)simos_console_handler,
	  simos_console_read, simos_console_write,
	  simos_console_close, simos_console_init,
	  NULL, FALSE, NULL
	}

#endif

};

static HashList ioDevices;


/* IO thread main procedure */
void ioMain(ThreadArg arg) {

    int i;
    Error error;
    ThreadId t;
    ThreadId expectedFrom;
    Message msg, reply;
    DriverMessage driverMsg;

    ioDevices = hashListNew();

    ioConsolePutString("ioThread: loading ");
    ioConsolePutInt(IO_DEVCOUNT);
#ifndef SIMOS
    ioConsolePutString(" drivers...\n");
#else
    ioConsolePutString(" driver...\n");
#endif
    
    /* due to the centralized interrupt handling in certain UARTs we
     * need to know each other
     */
#ifndef SIMOS
    ioDeviceTable[IO_SERIAL_A].extension = &(ioDeviceTable[IO_SERIAL_B]);
#endif

    for (i = 0; i < IO_DEVCOUNT; i++) {
	if (ioDeviceTable[i].init != NULL) {
	    ioDeviceTable[i].init( &(ioDeviceTable[i]) );
	}
    }
    
    for (i = 0; i < IO_DEVCOUNT; i++) {
	ioLoadDriver(i, &(ioDeviceTable[i]));
    }
    
    while (TRUE) {
	expectedFrom = ANY;
	tmMsgRecv(&expectedFrom, ANYMSGTYPE, &msg, INFINITY);
	switch (msg.id) {
	case IO_OPEN:
	    error = hashListGet(ioDevices,  
			    	(void**)(&t), msg.msg.ioOpen.deviceNumber);

	    reply.id = IO_OPENREPLY;
	    if (error == HASHNOTFOUND) {
		reply.msg.ioOpenReply.errorCode = IO_OPENFAILED;
	    }
	    else {
		reply.msg.ioOpenReply.errorCode = IO_OPENOK;
	    }					
	    reply.msg.ioOpenReply.deviceThreadId = t;
	    tmMsgSend(msg.from, &reply);
	    break;
	case IO_CLOSE:
	    /* msg is forwarded to driver thread or fails if the id is wrong */
	    driverMsg.id = IO_DRIVERCLOSE;
	    driverMsg.clientThreadId = msg.from;
	    error = tmMsgSend(msg.msg.ioClose.deviceThreadId, 
						    (Message*)&driverMsg);
	    if (error != TM_MSGSENDOK) {
		reply.id = IO_CLOSEREPLY;
		reply.msg.ioCloseReply.errorCode = IO_CLOSEFAILED;
		tmMsgSend(msg.from, &reply);
	    }
	    /* drivers actions: send reply to syscaller, clean up */
	    break;
	case UNKNOWN_SYSCALL:
	    /* possible reply on garbage IO_CLOSE forward */
	    break;
	default:
	    /* return error */
	    reply.id = UNKNOWN_SYSCALL;
	    tmMsgSend(msg.from, &reply);
	}
    }
}

static void ioLoadDriver(int number, IODevice dev) {

    ThreadId t;

    if (dev->interruptHandler != NULL) {
	(void)tmSetInterruptHandler(dev->interrupt, dev->interruptHandler,dev);
    }
    
    /* main function is for all devices the same */
    if (tmStart( &t, (ThreadMainFunction)ioDeviceMain,
		    dev, dev->name) != TM_STARTOK) {
	ERROR("Driver could not be started\n");
    }
    /* track the numbers to be able to open drivers later */
    hashListAdd(ioDevices, (void*)t, number);
}
