#ifndef GATEKEEPER_H
#define GATEKEEPER_H

/* Additional Messages */
enum {
        GateKeeper1 = 200,
        GateKeeper2,
        GateKeeper3,
        GateKeeper4,
        GateKeeper5,
};
        
/* Message Types */
enum msgtype_t {
        CAR_ARRIVE = 10, /* Car is waiting at the bridge */
        CAR_LEAVE = 11,  /* Car has left the bridge */
        CAR_ENTER = 50,  /* Car has permission to enter the bridge */
};
        

enum { 
        MAX_CARS = 5,  /* MAX # of waiting cars */
        NO_CAR = -1,    /* Invalid car */
        CAR_ID_MIN = 100, /* Start car number */
        NORTH = 1,      /* Car went north*/
        SOUTH = -1,     /* Car went south */
        NONE = 0,       /* No car/s */
};

void GateKeeper();


#endif /* GATEKEEPER_H */
