/*
	Copyright (c) 1996-1997 Swiss Federal Institute of Technology, 
	Computer Engineering and Networks Laboratory. All rights reserved.

	TOPSY - A Teachable Operating System. 
		Implementation of a tiny and simple micro kernel for
		teaching purposes.

	Permission to use, copy, modify, and distribute this software and its
	documentation for any purpose, without fee, and without written 
	agreement is hereby granted, provided that the above copyright notice 
	and the following two paragraphs appear in all copies of this software.


	
	File:                  $Source: /work/cvs/cvsroot/Topsy/User/UserSupport.c,v $
 	Author(s):             C. Conrad 
 	Affiliation:           ETH Zuerich, TIK
 	Version:               $Revision: 1.1.1.1 $
 	Creation Date:         21.3.97
 	Last Date of Change:   $Date: 2003/09/22 08:43:46 $      by: $Author: sgz $
	
	
*/

#include "UserSupport.h"
#include "stdarg.h"

char *strcat(), *strncat(), *strchr(char *, char), *strncpy(), *cc2str(),
    *rindex();
char *strcpy(), *strichr(), *strdchr(), *strposn(), *getword(), *index();
char *strset(), *strrset(), *strrchr(), *strbalp(), *strrpset(),
    *strpbrk();
char *strtok();
int strequ(), strlequ(), strlen(), strpat();



char *strchr(char *p, char c)
{

	if (!p)
		return (0);

	for (; *p; p++)
		if (*p == c)
			return (p);
	return (0);
}


int isdigit(int c)
{
	if (c >= '0' && c <= '9')
		return (1);
	return (0);
}

int strncmp(s1, s2, n)
char *s1, *s2;
int n;
{

	if (!s1 || !s2)
		return (0);

	while (n && (*s1 == *s2)) {
		if (*s1 == 0)
			return (0);
		s1++;
		s2++;
		n--;
	}
	if (n)
		return (*s1 - *s2);
	return (0);
}


char *strcpy(char *dstp, const char *srcp)
{
	char *dp = dstp;

	if (!dstp)
		return (0);
	*dp = 0;
	if (!srcp)
		return (dstp);

	while ((*dp++ = *srcp++) != 0);
	return (dstp);
}

void strtoupper(char *p)
{
	if (!p)
		return;
	for (; *p; p++)
		*p = toupper(*p);
}


void str_fmt(char *p, int size, int fmt)
{
	int n, m, len;

	len = strlen(p);
	switch (fmt) {
	case FMT_RJUST:
		for (n = size - len; n > 0; n--)
			strichr(p, ' ');
		break;
	case FMT_LJUST:
		for (m = size - len; m > 0; m--)
			strcat(p, " ");
		break;
	case FMT_RJUST0:
		for (n = size - len; n > 0; n--)
			strichr(p, '0');
		break;
	case FMT_CENTER:
		m = (size - len) / 2;
		n = size - (len + m);
		for (; m > 0; m--)
			strcat(p, " ");
		for (; n > 0; n--)
			strichr(p, ' ');
		break;
	}
}

static char *_getbase(char *, int *);
static int _atob(unsigned long *, char *, int);
static char *_getbase(char *p, int *basep)
{
	if (p[0] == '0') {
		switch (p[1]) {
		case 'x':
			*basep = 16;
			break;
		case 't':
		case 'n':
			*basep = 10;
			break;
		case 'o':
			*basep = 8;
			break;
		default:
			*basep = 10;
			return (p);
		}
		return (p + 2);
	}
	*basep = 10;
	return (p);
}


/*************************************************************
 *  _atob(vp,p,base)
 */
static int _atob(unsigned long *vp, char *p, int base)
{
	unsigned long value, v1, v2;
	char *q, tmp[20];
	int digit;

	if (base == 16 && (q = strchr(p, '.')) != 0) {
		if (q - p > sizeof(tmp) - 1)
			return (0);
		strncpy(tmp, p, q - p);
		tmp[q - p] = '\0';
		if (!_atob(&v1, tmp, 16))
			return (0);
		q++;
		if (strchr(q, '.'))
			return (0);
		if (!_atob(&v2, q, 16))
			return (0);
		*vp = (v1 << 16) + v2;
		return (1);
	}
	value = *vp = 0;
	for (; *p; p++) {
		value *= base;
		if (*p >= '0' && *p <= '9')
			digit = *p - '0';
		else if (*p >= 'a' && *p <= 'f')
			digit = *p - 'a' + 10;
		else if (*p >= 'A' && *p <= 'F')
			digit = *p - 'A' + 10;
		else
			return (0);
		if (digit >= base)
			return (0);
		value += digit;
	}
	*vp = value;
	return (1);
}

/*************************************************************
 *  atob(vp,p,base) 
 *      converts p to binary result in vp, rtn 1 on success
 */
int atob(unsigned int *vp, char *p, int base)
{
#if __mips >= 3 && defined(_LONGLONG)
	unsigned long long v;
#else
	unsigned long v;
#endif

	if (base == 0)
		p = _getbase(p, &base);
	if (_atob(&v, p, base)) {
		*vp = (unsigned int) v;	/* should be 32-bit value */
		return (1);
	}
	return (0);
}



/*************************************************************
 *  llatob(vp,p,base) 
 *      converts p to binary result in vp, rtn 1 on success
 */
int llatob(unsigned long *vp, char *p, int base)
{
	if (base == 0)
		p = _getbase(p, &base);
	return _atob(vp, p, base);
}



/*************************************************************
 *  char *btoa(dst,value,base) 
 *      converts value to ascii, result in dst
 */
char *btoa(char *dst, unsigned int value, int base)
{
	char buf[34], digit;
	int i, j, rem, neg, extnd = 0;

	if (value == 0) {
		dst[0] = '0';
		dst[1] = 0;
		return (dst);
	}
	neg = 0;
	if (base == -10) {
		base = 10;
		if (value & (1L << 31)) {
			value = (~value) + 1;
			neg = 1;
		}
	}
	if (base == -16) {
		base = 16;
		extnd = 1;
	}
	for (i = 0; value != 0; i++) {
		rem = value % base;
		value /= base;
		if (rem >= 0 && rem <= 9)
			digit = rem + '0';
		else if (rem >= 10 && rem <= 36)
			digit = (rem - 10) + 'a';
		buf[i] = digit;
	}
	buf[i] = 0;
	if (neg)
		strcat(buf, "-");
	if (extnd)
		strcat(buf, "x0");

/* reverse the string */
	for (i = 0, j = strlen(buf) - 1; j >= 0; i++, j--)
		dst[i] = buf[j];
	dst[i] = 0;
	return (dst);
}

#if __mips >= 3
/*************************************************************
 *  char *btoa(dst,value,base) 
 *      converts value to ascii, result in dst
 */
char *llbtoa(char *dst, unsigned long value, int base)
{
	char buf[66], digit;
	int i, j, rem, neg, extnd = 0;

	if (value == 0) {
		dst[0] = '0';
		dst[1] = 0;
		return (dst);
	}
	neg = 0;
	if (base == -10) {
		base = 10;
#ifdef _LONGLONG
		if (value & (1LL << 63)) {
#else
		if (value & (1L << 63)) {
#endif
			value = (~value) + 1;
			neg = 1;
		}
	}
	if (base == -16) {
		base = 16;
		extnd = 1;
	}
	for (i = 0; value != 0; i++) {
		rem = (int) (value % base);
		value /= base;
		if (rem >= 0 && rem <= 9)
			digit = rem + '0';
		else if (rem >= 10 && rem <= 36)
			digit = (rem - 10) + 'a';
		buf[i] = digit;
	}
	buf[i] = 0;
	if (neg)
		strcat(buf, "-");

	if (extnd)
		strcat(buf, "x0");

/* reverse the string */
	for (i = 0, j = strlen(buf) - 1; j >= 0; i++, j--)
		dst[i] = buf[j];
	dst[i] = 0;
	return (dst);
}
#endif

/*************************************************************
 *  gethex(vp,p,n) 
 *      convert n hex digits from p to binary, result in vp, 
 *      rtn 1 on success
 */
int gethex(unsigned long *vp, char *p, int n)
{
	unsigned long v;
	int digit;

	for (v = 0; n > 0; n--) {
		if (*p == 0)
			return (0);
		v <<= 4;
		if (*p >= '0' && *p <= '9')
			digit = *p - '0';
		else if (*p >= 'a' && *p <= 'f')
			digit = *p - 'a' + 10;
		else if (*p >= 'A' && *p <= 'F')
			digit = *p - 'A' + 10;
		else
			return (0);
		v |= digit;
		p++;
	}
	*vp = v;
	return (1);
}

int toupper(int c)
{

	if (islower(c))
		return (c - ('a' - 'A'));
	return (c);
}

char *strichr(char *p, int c)
{
	char *t;

	if (!p)
		return (p);
	for (t = p; *t; t++);
	for (; t >= p; t--)
		*(t + 1) = *t;
	*p = c;
	return (p);
}

char *strcat(char *dst, char *src)
{
	char *d;

	if (!dst || !src)
		return (dst);
	d = dst;
	for (; *d; d++);
	for (; *src; src++)
		*d++ = *src;
	*d = 0;
	return (dst);
}


char *strncpy(char *dst, const char *src, int n)
{
	char *d;

	if (!dst || !src)
		return (dst);
	d = dst;
	for (; *src && n; d++, src++, n--)
		*d = *src;
	while (n--)
		*d++ = '\0';
	return (dst);
}

int islower(int c)
{
	if (c >= 'a' && c <= 'z')
		return (1);
	return (0);
}

/*************************************************************
 *  int vsprintf(d,s,ap)
 */
int vsprintf(char *d, const char *s, va_list ap)
{
	const char *t;
	char *p, *dst, tmp[40];
	unsigned int n;
	int fmt, trunc, haddot, width, base, longlong, extnd = 0;
#ifdef FLOATINGPT
	double dbl;

#ifndef NEWFP
	EP ex;

#endif
#endif

	dst = d;
	for (; *s;) {
		if (*s == '%') {
			s++;
			fmt = FMT_RJUST;
			width = trunc = haddot = longlong = 0;
			for (; *s; s++) {
				if (strchr("dobxXuplscefg%", *s))
					break;
				else if (*s == '#')
					extnd = 1;
				else if (*s == '-')
					fmt = FMT_LJUST;
				else if (*s == '0')
					fmt = FMT_RJUST0;
				else if (*s == '~')
					fmt = FMT_CENTER;
				else if (*s == '*') {
					if (haddot)
						trunc = va_arg(ap, int);
					else
						width = va_arg(ap, int);
				} else if (*s >= '1' && *s <= '9') {
					for (t = s; isdigit(*s); s++);
					strncpy(tmp, t, s - t);
					tmp[s - t] = '\0';
					atob(&n, tmp, 10);
					if (haddot)
						trunc = n;
					else
						width = n;
					s--;
				} else if (*s == '.')
					haddot = 1;
			}
			if (*s == '%') {
				*d++ = '%';
				*d = 0;
			} else if (*s == 's') {
				p = va_arg(ap, char *);

				if (p)
					strcpy(d, p);
				else
					strcpy(d, "(null)");
			} else if (*s == 'c') {
				n = va_arg(ap, int);

				*d = n;
				d[1] = 0;
			} else {
				if (*s == 'l') {
					if (*++s == 'l') {
						longlong = 1;
						++s;
					}
				}
				if (strchr("dobxXup", *s)) {
					if (*s == 'd')
						base = -10;
					else if (*s == 'u')
						base = 10;
					else if (*s == 'x' || *s == 'X')
						if (extnd)
							base = -16;
						else
							base = 16;
					else if (*s == 'o')
						base = 8;
					else if (*s == 'b')
						base = 2;
					else if (*s == 'p') {
						/* Cls: %p is like 0x%08x */
						*d++ = '0';
						*d++ = 'x';
						base = 16;
						width = 8;
						fmt = FMT_RJUST0;
					}
#if __mips >= 3
					if (longlong)
#ifdef _LONGLONG
						llbtoa(d,
						       va_arg(ap,
							      long long),
						       base);
#else				/* assume long is "long long" */
						llbtoa(d, va_arg(ap, long),
						       base);
#endif
					else
#endif
						btoa(d, va_arg(ap, int),
						     base);

					if (*s == 'X')
						strtoupper(d);
				}
			}
			if (trunc)
				d[trunc] = 0;
			if (width)
				str_fmt(d, width, fmt);
			for (; *d; d++);
			s++;
		} else
			*d++ = *s++;
	}
	*d = 0;
	return ((int) (d - dst));	/* result should be 32bit */
}



void printf(ThreadId tty, const char *fmt, ...)
{

	/*va_list args;
	int r;
	char pbuffer[256];

	va_start(args, fmt);

	r = vsprintf(pbuffer, fmt, args);

	va_end(args);

	display(tty, pbuffer);*/

}

void byteCopy(Address targetAddress,
	      Address sourceAddress, unsigned long int nbBytes)
{
	char *src = (char *) sourceAddress;
	char *tar = (char *) targetAddress;
	unsigned long int i;

	for (i = 0; i < nbBytes; i++) {
		*tar++ = *src++;
	}
}

void zeroOut(Address target, unsigned long int size)
{
	char *tar = (char *) target;
	unsigned long int i;

	for (i = 0; i < size; i++)
		*tar++ = 0;
}

void stringCopy(char *target, char *source)
{
	while ((*target++ = *source++) != '\0');
}

void stringNCopy(char *target, char *source, unsigned long int size)
{
	while (((*target++ = *source++) != '\0') && ((--size) > 1));
	*target = '\0';
}

int stringLength(char *s)
{
	int len = 0;

	if (s != NULL)
		while (*s++ != '\0')
			len++;

	return len;
}



void stringConcat(char *dest, char *source1, char *source2)
{
	char *ptr;
	ptr = dest;
	stringCopy(ptr, source1);
	ptr += stringLength(source1);
	stringCopy(ptr, source2);
}

void int2string(char *str, int i)
{
	int j, nrc;

	j = i;
	nrc = 0;
	while (j > 0) {
		nrc++;
		j = (j - (j % 10)) / 10;
	}
	if (i < 0) {
		nrc++;
		str[0] = '-';
	}
	if (i == 0)
		str[0] = '0';
	str[nrc + 1] = 0;
	while (nrc > 0) {
		str[--nrc] = (i % 10) + 48;
		i = (i - (i % 10)) / 10;
	}
}
void display(ThreadId tty, char *s)
{
	char comment[MAXCOMMENTSIZE];
	unsigned long int size = stringLength(s);

	ioWrite(tty, s, &size);
}

int stringCompare(char *a, char *b)
{
	int i = 0;
	if (a != NULL && b != NULL) {
		while ((a[i] != '\0') && (b[i] != '\0')) {
			if (a[i] < b[i])
				return BEFORE;
			if (a[i] > b[i])
				return AFTER;
			i++;
		}
		if (i > 0)
			return EQUAL;
		else
			return 0;
	}
	return 0;
}


int power(int base, int n)
{
	int p;
	for (p = 1; n > 0; --n)
		p *= base;
	return p;
}


int atoi(int *intValue, char *string)
{
	char *currentPtr = string;
	int counter = 0;
	int nbChars = 1;

	*intValue = 0;

	/* cur positioned on last byte not NULL */
	while (*(currentPtr + 1) != '\0') {
		counter++;
		currentPtr++;
		nbChars++;
	}

	while (counter >= 0) {
		if (*currentPtr == '-') {
			if (counter == 0) {
				*intValue *= (-1);
			} else {
				return -1;
			}
		} else {
			if (*currentPtr - '0' < 0 || *currentPtr - '0' > 9) {
				return -1;
			}
			*intValue +=
			    (*currentPtr -
			     '0') * (power(10, nbChars - counter - 1));
		}
		counter--;
		currentPtr--;
	}
	return 1;
}

int strlen(char *s)
{
	int len = 0;
	while (*s != '\0') {
		len++;
		s++;
	}
	return len;
}

void reverse(char s[])
{
	int c, i, j;
	for (i = 0, j = strlen(s) - 1; i < j; i++, j--) {
		c = s[i];
		s[i] = s[j];
		s[j] = c;
	}
}
void itoa(int n, char s[])
{
	int i, sign;

	if ((sign = n) < 0)
		n = -n;
	i = 0;
	do {
		s[i++] = n % 10 + '0';
	} while ((n /= 10) > 0);
	if (sign < 0)
		s[i++] = '-';
	s[i] = '\0';
	reverse(s);
}

/*void byteCopy( Address targetAddress,
               Address sourceAddress,
               unsigned long int nbBytes)
{
    char* src = (char*)sourceAddress;
    char* tar = (char*)targetAddress;
    unsigned long int i;
    
    for (i = 0; i < nbBytes; i++) {
        *tar++ = *src++;
    }
}*/
