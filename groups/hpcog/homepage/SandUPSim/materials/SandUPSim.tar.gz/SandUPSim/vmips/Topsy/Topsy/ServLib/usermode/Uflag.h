#ifndef UFLAG_H
#define UFLAG_H

#include "UVirtServ.h"
#include "URemoteServ.h"
#include "servlibopt.h"

#ifndef ALWAYSVIRT
//note:be sure not define the following as:
//#define COMMONVIRTSERVFLAG (*((long*)VIRT_REMOTE_PHYS))
//because VIRT_REMOTE_PHYS is also a define
#define COMMONVIRTSERVFLAG (*((long*)(VIRT_REMOTE_PHYS)))
#else
#define COMMONVIRTSERVFLAG 1
#endif

#endif

