/*This is the mem stat module of sand simulator, which is developed by
ASL group of NCIC;
Copyright 2003 by ASL NCIC */

#include "memstatreg.h"
#include "memstat.h"
#include "error.h"

Memstat::Memstat()
{
	trace_start = false;
	cache_lev = 0;
}
void 
Memstat::TraceStart()
{
	 trace_start = true;	 
	 if(cache_lev <= 0)
	 	fprintf(stderr,"\n\n\ncache level is wrong ?\n\n\n\n\n");
	 dcache_hit_times = (uint64*) malloc(cache_lev * 8);
	 icache_hit_times = (uint64*)malloc(cache_lev * 8);
	 
	 for(int i = 0; i < cache_lev; i ++)
 	{
	 	dcache_hit_times[i] = 0;
		icache_hit_times[i] = 0;
 	}
	 
	 tlb_miss_times = 0;
	 tlb_hit_times = 0;
	 icache_miss_times = 0;
	 dcache_miss_times = 0;
	 pbuf_miss_times = 0;
	 stat_info.counter = 0;
}
void 
Memstat::getcachelev(int lev)
{
	cache_lev = lev;
}
void 
Memstat::TraceEnd()
{
	trace_start = false;
}
int
Memstat::SetTraceMask(uint16 mask)
{
	int count = 0;
	mem_mask = mask;
	if(mask & BoolMask)
		count += 2;
	if(mask & CacheHitLevMask)
		count += 1;
	if(mask & HitTimeMask)
		count += 2;
	if(mask & AddrMask)
		count += 4;	
	if(mask & CounterMask)
		count += 8;
	if(mask & CachefcMask)
		count += 8;
	if(mask & CachescMask)
		count += 8;
	if(mask & CachemissMask)
		count += 8;
	buf = (uint8*)malloc(count);
	return count;
}

void 
Memstat::RefreshTrace()
{	
	stat_info.boolval.content = 0x0000;
	stat_info.addr = 0x00000000;
	stat_info.hit_time = 0x0000;
	stat_info.hitted_cache_level = 0x00;
	stat_info.fc_hit_times = 0x00;
	stat_info.sc_hit_times = 0x00;
}

void 
Memstat::ShowTrace()
{
	if(trace_start)
		{
		if(mem_mask & BoolMask)
			{			
			fprintf(stderr, "The bool stat value is:\n");
			fprintf(stderr, "Cached  = %4d\n", stat_info.boolval.val.cacheable);
			fprintf(stderr, "Cache hitted = %4d\n", stat_info.boolval.val.cache_hitted);
			fprintf(stderr, "Tlb hitted = %4d\n", stat_info.boolval.val.tlb_hitted);
			fprintf(stderr, "Tlb invalidated = %4d\n", stat_info.boolval.val.tlb_invalidate);
			fprintf(stderr, "Tlb modication = %4d\n", stat_info.boolval.val.tlb_modication);
			fprintf(stderr, "Vbuf hitted = %4d\n", stat_info.boolval.val.vbuf_hitted);
			fprintf(stderr, "Pbuf hitted = %4d\n", stat_info.boolval.val.pbuf_hitted);
			fprintf(stderr, "Block_matched = %4d\n", stat_info.boolval.val.block_matched);
			fprintf(stderr, "Page_faulted = %4d\n", stat_info.boolval.val.page_faulted);
			fprintf(stderr, "read or write = %4d\n", stat_info.boolval.val.read_or_write);
			fprintf(stderr, "inst or data = %4d\n", stat_info.boolval.val.inst_or_data);
			fprintf(stderr, "cache invalidated = %4d\n", stat_info.boolval.val.cacheinv);
			}
		if(mem_mask & CacheHitLevMask)
			fprintf(stderr, "Cache hitted level = %4d\n", stat_info.hitted_cache_level);			
		if(mem_mask & HitTimeMask)
			fprintf(stderr, "Hit time = %4d\n", stat_info.hit_time);			
		if (mem_mask & AddrMask)			
			fprintf(stderr, "addr = 0x%8x\n",stat_info.addr);
		if( mem_mask & CounterMask)
			fprintf(stderr, "counter = 0x%8llu\n",stat_info.counter);
		fprintf(stderr, "first cache hit times = 0x%8llu\n",stat_info.fc_hit_times);
		fprintf(stderr, "second cache hit times = 0x%8llu\n",stat_info.sc_hit_times);
		fprintf(stderr, "cache miss times = 0x%8llu\n",stat_info.cache_miss_times);
		}
}
void 
Memstat::ShowTrace(uint16 mask, STAT_INFO  stat)
{
	if(mask & BoolMask)
	{			
		fprintf(stderr, "The bool stat value is:\n");
		fprintf(stderr, "Cached  = %4d\n", stat.boolval.val.cacheable);
		fprintf(stderr, "Cache hitted = %4d\n", stat.boolval.val.cache_hitted);
		fprintf(stderr, "Tlb hitted = %4d\n", stat.boolval.val.tlb_hitted);
		fprintf(stderr, "Tlb invalidated = %4d\n", stat.boolval.val.tlb_invalidate);
		fprintf(stderr, "Tlb modication = %4d\n", stat.boolval.val.tlb_modication);
		fprintf(stderr, "Vbuf hitted = %4d\n", stat.boolval.val.vbuf_hitted);
		fprintf(stderr, "Pbuf hitted = %4d\n", stat.boolval.val.pbuf_hitted);
		fprintf(stderr, "Block_matched = %4d\n", stat.boolval.val.block_matched);
		fprintf(stderr, "Page_faulted = %4d\n", stat.boolval.val.page_faulted);
		fprintf(stderr, "read or write = %4d\n", stat.boolval.val.read_or_write);
		fprintf(stderr, "inst or data = %4d\n", stat.boolval.val.inst_or_data);
		fprintf(stderr, "cache invalidated= %4d\n", stat.boolval.val.cacheinv);
	}
	if(mask & CacheHitLevMask)
		fprintf(stderr, "Cache hitted level = %4d\n", stat.hitted_cache_level);			
	if(mask & HitTimeMask)
		fprintf(stderr, "Hit time = %4d\n", stat.hit_time);			
	if (mask &AddrMask)			
		fprintf(stderr, "Addr = 0x%8x\n",stat.addr);
	if( mask & CounterMask)
		fprintf(stderr, "counter = 0x%8llu\n",stat.counter);
	fprintf(stderr, "first cache hit times = 0x%8llu\n",stat.fc_hit_times);
	fprintf(stderr, "second cache hit times = 0x%8llu\n",stat.sc_hit_times);
	fprintf(stderr, "cache miss times = 0x%8llu\n",stat.cache_miss_times);
	fprintf(stderr, "\n");
}





/*
void 
Memstat::SetHitTime(uint16 hit_time)
{
	if(trace_start && (mem_mask & HitTimeMask))
		stat_info.hit_time = hit_time;
}
*/
/*
void 
Memstat::SetHitLev(uint8 hit_lev, int mode)
{
	if(trace_start && (mem_mask & CacheHitLevMask))
	{
		stat_info.hitted_cache_level = hit_lev;
		if (hit_lev == cache_lev)
		{
			cache_miss_times ++;
			return;
		}
		if (mode == 	INSTFETCH)
		{
			icache_hit_times[hit_lev] ++;
			return;
		}
		dcache_hit_times[hit_lev] ++;
		return;		
	}
	else
		stat_info.hitted_cache_level = 0;
}
*/
/*
void 
Memstat::SetStatBool(uint16 set_mask,bool val)
{
	uint16 nset_mask= ~set_mask;
	if(trace_start && (mem_mask & BoolMask))	
	{
	if(val)
		boolval |= set_mask;	
	else		
		boolval &= nset_mask;
	}
}
*/
/*
uint8* 
Memstat::GetTracebuf(void)
{
	uint8* p = buf;
	if(trace_start)
		{
		if(mem_mask & BoolMask)
			{			
			*(uint16*)p = boolval;
			p += 2;
			}
		if(mem_mask & CacheHitLevMask)
			{
			*(uint8*)p = stat_info.hitted_cache_level;
			p ++;
			}
		if(mem_mask & HitTimeMask)
			{
			*(uint16*)p = stat_info.hit_time;
			p += 2;
			}
		if (mem_mask & InstAddrMask)
			{
			*(uint32*)p = stat_info.instr_addr;
			p += 4;
			}
		if (mem_mask & DataAddrMask)
			{
			*(uint32*)p = stat_info.data_addr;
			p += 4;
			}	
		if (mem_mask & TimeCounterMask)
			{
			*(uint32*)p = stat_info.instcounter;
			p += 8;
			}
		}
	return buf;
}
*/
/*
STAT_INFO
Memstat::RecoverTrace(uint8 mask, uint8* data)
{
	STAT_INFO  result;
	uint8* p = data;
	if(mask & BoolMask)
		{
		uint16 boolval = *(uint16*)p;
		p += 2;
		result.cacheable = boolval & CacheableMask;
		result.cache_hitted = boolval & CacheHitMask;
		result.tlb_hitted = boolval & TlbHitMask;
		result.tlb_invalidate = boolval & TlbINVMask;
		result.tlb_modication = boolval & TlbModifyMask;
		result.vbuf_hitted = boolval & VBufHitMask;
		result.pbuf_hitted = boolval & PBufHitMask;
		result.block_matched = boolval & BlockHitMask;
		result.page_faulted = boolval & PageFaultMask;
		}
	if(mask & CacheHitLevMask)
		{
		result.hitted_cache_level = * p;
		p ++;
		}
	if (mask & HitTimeMask)
		{
		result.hit_time = *(uint16*)p;
		p += 2;
		}
	if (mask & InstAddrMask)
		{
		result.instr_addr = *(uint32*)p;
		p += 4;
		}
	if (mask & DataAddrMask)
		{
		result.data_addr = *(uint32*)p;
		p += 4;
		}
	if (mask & TimeCounterMask)
		{
		result.instcounter = *(uint32*)p;
		p += 8;
		}
	return result;
}
*/


