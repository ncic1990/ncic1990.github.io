#ifndef __TMHAL_H
#define __TMHAL_H
/*
	Copyright (c) 1996-1997 Swiss Federal Institute of Technology, 
	Computer Engineering and Networks Laboratory. All rights reserved.

	TOPSY - A Teachable Operating System. 
		Implementation of a tiny and simple micro kernel for
		teaching purposes.

	Permission to use, copy, modify, and distribute this software and its
	documentation for any purpose, without fee, and without written 
	agreement is hereby granted, provided that the above copyright notice 
	and the following two paragraphs appear in all copies of this software.


	
	File:                  $Source: /work/cvs/cvsroot/Topsy/Threads/mips/TMHal.h,v $
 	Author(s):             Christian Conrad
 	Affiliation:           ETH Zuerich, TIK
 	Version:               $Revision: 1.20 $
 	Creation Date:         
 	Last Date of Change:   $Date: 2003/12/26 08:23:58 $
	
	
*/

#include "tm-include.h"
#include "cpu.h"
#include "Exception.h"
#include "Configuration.h"

#define MAXNBOFEXCEPTIONS    32
#define MAXNBOFINTERRUPTS     8

#ifndef SIMOS

#define STATUS_INT_ENABLE_KERNEL_PREV (SR_IEp | (SR_KUp & 0))
#define STATUS_INT_ENABLE_USER_PREV (SR_IEp | SR_KUp)

#else /* SIMOS, R4000 */

#define STATUS_INT_ENABLE_KERNEL_PREV (SR_IE | SR_KSU_KERNEL | SR_EXL)
#define STATUS_INT_ENABLE_USER_PREV (SR_IE | SR_KSU_USER | SR_EXL)

#endif

/* Processor dependent thread information */
typedef struct ProcContext_t {
    Register returnValue[2];       /* v0 - v1 */
    Register argument[4];          /* a0 - a3 */
    Register callerSaved[10];      /* t0 - t9 */
    Register calleeSaved[8];       /* s0 - s7 */
    Register globalPointer;        /* gp */
    Register stackPointer;         /* sp */
    Register framePointer;         /* fp */
    Register returnAddress;        /* ra */
    Register programCounter;       /* pc */
    Register hilo[2];              /* hi, lo multiplier registers */
    Register statusRegister;       /* sr after trapping */
    Register assemblerTemp;        /* assembler temp, used also by gcc */
} ProcContext;

/* Saving and restoring current thread context (assembler procedures) */
void saveContext(ProcContextPtr contextPtr);
void restoreContext(ProcContextPtr contextPtr);

/* operations on the thread context are machine dependent and 
 * encapsulated in the following functions. On CISC machines
 * most of these ops must be implemented using the current SP of
 * the context.
 */
void tmSetGP(ProcContextPtr contextPtr, Register value);
void tmSetReturnValue(ProcContextPtr contextPtr, Register value);
void tmSetStackPointer(ProcContextPtr contextPtr, Register value);
void tmSetReturnAddress(ProcContextPtr contextPtr, Register value);
void tmSetProgramCounter(ProcContextPtr contextPtr, Register value);
void tmSetStatusRegister(ProcContextPtr contextPtr, Register value);
void tmSetFramePointer(ProcContextPtr contextPtr, Register value);
void tmSetArgument0(ProcContextPtr contextPtr, Register value);
void tmSetArgument1(ProcContextPtr contextPtr, Register value);

void enableInterruptInContext( InterruptId intId, ProcContextPtr contextPtr);
void disableInterruptInContext( InterruptId intId, ProcContextPtr contextPtr);
void enableAllInterruptsInContext( ProcContextPtr contextPtr);

/* installs code by copying generalExceptionHandler()'s and 
 * UTLBMissHandler()'s code at certain mips specific addresses
 */
void tmInstallExceptionCode();

/*slfsmm>*/

/* Exception Context, used by the general exception handler before calling
 * saveContext(). This is a minimal save that allows to call saveContext as
 * a proper procedure.
 * - exceptionContext[0] <- a0
 * - exceptionContext[1] <- ra
 * - exceptionContext[2] <- sp
 * - exceptionContext[3] <- pc
 * - exceptionContext[4] <- tlbhi
 * - exceptionContext[5] <- t6 for store gp 2003-09-17
 */
/*move from file "TMHal.c"*/
#define EC_A0 0
#define EC_RA 1
#define EC_SP 2
#define EC_ESP 3
#define EC_BADVADDR  4
#define EC_GP 5
/*slfsmm031114_add>*/
#define EC_Linux_epc 6
#define EC_Linux_epc_off 24
#define EC_Linux_status 7
#define EC_Linux_status_off 28
#define EC_Linux_gp 8
#define EC_Linux_gp_off 32
/*slfsmm031114_add<*/
/*slfsmm031114_mod>*/
//unsigned int exceptionContext[6];
unsigned int exceptionContext[9];
/*slfsmm031114_mod>*/

/* Syscall exception handler (set per default as exception handler) */
void syscallExceptionHandler(ThreadId threadId);
/*slfsmm<*/

/* Hardware exception handler (set per default as exception handler) */
void hwExceptionHandler();

/* Automatic exit of a thread when stack underflow occurs */
void automaticThreadExit();
void endAutomaticThreadExit();

/*slfsmm>*/
#define MAXLINUXSYSCALL	256
//#ifndef REMOTESYSCALL
void HandleLinuxSysCall();
void SysCallNotImplemented();
void LinuxSyscallExit( );//v0==4001
void LinuxSyscallRead( );//v0==4003
void LinuxSyscallWrite( );//v0==4004
void LinuxSyscallOpen( );//v0==4005
void LinuxSyscallClose( );//v0==4006
void LinuxSyscallunlink( );//v0==4010
void LinuxSyscalltime( );//v0==4013
void LinuxSyscalllseek( );//v0==4019
void LinuxSyscallgetpid( );//v0==4020
/*slfsmm031021_add>*/
void LinuxSyscallgetuid( );//v0==4024
void LinuxSyscallaccess( );//v0==4033
void LinuxSyscallrename( );//v0==4038
void LinuxSyscalltimes( );//v0==4043
void LinuxSyscallgetgid( );//v0==4047
void LinuxSyscallgeteuid( );//v0==4049
void LinuxSyscallgetegid( );//v0==4050
void LinuxSyscallioctl( );//v0==4054
void LinuxSyscallfcntl( );//v0==4055
void LinuxSyscallsetrlimit( );//v0==4075
void LinuxSyscallgetrlimit( );//v0==4076
void LinuxSyscallgetrusage( );//v0==4077
void LinuxSyscallnewuname( );//v0==4122
/*slfsmm031021_add<*/
/*slfsmm031027_add>*/
void LinuxSyscallmprotect( );//v0==4125
void LinuxSyscallllseek( );//v0==4140
/*slfsmm031027_add<*/
/*slfsmm031025_add>*/
void LinuxSyscallfcntl64( );//v0==4220
/*slfsmm031025_add<*/
/*slfsmm002>*/
void LinuxSyscallbrk( );//v0==4045
void LinuxSyscallmmap( );//v0==4090
void LinuxSyscallmunmap( );//v0==4091
void LinuxSyscallftruncate( );//v0==4093
void LinuxSyscallstat( );//v0==4106
void LinuxSyscalllstat( );//v0==4107
void LinuxSyscallfstat( );//v0==4108
void LinuxSyscallnewselect( );//v0==4142
void LinuxSyscallnanosleep( );//v0==4166
void LinuxSyscallrt_sigaction( );//v0==4194
void LinuxSycallrt_sigprocmask( );//v0==4195
void LinuxSyscallmmap2( );//v0==4210
void LinuxSyscallftruncate64( );//v0==4212
void LinuxSyscallstat64( );//v0==4213
void LinuxSyscalllstat64( );//v0==4214
void LinuxSyscallfstat64( );//v0==4215
/*slfsmm002<*/
/*slfsmm<*/
//#endif

/* Symbols for the exception handlers (they are implemented in assembly) */
void UTLBMissHandler();
void endUTLBMissHandler();

void generalExceptionHandler();
void endGeneralExceptionHandler();

#endif /*__TMHAL_H*/

