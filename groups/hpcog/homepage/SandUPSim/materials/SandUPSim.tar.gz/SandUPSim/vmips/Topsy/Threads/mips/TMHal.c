/*
	Copyright (c) 1996-1997 Swiss Federal Institute of Technology, 
	Computer Engineering and Networks Laboratory. All rights reserved.

	TOPSY - A Teachable Operating System. 
		Implementation of a tiny and simple micro kernel for
		teaching purposes.

	Permission to use, copy, modify, and distribute this software and its
	documentation for any purpose, without fee, and without written 
	agreement is hereby granted, provided that the above copyright notice 
	and the following two paragraphs appear in all copies of this software.


	
	File:                  $Source: /work/cvs/cvsroot/Topsy/Threads/mips/TMHal.c,v $
 	Author(s):             Christian Conrad
 	Affiliation:           ETH Zuerich, TIK
 	Version:               $Revision: 1.4 $
 	Creation Date:         
 	Last Date of Change:   $Date: 2003/10/25 07:05:18 $      by: $Author: slfsmm $
	
	
*/

#include "TMHal.h"
#include "IOHal.h"
#include "Support.h"
#include "TMClock.h"
#include "TMScheduler.h"

/* Exception service branch table (exception handlers).
 * - 16 exception handlers,
 * - 16 reserved (not set)
 * - 1 UTLB handler (offset 32 in array) 
 */
ExceptionHandler exceptionHandlerTable[MAXNBOFEXCEPTIONS+1];

/*slfsmm>*/
LinuxSyscallHandler LinuxSyscallHandlerTable[MAXLINUXSYSCALL];
Message MsgForLinuxSyscall;
/*slfsmm:set parameter conversion handler*/
LinuxSyscallHandler tmSetLinuxSyscallHandler( int syscallno, 
					LinuxSyscallHandler syscallhandler)
{
    LinuxSyscallHandler oldHdler = LinuxSyscallHandlerTable[syscallno-4000];

    LinuxSyscallHandlerTable[syscallno-4000] = syscallhandler;
    return oldHdler;
}
/*slfsmm<*/

/* Hardware interrupt service branch table (interrupt handlers) and
 * corresponding arguments that may be passed to the interrupt handler.
 * - 6 hw interrupts
 * - 2 sw interrupts 
 */
InterruptHandler interruptHandlerTable[MAXNBOFINTERRUPTS];
void* interruptHandlerArgTable[MAXNBOFINTERRUPTS];

#ifndef SIMOS

/* 8254 Register Addressing structure */
typedef struct TimerRegisters_t{
    unsigned char counter0;
    unsigned char pad1[3];
    unsigned char counter1;
    unsigned char pad2[3];
    unsigned char counter2;
    unsigned char pad3[3];
    unsigned char ctrlWord;
    unsigned char pad4[3];
} TimerRegisters;

#endif

void tmInstallExceptionCode() 
{
    /* Installation of default basic exception handlers */
    /* INSTALL generalExceptionHandler AT LOCATION 0x8000_0080 */
    byteCopy( (Address)(K1SEG_BASE+0x80), generalExceptionHandler, 
	      endGeneralExceptionHandler-generalExceptionHandler);
    //ioConsolePutHexInt(endGeneralExceptionHandler);
    //ioConsolePutHexInt(generalExceptionHandler);

	
    /* INSTALL UTLBMissHandler AT LOCATION 0x8000_0000 */
    if (endUTLBMissHandler-UTLBMissHandler > 0x00000080) 
	PANIC("utlbmisshandler larger than 0x80 bytes");
    byteCopy( (Address)K1SEG_BASE, UTLBMissHandler,  
	      endUTLBMissHandler-UTLBMissHandler);

    /* RESETHandler AT LOCATION 0xbfc0_0000 is in EPROMs */
}    


InterruptHandler tmSetInterruptHandler( InterruptId intId, 
					InterruptHandler intHdler, void* arg)
{
    InterruptHandler oldIntHdler = interruptHandlerTable[intId];

    if (intId == SWINT_0 || intId == SWINT_1) {
	interruptHandlerTable[intId-6] = intHdler;
	interruptHandlerArgTable[intId-6] = arg;
    } else {
	interruptHandlerTable[intId+2] = intHdler;
	interruptHandlerArgTable[intId+2] = arg;
    }
    return oldIntHdler;
}


ExceptionHandler tmSetExceptionHandler( ExceptionId excId, 
					ExceptionHandler excHdler)
{
    ExceptionHandler oldExcHdler = exceptionHandlerTable[excId];

    exceptionHandlerTable[excId] = excHdler;
    return oldExcHdler;
}


void intDispatcher( Register causeReg)
{
    int offset=-1;

    causeReg &= CAUSE_IP_MASK;
    causeReg >>= CAUSE_IP_SHIFT;

    /* The invariant here is causeReg>0, otherwise an hardware
       error would have occurred */
    while (causeReg != 0) {
	causeReg >>= 1;
	offset += 1;
    }
    
    /* we call here the handler for interrupt offset with
     * its (optionally) defined argument
     */
    (interruptHandlerTable[offset])(interruptHandlerArgTable[offset]);

    tmResetClockInterrupt(offset-2);
}


void tmSetGP(ProcContextPtr contextPtr, Register value)
{
    contextPtr->globalPointer = value;
}

void tmSetReturnValue(ProcContextPtr contextPtr, Register value)
{
    contextPtr->returnValue[0] = value;
}

void tmSetStackPointer(ProcContextPtr contextPtr, Register value)
{
    contextPtr->stackPointer = value;
}

void tmSetReturnAddress(ProcContextPtr contextPtr, Register value)
{
    contextPtr->returnAddress = value;
}

void tmSetProgramCounter(ProcContextPtr contextPtr, Register value)
{
    contextPtr->programCounter = value;
}

void tmSetStatusRegister(ProcContextPtr contextPtr, Register value)
{
    contextPtr->statusRegister = value;
}

void tmSetFramePointer(ProcContextPtr contextPtr, Register value)
{
    contextPtr->framePointer = value;
}

void tmSetArgument0(ProcContextPtr contextPtr, Register value)
{
    contextPtr->argument[0] = value;
}

void tmSetArgument1(ProcContextPtr contextPtr, Register value)
{
    contextPtr->argument[1] = value;
}

void enableInterruptInContext( InterruptId intId, ProcContextPtr contextPtr)
{
    unsigned long int bitToSet = 1;
    
    if (intId < SWINT_0) {  /* either CLOCKINT, CENTRONICS, or DUART */
	bitToSet <<= (INTMASK_SHIFT+2+intId);
    } else {
	bitToSet <<= (INTMASK_SHIFT+intId-SWINT_0);
    }
    contextPtr->statusRegister |= bitToSet;
}
    
void disableInterruptInContext( InterruptId intId, ProcContextPtr contextPtr)
{
    unsigned long int bitToSet = 0;
    
    if (intId < SWINT_0) {  /* either CLOCKINT, CENTRONICS, or DUART */
	bitToSet <<= (INTMASK_SHIFT+2+intId);
    } else {
	bitToSet <<= (INTMASK_SHIFT+intId-SWINT_0);
    }
    contextPtr->statusRegister |= bitToSet;
}
    
void enableAllInterruptsInContext( ProcContextPtr contextPtr)
{
    contextPtr->statusRegister |= SR_INT_MASK;
}
