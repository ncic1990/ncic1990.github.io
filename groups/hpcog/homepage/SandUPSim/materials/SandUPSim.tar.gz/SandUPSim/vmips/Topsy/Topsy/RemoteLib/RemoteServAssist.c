/*TopsyAssistantServer:some assistant functions used in Topsy*/
#define TACOMMONDECLARE\
	uint32 tmp32;\
	COMMONDECLARE

#define TACOMMONRET(paramsdesptr,tmp32)\
do{\
	SetParamDescNum(paramsdesptr, 2);\
	SetParamDescParameter(paramsdesptr,0,(uint32)&tmp32,true,0,0);\
	SetParamDescParameter(paramsdesptr,1,(uint32)&rmt_errno,true,0,0);\
	WAITFORREPLY(paramsdesptr);\
	RELEASE( );\
	return tmp32;\
}while(0)

#define TACOMMONRET_1BUF(paramsdesptr,tmp32,buf,bufsize)\
do{\
	SetParamDescNum(paramsdesptr, 3);\
	SetParamDescParameter(paramsdesptr,0,(uint32)&tmp32,true,0,0);\
	SetParamDescParameter(paramsdesptr,1,(uint32)&rmt_errno,true,0,0);\
	SetParamDescParameter(paramsdesptr,2,(uint32)buf,false,0,bufsize);\
	WAITFORREPLY(paramsdesptr);\
	RELEASE();\
	return tmp32;\
}while(0)

void rsTAioConsolePutString(char* buf)
{
	CHECKPTR_1_NORETVAL(buf,"rsTAioConsolePutString:buf");
	
	ParamsDesc_t* paramsdesptr=&localservinfo.paramdesc;

	SetParamDescNum(paramsdesptr, 1);
	SetParamDescParameter(paramsdesptr,0,(uint32)buf,false,CHARALIGN,stringlen(buf)+1);
	REMOTECALL(TOPSYASSISTREQ,ioConsolePutStringservno,paramsdesptr);

	RELEASE();
}
void rsTAioConsolePutHexInt(long num)
{
	ParamsDesc_t* paramsdesptr=&localservinfo.paramdesc;

	SetParamDescNum(paramsdesptr, 1);
	SetParamDescParameter(paramsdesptr,0,(uint32)num,true,0,0);
	REMOTECALL(TOPSYASSISTREQ,ioConsolePutHexIntservno,paramsdesptr);

	RELEASE();
}
void rsTAstringout(char* buf)
{
	CHECKPTR_1_NORETVAL(buf,"rsTAstringout:buf");

	ParamsDesc_t* paramsdesptr=&localservinfo.paramdesc;

	SetParamDescNum(paramsdesptr, 1);
	SetParamDescParameter(paramsdesptr,0,(uint32)buf,false,CHARALIGN,stringlen(buf)+1);
	REMOTECALL(TOPSYASSISTREQ,stringoutservno,paramsdesptr);

	RELEASE();
}
char* rsTAstringin(char* buf,long maxcount)
{
	CHECKPTR_1_RETVAL(buf,"rsTAstringin:buf",NULL);

	uint32 tmp32;
	ParamsDesc_t* paramsdesptr=&localservinfo.paramdesc;

	SetParamDescNum(paramsdesptr, 1);
	SetParamDescParameter(paramsdesptr,0,maxcount,true,0,0);
	REMOTECALL(TOPSYASSISTREQ,stringinservno,paramsdesptr);

	SetParamDescNum(paramsdesptr,3);
	SetParamDescParameter(paramsdesptr,0,(uint32)&tmp32,true,0,0);
	SetParamDescParameter(paramsdesptr,1,(uint32)&rmt_errno,true,0,0);
	SetParamDescParameter(paramsdesptr,2,(uint32)buf,false,0,PARAMCHECKING_DEFAULTLEN);
	WAITFORREPLY(paramsdesptr);

	RELEASE();
	return (char*)tmp32;
}
//when returning 0:failed  1:ok
long rsTARedirectStdIO(long stdinto, long stdoutto, long stderrto)
{
	#ifdef DEBUGTA
	OUTPUTMSG("client msg:TA:RedirectStdIO");
	#endif

	TACOMMONDECLARE

	SetParamDescNum(paramsdesptr, 3);
	SetParamDescParameter(paramsdesptr,0,(uint32)stdinto,true,0,0);
	SetParamDescParameter(paramsdesptr,1,(uint32)stdoutto,true,0,0);
	SetParamDescParameter(paramsdesptr,2,(uint32)stderrto,true,0,0);
	REMOTECALL(TOPSYASSISTREQ,redirectstdioservno,paramsdesptr);

	TACOMMONRET(paramsdesptr,tmp32);
}
void rsTADeRedirectStdIO( )
{
	#ifdef DEBUGTA
	OUTPUTMSG("client msg:TA:DeRedirectStdIO");
	#endif

	ParamsDesc_t* paramsdesptr=&localservinfo.paramdesc;

	SetParamDescNum(paramsdesptr, 0);
	REMOTECALL(TOPSYASSISTREQ,deredirectstdioservno ,paramsdesptr);

	RELEASE();
}
//when returning 0:failed  1:ok
long rsTAChangeCWD(const char* pathname)
{
	#ifdef DEBUGTA
	OUTPUTMSG("client msg:TA:ChangeCWD");
	#endif
	CHECKPTR_1_RETVAL((char*)pathname,"rsTAChangeCWD:pathname",CWDFAILED);

	TACOMMONDECLARE

	SetParamDescNum(paramsdesptr, 1);
	SetParamDescParameter(paramsdesptr,0,(uint32)pathname,false,
		CHARALIGN,stringlen((char*)pathname)+1);
	REMOTECALL(TOPSYASSISTREQ,changecwdservno,paramsdesptr);

	TACOMMONRET(paramsdesptr,tmp32);
}
void rsTARecoverCWD( )
{
	#ifdef DEBUGTA
	OUTPUTMSG("client msg:TA:RecoverCWD");
	#endif

	ParamsDesc_t* paramsdesptr=&localservinfo.paramdesc;

	SetParamDescNum(paramsdesptr, 0);
	REMOTECALL(TOPSYASSISTREQ,recovercwdservno,paramsdesptr);

	RELEASE();
}
void rsTAprintfnull(const char* str) //to stdout
{
	CHECKPTR_1_NORETVAL((char*)str,"rsTAprintfnull:str");

	ParamsDesc_t* paramsdesptr=&localservinfo.paramdesc;

	SetParamDescNum(paramsdesptr, 1);
	SetParamDescParameter(paramsdesptr,0,(uint32)str,false,CHARALIGN,stringlen((char*)str)+1);
	REMOTECALL(TOPSYASSISTREQ,printfnullservno,paramsdesptr);

	RELEASE();
}
void rsTAprintfstr(const char* mode, const char* str) //to stdout
{
	CHECKPTR_2_NORETVAL((char*)mode,"rsTAprintfstr:mode",(char*)str,"rsTAprintfstr:str");

	ParamsDesc_t* paramsdesptr=&localservinfo.paramdesc;

	SetParamDescNum(paramsdesptr, 2);
	SetParamDescParameter(paramsdesptr,0,(uint32)mode,false,CHARALIGN,stringlen((char*)mode)+1);
	SetParamDescParameter(paramsdesptr,1,(uint32)str,false,CHARALIGN,stringlen((char*)str)+1);
	REMOTECALL(TOPSYASSISTREQ,printfstrservno,paramsdesptr);

	RELEASE();
}
void rsTAprintfnum(const char* mode, long num) //to stdout
{
	CHECKPTR_1_NORETVAL((char*)mode,"rsTAprintfnum:mode");

	ParamsDesc_t* paramsdesptr=&localservinfo.paramdesc;

	SetParamDescNum(paramsdesptr, 2);
	SetParamDescParameter(paramsdesptr,0,(uint32)mode,false,CHARALIGN,stringlen((char*)mode)+1);
	SetParamDescParameter(paramsdesptr,1,(uint32)num,true,0,0);
	REMOTECALL(TOPSYASSISTREQ,printfnumservno,paramsdesptr);

	RELEASE();
}
long rsTAgetcwd(char* buf, long size, long mode)
{
	#ifdef DEBUGTA
	OUTPUTMSG("client msg:TA:getcwd");
	#endif
	CHECKPTR_1_RETVAL(buf,"rsTAgetcwd:buf",TAGETCWDFAILED);

	TACOMMONDECLARE

	SetParamDescNum(paramsdesptr, 2);
	SetParamDescParameter(paramsdesptr,0,size,true,0,0);
	SetParamDescParameter(paramsdesptr,1,mode,true,0,0);
	REMOTECALL(TOPSYASSISTREQ,TAgetcwdservno,paramsdesptr);

	TACOMMONRET_1BUF(paramsdesptr,tmp32,buf,PARAMCHECKING_DEFAULTLEN);
}
void rsTAlssimulation(char* format)
{
	#ifdef DEBUGTA
	OUTPUTMSG("client msg:TA:lssimulation");
	#endif
	CHECKPTR_1_NORETVAL(format,"rsTAlssimulation:format");

	ParamsDesc_t* paramsdesptr=&localservinfo.paramdesc;

	SetParamDescNum(paramsdesptr, 1);
	SetParamDescParameter(paramsdesptr,0,(uint32)format,false,CHARALIGN,stringlen(format)+1);
	REMOTECALL(TOPSYASSISTREQ,TAlssimulationservno,paramsdesptr);

	RELEASE();
}
char* rsTAgetenv(char* envname,char* buf,long maxlen)
{
	#ifdef DEBUGTA
	OUTPUTMSG("client msg:TA:getenv");
	#endif
	CHECKPTR_2_RETVAL(envname,"rsTAgetenv:envname",buf,"rsTAgetenv:buf",NULL);

	uint32 tmp32;
	ParamsDesc_t* paramsdesptr=&localservinfo.paramdesc;

	SetParamDescNum(paramsdesptr, 2);
	SetParamDescParameter(paramsdesptr,0,(uint32)envname,false,CHARALIGN,stringlen(envname)+1);
	SetParamDescParameter(paramsdesptr,1,maxlen,true,0,0);
	REMOTECALL(TOPSYASSISTREQ,TAgetenvservno,paramsdesptr);

	SetParamDescNum(paramsdesptr, 3);
	SetParamDescParameter(paramsdesptr,0,(uint32)&tmp32,true,0,0);
	SetParamDescParameter(paramsdesptr,1,(uint32)&rmt_errno,true,0,0);
	SetParamDescParameter(paramsdesptr,2,(uint32)buf,false,0,PARAMCHECKING_DEFAULTLEN);
	WAITFORREPLY(paramsdesptr);

	RELEASE();
	if(tmp32) tmp32=(uint32)buf;
	return (char*)tmp32;
}

long rsTAchstdiobyname(char* stdinname,char* stdoutname,
	char* stderrname,bool inheritflag)
{
	#ifdef DEBUGTA
	OUTPUTMSG("client msg:TA:chstdiobyname");
	#endif
	CHECKPTR_2_RETVAL(stdinname,"rsTAchstdiobyname:stdinname",
		stdoutname,"rsTAchstdiobyname:stdoutname",TACHSTDIOBYNAMEFAILED);
	CHECKPTR_1_RETVAL(stderrname,"rsTAchstdiobyname:stderrname",
		TACHSTDIOBYNAMEFAILED);

	TACOMMONDECLARE

	SetParamDescNum(paramsdesptr, 4);
	SetParamDescParameter(paramsdesptr,0,(uint32)stdinname,false,CHARALIGN,stringlen(stdinname)+1);
	SetParamDescParameter(paramsdesptr,1,(uint32)stdoutname,false,CHARALIGN,stringlen(stdoutname)+1);
	SetParamDescParameter(paramsdesptr,2,(uint32)stderrname,false,CHARALIGN,stringlen(stderrname)+1);
	SetParamDescParameter(paramsdesptr,3,(uint32)inheritflag,true,0,0);
	REMOTECALL(TOPSYASSISTREQ,TAchstdiobynameservno,paramsdesptr);
	
	TACOMMONRET(paramsdesptr,tmp32);
}

