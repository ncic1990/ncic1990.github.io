#ifndef VIRTSERVRANGE_H
#define VIRTSERVRANGE_H

/*writen by slfsmm for virtual servers*/

#include "sysinclude.h"
#include "range.h"
#include "DBGTracer.h"
#include "VirtServ.h"

//for stdio redirection of Topsy and App
#define STDIONUM 3
#define NOTDIRECT -1
typedef struct RedirectStruct{
	long globalfds[STDIONUM];
	long appfds[STDIONUM];
	long currfds[STDIONUM];
	long localfds[STDIONUM];
}RedirectStruct_t;

//for the current working directory of Topsy
#define MAXCWDLEN 1024
typedef struct CWDStruct{
	char globalCWD[MAXCWDLEN];
	char currCWD[MAXCWDLEN];
	char localCWD[MAXCWDLEN];
}CWDStruct_t;

//for telling vmips the memory mapping managed by Topsy
#define INVALID_MMMAPPING -1
typedef struct mmmappingitem{
	long physbase;
	long virtbase;
	long size;
}mmmappingitem_t;
typedef struct mmmapping{
	mmmappingitem_t codeseg;
	mmmappingitem_t dataseg;
	mmmappingitem_t brk_dynamic;
	mmmappingitem_t mmmap_dynamic;
	mmmappingitem_t stackseg;
}mmmapping_t;
#define MAXFILENAME 256
typedef struct userinfo{
	char appname[MAXFILENAME];
	mmmapping_t usermmmapping;
}userinfo_t;
	
class VirtServRange : public Range {
public:
    VirtServRange(bool inheritflag, const char* tstdin, const char* tstdout, const char* tstderr) throw();
	virtual ~VirtServRange() throw();
    virtual void store_byte(uint32 offset, uint8 data, DeviceExc *client);
	virtual uint8 fetch_byte(uint32 offset, DeviceExc *client);
	virtual void store_halfword(uint32 offset, uint16 data, DeviceExc *client);
	virtual uint16 fetch_halfword(uint32 offset, DeviceExc *client);
	virtual void store_word(uint32 offset, uint32 data, DeviceExc *client);
	virtual uint32 fetch_word(uint32 offset, int mode, DeviceExc *client);

private:
	//buffer for transfer data
	long long VirtServBuffers[VirtualServerBufNum];
	uint32 GetReg(uint8 regno);
	void SetReg(uint8 regno,uint32 data);
	uint32 cp0_address_trans(uint32 vaddr, int mode, bool *cacheable,DeviceExc *client);
	char* Range_address_trans(uint32 vaddr,uint32 phys, int mode, DeviceExc *client);
	char* AddressTranslation(uint32 vaddr,DeviceExc *client,int mode,uint32* phyaddr,bool *cacheable);
	#define SYNCMEMTOCACHE 0
	#define SYNCCACHETOMEM 1
	/*slfsmm_maymod>*/
	#define MAXERRNO 125
	/*slfsmm_maymod<*/
	#define DEFAULTLEN -MAXERRNO-1
 	void physaddr_fetch_byte(uint32 phys, uint8* data, bool cacheable, DeviceExc *client);
	void physaddr_store_byte(uint32 phys, uint8 data, bool cacheable, DeviceExc *client);
	long SyncBufLength(uint32 physaddr,char* localvirtaddr,long mode, bool cacheable, DeviceExc *client);
	void SyncMemAndCache(uint32 virtaddr,uint32 physaddr,char* localvirtaddr,long len,long mode,bool cacheable,DeviceExc *client);

	/*setup Topsy env*/
	//four control functions
	void InitTopsyEnv(bool inheritflag, const char* tstdin, const char* tstdout, const char* tstderr);
	void DestroyTopsyEnv( );
	void InstallTopsyEnv( );
	void UnInstallTopsyEnv( );
	//struct for redirection
	RedirectStruct_t redirectfds;
	bool tstdio_inheritflag;
	//four functions for redirection of stdio
	#define DEFAULTSTDIO ":::"
	void InitRedirectStruct(bool inheritflag, const char* tstdin, const char* tstdout, const char* tstderr);
	void getinputstdio(const char* tstdio, const char* ttyname, const char* str, long which);
	long getdefaultstdio(const char* ttyname, const char* str, long which, long appflag);
	void destroyRedirectStruct( );
	void RedirectStdIO( );
	void DeRedirectStdIO( );
	//for current working directory
	CWDStruct_t topsycwd;
	void InitCWD( );
	void DestroyCWD( );
	void ChangeCWD( );
	void RecoverCWD( );
	//vmips can get the mmmapping managed by Topsy through the following
	//struct and functions
public:
	userinfo_t UserInfo;
private:
	void Inituserinfo(userinfo* ui);

	/*Local virtual server*/
	void StartLocalVirtualServer( uint8 data, DeviceExc *client);
	void HandlingLibcReturn(long ret, long err, DeviceExc *client);
	void FileOpenServer(DeviceExc *client);
	void FileReadServer(DeviceExc *client);
	void FileWriteServer(DeviceExc *client);
	void FileCloseServer(DeviceExc *client);
	void FileSeekServer(DeviceExc *client);
	void FileTellServer(DeviceExc* client);
	void RewindServer(DeviceExc* client);
	void FileEofServer(DeviceExc* client);
	void FileGetcServer(DeviceExc* client);
	void FileGetsServer(DeviceExc* client);
	void FilePutcServer(DeviceExc* client);
	void FilePutsServer(DeviceExc* client);
	void LibcgetcwdServer(DeviceExc* client);
	void LibcchdirServer(DeviceExc* client);

    /*OutputServer for such as debugging*/
    void StartOutputServer( uint8 data, DeviceExc *client);
public:
	void dumpregserver(DeviceExc *client);
private:
	void ErrMsgServer(DeviceExc *client);
	void TracerServer(DeviceExc *client);


	/*LinuxSyscall server*/
	void StartLinuxSyscallServer(uint8 data, DeviceExc *client);
	void HandlingSysCallReturn(long ret, DeviceExc *client);
	void LinuxSyscallReadServer(DeviceExc* client);
	void LinuxSyscallWriteServer(DeviceExc* client);
	void LinuxSyscallOpenServer(DeviceExc* client);
	void LinuxSyscallCloseServer(DeviceExc* client);
	void LinuxSyscallunlinkServer(DeviceExc* client);
	void LinuxSyscalltimeServer(DeviceExc* client);
	void LinuxSyscalllseekServer(DeviceExc* client);
	void LinuxSyscallgetpidServer(DeviceExc* client);
	void LinuxSyscallgetuidServer(DeviceExc* client);
	void LinuxSyscallaccessServer(DeviceExc* client);
	void LinuxSyscallrenameServer(DeviceExc* client);
	void LinuxSyscalltimesServer(DeviceExc* client);
	void LinuxSyscallgetgidServer(DeviceExc* client);
	void LinuxSyscallgeteuidServer(DeviceExc* client);
	void LinuxSyscallgetegidServer(DeviceExc* client);
	void LinuxSyscallioctlServer(DeviceExc* client);
	void LinuxSyscallfcntlServer(DeviceExc* client, long syscallnum);
	void LinuxSyscallgetrlimitServer(DeviceExc* client);
	void LinuxSyscallgetrusageServer(DeviceExc* client);
	void LinuxSyscallftruncateServer(DeviceExc* client);
	void LinuxSyscallfstatServer(DeviceExc* client, long syscallnum);
	void LinuxSyscallnewunameServer(DeviceExc* client);
	void LinuxSyscallllseekServer(DeviceExc* client);
	void LinuxSyscallnewselectServer(DeviceExc* client);
	void LinuxSyscallftruncate64Server(DeviceExc* client);
	void LinuxSyscallfstat64Server(DeviceExc* client, long syscallnum);
	
	/*TopsyAssistantServer:some assistant functions used in Topsy*/
	void StartTopsyAssistantServer(uint8 data, DeviceExc *client);
	void ioConsolePutStringServer(DeviceExc* client);
	void ioConsolePutHexIntServer(DeviceExc* client);
	void stringoutServer(DeviceExc* client);
	void stringinServer(DeviceExc* client);
	#define REDIRECTOK 1
	#define REDIRECTFAILED 0
	void redirectstdioServer(DeviceExc* client);
	void deredirectstdioServer(DeviceExc* client);
	#define CWDOK 1
	#define CWDFAILED 0
	void ChangeCWDServer(DeviceExc* client);
	void RecoverCWDServer(DeviceExc* client);
	void printfnullServer(DeviceExc* client);
	void printfstrServer(DeviceExc* client);
	void printfnumServer(DeviceExc* client);
	void memsetServer(DeviceExc* client);
	#define TAGETCWDOK 0
	#define TAGETCWDFAILED -1
	#define TAGETCWDABSOLUTE 1
	#define TAGETCWDDIRNAME 0
	void TAgetcwdServer(DeviceExc* client);
	void TAlssimulationServer(DeviceExc* client);
	void TAgetenvServer(DeviceExc* client);
	void TAmmmappinginforServer(DeviceExc* client);
	void TAappnameServer(DeviceExc* client);
	void TAinvalidcacheServer(DeviceExc* client);
	void TAgetallenvServer(DeviceExc* client);

 	/*other server*/
};

#endif /*VIRTSERVRANGE_H*/

