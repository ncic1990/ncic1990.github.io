/* Definitions to support the float coprocessor.
   Copyright NCIC

This file is part of Sand which originated from VMIP
*/

#include "cpone.h"
#include "excnames.h" // for exception defination
#include <math.h>

class DeviceExc;
class CPOne; /* avoid circular dependency */

//inline
 uint16 CPOne::funct(const uint32 instr) const {
	return (instr & 0x3f );
}

//inline 
uint16 CPOne::format(const uint32 instr) const {
	return ((instr >> 21) & 0x1f );
}

//inline 
uint16 CPOne::ft(const uint32 instr) const {
	return ((instr >> 16) & 0x1f );
}

//inline
 uint16 CPOne::fs(const uint32 instr) const {
	return ((instr >> 11) & 0x1f );
}

//inline 
uint16 CPOne::fd(const uint32 instr) const {
	return ((instr >> 6) & 0x1f );
}

//inline
 uint16 CPOne::opcode(const uint32 instr) const {
	   return (instr >> 26) & 0x03f;
}

CPOne::CPOne(CPU *m) {
	cpu = m;
	reset();
}

void CPOne::reset(void) {
	for(int i=0;i<32;i++)
		SingleFGR(i) = 0.0 ;
	fcsr = 0;
	fcr0 = 0;
	fcr25 = 0;
	fcr26 = 0;
	fcr28 = 0;
}
typedef void (CPOne::*emulate_funptr)(uint32, uint32);

void CPOne::cpone_emulate(uint32 instr, uint32 pc)
{
	//fprintf(stderr,"instr: %X, pc:%X\n", instr,pc);
static const emulate_funptr opcodeJumpTable[] = {
	&CPOne::fadd_emulate,&CPOne::fsub_emulate,
	&CPOne::fmul_emulate,&CPOne::fdiv_emulate,
	&CPOne::fsqrt_emulate,&CPOne::fabs_emulate,
	&CPOne::fmov_emulate,&CPOne::fneg_emulate,
	&CPOne::fround1_emulate,&CPOne::ftrunc1_emulate,
	&CPOne::fceill_emulate,&CPOne::ffloorl_emulate,    /*0xa_emulate,0xb*/ 
	&CPOne::fround_emulate,&CPOne::ftrunc_emulate,
	&CPOne::fceil_emulate,&CPOne::ffloor_emulate,
	&CPOne::fundef_emulate,&CPOne::fmovc_emulate,
	&CPOne::fmovz_emulate,&CPOne::fmovn_emulate,
	&CPOne::fundef_emulate,&CPOne::frecip_emulate,
	&CPOne::frsqrt_emulate,&CPOne::fundef_emulate,    /*0x16_emulate,0x17*/
	&CPOne::fundef_emulate,&CPOne::fundef_emulate,
	&CPOne::fundef_emulate,&CPOne::fundef_emulate,
	&CPOne::fundef_emulate,&CPOne::fundef_emulate,
	&CPOne::fundef_emulate,&CPOne::fundef_emulate,
	&CPOne::fcvts_emulate,&CPOne::fcvtd_emulate,	  /*0x20_emulate,0x21*/
	&CPOne::fcvte_emulate,&CPOne::fundef_emulate,
	&CPOne::fcvtw_emulate,&CPOne:: fcvtl_emulate, 	  /*0x24_emulate,0x25*/
	&CPOne::fundef_emulate,&CPOne::fundef_emulate,
	&CPOne::fundef_emulate,&CPOne::fundef_emulate,
	&CPOne::fundef_emulate,&CPOne::fundef_emulate,
	&CPOne::fundef_emulate,&CPOne::fundef_emulate,
	&CPOne::fundef_emulate,&CPOne::fundef_emulate,
	&CPOne::fcmp_op_emulate,&CPOne::fcmp_op_emulate,	  /*0x30_emulate,0x31*/
	&CPOne::fcmp_op_emulate,&CPOne::fcmp_op_emulate,
	&CPOne::fcmp_op_emulate,&CPOne::fcmp_op_emulate,
	&CPOne::fcmp_op_emulate,&CPOne::fcmp_op_emulate,
	&CPOne::fcmp_op_emulate,&CPOne::fcmp_op_emulate,
	&CPOne::fcmp_op_emulate,&CPOne::fcmp_op_emulate,
	&CPOne::fcmp_op_emulate,&CPOne::fcmp_op_emulate,
	&CPOne::fcmp_op_emulate,&CPOne::fcmp_op_emulate    /*0x3e_emulate,0x3f*/
};

	fmt = format(instr);

if(fmt >= 0x10) {
   (this->*opcodeJumpTable[funct(instr)])(instr, pc);
   return;
}
uint8 rtnum = ft(instr);
uint8 fsnum  = fs(instr);
switch(fmt) {
	case F_bc_op:
		if( rtnum & 01) { // bc1t
				if( fcr31 & F_CSR31_C) { //condition match 
					cpu->branch(instr,cpu->pc);
				}
				else if (rtnum & 02 ) { //bc1tl skip next  inst
					cpu->pc += 4;
				}
		}
		else { //bc1f 
			if(!(fcr31 & F_CSR31_C)) {// !match
					cpu->branch(instr,cpu->pc);
			}
			else if (rtnum & 02) {//bc1fl
					cpu->pc += 4;
				}
		}
		break;
	case F_cfc_op:
		if (fsnum == 31) {
            cpu->reg[rtnum] = fcr31;
         }
		else 
        	fundef_emulate(instr,pc); 
		break;
	case F_ctc_op:
		fcr31 = cpu->reg[rtnum];
		break;
		
	case F_mfc_op:
		cpu->reg[rtnum] = IntFGR(fsnum);
		break;
	case F_mtc_op:
		IntFGR(fsnum) = cpu->reg[rtnum];
		break;
		
	case F_dmfc_op:
		fundef_emulate(instr,pc);
		break;
	case F_dmtc_op:
		fundef_emulate(instr,pc);
		break;
		
	default:
		fundef_emulate(instr,pc);
	break;
}
}


void
CPOne::fadd_emulate(uint32 instr, uint32 pc)
{
	if(fmt == FMT_S) {
		SingleFGR(fd(instr)) = SingleFGR(fs(instr)) + SingleFGR(ft(instr)) ;
	}
	else {
		DoubleFGR(fd(instr)) = DoubleFGR(fs(instr)) + DoubleFGR(ft(instr)) ;
	}

}

void
CPOne::fsub_emulate(uint32 instr, uint32 pc)
{
	if(fmt == FMT_S) {
		SingleFGR(fd(instr)) = SingleFGR(fs(instr)) - SingleFGR(ft(instr)) ;
	}
	else {
		DoubleFGR(fd(instr)) = DoubleFGR(fs(instr)) - DoubleFGR(ft(instr)) ;
	}

}

void
CPOne::fmul_emulate(uint32 instr, uint32 pc)
{
//    fprintf(stderr,"Enter fmul emulation.\n");
	if(fmt == FMT_S) {
		SingleFGR(fd(instr)) = SingleFGR(fs(instr)) * SingleFGR(ft(instr)) ;
	}
	else {
		DoubleFGR(fd(instr)) = DoubleFGR(fs(instr)) * DoubleFGR(ft(instr)) ;
	}
}

void
CPOne::fdiv_emulate(uint32 instr, uint32 pc)
{
	if(fmt == FMT_S) {
		if(SingleFGR(ft(instr)) == 0.0 ) {
			fprintf(stderr,"FPE:divide by zero! 1\n");
			cpu->exception(FPE);
			return;
		}
		SingleFGR(fd(instr)) = SingleFGR(fs(instr)) / SingleFGR(ft(instr)) ;
	}
	else {
		if(DoubleFGR(ft(instr)) == 0.0 ) {
			fprintf(stderr,"FPE:divide by zero 2\n");
			cpu->exception(FPE);
			return;
		}

		DoubleFGR(fd(instr)) = DoubleFGR(fs(instr)) / DoubleFGR(ft(instr)) ;
	}
}

void
CPOne::fsqrt_emulate(uint32 instr, uint32 pc)
{
	if(fmt == FMT_S) {
		SingleFGR(fd(instr)) = (float)sqrt(SingleFGR(fs(instr)) ) ;
	}
	else {
		DoubleFGR(fd(instr)) = sqrt(DoubleFGR(fs(instr))) ;	
	}

}

void
CPOne::fabs_emulate(uint32 instr, uint32 pc)
{
	if(fmt == FMT_S) {
		SingleFGR(fd(instr)) = ( SingleFGR(fs(instr)) > 0.0 ) ? SingleFGR(fs(instr)) : - SingleFGR(fs(instr))  ;
	}
	else {
		DoubleFGR(fd(instr)) = ( DoubleFGR(fs(instr)) > 0.0) ? DoubleFGR(fs(instr)) : - DoubleFGR(fs(instr)) ;	
	}

}

void
CPOne::fmov_emulate(uint32 instr, uint32 pc)
{
	if(fmt == FMT_S) {
		SingleFGR(fd(instr)) =  SingleFGR(fs(instr)) ;
	}
	else {
		DoubleFGR(fd(instr)) =  DoubleFGR(fs(instr)) ;	
	}
}

void
CPOne::fneg_emulate(uint32 instr, uint32 pc)
{
	if(fmt == FMT_S) {
		SingleFGR(fd(instr)) = ( - SingleFGR(fs(instr)) ) ;
	}
	else {
		DoubleFGR(fd(instr)) = ( - DoubleFGR(fs(instr)) ) ;	
	}
 
}

void
CPOne::fround1_emulate(uint32 instr, uint32 pc)
{
	if(fmt == FMT_S) {
		LongLongFGR(fd(instr)) = (long long)(SingleFGR(fs(instr)) > 0.0 ? SingleFGR(fs(instr)) + 0.5 : SingleFGR(fs(instr)) - 0.5) ;
 	}
	else {
		LongLongFGR(fd(instr)) = (long long )(DoubleFGR(fs(instr)) > 0.0 ? DoubleFGR(fs(instr)) + 0.5 : DoubleFGR(fs(instr)) - 0.5);
	} 
}

void
CPOne::ftrunc1_emulate(uint32 instr, uint32 pc)
{
	if(fmt == FMT_S) {
		LongLongFGR(fd(instr)) = (long long)(SingleFGR(fs(instr)));
 	}
	else {
		LongLongFGR(fd(instr)) = (long long )(DoubleFGR(fs(instr))); 
	} 

}

void
CPOne::fceill_emulate(uint32 instr, uint32 pc)
{
	if(fmt == FMT_S) {
		LongLongFGR(fd(instr)) = (long long)(SingleFGR(fs(instr)) > 0.0 ? SingleFGR(fs(instr)) +  SP_NEAR_ONE: SingleFGR(fs(instr)) ) ;
 	}
	else {
		LongLongFGR(fd(instr)) = (long long )(DoubleFGR(fs(instr)) > 0.0 ? DoubleFGR(fs(instr)) + DP_NEAR_ONE : DoubleFGR(fs(instr)) );
	} 

}

void
CPOne::ffloorl_emulate(uint32 instr, uint32 pc)
{
	if(fmt == FMT_S) {
		LongLongFGR(fd(instr)) = (long long)(SingleFGR(fs(instr)) > 0.0 ? SingleFGR(fs(instr)) : SingleFGR(fs(instr)) - SP_NEAR_ONE ) ;
 	}
	else {
		LongLongFGR(fd(instr)) = (long long )(DoubleFGR(fs(instr)) > 0.0 ? DoubleFGR(fs(instr)): DoubleFGR(fs(instr)) - DP_NEAR_ONE );
	} 
}

void
CPOne::fround_emulate(uint32 instr, uint32 pc)
{
	if(fmt == FMT_S) {
		IntFGR(fd(instr)) = (int32)(SingleFGR(fs(instr)) > 0.0 ? SingleFGR(fs(instr)) + 0.5 : SingleFGR(fs(instr)) - 0.5) ;
 	}
	else {
		IntFGR(fd(instr)) = (int32)(DoubleFGR(fs(instr)) > 0.0 ? DoubleFGR(fs(instr)) + 0.5 : DoubleFGR(fs(instr)) - 0.5);
	} 

}

void
CPOne::ftrunc_emulate(uint32 instr, uint32 pc)
{
	if(fmt == FMT_S) {
		IntFGR(fd(instr)) = (int32)(SingleFGR(fs(instr)));
 	}
	else {
		IntFGR(fd(instr)) = (int32)(DoubleFGR(fs(instr))); 
	} 


}

void
CPOne::fceil_emulate(uint32 instr, uint32 pc)
{
	if(fmt == FMT_S) {
		IntFGR(fd(instr)) = (int32)(SingleFGR(fs(instr)) > 0.0 ? SingleFGR(fs(instr)) +  SP_NEAR_ONE: SingleFGR(fs(instr)) ) ;
 	}
	else {
		IntFGR(fd(instr)) = (int32)(DoubleFGR(fs(instr)) > 0.0 ? DoubleFGR(fs(instr)) + DP_NEAR_ONE : DoubleFGR(fs(instr)) );
	} 


}

void
CPOne::ffloor_emulate(uint32 instr, uint32 pc)
{
	if(fmt == FMT_S) {
		IntFGR(fd(instr)) = (int32)(SingleFGR(fs(instr)) > 0.0 ? SingleFGR(fs(instr)) : SingleFGR(fs(instr)) - SP_NEAR_ONE ) ;
 	}
	else {
		IntFGR(fd(instr)) = (int32)(DoubleFGR(fs(instr)) > 0.0 ? DoubleFGR(fs(instr)): DoubleFGR(fs(instr)) - DP_NEAR_ONE );
	} 

}

void
CPOne::fmovc_emulate(uint32 instr, uint32 pc)
{
    fundef_emulate(instr,pc);
}

void
CPOne::fmovz_emulate(uint32 instr, uint32 pc)
{
     fundef_emulate(instr,pc);

}

void
CPOne::fmovn_emulate(uint32 instr, uint32 pc)
{
     fundef_emulate(instr,pc);

}

void
CPOne::frecip_emulate(uint32 instr, uint32 pc)
{
     fundef_emulate(instr,pc);

}

void
CPOne::frsqrt_emulate(uint32 instr, uint32 pc)
{
     fundef_emulate(instr,pc);

}

void
CPOne::fcvts_emulate(uint32 instr, uint32 pc)
{   
	if(fmt == FMT_D) SingleFGR(fd(instr)) = (float) DoubleFGR(fs(instr));
	else if(fmt == FMT_W) SingleFGR(fd(instr)) = (float) IntFGR(fs(instr));
	else if(fmt == FMT_L ) SingleFGR(fd(instr)) = (float) LongLongFGR(fs(instr));
	else fundef_emulate(instr,pc);

}

void
CPOne::fcvtd_emulate(uint32 instr, uint32 pc)
{
	if(fmt == FMT_S) DoubleFGR(fd(instr)) = (double) SingleFGR(fs(instr));
	else if(fmt == FMT_W) DoubleFGR(fd(instr)) = (double) IntFGR(fs(instr));
	else if(fmt == FMT_L ) DoubleFGR(fd(instr)) = (double) LongLongFGR(fs(instr));
	else fundef_emulate(instr,pc);
}
	 
void
CPOne::fcvte_emulate(uint32 instr, uint32 pc)
{
     fundef_emulate(instr,pc);

}

void
CPOne::fcvtw_emulate(uint32 instr, uint32 pc)
{
  // need read fcsr mode ?
  switch(fcr31 & 0x3) {
   case 0: // Round to nearest    
	if(fmt == FMT_S) IntFGR(fd(instr)) = (int)
		(SingleFGR(fs(instr)) > 0.0 ? SingleFGR(fs(instr)) + 0.5 : SingleFGR(fs(instr)) - 0.5) ;
	else if(fmt == FMT_D) IntFGR(fd(instr)) = (int)
		(DoubleFGR(fs(instr)) > 0.0 ? DoubleFGR(fs(instr)) + 0.5 : DoubleFGR(fs(instr)) - 0.5);
	else fundef_emulate(instr,pc);
	break;
   case 1: //Round toward 0 
	if(fmt == FMT_S) IntFGR(fd(instr)) = (int) (SingleFGR(fs(instr))) ;
	else if(fmt == FMT_D) IntFGR(fd(instr)) = (int) (DoubleFGR(fs(instr)) );
	else fundef_emulate(instr,pc);   
   	break;
   case 2: //Round to +infinity
   	if(fmt == FMT_S) IntFGR(fd(instr)) = (int)
		(SingleFGR(fs(instr)) > 0.0 ? SingleFGR(fs(instr)) : SingleFGR(fs(instr)) + SP_NEAR_ONE) ;
	else if(fmt == FMT_D) IntFGR(fd(instr)) = (int)
		(DoubleFGR(fs(instr)) > 0.0 ? DoubleFGR(fs(instr)) : DoubleFGR(fs(instr)) + DP_NEAR_ONE);
	else fundef_emulate(instr,pc);

   	break;
   case 3: // Round to -infinity 
   	if(fmt == FMT_S) IntFGR(fd(instr)) = (int)
		(SingleFGR(fs(instr)) > 0.0 ? SingleFGR(fs(instr)) : SingleFGR(fs(instr)) - SP_NEAR_ONE) ;
	else if(fmt == FMT_D) IntFGR(fd(instr)) = (int)
		(DoubleFGR(fs(instr)) > 0.0 ? DoubleFGR(fs(instr)) : DoubleFGR(fs(instr)) - DP_NEAR_ONE);
    else fundef_emulate(instr,pc);   
   break;	
  }
}

void
CPOne::fcvtl_emulate(uint32 instr, uint32 pc)
{
     fundef_emulate(instr,pc);

}
 
void
CPOne::fcmp_op_emulate(uint32 instr, uint32 pc)
{
	bool cond;
	int f1 = fs(instr);
	int f2 = ft(instr);
	if(fmt == FMT_S) {
		switch(funct(instr)) {
			case  F_C_OBF   : cond = false;  break;
			case  F_C_UN    : cond = false; break;
			case  F_C_EQ    : cond = ( SingleFGR(f1) == SingleFGR(f2)) ;break;
			case  F_C_UEQ   : cond = ( SingleFGR(f1) != SingleFGR(f2)) ;break;
			case  F_C_OLT   : cond = ( SingleFGR(f1) < SingleFGR(f2)) ;break;
			case  F_C_ULT   : cond = ( SingleFGR(f1) < SingleFGR(f2)) ;break;
			case  F_C_OLE   : cond = ( SingleFGR(f1) <= SingleFGR(f2)) ;break;
			case  F_C_ULE   : cond = ( SingleFGR(f1) <= SingleFGR(f2)) ;break;
			case  F_C_SF    : cond = false; break;
			case  F_C_NGLE  : cond = false; break;
			case  F_C_SEQ   : cond = ( SingleFGR(f1) == SingleFGR(f2)) ;break;
			case  F_C_NGL   : cond = ( SingleFGR(f1) == SingleFGR(f2)) ;break;
			case  F_C_LT    : cond = ( SingleFGR(f1) < SingleFGR(f2)) ;break;
			case  F_C_NGE   : cond = ( SingleFGR(f1) < SingleFGR(f2)) ;break;
			case  F_C_LE    : cond = ( SingleFGR(f1) <= SingleFGR(f2)) ;break;
			case  F_C_NGT  :  cond = ( SingleFGR(f1) <= SingleFGR(f2)) ;break;
			default:
							// shld not be here! ASSERT(1) 
							break;
		}
	}
	else if(fmt == FMT_D) {
		switch(funct(instr)) {
			case  F_C_OBF   : cond = false;  break;
			case  F_C_UN    : cond = false; break;
			case  F_C_EQ    : cond = ( DoubleFGR(f1) == DoubleFGR(f2)) ;break;
			case  F_C_UEQ   : cond = ( DoubleFGR(f1) != DoubleFGR(f2)) ;break;
			case  F_C_OLT   : cond = ( DoubleFGR(f1) < DoubleFGR(f2)) ;break;
			case  F_C_ULT   : cond = ( DoubleFGR(f1) < DoubleFGR(f2)) ;break;
			case  F_C_OLE   : cond = ( DoubleFGR(f1) <= DoubleFGR(f2)) ;break;
			case  F_C_ULE   : cond = ( DoubleFGR(f1) <= DoubleFGR(f2)) ;break;
			case  F_C_SF    : cond = false; break;
			case  F_C_NGLE  : cond = false; break;
			case  F_C_SEQ   : cond = ( DoubleFGR(f1) == DoubleFGR(f2)) ;break;
			case  F_C_NGL   : cond = ( DoubleFGR(f1) == DoubleFGR(f2)) ;break;
			case  F_C_LT    : cond = ( DoubleFGR(f1) < DoubleFGR(f2)) ;break;
			case  F_C_NGE   : cond = ( DoubleFGR(f1) < DoubleFGR(f2)) ;break;
			case  F_C_LE    : cond = ( DoubleFGR(f1) <= DoubleFGR(f2)) ;break;
			case  F_C_NGT  :  cond = ( DoubleFGR(f1) <= DoubleFGR(f2)) ;break;
			default:
							// shld not be here! ASSERT(1) 
							break;
		}
		
	}
	else {
		fundef_emulate(instr,pc);
		return;
		}
	cond ? fcr31 |= F_CSR31_C : fcr31 &= ~F_CSR31_C ;
}

void
CPOne::fundef_emulate(uint32 instr, uint32 pc)
{
	fprintf(stderr,"FP:Not defined yet:");
	cpu->cop_unimpl(1,instr,pc);
}
 
