#ifndef UVIRTSERV_H
#define UVIRTSERV_H

#define VirtualServerSpaceBase 0x7fffe800
#define VirtualServerSpace 2048
#define VirtualServerBase 0x7fffefff
#define VirtualServerNum 16
#define VirtualServerBufBase 0x7fffe800
#define VirtualServerBufNum 254
#define VirtualServerRegBase 0x7fffefec
#define FirstRegInBuf 507

#include "VirtServ.h"

#endif

