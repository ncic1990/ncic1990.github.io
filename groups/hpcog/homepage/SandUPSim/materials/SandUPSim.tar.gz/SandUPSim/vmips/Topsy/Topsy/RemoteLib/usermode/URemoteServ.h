#ifndef UREMOTESERV_H
#define UREMOTESERV_H

#define RemoteServerSpaceBase	0x7fffc000

#include "RemoteServ.h"

#endif

