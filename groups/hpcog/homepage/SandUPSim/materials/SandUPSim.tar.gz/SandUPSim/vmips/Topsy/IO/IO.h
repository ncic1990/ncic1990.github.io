/*
	Copyright (c) 1996-1997 Swiss Federal Institute of Technology, 
	Computer Engineering and Networks Laboratory. All rights reserved.

	TOPSY - A Teachable Operating System. 
		Implementation of a tiny and simple micro kernel for
		teaching purposes.

	Permission to use, copy, modify, and distribute this software and its
	documentation for any purpose, without fee, and without written 
	agreement is hereby granted, provided that the above copyright notice 
	and the following two paragraphs appear in all copies of this software.


	
	File:                  $Source: /work/cvs/cvsroot/Topsy/IO/IO.h,v $
 	Author(s):             George Fankhauser
 	Affiliation:           ETH Zuerich, TIK
 	Version:               $Revision: 1.1.1.1 $
 	Creation Date:         
 	Last Date of Change:   $Date: 2003/09/22 08:43:46 $      by: $Author: sgz $
	
	
*/

/* device numbers */

#ifndef SIMOS

#define IO_SERIAL_A 	0
#define IO_SERIAL_B 	1

#define IO_CONSOLE		IO_SERIAL_A /* A's all we've got */

#else

#define IO_CONSOLE  0

#endif

#ifndef SIMOS
#define IO_DEVCOUNT 2
#else
#define IO_DEVCOUNT 1
#endif

#include "IOConsole.h"

