#ifndef SERVLIB_H
#define SERVLIB_H

#include "LibcLinuxTypes.h"

long serv_errno;

FILE* Tfopen(const char * filename,const char * mode);
long Tfread( void *buffer, long size, long count, FILE *stream );
long Tfwrite( const void *buffer, long size, long count, FILE *stream );
int Tfclose( FILE *stream );
int Tfseek( FILE *stream, long offset, int origin );
long int Tftell(FILE* stream);
void Trewind(FILE* stream);
int Tfeof(FILE* stream);
int Tfgetc(FILE* stream);
char* Tfgets(char* s,int n,FILE* stream);
int Tfputc(int c,FILE* stream);
int Tfputs(const char* s,FILE*stream);
char* Tgetcwd(char* buf, long size);
int Tchdir(const char* path);

void TLexit(int exitcode);//v0==4001
int TLread(unsigned int fd, char * buf, long count);//v0==4003
int TLwrite(unsigned int fd, const char * buf, long count);//v0==4004
long TLopen(const char * filename, int flags, int mode);//v0==4005
long TLclose(unsigned int fd);//v0==4006
long TLunlink(const char* pathname);//v0==4010
long TLtime(int* tloc);//v0==4013
long TLlseek(unsigned int fd, long offset, unsigned int origin);//v0==4019
long TLgetpid(void);//v0==4020
long TLgetuid(void);//v0==4024
long TLaccess(const char * filename, int mode);//v0==4033
long TLrename(const char * oldname, const char * newname);//v0==4038
long TLtimes(struct tms* tbuf);//v0==4043
unsigned long TLbrk(unsigned long brk);//v0==4045
long TLgetgid(void);//v0==4047
long TLgeteuid(void);//v0==4049
long TLgetegid(void);//v0==4050
long TLioctl(unsigned int fd, unsigned int cmd, unsigned long arg);//v0==4054
long TLfcntl(unsigned int fd, unsigned int cmd, unsigned long arg);//v0==4055
long TLsetrlimit(unsigned int resource, struct rlimitformips*rlim);//v0==4075
long TLgetrlimit(unsigned int resource, struct rlimitformips *rlim);//v0==4076
long TLgetrusage(int who, struct rusageformips*ru);//v0==4077
unsigned long TLmmap(unsigned long addr, unsigned long len, unsigned long prot,
         unsigned long flags, unsigned long fd, unsigned long offset);//v0==4090
long TLmunmap(unsigned long addr, unsigned long len);//v0==4091
long TLftruncate(unsigned int fd, unsigned long length);//v0==4093
long TLstat(char * filename, struct statformips* statbuf);//v0==4106
long TLlstat(char * filename, struct statformips* statbuf);//v0==4107
long TLfstat(unsigned int fd, struct statformips* statbuf);//v0==4108
long TLnewuname(new_utsname_formips * name);//v0==4122
long TLmprotect(unsigned long start, size_t len, unsigned long prot);//v0==4125
long TLllseek(unsigned int fd, unsigned long offset_high, 
	unsigned long offset_low, loff_t * result, unsigned int origin);//v0==4140
long TLnewselect(int n, fd_set *inp, fd_set *outp, fd_set *exp, struct timeval *tvp);//v0==4142
long TLnanosleep(struct timespecformips *rqtp, struct timespecformips *rmtp);//v0==4166
long TLrt_sigaction(int sig, const struct sigactioninvalid *act, 
	struct sigactioninvalid *oact, long sigsetsize);//v0==4194
long TLrt_sigprocmask(int how, sigsetinvalid_t *set, sigsetinvalid_t *oset, 
	size_t sigsetsize);//v0==4195
long TLmmap2(unsigned long addr, unsigned long len, unsigned long prot,
          unsigned long flags, unsigned long fd, unsigned long pgoff);//v0==4210
long TLftruncate64(unsigned int fd, loff_t length);//v0==4212
long TLstat64(char * filename, struct stat64formips * statbuf, long flags);//v0==4213
long TLlstat64(char * filename, struct stat64formips * statbuf, long flags);//v0==4214
long TLfstat64(unsigned long fd, struct stat64formips * statbuf, long flags);//v0==4215
long TLfcntl64(long fd,long cmd,long arg);//v0==4220

#endif

