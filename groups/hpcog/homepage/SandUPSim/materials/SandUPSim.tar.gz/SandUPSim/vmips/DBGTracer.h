/***
 * header for DBGTrigger.cc
 * $Header: /work/cvs/cvsroot/vmips/DBGTracer.h,v 1.15.6.3 2004/09/24 03:05:48 xjw Exp $
 * cmy
 */ 
#ifndef _DBGTRACER_H
#define _DBGTRACER_H
#include "cpu.h"
#include "tlb.h"
#include "debugtrigger.h"
#include "stub-dis.h"
#include "options.h"
#include <fcntl.h>
#include "VirtServRange.h"
#include <zlib.h>

#define WINSIZE 35
class DBGTrcPool;
//class VirtServRange;

class DBGTracer {
private:
		static CPU * cpulist[16];
		static gzFile  flist[16];
		static uint  trclen[16];
		static FILE  *stepfp;
		static uint64 stepcounter;
		struct streamtable
		{
			uint32 index;
			uint32 strart_addr;
			int stride;
			uint32 num;
			uint64 start_clock;
			uint64 end_clock;
			uint64 fc_hit_times;
			uint64 sc_hit_times;
			uint64 cache_miss_times;
			
			uint64 instgap;
			uint32 mininstgap;
			uint32 maxinstgap;
			double devinstgap;
			uint64 squinstgap;;
			
			uint64 clockgap;
			uint32 minclkgap;
			uint32 maxclkgap;			
			double devclkgap;
			uint64 squclkgap;			
			
			streamtable *next;
		};
		struct streampool
		{
			uint32 head[WINSIZE];
			int array[WINSIZE - 1][WINSIZE];
			bool valid[WINSIZE];
			int index;
			uint64 counter[WINSIZE];
			uint64 fc_hit_times[WINSIZE];
			uint64 sc_hit_times[WINSIZE];
			uint64 cache_miss_times[WINSIZE];
		};
/*the above for stat, the following for debug*/

		static int oraSock; // socket for barrier
		static int pid;

public:		
		static uint16 tracemask[16];
		static char* appname;
		static userinfo_t usinfo;
		static int tracing;
		static int count;
		static void showPostTrace(CPU* cpu);
		static int recTrace(CPU *);
		static void recMissTrace(CPU*);
		static int traceon(CPU *);
		static int traceoff(CPU *);
		static void stat_plot(CPU*);
		static void stat_percent(CPU*);
		static void stat_rate(CPU*);
		static void fast_mem(CPU*);
		static void detectstream(CPU*);
		static void detectmemsize(CPU*);
		static void analizestream(CPU*);
		
/*the above for stat, the following for debug*/
		
		static int64 trcVar[64];
		static int pause(void);
		static int barrier(void);		
		static int trigger(int cmd);
		
		static int attachCPU(CPU *, uint no=0);
		static DBGTrcPool pctrace;
		static void dumpregs(CPU * cpu);
		
		static int initOraSocket(int port = 6677);		
	
};

/* Keep a pool of history */
class DBGTrcPool {
	public:
	void record(uint32 data1, uint32 data2 = 0) {
			pool[poolhead] = data1;
			pooldata[poolhead] = data2;
			poolhead ++;
			if(poolhead == poolsize) poolhead = 0;
	};
	void dump(void);
	DBGTrcPool(uint sz, uint type = 0) {
		this->poolsize = sz;
		this->type = type;
		pool = new uint32[sz];
		pooldata = new uint32[sz];
		poolhead = 0;
	};
	~DBGTrcPool() {
		delete pool;
		delete pooldata;
	};
	private:
		uint type;
		uint poolsize;
		uint poolhead ;
		uint32 * pool;
		uint32 * pooldata;
};

#endif

