./configure --target=mipsel-dsag-linux-gnu --with-mips=/work/mips --with-mips-endianness=little
