#ifndef LIBCLINUXTYPES_H
#define LIBCLINUXTYPES_H

/******************topsy types**********************/
//note:architecture dependding
typedef unsigned long long uint64;
typedef unsigned long uint32;
typedef unsigned short uint16;
typedef unsigned char uint8;

//for topsy assistant getcwd
#define TAGETCWDOK 0
#define TAGETCWDFAILED -1
#define TAGETCWDABSOLUTE 1
#define TAGETCWDDIRNAME 0

//for telling vmips the memory mapping managed by Topsy
#define INVALID_MMMAPPING -1
typedef struct mmmappingitem{
	long physbase;
	long virtbase;
	long size;
}mmmappingitem_t;
typedef struct mmmapping{
	mmmappingitem_t codeseg;
	mmmappingitem_t dataseg;
	mmmappingitem_t brk_dynamic;
	mmmappingitem_t mmmap_dynamic;
	mmmappingitem_t stackseg;
}mmmapping_t;

/******************libc types***********************/
typedef long bool;
#define true 1
#define false 0
#ifndef _STDIO_H //usr prog already define FILE
typedef long FILE;
#define NULL 0
#define EOF -1
typedef long long loff_t;
typedef long off_t;
typedef unsigned int size_t;
#endif 


/******************linux types**********************/
/*for syscall fstat64( )>*/
#ifndef _I386_STAT_H
#define _I386_STAT_H

/* This matches struct stat64 in glibc2.1, hence the absolutely
 * insane amounts of padding around dev_t's.
 */
#define STATDOMAINNUMNEED 13
struct stat64for386{
	unsigned short	st_dev;
	unsigned char	__pad0[10];

#define STAT64_HAS_BROKEN_ST_INO	1
	unsigned long	__st_ino;

	unsigned int	st_mode;
	unsigned int	st_nlink;

	unsigned long	st_uid;
	unsigned long	st_gid;

	unsigned short	st_rdev;
	unsigned char	__pad3[10];

	long long		st_size;
	unsigned long	st_blksize;

	unsigned long	st_blocks;	//Number 512-byte blocks allocated. 
	unsigned long	__pad4;		// future possible st_blocks high bits 

	unsigned long	st_accesstime;
	unsigned long	__pad5;

	unsigned long	st_modifytime;
	unsigned long	__pad6;

	unsigned long	st_createtime;
	unsigned long	__pad7;		// will be high 32 bits of ctime someday 

	unsigned long long	st_ino;
};

struct stat64formips {
	unsigned long	st_dev;
	unsigned long	st_pad0[3];	//Reserved for st_dev expansion 
	unsigned long long st_ino;	//ino_t
	unsigned int	st_mode;	//mode_t
	int     		st_nlink;	//nlink_t
	int     		st_uid;		//uid_t
	int				st_gid;		//gid_t
	unsigned long	st_rdev;
	unsigned long	st_pad1[3];	//Reserved for st_rdev expansion
	long long		st_size;
	 // Actually this should be timestruc_t st_atime, st_mtime and st_ctime
	 // but we don't have it under Linux.
	long			st_accesstime;	//time_t
	unsigned long	reserved0;	// Reserved for st_atime expansion
	long			st_modifytime;	//time_t
	unsigned long	reserved1;	//Reserved for st_atime expansion 
	long			st_createtime;	//time_t
	unsigned long	reserved2;	// Reserved for st_atime expansion  
	unsigned long	st_blksize;
	long long		st_blocks;
};

#endif
/*for syscall fstat64( )<*/

//for syscall stat
struct statformips {
	unsigned int		st_dev;
	long				st_pad1[3];		/* Reserved for network id */
	unsigned long		st_ino;
	unsigned int		st_mode;
	int					st_nlink;
	int					st_uid;
	int					st_gid;
	unsigned int		st_rdev;
	long				st_pad2[2];
	long				st_size;
	long				st_pad3;
	/*
	 * Actually this should be timestruc_t st_atime, st_mtime and st_ctime
	 * but we don't have it under Linux.
	 */
	long				st_accesstime;
	long				reserved0;
	long				st_modifytime;
	long				reserved1;
	long				st_createtime;
	long				reserved2;
	long				st_blksize;
	long				st_blocks;
	long				st_pad4[14];
};

/*for syscall newuname( )>*/
#ifndef _LINUX_UTSNAME_H
#define _LINUX_UTSNAME_H
struct new_utsname_fori386{
	char sysname[65];
	char nodename[65];
	char release[65];
	char version[65];
	char machine[65];
	char domainname[65];
};
typedef struct new_utsname_fori386 new_utsname_formips;
#endif
/*for syscall newuname( )<*/

/*structure for syscall times*/
#ifndef _LINUX_TIMES_H
#define _LINUX_TIMES_H
struct tms {
	long tms_utime;
	long tms_stime;
	long tms_cutime;
	long tms_cstime;
};
#endif

/*struct for newselect*/
#ifndef _LINUX_POSIX_TYPES_H
#define _LINUX_POSIX_TYPES_H
#undef __NFDBITS
#define __NFDBITS	(8 * sizeof(unsigned long))

#undef __FD_SETSIZE
#define __FD_SETSIZE	1024

#undef __FDSET_LONGS
#define __FDSET_LONGS	(__FD_SETSIZE/__NFDBITS)

typedef struct {
	unsigned long fds_bits [__FDSET_LONGS];
} fd_set;
#endif

#ifndef _LINUX_TIME_H
#define _LINUX_TIME_H
struct timeval {
	long		tv_sec;		/* seconds */
	long	tv_usec;	/* microseconds */
};
#endif 

#ifndef _LINUX_RESOURCE_H
#define _LINUX_RESOURCE_H
/*
 * Resource control/accounting header file for linux
 */

/*
 * Definition of struct rusage taken from BSD 4.3 Reno
 * 
 * We don't support all of these yet, but we might as well have them....
 * Otherwise, each time we add new items, programs which depend on this
 * structure will lose.  This reduces the chances of that happening.
 */
#define	RUSAGE_SELF	0
#define	RUSAGE_CHILDREN	(-1)
#define RUSAGE_BOTH	(-2)		/* sys_wait4() uses this */

struct	rusageformips {
	struct timeval ru_utime;	/* user time used */
	struct timeval ru_stime;	/* system time used */
	long	ru_maxrss;		/* maximum resident set size */
	long	ru_ixrss;		/* integral shared memory size */
	long	ru_idrss;		/* integral unshared data size */
	long	ru_isrss;		/* integral unshared stack size */
	long	ru_minflt;		/* page reclaims */
	long	ru_majflt;		/* page faults */
	long	ru_nswap;		/* swaps */
	long	ru_inblock;		/* block input operations */
	long	ru_oublock;		/* block output operations */
	long	ru_msgsnd;		/* messages sent */
	long	ru_msgrcv;		/* messages received */
	long	ru_nsignals;		/* signals received */
	long	ru_nvcsw;		/* voluntary context switches */
	long	ru_nivcsw;		/* involuntary " */
};

struct rlimitformips {
	unsigned long	rlim_cur;
	unsigned long	rlim_max;
};
#endif/*resource limit*/

/*for signal*/
struct sigactioninvalid {
	long invalid;
};
typedef struct {
	unsigned long invalid;
} sigsetinvalid_t;

/*for nanosleep*/
struct timespecformips{
	long	tv_sec;		/* seconds */
	long	tv_nsec;	/* nanoseconds */
};

#endif/*end of file*/

