/*
	Copyright (c) 1996-1997 Swiss Federal Institute of Technology, 
	Computer Engineering and Networks Laboratory. All rights reserved.

	TOPSY - A Teachable Operating System. 
		Implementation of a tiny and simple micro kernel for
		teaching purposes.

	Permission to use, copy, modify, and distribute this software and its
	documentation for any purpose, without fee, and without written 
	agreement is hereby granted, provided that the above copyright notice 
	and the following two paragraphs appear in all copies of this software.


	
	File:                  $Source: /work/cvs/cvsroot/Topsy/Topsy/Support.c,v $
 	Author(s):             Christian Conrad
 	Affiliation:           ETH Zuerich, TIK
 	Version:               $Revision: 1.8 $
 	Creation Date:         
 	Last Date of Change:   $Date: 2003/12/09 07:57:24 $      by: $Author: slfsmm $
	
	
*/

#include "Support.h"


void byteCopy( Address targetAddress,
	       Address sourceAddress,
	       unsigned long int nbBytes)
{
    char* src = (char*)sourceAddress;
    char* tar = (char*)targetAddress;
    unsigned long int i;
    
    for (i = 0; i < nbBytes; i++) {
	*tar++ = *src++;
    }
}

void zeroOut(Address target, unsigned long int size)
{
    char* tar = (char*)target;
    unsigned long int i;
    
    for (i = 0; i < size; i++) *tar++ = 0;
}

void stringCopy( char* target,
		 char* source)
{
    while ((*target++ = *source++) != '\0')
      ;
}

void stringNCopy(char* target, char* source, unsigned long int size)
{
    while (((*target++ = *source++) != '\0') && ((--size) > 1)) ;
    *target = '\0';
}

long stringlen(char* buf)
{
	long count=0;
	while(buf[count])
		count++;
	return count;
}

int stringcmp(char *a, char *b)
{
	int i = 0;
	if (a != NULL && b != NULL) {
		while ((a[i] != '\0') && (b[i] != '\0')) {
			if (a[i] < b[i])
				return -1;
			if (a[i] > b[i])
				return 1;
			i++;
		}
		if ((a[i] == '\0')&&(b[i] == '\0'))
			return 0;
		else if(a == '\0')
			return -1;
		else
			return 1;
	}
	if((a == NULL)&&(b == NULL))
		return 0;
	else if(a == NULL)
		return -1;
	else
		return 1;
}

//from start, find a string block, the block base is returned, and the len of the block is in blocklen
//when no block *blocklen is 0!
char* findstringblock(char* start, long* blocklen)
{	
	char* blockstart;
	
	while((*start)==' ') start++;
	blockstart=start, *blocklen=0;
	while(((*start)!=' ')&&((*start)!='\0'))
		start++,(*blocklen)++;
	return blockstart;
	
}

//when find,return offset in block; when failed ,return -1
int findcharinblock(char* start,long len,char c)
{
	long count;
	for(count=0;count<len;count++)
		if(start[count]==c) return count;
	return -1;
}

void clearHeaderSpaceInString(char* src, char* des)
{
	while(*src==' ') src++;
	while((*des=*src)!='\0') des++,src++;
}

void clearEndingSpaceInString(char* str)
{
	long len=stringlen(str);
	long count;

	for(count=len-1;count>=0;count--){
		if(str[count]==' ') 
			continue;
		else{
			str[count+1]='\0';
			break;
		}
	}
}

//when meeting the first '\n', change it to '\0' in a string
void ReturnToNullInString(char* src)
{
	while((*src!='\0')&&(*src!='\n')) src++;
	if(*src=='\n') *src='\0';
}

//only copy n chars from source to dest
void StringOnlyNCopy(char* dest, char* src, long size)
{
	long count;
 	for(count=0;count<size;count++){
		*dest=*src;
		dest++;src++;
	}
}

