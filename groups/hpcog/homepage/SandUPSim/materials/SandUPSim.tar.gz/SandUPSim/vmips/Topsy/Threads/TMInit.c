/*
	Copyright (c) 1996-1997 Swiss Federal Institute of Technology, 
	Computer Engineering and Networks Laboratory. All rights reserved.

	TOPSY - A Teachable Operating System. 
		Implementation of a tiny and simple micro kernel for
		teaching purposes.

	Permission to use, copy, modify, and distribute this software and its
	documentation for any purpose, without fee, and without written 
	agreement is hereby granted, provided that the above copyright notice 
	and the following two paragraphs appear in all copies of this software.


	
	File:                  $Source: /work/cvs/cvsroot/Topsy/Threads/TMInit.c,v $
 	Author(s):             Christian Conrad
 	Affiliation:           ETH Zuerich, TIK
 	Version:               $Revision: 1.5 $
 	Creation Date:         
 	Last Date of Change:   $Date: 2004/01/11 09:30:38 $      by: $Author: slfsmm $
	
	
*/

#include "cpu.h"
#include "Topsy.h"
#include "TMHal.h"
#include "TMInit.h"
#include "TMClock.h"
#include "HashList.h"
#include "List.h"
#include "Support.h"
#include "Threads.h"
#include "TMIPC.h"
#include "TMScheduler.h"
#include "TMThread.h"
#include "TMError.h"

/* Global variables */
List threadList;                  /* Contains all threads (user & kernel) */
extern HashList threadHashList;   /* Hash list of all threads */
extern Scheduler scheduler;       /* Scheduler structure */

/* Statically allocated thread structures for tm and mm */
/*slfsmm031121_del>Thread and ProcContext are now in kenel stack!*/
/*
Thread mmThread, tmThread;
ProcContext mmContext, tmContext;
*/
/*slfsmm031121_del<*/

void dummyExceptionHandler(ThreadId id)
{
    WARNING("No exception handler has been set yet");
}

void dummyInterruptHandler()
{
    WARNING("No interrupt handler has been set yet");
}

void initBasicExceptions()
{
    int i;
    
    /* setup the exception and interrupt handling at its correct place.
     * this is highly machine dependent (vectorized exceptions vs. software
     * dispatch (as on the mips).
     */
    tmInstallExceptionCode();
	
    /* Initialization of default dummy exception handlers */
    for (i = 0; i < MAXNBOFEXCEPTIONS; i++) {
	tmSetExceptionHandler(i, dummyExceptionHandler);
    }
    for (i = 0; i < MAXNBOFINTERRUPTS; i++) {
	tmSetInterruptHandler(i, dummyInterruptHandler, NULL);
    }
}


void tmInit( Address mmStack, Address tmStack, Address userInit)
{
    /* Initialisation of the scheduler data structures.
     * The first thread is passed as argument.
     */
     ThreadPtr tmThreadPtr=(ThreadPtr)tmStack;
     ThreadPtr mmThreadPtr=(ThreadPtr)mmStack;
    
	/*slfsmm031121_mod>Thread and ProcContext are now in kenel stack!*/
    //schedulerInit(&tmThread);
    schedulerInit(tmThreadPtr);
	/*slfsmm031121_mod<*/
    lockInit(threadLock);

    /* build mm and tm threads */
	/*slfsmm031121_mod>Thread and ProcContext are now in kenel stack!*/
	/*
    threadBuild( MMTHREADID, 0, "mmThread", &mmContext,
		 mmStack, TM_DEFAULTTHREADSTACKSIZE,
		 mmMain, (ThreadArg)0, KERNEL, FALSE, &mmThread);
    threadBuild( TMTHREADID, 0, "tmThread", &tmContext,
		 tmStack, TM_DEFAULTTHREADSTACKSIZE,
		 tmMain, (ThreadArg)userInit, KERNEL, FALSE, &tmThread);
	*/
	threadBuild( MMTHREADID, 0, "mmThread", 
		(ProcContextPtr)(mmStack+TM_DEFAULTTHREADSTACKSIZE-sizeof(ProcContext)),
		mmStack, TM_DEFAULTTHREADSTACKSIZE,
		mmMain, (ThreadArg)0, KERNEL, FALSE,mmThreadPtr );
	threadBuild( TMTHREADID, 0, "tmThread", 
		(ProcContextPtr)(tmStack+TM_DEFAULTTHREADSTACKSIZE-sizeof(ProcContext)),
		tmStack, TM_DEFAULTTHREADSTACKSIZE,
		tmMain, (ThreadArg)userInit, KERNEL, FALSE, tmThreadPtr);
	/*slfsmm031121_mod<*/

    /* Store pointer to mm and tm in threadHashList hash table */
    threadHashList = hashListNew();
    hashListAdd( threadHashList,mmThreadPtr, mmThreadPtr->id);
    hashListAdd( threadHashList, tmThreadPtr, tmThreadPtr->id);

    /* add mm and tm to threadList */
    threadList = listNew();
    listAddInFront(threadList, mmThreadPtr, NULL);
    listAddInFront(threadList, tmThreadPtr, NULL);
    
    /* Setting of default handlers for SYSCALL and Hardware exceptions */
    tmInstallErrorHandlers();

    /* Threads mm and tm are set to ready status, scheduling decision */
    schedulerSetReady(mmThreadPtr);
    schedulerSetReady(tmThreadPtr);

    INFO("MM and TM threads initialized and set to ready status");

    schedule();					/* first thread is picked */


    /* Clock configuration */
    if (setClockValue( CLOCK0, TIMESLICE, RATEGENERATOR ) != TM_OK) {
	PANIC("Clock could not be properly configured");
    }
    
    /* Restoring context of first thread to be activated */
    INFO("clock ready, restoring first kernel thread");
    
    restoreContext(scheduler.running->contextPtr);
    /*** initialization of the kernel ends here, from this point 
     *** we run in kernel mode with interrupts enabled.
     *** now this is the real thing (tm)...
     ***/
    

}
