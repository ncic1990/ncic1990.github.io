/* R3000 system control coprocessor emulation ("coprocessor zero").
   Copyright 2001, 2002, 2003 Brian R. Gaeke.

This file is part of VMIPS.

VMIPS is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 2 of the License, or (at your
option) any later version.

VMIPS is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
for more details.

You should have received a copy of the GNU General Public License along
with VMIPS; if not, write to the Free Software Foundation, Inc.,
59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.  */

/* Code to implement MIPS coprocessor zero (the "system control
 * coprocessor"), which provides for address translation and
 * exception handling.
 */

#include "cpzero.h"
#include "mapper.h"
#include "excnames.h"
#include "cpu.h"
#include "clkcpu.h"//added by zhangwl
#include "cpzeroreg.h"
#include "intctrl.h"
#include "deviceexc.h"
#include "error.h"
#include "tlb.h"
#include "vmips.h"

/*slfsmm031107_add>*/
//#define DEBUGCONFIG
/*slfsmm031107_add<*/

//STAT  stat_info;
static uint32 read_masks[] = {
	/*slfsmm031107_mod>*/
	//Index_MASK, Random_MASK, 
	R3k_Index_MASK, R3k_Random_MASK, 
	/*slfsmm031107_mod<*/
	EntryLo_MASK, 0, Context_MASK,
	PageMask_MASK, Wired_MASK, Error_MASK, BadVAddr_MASK, Count_MASK,
	EntryHi_MASK, Compare_MASK, Status_MASK, Cause_MASK, EPC_MASK,
	PRId_MASK, Config_MASK, LLAddr_MASK, WatchLo_MASK, WatchHi_MASK,
	0, 0, 0, 0, 0, 0, ECC_MASK, CacheErr_MASK, TagLo_MASK, TagHi_MASK,
	ErrorEPC_MASK, 0
};

static uint32 write_masks[] = {
	/*slfsmm031107_mod>*/
	//Index_MASK, 0, 
	R3k_Index_MASK, 0, 
	/*slfsmm031107_mod<*/
	EntryLo_MASK, 0, Context_MASK & ~Context_BadVPN_MASK,
	PageMask_MASK, Wired_MASK, Error_MASK, 0, Count_MASK,
	EntryHi_MASK, Compare_MASK, Status_MASK,
	Cause_MASK & ~Cause_IP_Ext_MASK, 0, 0, Config_MASK, LLAddr_MASK,
	WatchLo_MASK, WatchHi_MASK, 0, 0, 0, 0, 0, 0, ECC_MASK,
	CacheErr_MASK, TagLo_MASK, TagHi_MASK, ErrorEPC_MASK, 0
};

/* Initialization */
CPZero::CPZero(CPU *m, IntCtrl *i)
{
//	attach(m, i);	
	int j;

	for(j=0;j<32;j++)
		reg[j]=0;
//	Random_Seed = (uint32) time(NULL);
//	fprintf(stderr, "@@@@  Random_Seed->%x\n",Random_Seed);	
	Random_Seed = 0x123456;
}

/* Reset (warm or cold) */
void
CPZero::reset(void)
{
	int r;
	for (r = 0; r < 16; r++) {
#ifdef INTENTIONAL_CONFUSION
		reg[r] = random() & (read_masks[r] | write_masks[r]);
#endif /* INTENTIONAL_CONFUSION */
	}
	/* Turn off any randomly-set pending-interrupt bits, as these
	 * can impact correctness. */
	reg[Cause] &= ~Cause_IP_MASK;
	/* Reset Random register to upper bound (8<=Random<=63) */
	//slfsmm_note:tlb entry number can be modified in config file
	reg[Random] = Random_UPPER_BOUND << Random_Shift;
	/* Reset Status register: clear KUc, IEc, SwC (i.e., caches are not
	 * switched), TS (TLB shutdown has not occurred), and set BEV (Bootstrap
	 * exception vectors ARE in effect).
	 */
	reg[Status] = (reg[Status] | Status_DS_BEV_MASK) &
		~(Status_KUc_MASK | Status_IEc_MASK | Status_DS_SwC_MASK |
		  Status_DS_TS_MASK);
	reg[PRId] = 0x00000230; /* MIPS R3000A */
}

/* We have been presented with a CPU and/or interrupt controller to
 * associate with. */
void 
CPZero::SetHWConfig( )
{
	/*slfsmm031107_add>the tlb entry number can be modified through config file*/
	#ifdef DEBUGCONFIG
	fprintf(stderr,"cpzeroMsg:SetHWConfig begins...\n");
	#endif
	/* (1) Random fields */
	Random_UPPER_BOUND=machine->opt_tlbentrynum-1;
	Random_LOWER_BOUND=machine->opt_tlbentryreserved;
	Random_Random_MASK=Random_UPPER_BOUND<<Random_Shift;
	/*slfsmm031107_note>*/
	Random_MASK=Random_Random_MASK;	//I am not sure
	/*slfsmm031107_note<*/
	/* (0) Index fields */
	Index_Index_MASK=Random_UPPER_BOUND<<Index_Shift;
	Index_MASK=Index_Index_MASK|Index_P_MASK;

	//reconfig the read_masks and write_masks
	read_masks[Index]=Index_MASK;
	read_masks[Random]=Random_MASK;
	write_masks[Index]=Index_MASK;
	
	#ifdef DEBUGCONFIG
	fprintf(stderr,"cpzeroMsg:Index_Index_MASK->0x%x, Index_MASK->0x%x\n",
		Index_Index_MASK,Index_MASK);
	fprintf(stderr,"cpzeroMsg:Random_Random_MASK->0x%x, Random_MASK->0x%x\n",
		Random_Random_MASK,Random_MASK);
	fprintf(stderr,"cpzeroMsg:Random_UPPER_BOUND->0x%x, Random_LOWER_BOUND->0x%x\n",
		Random_UPPER_BOUND,Random_LOWER_BOUND);
	fprintf(stderr,"cpzeroMsg:SetHWConfig ends!\n");
	#endif
	/*slfsmm031107_add<*/
}
void
CPZero::attach(vmips* vm,CPU *m, IntCtrl *i, TLB* t)
{
	machine=vm;
	if (m) cpu = m;
	if (i) intc = i;
	tlb = t;
	if(machine==NULL) fprintf(stderr,"fatal error:cpzero::attach:machine is NULL!\n");
	SetHWConfig();
}


void
CPZero::dump_regs(FILE *f)
{
	int x;

	fprintf(f, "CP0 Dump Registers: [       ");
	for (x = 0; x < 16; x++) {
		fprintf(f," R%02d=%08x ",x,reg[x]);
		if (x % 4 == 1) {
			fputc('\n',f);
		}
	}
	fprintf(f, "]\n");
}

void
CPZero::dump_tlb(FILE *f)
{
	int x;
        TLB_ENTRY  e;
	uint32 * p;
	fprintf(f, "Dump TLB: [\n");
	for (x=0;x<64;x++) 
	{
		e = tlb -> tlb_entry[x];
		p = (uint32*)(&(tlb -> tlb_entry[x]));
		fprintf(f,"Entry %02d: (%08x%08x) V=%05x A=%02x P=%05x %c%c%c%c\n", x,
			(* (p + 1)), (*p), e.entry.vpn, e.entry.asid, e.entry.pfn,
                        e.entry.n?'n':'N', e.entry.d?'D':'d', e.entry.v?'V':'v', e.entry.g?'G':'g');
	}
	fprintf(f, "]\n");
}

void
CPZero::dump_regs_and_tlb(FILE *f)
{
	dump_regs(f);
	dump_tlb(f);
}

/* Request for address translation (possibly using the TLB). */
uint32
CPZero::address_trans(uint32 vaddr, int mode, bool *cacheable,
	DeviceExc *client)
{
	if (kernel_mode()) {
		switch(vaddr & KSEG_SELECT_MASK) {
			case KSEG0:
				*cacheable = true;
				return vaddr - KSEG0_CONST_TRANSLATION;
				break;
			case KSEG1:
				*cacheable = false;
				return vaddr - KSEG1_CONST_TRANSLATION;
				break;
			case KSEG2:
			case KSEG2_top:
				return tlb -> addr_translate(KSEG2, vaddr, mode, cacheable, client);
				break;
			default: /* KUSEG */
				return tlb -> addr_translate(KUSEG, vaddr, mode, cacheable, client);
				break;
		}
	} else /* user mode */ {
		if (vaddr & KERNEL_SPACE_MASK) {
			/* Can't go there. */
			client->exception(mode == DATASTORE ? AdES : AdEL, mode);
			return 0xffffffff;
		} else /* user space address */ {
			return tlb -> addr_translate(KUSEG, vaddr, mode, cacheable, client);
		}
	}
}

void
CPZero::mfc0_emulate(uint32 instr, uint32 pc)
{
	cpu->reg[cpu->rt(instr)] =
		(reg[cpu->rd(instr)] & read_masks[cpu->rd(instr)]);
}

void
CPZero::mtc0_emulate(uint32 instr, uint32 pc)
{
	int regno = cpu->rd(instr);
	uint32 new_data = cpu->reg[cpu->rt(instr)];

	/* DO AS I SAY, NOT AS I DO...
	 * This preserves the bits which are readable but not writable,
     * and writes the bits which are writable with new data, thus
	 * making it suitable for mtc0-type operations.
	 * If you want to write all the bits which are _connected_,
	 * use reg[regno] = new_data & write_masks[regno]; .
     */
	reg[regno] = (reg[regno] & (read_masks[regno] & ~write_masks[regno]))
		| (new_data & write_masks[regno]);
}

void
CPZero::bc0x_emulate(uint32 instr, uint32 pc)
{
	uint16 condition = cpu->rt(instr);
	switch(condition)
        {
		case 0: /* bc0f */ if (! cpCond) { cpu->branch(instr, pc); } break;
		case 1: /* bc0t */ if (cpCond) { cpu->branch(instr, pc); } break;
		case 2: /* bc0fl - not valid, but not reserved(A-17, H&K) - no-op. */ ;
		case 3: /* bc0tl - not valid, but not reserved(A-21, H&K) - no-op. */ ;
		default: cpu->exception(RI); break; /* reserved */
	}
}
void
CPZero::rfe_emulate(uint32 instr, uint32 pc)
{
		reg[Status] = (reg[Status] & 0xfffffff0) | ((reg[Status] >> 2) & 0x0f);
}

//added by zhangwl on Oct 21th 2003
/*void
CPZero::rfe_clkemulate(uint32 instr, uint32 pc)
{
	if (!(clkcpu->exception_pending))
		reg[Status] = (reg[Status] & 0xfffffff0) | ((reg[Status] >> 2) & 0x0f);
}

bool tempreg2(uint16 temp) //judge temp register
{
	return(((temp >= 8) &&(temp <= 15)) || (temp == 24) || (temp == 25));	
}*/

void
CPZero::mfc0_clkemulate(uint32 pc)
{
	clkcpu->ex_mem.ALUoutput = 
		(reg[clkcpu->id_ex.rd] & read_masks[clkcpu->id_ex.rd]); //temp measure
}

void
CPZero::mtc0_clkemulate(uint32 pc)
{
	int regno = clkcpu->id_ex.rd;
	uint32 new_data = clkcpu->id_ex.b;

	/* DO AS I SAY, NOT AS I DO...
	 * This preserves the bits which are readable but not writable,
     * and writes the bits which are writable with new data, thus
	 * making it suitable for mtc0-type operations.
	 * If you want to write all the bits which are _connected_,
	 * use reg[regno] = new_data & write_masks[regno]; .
     */
	reg[regno] = (reg[regno] & (read_masks[regno] & ~write_masks[regno]))
		| (new_data & write_masks[regno]);

}

void
CPZero::bc0x_clkemulate(uint32 pc)
{
	uint16 condition = clkcpu->id_ex.rt;
	switch(condition)
        {
		case 0: /* bc0f */ if (! cpCond) { clkcpu->branch(pc); } break;
		case 1: /* bc0t */ if (cpCond) { clkcpu->branch(pc); } break;
		case 2: /* bc0fl - not valid, but not reserved(A-17, H&K) - no-op. */ ;
		case 3: /* bc0tl - not valid, but not reserved(A-21, H&K) - no-op. */ ;
		default: clkcpu->exception(RI); break; /* reserved */
	}
}
//end -added by zhangwl on Oct 21th 2003

//added by zhangwl on Oct 21th 2003
void
CPZero::cpzero_clkemulate(uint32 pc)
{
	clkcpu = (CLKCPU *) cpu;
	if (clkcpu->id_ex.rs > 15) {
		switch(clkcpu->id_ex.funct) {
			case 1: tlb -> tlbr_emulate(clkcpu->id_ex.instr, pc); break;
			case 2: tlb -> tlbwi_emulate(clkcpu->id_ex.instr, pc); break;
			case 6: tlb -> tlbwr_emulate(clkcpu->id_ex.instr, pc); break;
			case 8: tlb -> tlbp_emulate(clkcpu->id_ex.instr, pc); break;
			case 16: rfe_emulate(clkcpu->id_ex.instr, pc); break;//instr, 
			default: clkcpu->exception(RI,ANY,0); break;
		}
	} else {
		switch(clkcpu->id_ex.rs) {
			case 0: mfc0_clkemulate(pc); break;//instr,
			case 2: cpu->exception(RI,ANY,0); break; /* cfc0 - reserved */
			case 4: mtc0_clkemulate(pc); break;//instr,
			case 6: clkcpu->exception(RI,ANY,0); break; /* ctc0 - reserved */
			case 8: bc0x_clkemulate(pc); break;//instr,
			default: clkcpu->exception(RI,ANY,0); break;
		}
	}
}

//end -added by zhangwl on Oct 21th 2003

void
CPZero::cpzero_emulate(uint32 instr, uint32 pc)
{
	if (cpu->rs(instr) > 15) {
		switch(cpu->funct(instr)) {
			case 1: tlb -> tlbr_emulate(instr, pc); break;
			case 2: tlb -> tlbwi_emulate(instr, pc); break;
			case 6: tlb -> tlbwr_emulate(instr, pc); break;
			case 8: tlb -> tlbp_emulate(instr, pc); break;
			case 16: rfe_emulate(instr, pc); break;
			default: cpu->exception(RI,ANY,0); break;
		}
	} else {
		switch(cpu->rs(instr)) {
			case 0: mfc0_emulate(instr,pc); break;
			case 2: cpu->exception(RI,ANY,0); break; /* cfc0 - reserved */
			case 4: mtc0_emulate(instr,pc); break;
			case 6: cpu->exception(RI,ANY,0); break; /* ctc0 - reserved */
			case 8: bc0x_emulate(instr,pc); break;
			default: cpu->exception(RI,ANY,0); break;
		}
	}
}
/* For initial == 12, lower bound == 8, upper bound == 63, the
 * sequence looks like this:
 *  12 11 10  9  8 63 62 61 60 ... 12 11 10  9  8 63 ... (x)
 *  51 52 53 54 55  0  1  2  3 ... 51 52 53 54 55  0 ... (63 - x)
 */
void
CPZero::adjust_random(void)
{
#ifndef LAZY_RANDOM
	int32 r = (int32) (reg[Random] >> Random_Shift);
    r = -(((Random_UPPER_BOUND - r + 1) %
		(Random_UPPER_BOUND - Random_LOWER_BOUND + 1)) -
			Random_UPPER_BOUND);
	reg[Random] = (uint32) (r << Random_Shift);
#else	
	/* see CPZero() for initial seed  */
	srand(Random_Seed);
	Random_Seed = rand();
	reg[Random] = (( Random_Seed % (Random_UPPER_BOUND-Random_LOWER_BOUND +1 )) + Random_LOWER_BOUND) << Random_Shift;
#endif
}
/* move to .h for speed : cmy
uint32
CPZero::getIP(void)
{
    uint32 HwIP = 0, IP = 0;
	if (intc != NULL) {
		HwIP = intc->calculateIP();	// Check for a hardware interrupt.
	}
	IP = (reg[Cause] & Cause_IP_SW_MASK) | HwIP;
    return IP;
}
********/

void
CPZero::enter_exception(uint32 pc, uint32 excCode, uint32 ce, bool dly)
{

	if(excCode > 3 && excCode !=8 && excCode != 9) {
			DBGTracer::pause();
			DBGTracer::pctrace.dump();
			DBGTracer::dumpregs(cpu);
	}
	/* Save exception PC in EPC. */
	reg[EPC] = pc;
	/* Disable interrupts and enter Kernel mode. */
	reg[Status] = (reg[Status] & ~Status_KU_IE_MASK) |
		((reg[Status] & Status_KU_IE_MASK) << 2);
	/* Clear Cause register BD, CE, and ExcCode fields. */
	reg[Cause] &= ~(Cause_BD_MASK|Cause_CE_MASK|Cause_ExcCode_MASK);
	/* Set Cause register CE field if this is a Coprocessor
	 * Unusable exception. (If we are passed ce=-1 we don't want
	 * to toggle bits in Cause.) */
	if (excCode == CpU) {
	  reg[Cause] |= ((ce & 0x3) << 28);
	}
	/* Update IP, BD, ExcCode fields of Cause register. */
	reg[Cause] |= getIP () | (dly << 31) | (excCode << 2);
}

bool
CPZero::use_boot_excp_address(void)
{
	return (reg[Status] & Status_DS_BEV_MASK);
}

bool
CPZero::caches_isolated(void)
{
	return (reg[Status] & Status_DS_IsC_MASK);
}

bool
CPZero::caches_swapped(void)
{
	return (reg[Status] & Status_DS_SwC_MASK);
}

bool
CPZero::cop_usable(int coprocno)
{
	switch (coprocno) {
		case 3: return (reg[Status] & Status_CU3_MASK);
		case 2: return (reg[Status] & Status_CU2_MASK);
		case 1: return (reg[Status] & Status_CU1_MASK);
		case 0: return (reg[Status] & Status_CU0_MASK);
		default: fatal_error ("Bad coprocno passed to CPZero::cop_usable()");
	};
}


/* move to .h for speed : cmy
bool
CPZero::interrupt_pending(void)
{
	if (! interrupts_enabled())
		return false;	// Can't very well argue with IEc == 0... 
	// Mask IP with the interrupt mask, and return true if nonzero: 
	return ((getIP () & (reg[Status] & Status_IM_MASK)) != 0);
}
******/
void
CPZero::read_debug_info(uint32 *status, uint32 *bad, uint32 *cause)
{
	*status = reg[Status];
	*bad = reg[BadVAddr];
	*cause = reg[Cause];
}

void
CPZero::write_debug_info(uint32 status, uint32 bad, uint32 cause)
{
	reg[Status] = status;
	reg[BadVAddr] = bad;
	reg[Cause] = cause;
}

/* TLB translate VADDR without exceptions.  Returns true if a valid
 * TLB mapping is found, false otherwise. If VADDR has no valid mapping,
 * PADDR is written with 0xffffffff, otherwise it is written with the
 * translation.
 */
