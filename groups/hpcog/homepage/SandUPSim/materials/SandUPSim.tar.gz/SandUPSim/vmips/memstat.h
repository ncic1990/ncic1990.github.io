/*This is the mem stat module of sand simulator, which is developed by
ASL group of NCIC;
Copyright 2003 by ASL NCIC */
#ifndef _MEMSTAT_H
#define _MEMSTAT_H

#include "sysinclude.h"
#include "memstatreg.h"
#include "accesstypes.h"


union  BOOLVAL
{
		uint16 content;
		struct 
		{			 
	      		 unsigned  cache_hitted : 1;  // 1 if the cache hitted 
		        unsigned  tlb_hitted : 1;          // 1 if tlb miss
      			 unsigned  tlb_invalidate : 1;        // 1 if the tlb hit, but is invalidated
		        unsigned  tlb_modication : 1;     // 1 if the tlb modication execption happened
            		 unsigned  vbuf_hitted : 1;         // 1 if the victim buffer is hitted
		        unsigned  pbuf_hitted : 1;         // 1 if the prefetch buffer is hitted
        		unsigned  block_matched : 1;       // 1 if block register is matched
	      		 unsigned  page_faulted : 1;        // 1 if page faulted else 0
	      		 unsigned cacheable : 1;        // 1 if the addr translate through cache
	      		 unsigned read_or_write : 1;      // 1 if this access memory is read
	      		 unsigned inst_or_data : 1;    // 1 if this access memory is about inst
	      		 unsigned cacheinv    	    : 1;   // 1 if this access find a invalidate cache entry
		}val; 		
};
struct STAT_INFO
{
	
	BOOLVAL boolval;
        uint8 hitted_cache_level;   // which level of cache is hitted.,if cache_hitted is 0,
        uint32  addr;         		  // the address of the instruction or data        
        uint16 hit_time;                // the time need for complete this memory_referenced
	uint64 counter;                             
	uint64 fc_hit_times;
	uint64 sc_hit_times;
	uint64 cache_miss_times;
};
class  Memstat
{
	friend class DBGTracer;
	friend class vmips;
	friend class CPU;
protected:                          
	bool trace_start;
	uint16 mem_mask;
	STAT_INFO  stat_info;
//	uint16  boolval;
	
	uint8* buf;
	
	int cache_lev;
       uint64 *dcache_hit_times;  //total times of  data cache miss
       uint64 *icache_hit_times;  //total times of  instr cache miss
       
       uint64 tlb_miss_times;         // total times of tlb miss
       uint64 tlb_hit_times;            //total times of tlb hit
       uint64 dcache_miss_times;    // times of last level cache misses when data related       
       uint64 icache_miss_times; // l times of last level cache misses when instruction related
	
public:

	uint32 pbuf_miss_times;  // times of pbuf misses when data related
	
	Memstat();

	void RefreshTrace();	
	void TraceStart();	
        int  SetTraceMask(uint16 mask);
        void ShowTrace(uint16 mask, STAT_INFO  stat );
	void ShowTrace();
        void TraceEnd();
	void getcachelev(int lev);

inline void RecoverTrace(uint8 mask, uint8* data, STAT_INFO* result)
{
	uint8* p = data;
	if(mask & BoolMask)
	{
		uint16 boolval = *(uint16*)p;
		p += 2;
		(result ->boolval).val.cacheable = (bool)(boolval & CacheableMask);
		(result ->boolval).val.cache_hitted = (bool)(boolval & CacheHitMask);
		(result ->boolval).val.tlb_hitted = (bool)(boolval & TlbHitMask);
		(result ->boolval).val.tlb_invalidate = (bool)(boolval & TlbINVMask);
		(result ->boolval).val.tlb_modication =(bool)( boolval & TlbModifyMask);
		(result ->boolval).val.vbuf_hitted = (bool)(boolval & VBufHitMask);
		(result ->boolval).val.pbuf_hitted = (bool)(boolval & PBufHitMask);
		(result ->boolval).val.block_matched = (bool)(boolval & BlockHitMask);
		(result ->boolval).val.page_faulted = (bool)(boolval & PageFaultMask);
		(result ->boolval).val.inst_or_data = (bool)(boolval & InstOrData);
		(result ->boolval).val.read_or_write = (bool)(boolval & ReadOrWrite);
		(result ->boolval).val.cacheinv = (bool)(boolval & CacheInvMask);
	}
	if(mask & CacheHitLevMask)
	{
		result ->hitted_cache_level = * p;
		p ++;
	}
	if (mask & HitTimeMask)
	{
		result ->hit_time = *(uint16*)p;
		p += 2;
	}
	if (mask & AddrMask)
	{
		result ->addr = *(uint32*)p;
		p += 4;
	}
	if ( mask & CounterMask)
	{
		result ->counter = *(uint64*)p;
		p += 8;
	}
	if(mask & CachefcMask)
	{
		result ->fc_hit_times = *(uint64*)p;
		p += 8;
	}
	if(mask & CachescMask)
	{
		result ->sc_hit_times = *(uint64*)p;
		p += 8;
	}
	if(mask & CachemissMask)
	{
		result ->cache_miss_times = *(uint64*)p; 
	}
}

inline uint8*  GetTracebuf()
{
	uint8* p = buf;	
	if(trace_start)
	{
		if(mem_mask & BoolMask)
		{			
			*(uint16*)p = stat_info.boolval.content;
			p += 2;
		}
		if(mem_mask & CacheHitLevMask)
		{
			*(uint8*)p = stat_info.hitted_cache_level;
			p ++;
		}
		if(mem_mask & HitTimeMask)
		{
			*(uint16*)p = stat_info.hit_time;
			p += 2;
		}
		if (mem_mask & AddrMask)
		{
			*(uint32*)p = stat_info.addr;
			p += 4;
		}
		if (mem_mask & CounterMask)
		{
			*(uint64*)p = stat_info.counter;
			p += 8;
		}
		if(mem_mask & CachefcMask)
		{
			*(uint64*)p = dcache_hit_times[0] + icache_hit_times[0];
			p += 8;
		}
		if(mem_mask & CachescMask)
		{
			*(uint64*)p = dcache_hit_times[1] + dcache_hit_times[1];
			p += 8;
		}
		if(mem_mask & CachemissMask)
		{
			*(uint64*)p = dcache_miss_times + icache_miss_times;
		}
 
		}
	
	return buf;
}
inline void SetHitTime(uint8 hit_time)
{
	if(trace_start && (mem_mask & HitTimeMask))
		stat_info.hit_time = hit_time;
}

inline void SetHitLev(uint8 hit_lev, int32 mode)
{
	if(trace_start && (mem_mask & CacheHitLevMask))
	{
		stat_info.hitted_cache_level = hit_lev;
		if (hit_lev == cache_lev)
		{
			if(mode == INSTFETCH)
				icache_miss_times ++;
			else
				dcache_miss_times ++;
			return;
		}
		if (mode == 	INSTFETCH)
		{
			icache_hit_times[hit_lev] ++;
			return;
		}
		dcache_hit_times[hit_lev] ++;
		return;		
	}
	else
		stat_info.hitted_cache_level = 0;
}
inline void SetStatBool(uint16 set_mask,bool val)
{
	uint16 nset_mask= ~set_mask;
	if(trace_start && (mem_mask & BoolMask))	
	{
		if(val)
			stat_info.boolval.content |= set_mask;	
		else		
			stat_info.boolval.content &= nset_mask;	
		if(set_mask == TlbHitMask)
			if(!val)
				tlb_miss_times ++;
			else
				tlb_hit_times ++;
	}
}
inline void SetAddr(uint32 addr)
{
	if(trace_start && (mem_mask & AddrMask))		
		stat_info.addr = addr;	
}
};
#endif // _MEMSTAT_H


