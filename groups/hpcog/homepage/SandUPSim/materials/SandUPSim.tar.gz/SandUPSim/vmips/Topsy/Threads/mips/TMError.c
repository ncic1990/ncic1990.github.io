/*
	Copyright (c) 1996-1997 Swiss Federal Institute of Technology, 
	Computer Engineering and Networks Laboratory. All rights reserved.

	TOPSY - A Teachable Operating System. 
		Implementation of a tiny and simple micro kernel for
		teaching purposes.

	Permission to use, copy, modify, and distribute this software and its
	documentation for any purpose, without fee, and without written 
	agreement is hereby granted, provided that the above copyright notice 
	and the following two paragraphs appear in all copies of this software.


	
	File:                  $Source: /work/cvs/cvsroot/Topsy/Threads/mips/TMError.c,v $
 	Author(s):             Christian Conrad
 	Affiliation:           ETH Zuerich, TIK
 	Version:               $Revision: 1.21 $
 	Creation Date:         
 	Last Date of Change:   $Date: 2004/01/10 09:30:38 $      by: $Author: slfsmm $
	
	
*/

#include "TMError.h"
#include "Threads.h"
#include "Messages.h"
#include "TMHal.h"
#include "TMScheduler.h"
#include "LinuxSyscallUnistd.h"

static void tmReservedInstructionError(ThreadId currentThread);
static void tmCPunusableError(ThreadId currentThread);
static void tmOverflowError(ThreadId currentThread);
static void tmBreakpointError(ThreadId currentThread);


void tmInstallErrorHandlers(void)
{
    int i;
    /* Vital for correct operations
     */
    tmSetExceptionHandler(SYSCALL, syscallExceptionHandler);
    tmSetExceptionHandler(HARDWARE_INT, hwExceptionHandler);
    tmSetInterruptHandler(CLOCKINT_0, tmClockHandler, NULL);

    /* Error handling for faulting threads
     */
    tmSetExceptionHandler(RES_INSTR, tmReservedInstructionError);
    tmSetExceptionHandler(CP_UNUSABLE, tmCPunusableError);
    tmSetExceptionHandler(OVERFLOW, tmOverflowError);
    tmSetExceptionHandler(BREAKPOINT, tmBreakpointError);

//    #ifndef REMOTESYSCALL
	/*slfsmm>Linux syscall handler*/
	for(i=0;i<MAXLINUXSYSCALL;i++)
		tmSetLinuxSyscallHandler(__NR_sys_Linux+i,SysCallNotImplemented);
 	tmSetLinuxSyscallHandler(__NR_sys_exit,LinuxSyscallExit); //4001
	tmSetLinuxSyscallHandler(__NR_sys_read,LinuxSyscallRead);//4003
	tmSetLinuxSyscallHandler(__NR_sys_write,LinuxSyscallWrite);//4004
	tmSetLinuxSyscallHandler(__NR_sys_open,LinuxSyscallOpen);//4005
	tmSetLinuxSyscallHandler(__NR_sys_close,LinuxSyscallClose);//4006
	tmSetLinuxSyscallHandler(__NR_sys_unlink,LinuxSyscallunlink);//4010
	tmSetLinuxSyscallHandler(__NR_sys_time,LinuxSyscalltime);//4013
	tmSetLinuxSyscallHandler(__NR_sys_lseek,LinuxSyscalllseek);//4019
	tmSetLinuxSyscallHandler(__NR_sys_getpid,LinuxSyscallgetpid);//4020
	tmSetLinuxSyscallHandler(__NR_sys_getuid,LinuxSyscallgetuid);//4024
	tmSetLinuxSyscallHandler(__NR_sys_access,LinuxSyscallaccess);//4033
	tmSetLinuxSyscallHandler(__NR_sys_rename,LinuxSyscallrename);//4038
	tmSetLinuxSyscallHandler(__NR_sys_times,LinuxSyscalltimes);//4043
	tmSetLinuxSyscallHandler(__NR_sys_brk,LinuxSyscallbrk);//4045
	tmSetLinuxSyscallHandler(__NR_sys_getgid,LinuxSyscallgetgid);//4047
	tmSetLinuxSyscallHandler(__NR_sys_geteuid,LinuxSyscallgeteuid);//4049
	tmSetLinuxSyscallHandler(__NR_sys_getegid,LinuxSyscallgetegid);//4050
	tmSetLinuxSyscallHandler(__NR_sys_ioctl,LinuxSyscallioctl);//4054
	tmSetLinuxSyscallHandler(__NR_sys_fcntl,LinuxSyscallfcntl);//4055
	tmSetLinuxSyscallHandler(__NR_sys_setrlimit,LinuxSyscallsetrlimit);//4075
	tmSetLinuxSyscallHandler(__NR_sys_getrlimit,LinuxSyscallgetrlimit);//4076
	tmSetLinuxSyscallHandler(__NR_sys_getrusage,LinuxSyscallgetrusage);//4077
	tmSetLinuxSyscallHandler(__NR_sys_mmap,LinuxSyscallmmap);//4090
	tmSetLinuxSyscallHandler(__NR_sys_munmap,LinuxSyscallmunmap);//4091
	tmSetLinuxSyscallHandler(__NR_sys_ftruncate,LinuxSyscallftruncate);//4093
	tmSetLinuxSyscallHandler(__NR_sys_stat,LinuxSyscallstat);//4106
	tmSetLinuxSyscallHandler(__NR_sys_lstat,LinuxSyscalllstat);//4107
	tmSetLinuxSyscallHandler(__NR_sys_fstat,LinuxSyscallfstat);//4108
	tmSetLinuxSyscallHandler(__NR_sys_uname,LinuxSyscallnewuname);//4122
	tmSetLinuxSyscallHandler(__NR_sys_mprotect,LinuxSyscallmprotect);//4125
	tmSetLinuxSyscallHandler(__NR_sys__llseek,LinuxSyscallllseek);//4140
	tmSetLinuxSyscallHandler(__NR_sys__newselect,LinuxSyscallnewselect);//4142
	tmSetLinuxSyscallHandler(__NR_sys_nanosleep,LinuxSyscallnanosleep);//4166
	tmSetLinuxSyscallHandler(__NR_sys_rt_sigaction,LinuxSyscallrt_sigaction);//4194
	tmSetLinuxSyscallHandler(__NR_sys_rt_sigprocmask,LinuxSycallrt_sigprocmask);//4195
	tmSetLinuxSyscallHandler(__NR_sys_mmap2,LinuxSyscallmmap2);//4210
	tmSetLinuxSyscallHandler(__NR_sys_ftruncate64,LinuxSyscallftruncate64);//4212
	tmSetLinuxSyscallHandler(__NR_sys_stat64,LinuxSyscallstat64);//4213
	tmSetLinuxSyscallHandler(__NR_sys_lstat64,LinuxSyscalllstat64);//4214
	tmSetLinuxSyscallHandler(__NR_sys_fstat64,LinuxSyscallfstat64);//4215
	tmSetLinuxSyscallHandler(__NR_sys_fcntl64,LinuxSyscallfcntl64);//4220
	/*slfsmm<*/
//	#endif
}


static void tmError(ThreadId currentThread, char* errorString)
{
    Message msg;
    
    msg.id = TM_KILL;
    msg.from = TMTHREADID;
    msg.msg.tmKill.id = currentThread;
    ERROR(errorString);
    /* immediate in-kernel delivery without syscall
     * kSend does a schedule after the message arrived
     */
    kSend(TMTHREADID, &msg); 
}

static void tmReservedInstructionError(ThreadId currentThread)
{
    tmError(currentThread, "reserved instruction.");
}

static void tmCPunusableError(ThreadId currentThread)
{
    tmError(currentThread, "CP unusable.");
}

static void tmOverflowError(ThreadId currentThread)
{
    tmError(currentThread, "arithmetic overflow.");
}

static void tmBreakpointError(ThreadId currentThread)
{
    tmError(currentThread, "breakpoint.");
}

