#ifndef _DEBUGTRIGGER_H
#define _DEBUGTRIGGER_H
#define DBG_INSTDUMP_ON		1
#define DBG_INSTDUMP_OFF	2

#define DBG_TRACE_ON		3
#define DBG_TRACE_OFF		4

#define DBG_CLKSTEP_ON 		5
#define DBG_CLKSTEP_OFF		6
#endif
