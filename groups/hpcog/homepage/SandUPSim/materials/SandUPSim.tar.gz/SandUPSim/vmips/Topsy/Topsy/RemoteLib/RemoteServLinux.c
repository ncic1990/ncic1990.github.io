/*Linux syscall*/
#define LINUXERR -1
uint32 HandleLinuxSyscallReturn(uint32 v0,uint32 a3)
{
	if(a3){
		rmt_errno=v0;
		return -1;
	}else
		return v0;
}

#define LINUXCOMMONDECLARE\
	uint32 v0,a3;\
	COMMONDECLARE

#define LINUXCOMMONRET(paramsdesptr,v0,a3)\
do{\
	SetParamDescNum(paramsdesptr, 2);\
	SetParamDescParameter(paramsdesptr,0,(uint32)&v0,true,0,0);\
	SetParamDescParameter(paramsdesptr,1,(uint32)&a3,true,0,0);\
	WAITFORREPLY(paramsdesptr);\
	RELEASE( );\
	return HandleLinuxSyscallReturn(v0,a3);\
}while(0)

#define LINUXCOMMONRET_1BUF(paramsdesptr,v0,a3,buf,bufsize)\
do{\
	SetParamDescNum(paramsdesptr, 3);\
	SetParamDescParameter(paramsdesptr,0,(uint32)&v0,true,0,0);\
	SetParamDescParameter(paramsdesptr,1,(uint32)&a3,true,0,0);\
	SetParamDescParameter(paramsdesptr,2,(uint32)buf,false,0,bufsize);\
	WAITFORREPLY(paramsdesptr);\
	RELEASE( );\
	return HandleLinuxSyscallReturn(v0,a3);\
}while(0)

//v0==4000+3
uint32 rslinuxread(uint32 fd,char * buf,uint32 count) 
{
	#ifdef DEBUGLINUX
	OUTPUTMSG("client msg:linux:read");
	#endif
	CHECKPTR_1_RETVAL(buf,"rslinuxread:buf",-ENOMEM);

	LINUXCOMMONDECLARE

	SetParamDescNum(paramsdesptr, 2);
	SetParamDescParameter(paramsdesptr,0,fd,true,0,0);
	SetParamDescParameter(paramsdesptr,1,count,true,0,0);
	REMOTECALL(LINUXSYSCALL,LinuxSyscallreadservno,paramsdesptr);

	LINUXCOMMONRET_1BUF(paramsdesptr,v0,a3,buf,PARAMCHECKING_DEFAULTLEN);
}
//v0==4000+4
uint32 rslinuxwrite(uint32 fd,const char * buf,uint32 count)
{
	#ifdef DEBUGLINUX
	OUTPUTMSG("client msg:linux:write");
	#endif
	CHECKPTR_1_RETVAL((char*)buf,"rslinuxwrite:buf",-ENOMEM);
	
	LINUXCOMMONDECLARE

	SetParamDescNum(paramsdesptr, 3);
	SetParamDescParameter(paramsdesptr,0,fd,true,0,0);
	SetParamDescParameter(paramsdesptr,1,(uint32)buf,false,CHARALIGN,count);
	SetParamDescParameter(paramsdesptr,2,count,true,0,0);
	REMOTECALL(LINUXSYSCALL,LinuxSyscallwriteservno,paramsdesptr);

	LINUXCOMMONRET(paramsdesptr,v0,a3);
}
//v0==4000+5
uint32 rslinuxopen(const char* filename,uint32 flag,uint32 mode)
{
	#ifdef DEBUGLINUX
	OUTPUTMSG("client msg:linux:open");
	#endif
	CHECKPTR_1_RETVAL((char*)filename,"rslinuxopen:filename",-ENOMEM);

	LINUXCOMMONDECLARE
	
	SetParamDescNum(paramsdesptr, 3);
	SetParamDescParameter(paramsdesptr,0,(uint32)filename,false,CHARALIGN,stringlen((char*)filename)+1);
	SetParamDescParameter(paramsdesptr,1,flag,true,0,0);
	SetParamDescParameter(paramsdesptr,2,mode,true,0,0);
	REMOTECALL(LINUXSYSCALL,LinuxSyscallopenservno,paramsdesptr);
	
	LINUXCOMMONRET(paramsdesptr,v0,a3);
}
//v0==4000+6
uint32 rslinuxclose(uint32 fd)
{
	#ifdef DEBUGLINUX
	OUTPUTMSG("client msg:linux:close");
	#endif
	LINUXCOMMONDECLARE

	SetParamDescNum(paramsdesptr, 1);
	SetParamDescParameter(paramsdesptr,0,(uint32)fd,true,0,0);
	REMOTECALL(LINUXSYSCALL,LinuxSyscallcloseservno,paramsdesptr);

	LINUXCOMMONRET(paramsdesptr,v0,a3);
}
//v0==4000+10
long rslinuxunlink(const char* pathname)
{
	#ifdef DEBUGLINUX
	OUTPUTMSG("client msg:linux:unlink");
	#endif
	CHECKPTR_1_RETVAL((char*)pathname,"rslinuxunlink:pathname",-ENOMEM);

	LINUXCOMMONDECLARE
	
	SetParamDescNum(paramsdesptr, 1);
	SetParamDescParameter(paramsdesptr,0,(uint32)pathname,false,CHARALIGN,stringlen((char*)pathname)+1);
	REMOTECALL(LINUXSYSCALL,LinuxSyscallunlinkservno,paramsdesptr);
	
	LINUXCOMMONRET(paramsdesptr,v0,a3);
}
//v0==4000+13
long rslinuxtime(int* tloc) //note:tloc could be NULL
{
	#ifdef DEBUGLINUX
	OUTPUTMSG("client msg:linux:time");
	#endif

	uint32 v0,a3;
	COMMONDECLARE
	
	SetParamDescNum(paramsdesptr,0);
	REMOTECALL(LINUXSYSCALL,LinuxSyscalltimeservno,paramsdesptr);
	
	SetParamDescNum(paramsdesptr, 2);
	SetParamDescParameter(paramsdesptr,0,(uint32)&v0,true,0,0);
	SetParamDescParameter(paramsdesptr,1,(uint32)&a3,true,0,0);
	WAITFORREPLY(paramsdesptr);
	if(tloc&&!a3) *tloc=v0;
	
	RELEASE( );
	return HandleLinuxSyscallReturn(v0,a3);
}
//v0==4000+19
uint32 rslinuxlseek(uint32 fd,uint32 offset,uint32 origin)
{
	#ifdef DEBUGLINUX
	OUTPUTMSG("client msg:linux:lseek");
	#endif
	LINUXCOMMONDECLARE

	SetParamDescNum(paramsdesptr, 3);
	SetParamDescParameter(paramsdesptr,0,fd,true,0,0);
	SetParamDescParameter(paramsdesptr,1,offset,true,0,0);
	SetParamDescParameter(paramsdesptr,2,origin,true,0,0);
	REMOTECALL(LINUXSYSCALL,LinuxSyscalllseekservno,paramsdesptr);

	LINUXCOMMONRET(paramsdesptr,v0,a3);
}
//v0==4000+20
long rslinuxgetpid(void)
{
	#ifdef DEBUGLINUX
	OUTPUTMSG("client msg:linux:getpid");
	#endif

	LINUXCOMMONDECLARE
	
	SetParamDescNum(paramsdesptr, 0);
	REMOTECALL(LINUXSYSCALL,LinuxSyscallgetpidservno,paramsdesptr);
	
	LINUXCOMMONRET(paramsdesptr,v0,a3);
}
//v0==4000+24
uint32 rslinuxgetuid( )
{
	#ifdef DEBUGLINUX
	OUTPUTMSG("client msg:linux:getuid");
	#endif
	LINUXCOMMONDECLARE

	SetParamDescNum(paramsdesptr, 0);
	REMOTECALL(LINUXSYSCALL,LinuxSyscallgetuidservno,paramsdesptr);

	LINUXCOMMONRET(paramsdesptr,v0,a3);
}
//v0==4000+33
long rslinuxaccess(const char * filename, int mode)
{
	#ifdef DEBUGLINUX
	OUTPUTMSG("client msg:linux:access");
	#endif
	CHECKPTR_1_RETVAL((char*)filename,"rslinuxaccess:filename",-ENOMEM);

	LINUXCOMMONDECLARE
	
	SetParamDescNum(paramsdesptr, 2);
	SetParamDescParameter(paramsdesptr,0,(uint32)filename,false,CHARALIGN,stringlen((char*)filename)+1);
	SetParamDescParameter(paramsdesptr,1,mode,true,0,0);
	REMOTECALL(LINUXSYSCALL,LinuxSyscallaccessservno,paramsdesptr);
	
	LINUXCOMMONRET(paramsdesptr,v0,a3);
}
//v0==4000+38
long rslinuxrename(const char * oldname, const char * newname)
{
	#ifdef DEBUGLINUX
	OUTPUTMSG("client msg:linux:rename");
	#endif
	CHECKPTR_2_RETVAL((char*)oldname,"rslinuxrename:oldname",
		(char*)newname,"rslinuxrename:newname",-ENOMEM);

	LINUXCOMMONDECLARE
	
	SetParamDescNum(paramsdesptr, 2);
	SetParamDescParameter(paramsdesptr,0,(uint32)oldname,false,CHARALIGN,stringlen((char*)oldname)+1);
	SetParamDescParameter(paramsdesptr,1,(uint32)newname,false,CHARALIGN,stringlen((char*)newname)+1);
	REMOTECALL(LINUXSYSCALL,LinuxSyscallrenameservno,paramsdesptr);
	
	LINUXCOMMONRET(paramsdesptr,v0,a3);
}
//v0==4000+43
long rslinuxtimes(struct tms* tbuf)
{
	#ifdef DEBUGLINUX
	OUTPUTMSG("client msg:linux:times");
	#endif
	CHECKPTR_1_RETVAL((char*)tbuf,"rslinuxtimes:tbuf",-ENOMEM);

	LINUXCOMMONDECLARE 

	SetParamDescNum(paramsdesptr,0);
	REMOTECALL(LINUXSYSCALL,LinuxSyscalltimesservno,paramsdesptr);
	
	LINUXCOMMONRET_1BUF(paramsdesptr,v0,a3,tbuf,sizeof(struct tms));
}
//v0==4000+47
uint32 rslinuxgetgid( )
{
	#ifdef DEBUGLINUX
	OUTPUTMSG("client msg:linux:getgid");
	#endif
	LINUXCOMMONDECLARE

	SetParamDescNum(paramsdesptr, 0);
	REMOTECALL(LINUXSYSCALL,LinuxSyscallgetgidservno,paramsdesptr);

	LINUXCOMMONRET(paramsdesptr,v0,a3);
}
//v0==4000+49
uint32 rslinuxgeteuid( )
{
	#ifdef DEBUGLINUX
	OUTPUTMSG("client msg:linux:geteuid");
	#endif
	LINUXCOMMONDECLARE

	SetParamDescNum(paramsdesptr, 0);
	REMOTECALL(LINUXSYSCALL,LinuxSyscallgeteuidservno,paramsdesptr);

	LINUXCOMMONRET(paramsdesptr,v0,a3);
}
//v0==4000+50
uint32 rslinuxgetegid( )
{
	#ifdef DEBUGLINUX
	OUTPUTMSG("client msg:linux:getegid");
	#endif
	LINUXCOMMONDECLARE

	SetParamDescNum(paramsdesptr, 0);
	REMOTECALL(LINUXSYSCALL,LinuxSyscallgetegidservno,paramsdesptr);

	LINUXCOMMONRET(paramsdesptr,v0,a3);
}
//v0==4000+54
//not: ioctl is not implemented completely!
long rslinuxioctl(unsigned int fd, unsigned int cmd, unsigned long arg)
{
	#ifdef DEBUGLINUX
	OUTPUTMSG("client msg:linux:ioctl");
	#endif

	rmt_errno=ENOTTY; //special
	return -1;
	
	LINUXCOMMONDECLARE
	
	SetParamDescNum(paramsdesptr, 3);
	SetParamDescParameter(paramsdesptr,0,fd,true,0,0);
	SetParamDescParameter(paramsdesptr,1,cmd,true,0,0);
	SetParamDescParameter(paramsdesptr,2,arg,true,0,0);
	REMOTECALL(LINUXSYSCALL,LinuxSyscallioctlservno,paramsdesptr);
	
	LINUXCOMMONRET(paramsdesptr,v0,a3);
}
//v0==4000+55
uint32 rslinuxfcntl(uint32 fd,uint32 cmd,uint32 arg)
{
	#ifdef DEBUGLINUX
	OUTPUTMSG("client msg:linux:fcntl");
	#endif
	LINUXCOMMONDECLARE

	SetParamDescNum(paramsdesptr, 3);
	SetParamDescParameter(paramsdesptr,0,fd,true,0,0);
	SetParamDescParameter(paramsdesptr,1,cmd,true,0,0);
	SetParamDescParameter(paramsdesptr,2,arg,true,0,0);
	REMOTECALL(LINUXSYSCALL,LinuxSyscallfcntlservno,paramsdesptr);

	LINUXCOMMONRET(paramsdesptr,v0,a3);
}
//v0==4000+76
long rslinuxgetrlimit(unsigned int resource, struct rlimitformips *rlim)
{
	#ifdef DEBUGLINUX
	OUTPUTMSG("client msg:linux:getrlimit");
	#endif
	CHECKPTR_1_RETVAL((char*)rlim,"rslinuxgetrlimit:rlim",-ENOMEM);

	LINUXCOMMONDECLARE
	
	SetParamDescNum(paramsdesptr, 1);
	SetParamDescParameter(paramsdesptr,0,resource,true,0,0);
	REMOTECALL(LINUXSYSCALL,LinuxSyscallgetrlimitservno,paramsdesptr);
	
	LINUXCOMMONRET_1BUF(paramsdesptr,v0,a3,rlim,sizeof(struct rlimitformips));
}
//v0==4000+77
long rslinuxgetrusage(int who, struct rusageformips* ru)
{
	#ifdef DEBUGLINUX
	OUTPUTMSG("client msg:linux:getrusage");
	#endif
	CHECKPTR_1_RETVAL((char*)ru,"rslinuxgetrusage:ru",-ENOMEM);

	LINUXCOMMONDECLARE
	
	SetParamDescNum(paramsdesptr, 1);
	SetParamDescParameter(paramsdesptr,0,who,true,0,0);
	REMOTECALL(LINUXSYSCALL,LinuxSyscallgetrusageservno,paramsdesptr);
	
	LINUXCOMMONRET_1BUF(paramsdesptr,v0,a3,ru,sizeof(struct rusageformips));
}
//v0==4000+93
long rslinuxftruncate(unsigned int fd, unsigned long length)
{
	#ifdef DEBUGLINUX
	OUTPUTMSG("client msg:linux:ftruncate");
	#endif

	LINUXCOMMONDECLARE
	
	SetParamDescNum(paramsdesptr, 2);
	SetParamDescParameter(paramsdesptr,0,fd,true,0,0);
	SetParamDescParameter(paramsdesptr,1,length,true,0,0);
	REMOTECALL(LINUXSYSCALL,LinuxSyscallftruncateservno,paramsdesptr);
	
	LINUXCOMMONRET(paramsdesptr,v0,a3);
}
//v0==4000+106
long rslinuxstat(char * filename, struct statformips* statbuf)
{
	#ifdef DEBUGLINUX
	OUTPUTMSG("client msg:linux:stat");
	#endif
	CHECKPTR_2_RETVAL((char*)filename,"rslinuxstat:filename",
		(char*)statbuf,"rslinuxstat:statbuf",-ENOMEM);

	LINUXCOMMONDECLARE 

	SetParamDescNum(paramsdesptr,1);
	SetParamDescParameter(paramsdesptr,0,(uint32)filename,false,CHARALIGN,stringlen(filename)+1);
	REMOTECALL(LINUXSYSCALL,LinuxSyscallstatservno,paramsdesptr);
	
	LINUXCOMMONRET_1BUF(paramsdesptr,v0,a3,statbuf,sizeof(struct statformips));
}
//v0==4000+107
long rslinuxlstat(char * filename, struct statformips* statbuf)
{
	#ifdef DEBUGLINUX
	OUTPUTMSG("client msg:linux:lstat");
	#endif
	CHECKPTR_2_RETVAL((char*)filename,"rslinuxlstat:filename",
		(char*)statbuf,"rslinuxlstat:statbuf",-ENOMEM);

	LINUXCOMMONDECLARE 

	SetParamDescNum(paramsdesptr,1);
	SetParamDescParameter(paramsdesptr,0,(uint32)filename,false,CHARALIGN,stringlen(filename)+1);
	REMOTECALL(LINUXSYSCALL,LinuxSyscalllstatservno,paramsdesptr);
	
	LINUXCOMMONRET_1BUF(paramsdesptr,v0,a3,statbuf,sizeof(struct statformips));
}
//v0==4000+108
long rslinuxfstat(unsigned int fd, struct statformips* statbuf)
{
	#ifdef DEBUGLINUX
	OUTPUTMSG("client msg:linux:fstat");
	#endif
	CHECKPTR_1_RETVAL((char*)statbuf,"rslinuxfstat:statbuf",-ENOMEM);

	LINUXCOMMONDECLARE 

	SetParamDescNum(paramsdesptr,1);
	SetParamDescParameter(paramsdesptr,0,fd,true,0,0);
	REMOTECALL(LINUXSYSCALL,LinuxSyscallfstatservno,paramsdesptr);
	
	LINUXCOMMONRET_1BUF(paramsdesptr,v0,a3,statbuf,sizeof(struct statformips));
}
//v0==4000+122
uint32 rslinuxnewuname(new_utsname_formips* name)
{
	#ifdef DEBUGLINUX
	OUTPUTMSG("client msg:linux:newuname");
	#endif
	CHECKPTR_1_RETVAL(name,"rslinuxnewuname:name",-ENOMEM);
	
	LINUXCOMMONDECLARE 

	SetParamDescNum(paramsdesptr, 0);
	REMOTECALL(LINUXSYSCALL,LinuxSyscallnewunameservno,paramsdesptr);

	LINUXCOMMONRET_1BUF(paramsdesptr,v0,a3,name,sizeof(new_utsname_formips));
}
//v0==4000+140
long rslinuxllseek(unsigned int fd, unsigned long offset_high,
	unsigned long offset_low, loff_t * result, unsigned int origin)
{
	#ifdef DEBUGLINUX
	OUTPUTMSG("client msg:linux:llseek");
	#endif
	CHECKPTR_1_RETVAL((char*)result,"rslinuxllseek:result",-ENOMEM);

	LINUXCOMMONDECLARE 

	SetParamDescNum(paramsdesptr,4);
	SetParamDescParameter(paramsdesptr,0,fd,true,0,0);
	SetParamDescParameter(paramsdesptr,1,offset_high,true,0,0);
	SetParamDescParameter(paramsdesptr,2,offset_low,true,0,0);
	SetParamDescParameter(paramsdesptr,3,origin,true,0,0);
	REMOTECALL(LINUXSYSCALL,LinuxSyscallllseekservno,paramsdesptr);
	
	LINUXCOMMONRET_1BUF(paramsdesptr,v0,a3,result,sizeof(loff_t));
}
//v0==4000+142
long rslinuxselect(int n, fd_set *inp, fd_set *outp, fd_set *exp, struct timeval *tvp)
{
	#ifdef DEBUGLINUX
	OUTPUTMSG("client msg:linux:select");
	#endif
	CHECKPTR_2_RETVAL((char*)inp,"rslinuxselect:inp",
		(char*)outp,"rslinuxselect:outp",-ENOMEM);
	CHECKPTR_2_RETVAL((char*)exp,"rslinuxselect:exp",
		(char*)tvp,"rslinuxselect:tvp",-ENOMEM);

	uint32 v0,a3;
	COMMONDECLARE
	
	SetParamDescNum(paramsdesptr,5);
	SetParamDescParameter(paramsdesptr,0,n,true,0,0);
	SetParamDescParameter(paramsdesptr,1,(uint32)inp,false,DWORDALIGN,sizeof(fd_set));
	SetParamDescParameter(paramsdesptr,2,(uint32)outp,false,DWORDALIGN,sizeof(fd_set));
	SetParamDescParameter(paramsdesptr,3,(uint32)exp,false,DWORDALIGN,sizeof(fd_set));
	SetParamDescParameter(paramsdesptr,4,(uint32)tvp,false,DWORDALIGN,sizeof(struct timeval));
	REMOTECALL(LINUXSYSCALL,LinuxSyscallnewselectservno,paramsdesptr);
	
	SetParamDescNum(paramsdesptr, 6);
	SetParamDescParameter(paramsdesptr,0,(uint32)&v0,true,0,0);
	SetParamDescParameter(paramsdesptr,1,(uint32)&a3,true,0,0);
	SetParamDescParameter(paramsdesptr,2,(uint32)inp,false,0,sizeof(fd_set));
	SetParamDescParameter(paramsdesptr,3,(uint32)outp,false,0,sizeof(fd_set));
	SetParamDescParameter(paramsdesptr,4,(uint32)exp,false,0,sizeof(fd_set));
	SetParamDescParameter(paramsdesptr,5,(uint32)tvp,false,0,sizeof(struct timeval));
	WAITFORREPLY(paramsdesptr);
	
	RELEASE( );
	return HandleLinuxSyscallReturn(v0,a3);
}
//v0==4000+212
void splitlonglong(long long llval, long* high, long* low) //note: for LSB!
{
	long* lenbuf=(long*)(&llval);
	if(high) *high=lenbuf[1];
	if(low) *low=lenbuf[0];
}
long rslinuxftruncate64(unsigned int fd, loff_t length)
{
	#ifdef DEBUGLINUX
	OUTPUTMSG("client msg:linux:ftruncate64");
	#endif

	long lenhigh,lenlow;
	LINUXCOMMONDECLARE

	//split length into two parts
	splitlonglong((long long)length,&lenhigh,&lenlow);
	
	SetParamDescNum(paramsdesptr, 3);
	SetParamDescParameter(paramsdesptr,0,fd,true,0,0);
	SetParamDescParameter(paramsdesptr,1,lenlow,true,0,0);
	SetParamDescParameter(paramsdesptr,2,lenhigh,true,0,0);
	REMOTECALL(LINUXSYSCALL,LinuxSyscallftruncate64servno,paramsdesptr);
	
	LINUXCOMMONRET(paramsdesptr,v0,a3);
}
//for stat64, lstat64 and fstat64
#define LINUXSTAT64COMMONRET(paramsdesptr,v0,a3,statbuf)\
do{\
	RServDataUnit_t statreply[STATDOMAINNUMNEED];\
	SetParamDescNum(paramsdesptr, 3);\
	SetParamDescParameter(paramsdesptr,0,(uint32)&v0,true,0,0);\
	SetParamDescParameter(paramsdesptr,1,(uint32)&a3,true,0,0);\
	SetParamDescParameter(paramsdesptr,2,(uint32)statreply,false,0,\
		sizeof(RServDataUnit_t)*STATDOMAINNUMNEED);\
	WAITFORREPLY(paramsdesptr);\
	\
	if(!a3) CopyStat64Local(statbuf,(long long *)statreply);\
	\
	RELEASE();\
	return HandleLinuxSyscallReturn(v0,a3);\
}while(0)
//v0==4000+213
long rslinuxstat64(char * filename, struct stat64formips* statbuf, long flags)
{
	#ifdef DEBUGLINUX
	OUTPUTMSG("client msg:linux:stat64");
	#endif
	CHECKPTR_2_RETVAL(filename,"rslinuxstat64:filename",
		(char*)statbuf,"rslinuxstat64:statbuf",-ENOMEM);

	uint32 v0,a3;
	COMMONDECLARE

	SetParamDescNum(paramsdesptr, 2);
	SetParamDescParameter(paramsdesptr,0,(uint32)filename,false,CHARALIGN,stringlen(filename)+1);
	SetParamDescParameter(paramsdesptr,1,flags,true,0,0);
	REMOTECALL(LINUXSYSCALL,LinuxSyscallstat64servno,paramsdesptr);

	LINUXSTAT64COMMONRET(paramsdesptr,v0,a3,statbuf);
}
//v0==4000+214
long rslinuxlstat64(char * filename, struct stat64formips* statbuf, long flags)
{
	#ifdef DEBUGLINUX
	OUTPUTMSG("client msg:linux:lstat64");
	#endif
	CHECKPTR_2_RETVAL(filename,"rslinuxlstat64:filename",
		(char*)statbuf,"rslinuxlstat64:statbuf",-ENOMEM);

	uint32 v0,a3;
	COMMONDECLARE

	SetParamDescNum(paramsdesptr, 2);
	SetParamDescParameter(paramsdesptr,0,(uint32)filename,false,CHARALIGN,stringlen(filename)+1);
	SetParamDescParameter(paramsdesptr,1,flags,true,0,0);
	REMOTECALL(LINUXSYSCALL,LinuxSyscalllstat64servno,paramsdesptr);

	LINUXSTAT64COMMONRET(paramsdesptr,v0,a3,statbuf);
}
//v0==4000+215
uint32 rslinuxfstat64(uint32 fd,struct stat64formips* statbuf,uint32 flags)
{
	#ifdef DEBUGLINUX
	OUTPUTMSG("client msg:linux:fstat64");
	#endif
	CHECKPTR_1_RETVAL((char*)statbuf,"rslinuxfstat64:statbuf",-ENOMEM);
	
	uint32 v0,a3;
	COMMONDECLARE
	
	SetParamDescNum(paramsdesptr, 2);
	SetParamDescParameter(paramsdesptr,0,fd,true,0,0);
	SetParamDescParameter(paramsdesptr,1,flags,true,0,0);
	REMOTECALL(LINUXSYSCALL,LinuxSyscallfstat64servno,paramsdesptr);

	LINUXSTAT64COMMONRET(paramsdesptr,v0,a3,statbuf);
}
//v0==4000+220
uint32 rslinuxfcntl64(uint32 fd,uint32 cmd,uint32 arg)
{
	#ifdef DEBUGLINUX
	OUTPUTMSG("client msg:linux:fcntl64");
	#endif
	LINUXCOMMONDECLARE

	SetParamDescNum(paramsdesptr, 3);
	SetParamDescParameter(paramsdesptr,0,fd,true,0,0);
	SetParamDescParameter(paramsdesptr,1,cmd,true,0,0);
	SetParamDescParameter(paramsdesptr,2,arg,true,0,0);
	REMOTECALL(LINUXSYSCALL,LinuxSyscallfcntl64servno,paramsdesptr);

	LINUXCOMMONRET(paramsdesptr,v0,a3);
}

