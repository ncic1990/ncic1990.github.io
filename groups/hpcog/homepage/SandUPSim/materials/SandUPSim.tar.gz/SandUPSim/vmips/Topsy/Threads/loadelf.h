#ifndef LOADELF_H
#define LOADELF_H
#include "LibcLinuxTypes.h"

void initcmdline( );
void initenvvar( );
unsigned long fileread();

#define MAXCOMMANDLINEPARTS 25
#define NOTREDIRECT -1
#define STDIONUM 3
typedef struct commandlineformat{
	//args
	char* cmdlinebase;
	long cmdlinelen;	//stringlen(commandline)+1
	long argc;
	long argv[MAXCOMMANDLINEPARTS];		//offset
	//redirect stdio
	long redirect[STDIONUM];	//redirection of three standard input and output
	//cwd
	long cwdhasbechanged;
}commandlineformat_t;

//values of status in cmdlinestatus_t
#define CMDNORMAL 0
#define CMDBATCH 1
typedef struct CmdLineStatus{
	long status;
}cmdlinestatus_t;

typedef struct BatchStatus{
	FILE* fp;
	long which;//which command line
}batchstatus_t;

//struct for environment variables
typedef struct EnvVarStruct{
	unsigned long envc;
	unsigned long envlen;  //should include the last null char
	char* env_vars;
}envvar_t;

//struct for Auxillary Vectors
typedef struct AuxVecStruct{
	unsigned long a_phdr;
	unsigned long a_phent;
	unsigned long a_phnum;
	unsigned long a_base;
	unsigned long a_entry;
}auxvec_t;

#endif/*end of head file*/

