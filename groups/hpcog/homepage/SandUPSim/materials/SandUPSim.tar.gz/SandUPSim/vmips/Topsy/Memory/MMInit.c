/*
	Copyright (c) 1996-1997 Swiss Federal Institute of Technology, 
	Computer Engineering and Networks Laboratory. All rights reserved.

	TOPSY - A Teachable Operating System. 
		Implementation of a tiny and simple micro kernel for
		teaching purposes.

	Permission to use, copy, modify, and distribute this software and its
	documentation for any purpose, without fee, and without written 
	agreement is hereby granted, provided that the above copyright notice 
	and the following two paragraphs appear in all copies of this software.


	
	File:                  $Source: /work/cvs/cvsroot/Topsy/Memory/MMInit.c,v $
 	Author(s):             George Fankhauser
 	Affiliation:           ETH Zuerich, TIK
 	Version:               $Revision: 1.7 $
 	Creation Date:         
 	Last Date of Change:   $Date: 2003/11/08 15:49:59 $      by: $Author: slfsmm $
	
	
*/

#include "MMInit.h"
#include "Threads.h"

#include "MemoryLayout.h"
#include "MMHeapMemory.h"
#include "MMVirtualMemory.h"
#include "MMMapping.h"
#include "MMError.h"

/*slfsmm031031_add>*/
extern long totalmemory;
/*slfsmm031031_add<*/

void mmInit(SegMapPtr segMapPtr, Address* mmStackPtr, Address* tmStackPtr)
{
    Address heapAddress;

    /* memory error handlers need to be installed */ 
    mmInstallErrorHandlers();
	
    /* build dynamic kernel heap memory in one vm region (which will be
     * created later using heap memory for lists and descriptors)
     * the heap always starts after the static kernel data...
     */
    /**/
	/*ioConsolePutString("kernelCodeStart:");
    ioConsolePutHexInt(segMapPtr->kernelCodeStart);
	ioConsolePutString("kernelCodeSize:");
    ioConsolePutHexInt(segMapPtr->kernelCodeSize);
    ioConsolePutString("kernelDataStart:");
    ioConsolePutHexInt(segMapPtr->kernelDataStart);
    ioConsolePutString("kernelDataSize:");
    ioConsolePutHexInt(segMapPtr->kernelDataSize);
    
    ioConsolePutString("userCodeStart:");
    ioConsolePutHexInt(segMapPtr->userCodeStart);
    ioConsolePutString("userCodeSize:");
    ioConsolePutHexInt(segMapPtr->userCodeSize);
    ioConsolePutString("userDataStart:");
 	ioConsolePutHexInt(segMapPtr->userDataStart);
    ioConsolePutString("userDataSize:");
 	ioConsolePutHexInt(segMapPtr->userDataSize);
    ioConsolePutString("userLoadedInKernelAt:");
    ioConsolePutHexInt(segMapPtr->userLoadedInKernelAt);
    */
    heapAddress = mmVmGetHeapAddress(segMapPtr->kernelDataStart, 
				     segMapPtr->kernelDataSize);

    if (hmInit(heapAddress) != HM_INITOK) 
    	ioConsolePutString("heap init failed.\n");
    else
    	ioConsolePutString("heap init OK.\n");



    /* set up page mapping */
	/*slfsmm031023_del>user thread is not created in the loading process*/
	/*
    mmInitMemoryMapping(segMapPtr->userCodeStart, segMapPtr->userCodeSize,
	    		segMapPtr->userDataStart, segMapPtr->userDataSize,
			segMapPtr->userLoadedInKernelAt);
    */
    /*slfsmm031023_del<*/

    /* setup memory region lists. beware: vmregionlist/freelist and first
       region descriptors must use static memory
       vmInit makes regions for the following:
       KERNEL:	boot/exception stack (first page in kernel memory)
       		kernel code
		kernel data
		kernel heap (dynamic data)
		stacks for mmStackPtr, tmStackPtr
		free region (what's left in kernel space)
	USER:	user code
		user data
		free region (what's left in user space)
     */
    if (mmVmInit(segMapPtr->kernelCodeStart, segMapPtr->kernelCodeSize,
		 segMapPtr->kernelDataStart, segMapPtr->kernelDataSize,
		 segMapPtr->userCodeStart, segMapPtr->userCodeSize,
		 segMapPtr->userDataStart, segMapPtr->userDataSize,
		 mmStackPtr, tmStackPtr) != MM_VMINITOK) {
	PANIC("vm init failed");
    }
}
