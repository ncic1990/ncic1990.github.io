/*support processes when implementing IO through VirtServ*/

#define VIRT_IO_ARG0(type,service)\
do{\
__asm__ __volatile__(\
	".set\tnoreorder\n\t"\
	".set\tnoat\n\t"\
	"li\t$26,%0\n"\
	"li\t$27,%1\n"\
	"sb\t$27,($26)\n"\
	".set\tat\n\t"\
	".set\treorder"\
	:\
	:"i"(type),\
	 "i"(service)\
	);\
}while(0)

#define VIRT_IO_ARG1(type,service,regbase,arg1)\
do{\
__asm__ __volatile__(\
	".set\tnoreorder\n\t"\
	".set\tnoat\n\t"\
	"li\t$26,%2\n"\
	"sw\t%3,0($26)\n"\
	"li\t$26,%0\n"\
	"li\t$27,%1\n"\
	"sb\t$27,($26)\n"\
	".set\tat\n\t"\
	".set\treorder"\
	:\
	:"i"(type),\
	 "i"(service),\
	 "i"(regbase),\
	 "r"(arg1)\
	);\
}while(0)

#define VIRT_IO_ARG2(type,service,regbase,arg1,arg2)\
do{\
__asm__ __volatile__(\
	".set\tnoreorder\n\t"\
	".set\tnoat\n\t"\
	"li\t$26,%2\n"\
	"sw\t%3,0($26)\n"\
	"sw\t%4,-4($26)\n"\
	"li\t$26,%0\n"\
	"li\t$27,%1\n"\
	"sb\t$27,($26)\n"\
	".set\tat\n\t"\
	".set\treorder"\
	:\
	:"i"(type),\
	 "i"(service),\
	 "i"(regbase),\
	 "r"(arg1),\
	 "r"(arg2)\
	);\
}while(0)

#define VIRT_IO_ARG1_RET2(type,service,regbase,arg1,ret1,ret2)\
do{\
__asm__ __volatile__(\
	".set\tnoreorder\n\t"\
	".set\tnoat\n\t"\
	"li\t$26,%4\n"\
	"sw\t%5,0($26)\n"\
	"li\t$26,%2\n"\
	"li\t$27,%3\n"\
	"sb\t$27,($26)\n"\
	"li\t$26,%4\n"\
	"lw\t%0,0($26)\n"\
	"lw\t%1,-4($26)\n"\
	".set\tat\n\t"\
	".set\treorder"\
	:"=r"(ret1),"=r"(ret2)\
	:"i"(type), "i"(service), "i"(regbase),\
	 "r"(arg1)\
	);\
}while(0)

#define VIRT_IO_ARG2_RET2(type,service,regbase,arg1,arg2,ret1,ret2)\
do{\
__asm__ __volatile__(\
	".set\tnoreorder\n\t"\
	".set\tnoat\n\t"\
	"li\t$26,%4\n"\
	"sw\t%5,0($26)\n"\
	"sw\t%6,-4($26)\n"\
	"li\t$26,%2\n"\
	"li\t$27,%3\n"\
	"sb\t$27,($26)\n"\
	"li\t$26,%4\n"\
	"lw\t%0,0($26)\n"\
	"lw\t%1,-4($26)\n"\
	".set\tat\n\t"\
	".set\treorder"\
	:"=r"(ret1),"=r"(ret2)\
	:"i"(type), "i"(service), "i"(regbase),\
	 "r"(arg1), "r"(arg2)\
	);\
}while(0)

#define VIRT_IO_ARG3_RET2(type,service,regbase,arg1,arg2,arg3,ret1,ret2)\
do{\
__asm__ __volatile__(\
	".set\tnoreorder\n\t"\
	".set\tnoat\n\t"\
	"li\t$26,%4\n"\
	"sw\t%5,0($26)\n"\
	"sw\t%6,-4($26)\n"\
	"sw\t%7,-8($26)\n"\
	"li\t$26,%2\n"\
	"li\t$27,%3\n"\
	"sb\t$27,($26)\n"\
	"li\t$26,%4\n"\
	"lw\t%0,0($26)\n"\
	"lw\t%1,-4($26)\n"\
	".set\tat\n\t"\
	".set\treorder"\
	:"=r"(ret1),"=r"(ret2)\
	:"i"(type), "i"(service), "i"(regbase),\
	 "r"(arg1), "r"(arg2),"r"(arg3)\
	);\
}while(0)

