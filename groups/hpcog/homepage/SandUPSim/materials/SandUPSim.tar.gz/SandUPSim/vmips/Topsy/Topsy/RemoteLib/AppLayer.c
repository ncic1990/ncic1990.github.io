//application layer
bool getServAddress(ServInfoDesc_t* servinfoptr)
{
	return true;
}
void switchAddresses(ServInfoDesc_t* servinfoptr)
{
	addrdesc_t address;
	address=servinfoptr->destaddr;
	servinfoptr->destaddr=servinfoptr->srcaddr;
	servinfoptr->srcaddr=address;
}
void setServType(ServInfoDesc_t* servinfoptr,uint32 type,uint32 service)
{
	servinfoptr->type=type;
	servinfoptr->service=service;
}
uint32 calsizeofRDBP(ParamsDesc_t* paramsdesc, uint32* contentsize)
{
	uint32 count;
	uint32 size=0;
	uint32 align;

	if(!paramsdesc) goto out0;
	size=sizeof(RServDataUnit_t);
	if(paramsdesc->paramnum==DEFCANNOTSERV) goto out0 ;
	size+=paramsdesc->paramnum*sizeof(DSParamDesc_t);
	if(contentsize) *contentsize=size;
	for(count=0;count<paramsdesc->paramnum;count++){
		if(paramsdesc->parameters[count].notpointer) continue;
		if((long)paramsdesc->parameters[count].len==(long)PARAM_POINTERNULL)
			continue;
		align=paramsdesc->parameters[count].align;
		align=up2exp(align);
		size=(size+align-1)&(~(align-1));
		paramsdesc->parameters[count].offset=size;
		size+=paramsdesc->parameters[count].len;
	}
	goto out1;
out0:
	if(contentsize) *contentsize=size;
out1:
	return size;
}
bool SetParamDescNum(ParamsDesc_t* paramsdesc,uint32 num)
{
	if(!paramsdesc) {
		#ifndef REMOTESERVQUIET
		ioConsolePutString("client err:SetParamnum:paramsdesc is NULL!\n"); 
		#endif
		return false;
	}
	paramsdesc->paramnum=num;
	return true;
}
bool SetParamDescParameter(ParamsDesc_t* paramsdesc,uint32 which,
	uint32 paramval,uint32 notpointer,uint32 align,uint32 len)
{
	if(!paramsdesc) {
		#ifndef REMOTESERVQUIET
		ioConsolePutString("client err:SetParameter:paramsdesc is NULL!\n"); 
		#endif
		return false;
	}
	if((which<0)||(which>=MAXPARAMETERS)) {
		#ifndef REMOTESERVQUIET
		ioConsolePutString("client err:SetParameter:which is invalid!\n");
		#endif
		return false;
	}
	paramsdesc->parameters[which].paramval=paramval;
	paramsdesc->parameters[which].notpointer=notpointer;
	paramsdesc->parameters[which].align=align;
	paramsdesc->parameters[which].len=len;
	return true;
}

