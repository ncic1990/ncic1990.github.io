#include    <stdio.h>
#include    <sys/types.h>   /* basic system data types */
#include    <sys/socket.h>  /* basic socket definitions */
#include    <netinet/in.h>  /* sockaddr_in{} and other Internet defns */
#include    <netinet/tcp.h>  /* sockaddr_in{} and other Internet defns */
#include    <arpa/inet.h>   /* inet(3) functions */


#include    <sys/stat.h> /* added for stat by zhangwl*/
#include    <unistd.h>

#define __CMP_DEBUG__ //for changed register value's auto compare   -add by zhangwl

int
main(int argc, char **argv)
{
	int					listenfd, connfd1,connfd2;
	pid_t				childpid;
	socklen_t			clilen;
	struct sockaddr_in	cliaddr1,cliaddr2, servaddr;
	char buf[256];
	char obuf[16] = "Please go on.";
	int rc = 0,rc1,rc2;
	int on = 1;
	
	
	unsigned short port = 6677;
	struct stat statbuf;
	
	if( argc == 2) port = atoi(argv[1]);
	if(port ==0 ) {
			printf("Usage: barrier [port]\n");
			exit(0);
	}
	else port = 6677;
	listenfd = socket(AF_INET, SOCK_STREAM, 0);

	bzero(&servaddr, sizeof(servaddr));
	servaddr.sin_family      = AF_INET;
	servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
	servaddr.sin_port        = htons(port);

	setsockopt(listenfd, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on));
	setsockopt(listenfd, IPPROTO_TCP, TCP_NODELAY, &on, sizeof(on)); 

	rc = bind(listenfd, (struct sockaddr*) &servaddr, sizeof(servaddr));
	if(rc < -1) perror("bind");

	listen(listenfd, 2);
	connfd1 = accept(listenfd, (struct sockaddr*)&cliaddr1, &clilen);
	printf("1 client connected.\n");
	connfd2 = accept(listenfd, (struct sockaddr*)&cliaddr2, &clilen);
	printf("2 clients connected.\n");
	if(connfd1 < 0  || connfd2 < 0) perror("connect");

	while(1) {
		rc1 = read(connfd1,buf,4);
			printf("received breq from %d\n", *(int*)buf);

		rc2 = read(connfd2,buf,4);
			printf("received breq from %d\n", *(int*)buf);
		if(rc1 <0  || rc2 < 0) {
			printf("Client read error\n");
			goto exit;
		}
		
#ifdef __CMP_DEBUG__   //add by zhangwl
		else{
		/* execute shell command to diff the files a.doc and b.doc
		  * if the output file c.doc is empty, 
		  *       then go on directly,
		  *       else  waiting for input, all judged by people
		  */
			system("diff a.doc b.doc 2>&1 >&c.doc");	
			stat("c.doc", &statbuf);
//			printf("@@@@ filesize->%8x\n", (statbuf.st_size));
			if ((statbuf.st_size) != 0x0)
			{
				printf("Judge by yourself, press return to continue����\n");
				fgets(buf,16,stdin);
			}
			write(connfd1,obuf,16);
			write(connfd2,obuf,16);			
		}
#else//the original code
		printf("press return to continue\n");		
		fgets(buf,16,stdin);		
		write(connfd1,obuf,16);		
		write(connfd2,obuf,16);
#endif
	
	}
//	close(listenfd);
exit:
	close(connfd1);			/* parent closes connected socket */
	close(connfd2);			/* parent closes connected socket */
}
