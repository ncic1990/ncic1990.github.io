#ifndef DBGREMOTESERV_H
#define DBGREMOTESERV_H

/*debug switches*/
//#define WALKPATH
//#define DEBUGGLOBAL
//#define DEBUGHAL
//#define DEBUGSR
//#define DEBUGAPP
//#define DEBUGLIBC
//#define DEBUGLINUX
//#define DEBUGTA
//#define REMOTESERVQUIET
#define STRICTCHECKING

#endif/*DBGREMOTESERV_H*/

