/**
 *	$Header: /work/cvs/cvsroot/vmips/tlb.cc,v 1.22 2003/12/15 01:07:17 xjw Exp $
 */
 
/*This is the TLB module of sand simulator, which is developed by
ASL group of NCIC;
Copyright 2003 by ASL NCIC */

#include <assert.h>
#include "tlb.h"
#include "cpzeroreg.h"
#include "deviceexc.h"
#include "excnames.h"
#include "cpzero.h"
#include "memstat.h"
#include "memstatreg.h"
#include "vmips.h"
#include "error.h"
#define NEWMETHOD
/*slfsmm031107_add>*/
//#define DEBUGCONFIG
/*slfsmm031107_add<*/

TLB::TLB( )
{	
	lastmatch = 0;	
}
void 
TLB:: adjust(uint8 index, uint32 vpn )
{
	uint8 tmpindex = a[index];	
	if((uint32)(index + 1) < TLB_ENTRYS  && tlb_entry[a[index + 1]].entry.vpn < vpn )
	{
		while((uint32)(index + 1) < TLB_ENTRYS && tlb_entry[a[index + 1]].entry.vpn < vpn)
		{
			a[index] = a[index + 1];
			tlb_entry[a[index]].entry.z0 = index;
			index ++;
		}
		a[index] = tmpindex;
		tlb_entry[a[index]].entry.z0 = index;
	}
	else
	{
		while(index - 1 >= 0 && tlb_entry[a[index - 1]].entry.vpn > vpn )
		{
			a[index] = a[index - 1];
			tlb_entry[a[index]].entry.z0 = index;
			index --;
		}
		a[index] = tmpindex;
		tlb_entry[a[index]].entry.z0 = index;
	}
}
int 
TLB::binsearch(uint32 vpn, uint32 asid)
{
	int low, hig, mid;	
	low = 0;
	hig = TLB_ENTRYS - 1;	
	while( low <= hig)
	{
		mid = (low + hig) /2 ;
		if(vpn > tlb_entry[a[mid]].entry.vpn)
		{
			low = mid + 1;
			continue;
		}
		
		if(vpn <= tlb_entry[a[mid]].entry.vpn)
		{
			hig = mid - 1;
			continue;
		}		
	}
	while(tlb_entry[a[low]].entry.vpn == vpn)
	{
		if (tlb_entry[a[low]].entry.g || tlb_entry[a[low]].entry.asid == asid)
			return a[low];
	  	low++;		
	}
	return -1;
}
void
TLB::attach(vmips* m,CPZero *p , Memstat * ms )
{
	machine=m;
	cp0 = p;
	memstat = ms;

	/*slfsmm031107_add>*/
	if(!machine) fprintf(stderr,"fatal error:tlb:machine is NULL!\n");
	if(!cp0) fprintf(stderr,"fatal error:tlb:cp0 is NULL!\n");
	TLB_ENTRYS=machine->opt_tlbentrynum;
	TLB_ENTRYSRESERVED=machine->opt_tlbentryreserved;
	#ifdef DEBUGCONFIG
	fprintf(stderr,"tlb msg:tlb entries->%d, tlb entries reserved->%d\n",
		TLB_ENTRYS,TLB_ENTRYSRESERVED);
	#endif
	tlb_entry=new TLB_ENTRY[TLB_ENTRYS];
	a = (int*) malloc(TLB_ENTRYS * 4);	
	for(uint32 i = 0; i < TLB_ENTRYS; i ++)
	{
		a[i] = i;
		tlb_entry[i].entry.z0 = i;
	}
	/*slfsmm031107_add<*/
	
}

void 
TLB::tlbr_emulate(uint32 instr, uint32 pc)
{
	

	int index = ((cp0 -> reg[Index]) & cp0->Index_Index_MASK) >> Index_Shift;
	uint32 *p = (uint32*) (&tlb_entry[index].content);
	cp0 -> reg[EntryLo] = (*p ++) & EntryLo_MASK;
	cp0 -> reg[EntryHi] = (*p)  & EntryHi_MASK;

}
void 
TLB::tlbwi_emulate(uint32 instr, uint32 pc)
{
	int index = ((cp0 ->reg[Index]) & cp0->Index_Index_MASK) >> Index_Shift;	
	uint8 tmpindex = tlb_entry[index].entry.z0;
	uint32 tmpvpn = tlb_entry[index].entry.vpn;
	tlb_entry[index].hilo[0] = cp0 ->reg[EntryLo] & EntryLo_MASK;
	tlb_entry[index].hilo[1] = cp0 ->reg[EntryHi] & EntryHi_MASK;
	#ifdef NEWMETHOD
	if(tmpvpn != tlb_entry[index].entry.vpn)
		adjust(tmpindex, tlb_entry[index].entry.vpn);
	else 
		 tlb_entry[index].entry.z0 = tmpindex;
	#endif
	lastmatch = index;
}
void 
TLB::tlbwr_emulate(uint32 instr, uint32 pc)
{
#ifdef LAZY_RANDOM
	cp0->adjust_random(); //add by cmy,change random reg lazily
#endif	
	int random = (cp0 ->reg[Random] &  cp0->Random_Random_MASK) >> Random_Shift;
	uint8 tmpindex = tlb_entry[random].entry.z0;
	uint32 tmpvpn = tlb_entry[random].entry.vpn;
        tlb_entry[random].hilo[0] = cp0 ->reg[EntryLo] & EntryLo_MASK;
	tlb_entry[random].hilo[1] = cp0 ->reg[EntryHi] & EntryHi_MASK;
	#ifdef NEWMETHOD
	if(tmpvpn != tlb_entry[random].entry.vpn)		
	      adjust(tmpindex, tlb_entry[random].entry.vpn);		
	else 
		 tlb_entry[random].entry.z0 = tmpindex;
	#endif
	lastmatch = random;
}
void 
TLB::tlbp_emulate(uint32 instr, uint32 pc)
{
	int x;
	uint32 vpn, asid;
	cp0 ->reg[Index] = (1 << 31);
	vpn = (cp0 ->reg[EntryHi] & EntryHi_VPN_MASK) >> 12;
	asid = (cp0 ->reg[EntryLo] & EntryHi_ASID_MASK) >> 6;

	if (tlb_entry[lastmatch].entry.vpn == vpn) 
		if (tlb_entry[lastmatch].entry.g || tlb_entry[lastmatch].entry.asid == asid)
              {
			cp0 ->reg[Index] = (lastmatch << Index_Shift) &  cp0->Index_MASK;
			return;	
              }
	#ifdef NEWMETHOD
        x = binsearch(vpn, asid);
        if(x != -1)      
      	{
        	cp0 ->reg[Index] = (x << Index_Shift) &  cp0->Index_MASK;
		lastmatch = x;
      	}
        #else
	
	for (x = 0; x < TLB_ENTRYS; x++)
        {
		if (tlb_entry[x].entry.vpn == vpn) 
                 {
			if (tlb_entry[x].entry.g || tlb_entry[x].entry.asid == asid)
                         {
				cp0 ->reg[Index] = (x << Index_Shift) &  cp0->Index_MASK;
				lastmatch = x;
				return;	
                         }
                 }
        }
      #endif
}


uint32
TLB::addr_translate(uint32 seg, uint32 vaddr, int mode, bool *cacheable,
	DeviceExc *client)
{
	TLB_ENTRY *match = NULL;
	uint32 asid = (cp0 -> reg[EntryHi] & EntryHi_ASID_MASK) >> 6; 
	uint32 vpn = (vaddr & EntryHi_VPN_MASK) >> 12;
	match = find_matching_tlb_entry(vpn, asid);
	tlb_user_miss = false;
	if (match) 
	{
		if (!match ->entry.v) 
		{
			/* TLB Invalid exception */
			memstat -> SetStatBool(TlbINVMask,true);
			load_addr_trans_excp_info(vaddr,vpn,match);
			client -> exception(mode == DATASTORE ? TLBS : TLBL, mode);
			return 0xffffffff;
		}
		else if (!match ->entry.d && mode == DATASTORE) 
		{
			/* TLB Mod exception */
			memstat ->SetStatBool(TlbModifyMask,true);
			load_addr_trans_excp_info(vaddr,vpn,match);
			client -> exception(Mod, DATASTORE);
			return 0xffffffff;
		} 
		else 
		{
			memstat ->SetStatBool(TlbINVMask,false);
			memstat ->SetStatBool(TlbModifyMask,false);	
			/* We have a matching TLB entry which is valid. */
			*cacheable = !match ->entry.n;
			memstat ->SetStatBool(TlbHitMask,true);
			return ((match ->entry.pfn) << 12) | (vaddr & ~EntryHi_VPN_MASK);
		}
	}
	else /* TLB Miss exception */
	{
	      memstat ->SetStatBool(TlbHitMask,false);
		if (seg == KUSEG)
			tlb_user_miss = true;  /* User TLB Miss exception */		
		load_addr_trans_excp_info(vaddr,vpn,match);
		client -> exception(mode == DATASTORE ? TLBS : TLBL, mode);
		return 0xffffffff;
		
	}
}

void
TLB::load_addr_trans_excp_info(uint32 va, uint32 vpn, TLB_ENTRY *match)
{
	cp0 -> reg[BadVAddr] = va;
	cp0 -> reg[Context] = (cp0 -> reg[Context] & ~Context_BadVPN_MASK) | (vpn  << 2);	
	if (match)
		cp0 -> reg[EntryHi] = (*(++((uint32*)match ) )) & EntryHi_MASK;
	else
		cp0 -> reg[EntryHi] = va & EntryHi_MASK;
		
}

TLB_ENTRY *
TLB::find_matching_tlb_entry(uint32 vpn, uint32 asid)
{
	int x;
	TLB_ENTRY *match = NULL;

	if (tlb_entry[lastmatch].entry.vpn == vpn) 
		if (tlb_entry[lastmatch].entry.g || tlb_entry[lastmatch].entry.asid == asid)
              {
			match = &(tlb_entry[lastmatch]);
			return match;	
              }	
	#ifndef NEWMETHOD
		
	for (x = 0; x < TLB_ENTRYS; x++) 
	{
		if (tlb_entry[x].entry.vpn == vpn) 
		{
			if (tlb_entry[x].entry.g || tlb_entry[x].entry.asid == asid) 
			{
				match = &(tlb_entry[x]);
				break;
			}
		}
	}
	#else
	
	x = binsearch(vpn, asid);
        if(x != -1)       
      	{
        	match = &(tlb_entry[x]);
		lastmatch = x;
      	}
	#endif
	return match;
}
bool
TLB::debug_tlb_translate(uint32 vaddr, uint32 *paddr)
{
	TLB_ENTRY *match = NULL;
	uint32 asid = cp0 -> reg[EntryHi] & EntryHi_ASID_MASK;
	uint32 vpn = vaddr & EntryHi_VPN_MASK;
	bool rv;

	if ((!cp0 -> kernel_mode()) && (vaddr & KERNEL_SPACE_MASK)) {
		*paddr = 0xffffffff;
		rv = false;
	} else if (cp0 -> kernel_mode() && (vaddr & KSEG_SELECT_MASK) == KSEG0) {
		*paddr = vaddr - KSEG0_CONST_TRANSLATION;
		rv = true;
	} else if (cp0 -> kernel_mode() && (vaddr & KSEG_SELECT_MASK) == KSEG1) {
		*paddr = vaddr - KSEG1_CONST_TRANSLATION;
		rv = true;
	} else /* KUSEG */
        {
		match = find_matching_tlb_entry(vpn, asid);
		if (!match || !match -> entry.v)
                {
			*paddr = 0xffffffff;
			rv = false;
		} else {
			*paddr = match -> entry.pfn | (vaddr & ~EntryHi_VPN_MASK);
			rv = true;
		}
	}
	return rv;
}
