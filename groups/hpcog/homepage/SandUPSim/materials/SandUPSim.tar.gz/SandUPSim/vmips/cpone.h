/* Definitions to support the system float coprocessor.
   Copyright NCIC
 */

/*
  add cpone(fpu) support  for hpcog; cmy
*/
#ifndef _CPONE_H_
#define _CPONE_H_
#include "cpu.h"
#include "sysinclude.h"
#include "deviceexc.h"
#include "debug.h"

class DeviceExc;

/* FPU Extraction macros */
#define FMT_S	0x10
#define FMT_D   0x11
#define FMT_W   0x14
#define FMT_L   0x15

#define DoubleFGR(r) freg[(r)>>1].dfr
#define SingleFGR(r) freg[(r)>>1].fr[(r)&1]
#define IntFGR(r)    freg[r>>1].ir[(r)&1]
#define LongLongFGR(r) freg[(r)>>1].llr

#define SP_NEAR_ONE     0.999999
#define DP_NEAR_ONE     0.9999999999999

#define F_C_OBF   0x30
#define F_C_UN    0x31
#define F_C_EQ    0x32
#define F_C_UEQ   0x33
#define F_C_OLT   0x34
#define F_C_ULT   0x35
#define F_C_OLE   0x36
#define F_C_ULE   0x37
#define F_C_SF    0x38
#define F_C_NGLE  0x39
#define F_C_SEQ   0x3a
#define F_C_NGL   0x3b
#define F_C_LT    0x3c
#define F_C_NGE   0x3d
#define F_C_LE    0x3e
#define F_C_NGT   0x3f


#define F_mfc_op          0x00
#define F_dmfc_op         0x01
#define F_cfc_op          0x02
#define F_mtc_op          0x04
#define F_dmtc_op         0x05
#define F_ctc_op          0x06
#define F_bc_op           0x08


#define F_CSR31_C (1<<23)
typedef union {
	float fr[2];
	double dfr;
	int32	ir[2];
	long long llr;
} FReg;

class CPOne
{
friend class CPU;
public:
	FReg freg[16];
	CPU *cpu;
	uint32 fcsr;
	uint32 fcr0;
	uint32 fcr25;
	uint32 fcr26;
	uint32 fcr28;
	uint32 fcr31;
protected:	
	void 	fadd_emulate(uint32 instr, uint32 pc);
	void 	fsub_emulate(uint32 instr, uint32 pc);
	void 	fmul_emulate(uint32 instr, uint32 pc);
	void 	fdiv_emulate(uint32 instr, uint32 pc);
	void 	fsqrt_emulate(uint32 instr, uint32 pc);
	void 	fabs_emulate(uint32 instr, uint32 pc);
	void 	fmov_emulate(uint32 instr, uint32 pc);
	void 	fneg_emulate(uint32 instr, uint32 pc);
	void 	fround1_emulate(uint32 instr, uint32 pc);
	void 	ftrunc1_emulate(uint32 instr, uint32 pc);
	void 	fceill_emulate(uint32 instr, uint32 pc);
	void 	ffloorl_emulate(uint32 instr, uint32 pc); /*0xa_emulate;0xb*/ 
	void 	fround_emulate(uint32 instr, uint32 pc);
	void 	ftrunc_emulate(uint32 instr, uint32 pc);
	void 	fceil_emulate(uint32 instr, uint32 pc);
	void 	ffloor_emulate(uint32 instr, uint32 pc);
	void 	fmovc_emulate(uint32 instr, uint32 pc);
	void 	fmovz_emulate(uint32 instr, uint32 pc);
	void 	fmovn_emulate(uint32 instr, uint32 pc);
	void 	frecip_emulate(uint32 instr, uint32 pc);
	void 	frsqrt_emulate(uint32 instr, uint32 pc);
	void 	fcvts_emulate(uint32 instr, uint32 pc);
	void 	fcvtd_emulate(uint32 instr, uint32 pc);	 
	void 	fcvte_emulate(uint32 instr, uint32 pc);
	void 	fcvtw_emulate(uint32 instr, uint32 pc);
	void 	fcvtl_emulate(uint32 instr, uint32 pc); 
	void 	fcmp_op_emulate(uint32 instr, uint32 pc);
	void 	fundef_emulate(uint32 instr, uint32 pc); 
public:
	CPOne(CPU *m = NULL);
	void reset(void);
	bool cop_usable (int coprocno);
	void cpone_emulate(uint32 instr, uint32 pc);
	void dump_regs(FILE *f);
	void adjust_random(void);
	void read_debug_info(uint32 *status, uint32 *bad, uint32 *cause);
	void write_debug_info(uint32 status, uint32 bad, uint32 cause);
        uint16 fs(const uint32 instr) const;
        uint16 ft(const uint32 instr) const;
        uint16 fd(const uint32 instr) const;
	uint16 funct(const uint32 instr) const;
	uint16 format(const uint32 instr) const;
	uint16 opcode(const uint32 instr) const;
	uint16 fmt;
};

#endif /* _CPONE_H_ */
