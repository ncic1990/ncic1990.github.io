#ifndef SERVLIBOPT_H
#define SERVLIBOPT_H

//#define ALWAYSVIRT

#endif

