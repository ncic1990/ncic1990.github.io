#include "LinuxSyscall.h"
#include "LinuxSyscallUnistd.h"

#ifdef SYSCALLINLINE

long sys_errno;

_syscall1(void,sys_exit,int,exitcode)//v0==4001
_syscall3(int,sys_read,unsigned int,fd,char *,buf,long,count)//v0==4003
_syscall3(int,sys_write,unsigned int,fd,const char *,buf,long,count)//v0==4004
_syscall3(long,sys_open,const char*,filename,int,flag,int,mode)//v0==4005
_syscall1(long,sys_close,unsigned int,fd)//v0==4006
_syscall1(long,sys_unlink,const char*,pathname)//v0==4010
_syscall1(long, sys_time, int *, tloc)//v0==4013
_syscall3(long,sys_lseek,unsigned int,fd,long,offset,unsigned int,origin)//v0==4019
_syscall0(long, sys_getpid)//v0==4020
_syscall0(long,sys_getuid)//v0==4024
_syscall2(long,sys_access,const char *, filename, int, mode)//v0==4033
_syscall2(long, sys_rename, const char *, oldname, const char *, newname)//v0==4038
_syscall1(long,sys_times, struct tms *, tbuf)//v0==4043
_syscall1(unsigned long,sys_brk,unsigned long, brk)//v0==4045
_syscall0(long,sys_getgid)//v0==4047
_syscall0(long,sys_geteuid)//v0==4049
_syscall0(long,sys_getegid)//v0==4050
_syscall3(long,sys_ioctl,unsigned int,fd, unsigned int,cmd, unsigned long,arg)//v0==4054
_syscall3(long,sys_fcntl,unsigned int,fd, unsigned int,cmd, unsigned long,arg)//v0==4055
_syscall2(long,sys_setrlimit, unsigned int, resource, struct rlimitformips*, rlim)//v0==4075
_syscall2(long, sys_getrlimit, unsigned int, resource, struct rlimit *, rlim)//v0==4076
_syscall2(long, sys_getrusage, int, who, struct rusage *, ru)//v0==4077
_syscall6(unsigned long,sys_mmap,unsigned long,addr, unsigned long, len, 
	unsigned long,prot, unsigned long, flags, unsigned long, fd, unsigned long, offset)//v0==4090
_syscall2(long,sys_munmap,unsigned long,addr, unsigned long, len)//v0==4091
_syscall2(long,sys_ftruncate,unsigned int, fd, unsigned long, length)//v0==4093
_syscall2(long,sys_stat,char *, filename, struct statformips*, statbuf)//v0==4106
_syscall2(long,sys_lstat,char *, filename, struct statformips*, statbuf)//v0==4107
_syscall2(long,sys_fstat,unsigned int, fd, struct statformips*, statbuf)//v0==4108
_syscall1(long,sys_uname,new_utsname_formips *,name)//v0==4122
_syscall3(long,sys_mprotect,unsigned long, start, size_t, len, unsigned long, prot)//v0==4125
_syscall5(long,sys__llseek, unsigned int, fd, unsigned long, offset_high,
	unsigned long, offset_low, long long *, result, unsigned int, origin)//v0==4140
_syscall5(long, sys_newselect, int, n, fd_set *, inp, fd_set *, outp,
	fd_set *, exp, struct timeval *, tvp)//v0==4142
_syscall2(long,sys_nanosleep,struct timespecformips *,rqtp, struct timespecformips *,rmtp)//v0==4166
_syscall4(long, sys_rt_sigaction, int, sig, const struct sigactioninvalid *,act, 
	struct sigactioninvalid *,oact, long, sigsetsize)//v0==4194
_syscall4(long,sys_rt_sigprocmask,int, how, sigsetinvalid_t *,set, sigsetinvalid_t *,oset, 
	size_t, sigsetsize)//v0==4195
_syscall6(long,sys_mmap2,unsigned long,addr, unsigned long, len, 
	unsigned long,prot, unsigned long, flags, unsigned long, fd, unsigned long, pgoff)//v0==4210
_syscall2(long,sys_ftruncate64,unsigned int, fd, loff_t, length)//v0==4212
_syscall3(long,sys_stat64,char*, filename,struct stat64formips*,statbuf,long,flags)//v0==4213
_syscall3(long,sys_lstat64,char*, filename,struct stat64formips*,statbuf,long,flags)//v0==4214
_syscall3(long,sys_fstat64,unsigned long, fd,struct stat64formips*,statbuf,long,flags)//v0==4215
_syscall3(long,sys_fcntl64,unsigned int,fd, unsigned int,cmd, unsigned long,arg)//v0==4220

#endif 

