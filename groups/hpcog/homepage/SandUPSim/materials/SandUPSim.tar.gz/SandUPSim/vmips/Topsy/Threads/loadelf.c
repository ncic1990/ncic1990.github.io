#include "servlib.h"
#include "Messages.h"
#include "Syscall.h"
#include "elf.h"
#include "MMMapping.h"
#include "MMVirtualMemory.h"
#include "LibcLinuxTypes.h"
#include "loadelf.h"
#include "LLfcntl.h"
#include "globalopt.h"
#include "Support.h"
#include "LinuxSyscallmman.h"

int byte_order;
/* Function to swap the byte-order for Elf32_Word items (ints) */
Elf32_Word eword_swap(Elf32_Word word)
{
    if (byte_order == ELFDATA2LSB)
      return word;
    return word;
}
/* Function to swap the byte-order for Elf32_Half items (ushorts) */
Elf32_Half ehalf_swap(Elf32_Half half)
{
    if (byte_order == ELFDATA2LSB)
      return half;
    return half;
}

//variables for commandline
//global variables for tranfering command line to threadstart
//#define OUTPUTCMDLINEFORMAT
#define MAXCOMMANDLINELEN 4096
#define MAXCOMMANDLINELENUSED MAXCOMMANDLINELEN/2
long maxusercommandlinelen=MAXCOMMANDLINELEN;
char* home_last_dir;
char* usercommandline=NULL;
commandlineformat_t cmdlineformat;
//cmdline status
cmdlinestatus_t cmdlinestatus;
//batch status
batchstatus_t batchstatus;
//fp for opening file
FILE* exefile;

//information for creating thread
//environment variables
#define MAXENVLEN 4096
long maxenvlen=MAXENVLEN;
char* env_variables;
envvar_t envvar_format;
//Auxillary Vector
auxvec_t aux_vec;

void initcmdline( )
{
	//init cmdline format
	cmdlineformat.redirect[0]=NOTREDIRECT;
	cmdlineformat.redirect[1]=NOTREDIRECT;
	cmdlineformat.redirect[2]=NOTREDIRECT;
	cmdlineformat.cwdhasbechanged=0;
	//init cmdline status
	cmdlinestatus.status=CMDNORMAL;
	//init batch status
	batchstatus.fp=NULL;
	batchstatus.which=0;
	//init fp for opening file
	exefile=NULL;
	//init home and last diretory
	if(Tgetcwd(home_last_dir,MAXCOMMANDLINELENUSED)==NULL)
		printfnull("pwd: can not get home pwd!\n");
	stringCopy(home_last_dir+MAXCOMMANDLINELENUSED, home_last_dir);
	
	char helpcolor[]= { 27,'[','3','2','m',0}; //green
	char normalcolor[]= { 27,'[','0','m',0}; //reset
	printfstr("trying cmdline '%shelp",helpcolor);
	printfstr("%s' to get some info.\n\n",normalcolor);
	
}

//#define DBGENVVAR
void initenvvar( )
{
	unsigned long count;
	char* ptr;
	unsigned long len;

	#ifdef DBGENVVAR
	ioConsolePutString("init environment variables...\n");
	#endif
	envvar_format.envc=0;
	envvar_format.envlen=0;
	envvar_format.env_vars=env_variables;

	//get the environment variables and envc
	envvar_format.envc=TAgetallenv(envvar_format.env_vars,maxenvlen);
	//refresh the envlen
	ptr=envvar_format.env_vars;
	for(count=0;count<envvar_format.envc;count++){
		len=stringlen(ptr)+1;
		ptr+=len;
		envvar_format.envlen+=len;
	}
	
	#ifdef DBGENVVAR
	ioConsolePutString("environment initialization ends.\n");
	#endif
}

bool checkCmdlineLen( )
{
	long cmdlinelen=stringlen(usercommandline);
	if(cmdlinelen>=MAXCOMMANDLINELENUSED){
		ioConsolePutString("Shell err:checkcmdlineLen:Commandline is too long!\n");
		return false;
	}
	return true;
}

void initRedirection( )
{
	long count;
	for(count=0;count<3;count++){
		if(cmdlineformat.redirect[count]!=NOTREDIRECT){
			TLclose(cmdlineformat.redirect[count]);
			#ifdef OUTPUTCMDLINEFORMAT
			switch(count){
				case 0:
					ioConsolePutString("Shell msg:initRedirection:Cancel redirection of stdin: 0x");
					ioConsolePutHexInt(cmdlineformat.redirect[count]);
					break;
				case 1:
					ioConsolePutString("Shell msg:initRedirection:Cancel redirection of stdout: 0x");
					ioConsolePutHexInt(cmdlineformat.redirect[count]);
					break;
				case 2:
					ioConsolePutString("Shell msg:initRedirection:Cancel redirection of stderr: 0x");
					ioConsolePutHexInt(cmdlineformat.redirect[count]);
					break;
			}
			#endif
			cmdlineformat.redirect[count]=NOTREDIRECT;
		}
	}
}

bool doRedirection(char* start, long len)
{
	char tmpchar=start[len];
	start[len]='\0';
	char* filename=start+1;
	long filenamelen=len-1;
	int fd;
	FILE* fp;

	if(start[0]=='<'){
		goto redirectin;
	}
	if(start[1]=='<'){
		filename++;
		filenamelen--;
		switch(start[0]){
			case '0': goto redirectin;
			default: 
				ioConsolePutString("Shell err:redirection:expect '0' before '<' !\n");
				goto outfailed;
		}
	}
	if(start[0]=='>'){
		goto redirectout;
	}
	if(start[1]=='>'){
		filename++;
		filenamelen--;
		switch(start[0]){
  			case '1': goto redirectout;
			case '2': goto redirecterr;
			default: 
				ioConsolePutString("Shell err:redirection:expect '1' or '2' before '>' !\n");
				goto outfailed;
		}
	}
	
outfailed:
	start[len]=tmpchar;
	return false;
redirectin:
	if(cmdlineformat.redirect[0]!=NOTREDIRECT){
		ioConsolePutString("Shell err:redirection:multi redirection of stdin!\n");
		goto outfailed;
	}
	if(filenamelen==0){
		ioConsolePutString("Shell err:redirection: filename for redirecting stdin is NULL!\n");
		goto outfailed;
	}
	fd=TLopen(filename,0,0);
	if(fd<0){
		ioConsolePutString("Shell err:redirection:stdin: can not open file \"");
		ioConsolePutString(filename);
		ioConsolePutString("\"!\n");
		goto outfailed;
	}
	cmdlineformat.redirect[0]=fd;
	#ifdef OUTPUTCMDLINEFORMAT
	ioConsolePutString("Shell msg:redirection:redirect stdin to file \"");
	ioConsolePutString(filename);
	ioConsolePutString("\": 0x");
	ioConsolePutHexInt(fd);
	#endif
	goto outok;
redirectout:
	if(cmdlineformat.redirect[1]!=NOTREDIRECT){
		ioConsolePutString("Shell err:redirection:multi redirection of stdout!\n");
		goto outfailed;
	}
	if(filenamelen==0){
		ioConsolePutString("Shell err:redirection: filename for redirecting stdout is NULL!\n");
		goto outfailed;
	}
	fp=Tfopen(filename,"w");
	if(fp==NULL){
		ioConsolePutString("Shell err:redirection:stdout: can not open file \"");
		ioConsolePutString(filename);
		ioConsolePutString("\"!\n");
		goto outfailed;
	}
	Tfclose(fp);
	fd=TLopen(filename,O_RDWR_MIPS | O_CREAT_MIPS | O_TRUNC_MIPS,0666);
	if(fd<0){
		ioConsolePutString("Shell err:redirection:stdout: can not open file \"");
		ioConsolePutString(filename);
		ioConsolePutString("\"!\n");
		goto outfailed;
	}
	cmdlineformat.redirect[1]=fd;
	#ifdef OUTPUTCMDLINEFORMAT
	ioConsolePutString("Shell msg:redirection:redirect stdout to file \"");
	ioConsolePutString(filename);
	ioConsolePutString("\": 0x");
	ioConsolePutHexInt(fd);
	#endif
	goto outok;
redirecterr:
	if(cmdlineformat.redirect[2]!=NOTREDIRECT){
		ioConsolePutString("Shell err:redirection:multi redirection of stderr!\n");
		goto outfailed;
	}
	if(filenamelen==0){
		ioConsolePutString("Shell err:redirection: filename for redirecting stderr is NULL!\n");
		goto outfailed;
	}
	fp=Tfopen(filename,"w");
	if(fp==NULL){
		ioConsolePutString("Shell err:redirection:stderr: can not open file \"");
		ioConsolePutString(filename);
		ioConsolePutString("\"!\n");
		goto outfailed;
	}
	Tfclose(fp);
	fd=TLopen(filename,O_RDWR_MIPS | O_CREAT_MIPS | O_TRUNC_MIPS,0666);
	if(fd<0){
		ioConsolePutString("Shell err:redirection:stderr: can not open file \"");
		ioConsolePutString(filename);
		ioConsolePutString("\"!\n");
		goto outfailed;
	}
	cmdlineformat.redirect[2]=fd;
	#ifdef OUTPUTCMDLINEFORMAT
	ioConsolePutString("Shell msg:redirection:redirect stderr to file \"");
	ioConsolePutString(filename);
	ioConsolePutString("\": 0x");
	ioConsolePutHexInt(fd);
	#endif
outok:
	start[len]=tmpchar;
	return true;
}

bool HandlingRedirection( )
{
	char* nowstart=(char*)(usercommandline+MAXCOMMANDLINELENUSED);
	char* cmdstart=usercommandline;
	stringCopy(nowstart,usercommandline);
	long blocklen;

	initRedirection( );
	
	do{
		nowstart=findstringblock(nowstart, &blocklen);
		if(blocklen==0) break;
		if((findcharinblock(nowstart,blocklen,'<')==-1)&&
			(findcharinblock(nowstart,blocklen,'>')==-1)){
			stringNCopy(cmdstart,nowstart,blocklen+1);
			cmdstart+=blocklen;
			*cmdstart=' ';
			cmdstart++;
		}else{
			if(!doRedirection(nowstart,blocklen)) return false;
		}
		nowstart+=blocklen;
	}while(1);
	*((char*)cmdstart-1)='\0';
	return true;
}

//"@exefilename"
bool HandlingCWD( )
{
	#ifdef OUTPUTCMDLINEFORMAT
	ioConsolePutString("Shell msg:HandlingCWD:cmdline:");
	ioConsolePutString(usercommandline);
	ioConsolePutString("\n");
	#endif
	if(usercommandline[0]!='@') return true;

	char* pathbase=usercommandline+MAXCOMMANDLINELENUSED;
	char* newcmdline;
	long exefilenamelen;
	
	//get filename
	newcmdline=findstringblock((char*)(usercommandline+1), &exefilenamelen);
	if(newcmdline!=usercommandline+1)
		ioConsolePutString("Shell warning:HandlingCWD:@exefilename.\n");
	if(exefilenamelen<=0){
		ioConsolePutString("Shell err:HandlingCWD:can not find exefilename!\n");
		return false;
	}

	//get directory
	while((exefilenamelen>0)&&(newcmdline[exefilenamelen-1]!='/'))
		exefilenamelen--;
	if(exefilenamelen==0){//current directory
		pathbase[0]='.';
		pathbase[1]='\0';
	}else if(exefilenamelen==1){//root directory
		pathbase[0]='/';
		pathbase[1]='\0';
	}else{
		StringOnlyNCopy(pathbase, newcmdline, exefilenamelen);
		pathbase[exefilenamelen-1]='\0';
	}
	#ifdef OUTPUTCMDLINEFORMAT
	ioConsolePutString("Shell msg:HandlingCWD:filepath:");
	ioConsolePutString(pathbase);
	ioConsolePutString("\n");
	#endif

	//change cwd
	if(!ChangeCWD(pathbase)){
		ioConsolePutString("Shell err:HandlingCWD:can not change cwd!\n");
		return false;
	}
	cmdlineformat.cwdhasbechanged=1;

	//rearrange commandline
	stringCopy(pathbase, newcmdline+exefilenamelen);
	stringCopy(usercommandline,pathbase);
	#ifdef OUTPUTCMDLINEFORMAT
	ioConsolePutString("Shell msg:HandlingCWD:rearranged cmdline:");
	ioConsolePutString(usercommandline);
	ioConsolePutString("\n");
	#endif
 	return true;
}
void doRecoverCWD( )
{
	if(cmdlineformat.cwdhasbechanged){
		RecoverCWD();
		cmdlineformat.cwdhasbechanged=0;
	}
}

//if true: is a shell command , else not
#define CMDGETLEFT(src,len,dest)\
do{\
	src=findstringblock(src+len, &len);\
	len=stringlen(src);\
	StringOnlyNCopy(dest, src, len);\
	shellcmd[len]='\0';\
}while(0)
#define CMDGETNEXT(src,len,dest)\
do{\
	src=findstringblock(src+len, &len);\
	StringOnlyNCopy(dest, src, len);\
	shellcmd[len]='\0';\
}while(0)
void CommandlineHelp( )
{
	char dircolor[]= { 27,'[','3','3','m',0}; //yellow
	char execolor[]= { 27,'[','3','2','m',0}; //green
	char normalcolor[]= { 27,'[','0','m',0}; //reset
	
	//shell command
	printfnull("1: shell command:\n");
	printfnull("(1): echo [STRING]... ;\n");
	printfnull("(2): ls [OPTION]... [FILE]... : the OPTION and FILE is ignored, and ");
	printfstr("colors: %sdirectory",dircolor);
	printfstr("%s - ",normalcolor);
	printfstr("%sexefile",execolor);
	printfstr("%s - other files ;\n",normalcolor);
	printfnull("(3): pwd : get the current working directory ;\n");
	printfnull("(4): cd [PATH] :PATH can be '.' , '..' , '-' , ''  and pathname;\n");
	printfnull("(5): cat <FILE> :show the file content ;\n");
	printfnull("(6): exit :to quit from Topsy.\n");

	//general command line
	printfnull("\n2: general command line:\n");
	printfnull("(1): filename [ARG]... [STDIO REDIRECTION]... ;\n");
	printfnull("(2): @filename [ARG]... [STDIO REDIRECTION]... .\n");

	//predefined command line
	printfnull("\n3: predefined command line:\n");
	printfnull("(1): ':0' to execute ...data/topsy_hello/user.elf ;\n");
	printfnull("(2): ':1' to execute ...data/gzip/gz .\n");

	//batch command line
	printfnull("\n4: batch command line:\n");
	printfnull("(1): $batchfilename :to run the command lines in batch file,each line in the file is a general command line .\n");

}
bool shellcmdanalysis( )
{
	char* shellcmd=usercommandline+MAXCOMMANDLINELENUSED;
	char* cmdlinestart=usercommandline;
	long blocklen;
	FILE* fp;
	long ret;

	cmdlinestart=findstringblock(cmdlinestart, &blocklen);
	if(blocklen==0) return false;
	StringOnlyNCopy(shellcmd, cmdlinestart, blocklen);
	shellcmd[blocklen]='\0';

	if(!stringcmp(shellcmd,"ls")){//ls
		CMDGETLEFT(cmdlinestart,blocklen,shellcmd);
		TAlssimulation(shellcmd);
		return true;
	}
	
	if(!stringcmp(shellcmd, "cd")){ //change directory
		char* dir=shellcmd;
		CMDGETNEXT(cmdlinestart,blocklen,shellcmd);
		switch(shellcmd[0]){
			case '\0'://home dir
				dir=home_last_dir;
				break;
			case '-'://last dir
				dir=home_last_dir+MAXCOMMANDLINELENUSED;
				break;
			default:
				break;
		}
		if(Tgetcwd(usercommandline,MAXCOMMANDLINELENUSED)==NULL)
			printfnull("pwd: can not get cwd!\n");
		if(Tchdir(dir)<0)
			printfstr("cd: path \"%s\" is invalid!\n",dir);
		else
			stringCopy(home_last_dir+MAXCOMMANDLINELENUSED, usercommandline);
		return true;
	}

	if(!stringcmp(shellcmd,"help")){//for some information
		CommandlineHelp();
		return true;
	}

	if(!stringcmp(shellcmd, "pwd")){ //get cwd
		if(Tgetcwd(usercommandline,MAXCOMMANDLINELENUSED)==NULL)
			printfnull("pwd: can not get cwd!\n");
		else
			printfstr("pwd: %s\n",usercommandline);
		return true;
	}

	if(!stringcmp(shellcmd,"cat")){//cat
		CMDGETLEFT(cmdlinestart,blocklen,shellcmd);
		if((fp=Tfopen(shellcmd,"r"))==NULL)
			printfstr("Shell err:shellcmdanalysis:cat:invalid file name:%s\n",shellcmd);
		else{
			do{
				ret=Tfread(cmdlinestart,1,MAXCOMMANDLINELEN-1,fp);
				cmdlinestart[ret]='\0';
				printfstr("%s",cmdlinestart);
			}while(ret!=0);
			Tfclose(fp);
		}
		return true;
	}
	
	if(!stringcmp(shellcmd,"echo")){ //echo
		CMDGETLEFT(cmdlinestart,blocklen,shellcmd);
		printfstr("echo: %s\n",shellcmd);
		return true;
	}

	return false;
}

//commandline format: exe file name--args--redirection
bool cmdlineanalysis( )
{
	long cmdlinelen;

	//handing shell command
	if(shellcmdanalysis()) return false;
	
	//cwd analysis: '@' should be before any redirection,
	//that is: filename should before any redirection if using '@' to change cwd
	if(!HandlingCWD( )) return false;

	//redirection analysis
	#ifdef OUTPUTCMDLINEFORMAT
	ioConsolePutString("\nRedirection analysis begins...\n");
	#endif
	bool retval=HandlingRedirection();
	#ifdef OUTPUTCMDLINEFORMAT
	ioConsolePutString("Redirection analysis ends.\n");
	#endif
	if(!retval) return false;
	cmdlinelen=stringlen(usercommandline);
	#ifdef OUTPUTCMDLINEFORMAT
	ioConsolePutString("\ncommand line format:\n");
	ioConsolePutString("command line: ");
	ioConsolePutString(usercommandline);
	ioConsolePutString("\n");
	#endif

	//arg analysis
	cmdlineformat.cmdlinebase=usercommandline;
	cmdlineformat.cmdlinelen=cmdlinelen+1;
	cmdlineformat.argc=1;
	cmdlineformat.argv[0]=0;
	long count;
	for(count=0;count<cmdlinelen;count++){
		if(usercommandline[count]=='\0') goto outok;
		if(usercommandline[count]!=' ') continue;
		usercommandline[count]='\0';
		do{
			count++;
		}while(usercommandline[count]==' ');
		if(usercommandline[count]=='\0') goto outok;
		cmdlineformat.argv[cmdlineformat.argc]=count;
		cmdlineformat.argc++;
		if(cmdlineformat.argc>MAXCOMMANDLINEPARTS){
			ioConsolePutString("Shell err:cmdlineanalysis:Too many command line parts!\n");
			return false;
		}
	}
	
outok:
	#ifdef OUTPUTCMDLINEFORMAT
	ioConsolePutString("cmdlinebase:0x");
	ioConsolePutHexInt(cmdlineformat.cmdlinebase);
	ioConsolePutString("cmdlinelen:0x");
	ioConsolePutHexInt(cmdlineformat.cmdlinelen);
	ioConsolePutString("argc:0x");
	ioConsolePutHexInt(cmdlineformat.argc);
	ioConsolePutString("argv[]:\n");
	for(count=0;count<cmdlineformat.argc;count++){
		ioConsolePutString(cmdlineformat.argv[count]+cmdlineformat.cmdlinebase);
		ioConsolePutString("\n");
	}
	ioConsolePutString("\n");
	#endif
	return true;
}

bool PredefCmdline( )
{
	char* filename;
	char* defaultfilename0="topsy_hello/user.elf";
	char* defaultfilename1="gzip/gz";
	
	switch(usercommandline[1]){
		case '0': filename=defaultfilename0;break;
		case '1': filename=defaultfilename1;break;
		default: 
			ioConsolePutString("Shell err:PredefCmdline:not such predefined cmdline!\n");
			return false;			
	}
	stringCopy(usercommandline,filename);
	return true;
}

bool readBatchcmdLineFromfile( )
{
	char* cp;
	
	if(batchstatus.fp==NULL){
		ioConsolePutString("Shell err:readBatchcmdLineFromfile:fp for batch is NULL!\n");
		return false;
	}
command:
	cp=Tfgets(usercommandline,MAXCOMMANDLINELENUSED,batchstatus.fp);
	if(cp==NULL) return false;
	ReturnToNullInString(usercommandline);
	clearEndingSpaceInString(usercommandline);
	if(!checkCmdlineLen()) goto command;
	clearHeaderSpaceInString(usercommandline,usercommandline+MAXCOMMANDLINELENUSED);
	stringCopy(usercommandline,usercommandline+MAXCOMMANDLINELENUSED);
	if(usercommandline[0]=='\0') goto command;
	return true;
}
bool BatchCmdline( )
{
	switch(cmdlinestatus.status){
		case CMDNORMAL:
			if(batchstatus.fp!=NULL){
				ioConsolePutString("Shell warning:BatchCmdline:fp for batch is not NULL!\n");
				Tfclose(batchstatus.fp);
				batchstatus.fp=NULL;
			}
			char* filename=usercommandline+1;
			if((batchstatus.fp=Tfopen(filename,"r"))==NULL){
				ioConsolePutString("Shell err:BatchCmdline:can not open the batch file!\n");
				return false;
			}
			if(!readBatchcmdLineFromfile()){
				ioConsolePutString("Shell err:BatchCmdline:not invalid cmdline in batch file!\n");
				return false;
			}
			ioConsolePutString("\nShell msg: begin to execute command lines in batch file...\n");
			batchstatus.which=0;
			cmdlinestatus.status=CMDBATCH;
			ioConsolePutString("\nBatch cmdline:\n");
			ioConsolePutString(usercommandline);
			ioConsolePutString("\n");
			ioConsolePutString("\n");
			break;
		case CMDBATCH:
			if(batchstatus.fp==NULL){
				ioConsolePutString("Shell err:BatchCmdlin:fp for batch is NULL!\n");
				cmdlinestatus.status=CMDNORMAL;
				return false;
			}
			if(!readBatchcmdLineFromfile()){
				cmdlinestatus.status=CMDNORMAL;
				Tfclose(batchstatus.fp);
				batchstatus.fp=NULL;
				batchstatus.which=0;
				ioConsolePutString("Shell msg:BatchCmdline:end of batch file, congratulations!\n");
				return false;
			}
			batchstatus.which++;
			ioConsolePutString("\nBatch cmdline:\n");
			ioConsolePutString(usercommandline);
			ioConsolePutString("\n");
			ioConsolePutString("\n");
			break;
		default:
			ioConsolePutString("Shell err:BatchCmdLine:not such status at the entry of BatchCmdLine!\n");
			return false;
	}
	return true;
}

bool isexit(char* cmdline)
{
	if(!stringcmp(cmdline,"exit")) return true;
	return false;
}

bool NormalHandlingCmdline( )
{
	char cmdcolor[]= { 27,'[','3','5','m',0}; //pink
	char normalcolor[]= { 27,'[','0','m',0}; //reset
command:
	doRecoverCWD( );
	printfstr("%s[",cmdcolor);
	if(TAgetenv("USER",usercommandline,MAXCOMMANDLINELENUSED))
		printfstr("%s@",usercommandline);
	if(TAgetenv("HOSTNAME",usercommandline,MAXCOMMANDLINELENUSED))
		printfstr("%s ",usercommandline);
	TAgetcwd(usercommandline, MAXCOMMANDLINELENUSED, TAGETCWDDIRNAME);
	printfstr("%s]$",usercommandline);
	printfstr("%s",normalcolor);
	usercommandline[0]='\0';

	stringin(usercommandline,MAXCOMMANDLINELENUSED);
	ReturnToNullInString(usercommandline);
	clearEndingSpaceInString(usercommandline);
	if(!checkCmdlineLen()) goto command;
	clearHeaderSpaceInString(usercommandline,usercommandline+MAXCOMMANDLINELENUSED);
	stringCopy(usercommandline,usercommandline+MAXCOMMANDLINELENUSED);
	#ifdef OUTPUTCMDLINEFORMAT
	ioConsolePutString(usercommandline+MAXCOMMANDLINELENUSED);
	ioConsolePutString("\n");
	ioConsolePutString(usercommandline);
	ioConsolePutString("\n");
	#endif
	if(isexit(usercommandline)) endTopsy();
	switch(usercommandline[0]){
		case '$': //batch cmdline
			if(!BatchCmdline()) goto command;
			break;
		case ':': //predefine cmdline
			if(!PredefCmdline()) goto command;
			break;
		default: //normal cmdline
			break;
	}
	return true;
}

void docleaning( )
{
	usercommandline[0]='\0';
	if(exefile!=NULL){
		Tfclose(exefile);
		exefile=NULL;
	}
	doRecoverCWD( );
}
bool handlingcommandline( )
{
command:
	docleaning();
	switch(cmdlinestatus.status){
		case CMDBATCH:
			if(!BatchCmdline()) goto command;
			break;
		case CMDNORMAL:
			if(!NormalHandlingCmdline()) goto command;
			break;
		default:
			ioConsolePutString("Shell err:handlingcommandline:not such cmd status!\n");
			cmdlinestatus.status=CMDNORMAL;
			goto command;
	}
	
	if(!cmdlineanalysis()) goto command;
	if(isexit(usercommandline)) endTopsy();
	exefile=Tfopen(cmdlineformat.cmdlinebase,"r");
	if(exefile==NULL){
		ioConsolePutString("Shell err:handlingcommandline:Open file err.\nfile name:");
		ioConsolePutString(cmdlineformat.cmdlinebase);
		ioConsolePutString("\n");
		goto command;
	}
	return true;
}

/*checking and loading elf*/
int memorycmp(const void * cs,const void * ct,long count)
{
	const unsigned char *su1, *su2;
	int res = 0;

	for( su1 = cs, su2 = ct; 0 < count; ++su1, ++su2, count--)
		if ((res = *su1 - *su2) != 0)
			break;
	return res;
}

#define elf_check_arch(hdr)\
({\
	int __res = 1;\
	Elf32_Ehdr *__h = (hdr);\
\
	if (__h->e_machine != EM_MIPS)\
		__res = 0;\
	if (__h->e_ident[EI_CLASS] != ELFCLASS32)\
		__res = 0;\
\
	__res;\
})
/*
if ((__h->e_flags & EF_MIPS_ABI2) != 0)\
	__res = 0;\
if (((__h->e_flags & EF_MIPS_ABI) != 0) &&\
    ((__h->e_flags & EF_MIPS_ABI) != EF_MIPS_ABI_O32))\
	__res = 0;\
*/

bool elfchecking(char* filename,Elf32_Ehdr *elf_ex)
{
	if (memorycmp(elf_ex->e_ident, ELFMAG, SELFMAG) != 0)
		goto out;
	if (elf_ex->e_type != ET_EXEC && elf_ex->e_type != ET_DYN)
		goto out;
	if (!elf_check_arch(elf_ex))
		goto out;
	if (elf_ex->e_phentsize != sizeof(Elf32_Phdr))
		goto out;
	if (elf_ex->e_phnum > 65536U / sizeof(Elf32_Phdr))
		goto out;
	return true;
out:
	printfstr("file \"%s\" is not a valid elf for mips!\n",filename);
	return false;
}

//if there is an interpreter, the start_entry is the entry of the interpreter,
//other wise is the entry of the executable program.
//if there is an interpreter, the interp_load_addr is the base of the interpreter,
//other wise is zero
//#define DBG_INTERP_LOAD
#define PATH_MAX 4096
bool load_elf_interp(Elf32_Ehdr *elf_head,Elf32_Phdr * seg_table,FILE* fp_ex,
	unsigned long* start_entry,unsigned long *interp_load_addr)
{
	bool retval=true;
	unsigned long entry=elf_head->e_entry;
	unsigned long load_addr=0;
	Elf32_Half 	num_segs=ehalf_swap(elf_head->e_phnum);
	long count;
	Elf32_Phdr* seg_item;

	char* home_mips_ld="/work/mips";  //may be modified
	char* interp_name=NULL;
	FILE* fp_interp;
	unsigned long fd_interp;
	Elf32_Ehdr interp_elfhdr;
	Elf32_Off interp_segtab_offset;
	Elf32_Half interp_segtab_size;
	Elf32_Half interp_num_segs;
	Elf32_Phdr *interp_seg_table=NULL;
	int load_addr_set = 0;
	unsigned long last_bss = 0, elf_bss = 0;
	char* bss_base;

	//is there an interpreter??
	for(count=0,seg_item=seg_table;count<num_segs;count++,seg_item++){
		if(seg_item->p_type!=PT_INTERP) continue;

		//is an interpreter
		//Is there only an interpreter??
		if(interp_name) goto outfailed;
		//Is the name of the interpreter too long?
		if(seg_item->p_filesz>PATH_MAX)
			goto outfailed;
		//alloc space for interpreter name
		if(hmAlloc((Address*)&interp_name,seg_item->p_filesz+stringlen(home_mips_ld))
			!=HM_ALLOCOK)	
			goto outfailed;
		//get the home dir for mips ld
		byteCopy(interp_name,home_mips_ld,stringlen(home_mips_ld));
		//read the name of interpreter
		if(Tfseek(fp_ex,seg_item->p_offset,0))
			goto outfailed;
		if(Tfread(interp_name+stringlen(home_mips_ld),1,seg_item->p_filesz,fp_ex)
			!=seg_item->p_filesz)
			goto outfailed;
	}
	if(interp_name==NULL){
		ioConsolePutString(">statically linked\n");
		goto out;
	}
	//output the interpreter name
	ioConsolePutString(">dynamically linked\n");
	ioConsolePutString("interp is \"");
	ioConsolePutString(interp_name);
	ioConsolePutString("\"\n");
	
	//there is an interpreter
	#ifdef DBG_INTERP_LOAD
	ioConsolePutString("load_elf msg:load_elf_interp:loading interp...\n");
	#endif
	//open and read the elf header of the interpreter
	if((fp_interp=Tfopen(interp_name,"r"))==NULL) goto outfailed;
	if(Tfread(&interp_elfhdr,sizeof(char),sizeof(Elf32_Ehdr),fp_interp)
		!=sizeof(char)*sizeof(Elf32_Ehdr))
		goto outfailed;
	//do some checking
	if(!elfchecking(interp_name,&interp_elfhdr)) goto outfailed;
	//read segment table
	interp_segtab_offset =interp_elfhdr.e_phoff;
	interp_num_segs =interp_elfhdr.e_phnum;
	interp_segtab_size = interp_elfhdr.e_phentsize * interp_num_segs;
	if(Tfseek(fp_interp,interp_segtab_offset,0)) goto outfailed;
	if(hmAlloc((Address*)&interp_seg_table,interp_segtab_size)!=HM_ALLOCOK)
		goto outfailed;
	if(Tfread((char*)interp_seg_table,1,interp_segtab_size,fp_interp)!=interp_segtab_size)
		goto outfailed;
	//reopen
	Tfclose(fp_interp);
	if((fd_interp=TLopen(interp_name,0,0))<0) goto outfailed;
	
	//mapping the interpreter into the user space
#define ELF_PAGESTART(_v) ((_v) & ~(unsigned long)(PAGESIZE-1))
#define ELF_PAGEOFFSET(_v) ((_v) & (PAGESIZE-1))
#define ELF_PAGEALIGN(_v) (((_v) + PAGESIZE - 1) & ~(PAGESIZE - 1))
	for(count=0,seg_item=interp_seg_table;count<interp_num_segs;count++,seg_item++){
		if(seg_item->p_type!=PT_LOAD) continue;
	    int elf_type = MAP_PRIVATE | MAP_DENYWRITE;
	    int elf_prot = 0;
	    unsigned long k, map_addr;
		
	    if (seg_item->p_flags & PF_R) elf_prot =  PROT_READ;
	    if (seg_item->p_flags & PF_W) elf_prot |= PROT_WRITE;
	    if (seg_item->p_flags & PF_X) elf_prot |= PROT_EXEC;
	    if (interp_elfhdr.e_type == ET_EXEC || load_addr_set)
	    	elf_type |= MAP_FIXED;

		map_addr=do_mmap(load_addr+ELF_PAGESTART(seg_item->p_vaddr), 
			seg_item->p_memsz+ELF_PAGEOFFSET(seg_item->p_vaddr), 
			elf_prot, elf_type, fd_interp, 
			(seg_item->p_offset-ELF_PAGEOFFSET(seg_item->p_vaddr))>>PAGEBITS,0);
		#ifdef DBG_INTERP_LOAD
		ioConsolePutString("mmap:\n");
		ioConsolePutString("vaddr:0x");
		ioConsolePutHexInt(load_addr+ELF_PAGESTART(seg_item->p_vaddr));
		ioConsolePutString("len:0x");
		ioConsolePutHexInt(seg_item->p_memsz+ELF_PAGEOFFSET(seg_item->p_vaddr));
		ioConsolePutString("fd:0x");
		ioConsolePutHexInt(fd_interp);
		ioConsolePutString("offset:0x");
		ioConsolePutHexInt(seg_item->p_offset-ELF_PAGEOFFSET(seg_item->p_vaddr));
		ioConsolePutString("map_addr:0x");
		ioConsolePutHexInt(map_addr);
		#endif
		
		if(map_addr<0) goto outfailed;

		if (!load_addr_set && interp_elfhdr.e_type == ET_DYN) {
			load_addr = map_addr - ELF_PAGESTART(seg_item->p_vaddr);
			load_addr_set = 1;
		}

		k = load_addr + seg_item->p_vaddr + seg_item->p_filesz;
		if (k > elf_bss)
		elf_bss = k;
		k = load_addr + seg_item->p_vaddr + seg_item->p_memsz;
		if (k > last_bss)
		last_bss = k;
	}
	//set bss to zero
	count=ELF_PAGEALIGN(last_bss)-elf_bss;
	bss_base=(char*)elf_bss; //KUSEG
	if(count>0){
		#ifdef TASSISTMEMSET
		TAmemset(bss_base, 0, count);
		#else
		int i;
		for(i=0;i<count;i++,bss_base++)
			*bss_base=(char)0;
		#endif
	}
#undef ELF_PAGESTART
#undef ELF_PAGEOFFSET
#undef ELF_PAGEALIGN

	entry=load_addr+(unsigned long)interp_elfhdr.e_entry;
	#ifdef DBG_INTERP_LOAD
	ioConsolePutString("load_addr:0x");
	ioConsolePutHexInt(load_addr);
	ioConsolePutString("interp origin entry:0x");
	ioConsolePutHexInt((unsigned long)interp_elfhdr.e_entry);
	ioConsolePutString("entry:0x");
	ioConsolePutHexInt(entry);
	ioConsolePutString("elf_bss:0x");
	ioConsolePutHexInt(elf_bss);
	ioConsolePutString("last_bss:0x");
	ioConsolePutHexInt(last_bss);
	ioConsolePutString("bss and padded zero count:0x");
	ioConsolePutHexInt(count);
	ioConsolePutString("load_elf msg:load_elf_interp:loading interp ends.\n");
	#endif

outok:
	goto out;
outfailed:
	ioConsolePutString("load_elf err:load_elf_interp.\n");
	retval=false;
out:
	if(interp_name!=NULL) hmFree(interp_name);
	if(interp_seg_table!=NULL) hmFree(interp_seg_table);
	if(start_entry!=NULL) *start_entry=entry;
	if(interp_load_addr!=NULL) *interp_load_addr=load_addr;
	return retval;
}

unsigned long fileread()
{
	char *errorvmAlloc="vmAlloc err.\n";
	char *errorTfreadfile ="read file err.\n";
	char *TfreadfileOK="read file ok.\n";
	
	int i,retCode;
	Address codeStart,dataStart;
	unsigned long int codePhysStart,dataPhysStart;
	unsigned long codeSize,dataSize;
	unsigned long pro_entry;
	long ret;
	long leftzero;
	char* leftbase;
	unsigned long load_addr,interp_load_addr;

	FILE* fp;
	int 	nLength;
	Elf32_Ehdr 	*elf_head,elfheadS;
	Elf32_Off 	segtab_offset;	       /* segment table offset */
	Elf32_Half 	segtab_size;	       /* segment table size */
	Elf32_Half 	num_segs;	       /* number of segment entries */
	Elf32_Phdr 	*ptr, *seg_table ;       	/* segment table buffer */
	//for load segments
	Elf32_Phdr*  ptr_codedata[2];
	#define MAXLOADSEG 2
	int num_loadseg;

command:
	//reading command line
	exefile=NULL;
	if(!handlingcommandline()) goto command;
	fp=exefile;

	//read elf header
	nLength=sizeof(Elf32_Ehdr);
	if(Tfread(&elfheadS,sizeof(char),nLength,fp)!=sizeof(char)*nLength)
		goto retry_free_fp;
	elf_head = (Elf32_Ehdr *)&elfheadS;

	//elf checking
	if(!elfchecking(cmdlineformat.cmdlinebase, elf_head)) goto retry_free_fp;

	//read segment table
	byte_order = elf_head->e_ident[EI_DATA];
	segtab_offset = eword_swap(elf_head->e_phoff);
	segtab_size = eword_swap(elf_head->e_phentsize) * eword_swap(elf_head->e_phnum);
	num_segs = ehalf_swap(elf_head->e_phnum);
	if(Tfseek(fp,segtab_offset,0)) goto retry_free_fp;
	retCode=hmAlloc((Address*)&seg_table,segtab_size);
	if(retCode!=HM_ALLOCOK)
	{
		ioConsolePutString("load_elf err:fileread:vmAlloc err.\n");
		goto retry_free_fp;
	}
	if(Tfread((char*)seg_table,1,segtab_size,fp)!=segtab_size)
		goto retry_free_fp_segtab;

	//get the code segment and data segment pointer
	num_loadseg=0;
	for(i=0,ptr=seg_table;i<num_segs;i++,ptr++){
		if(ptr->p_type!=PT_LOAD) continue;
		if(num_loadseg>=MAXLOADSEG) goto retry_free_fp_segtab;
		ptr_codedata[num_loadseg]=ptr;
		num_loadseg++;
	}
	if(num_loadseg!=MAXLOADSEG) goto retry_free_fp_segtab;
	
	//get some information from segment table
	ptr=ptr_codedata[0];	//code segment 
	codeStart=(Address)eword_swap(ptr->p_vaddr); 
	codeSize =eword_swap(ptr->p_memsz);
	ptr=ptr_codedata[1];	//data segment
	dataStart=(Address)eword_swap(ptr->p_vaddr); 
	dataSize =eword_swap(ptr->p_memsz);

	//memory mapping
	retCode=(int)mmInitMemoryMapping(codeStart,codeSize,dataStart,dataSize,0,
		&codePhysStart,&dataPhysStart);
	if(retCode !=MM_INITMEMORYMAPPINGOK)
		goto retry_free_fp_segtab;

	//reading code and data segments from elf to memory(by k1seg)
	//and init some sections such as bss
	ptr=ptr_codedata[0];	//code segment
	if(Tfseek(fp,eword_swap(ptr->p_offset),0)) goto retry_free_fp_segtab;
	/*note: for code:
	  for virtserv:use K1SEG to avoiding invalidating the cache
	  for romoteserv:use K1SEG to avoiding cache semantic incoherence	
	  */
	if(Tfread((char*)(K1SEG_BASE+codePhysStart),1,eword_swap(ptr->p_memsz),fp)!=
		eword_swap(ptr->p_memsz)) 
		goto retry_free_fp_segtab;
	ptr=ptr_codedata[1];	//data segment
	if(Tfseek(fp,eword_swap(ptr->p_offset),0)) goto retry_free_fp_segtab;
	/*slfsmm031026_mod>init bss to 0*/
	//Tfread(eword_swap(ptr->p_vaddr),1,eword_swap(ptr->p_memsz),fp);
	/*note: for data:
	  for virtserv:use K1SEG to avoiding invalidating the cache
	  for romoteserv:the data is not put in the cache,so when accessed, it is slower	
	  */
	ret=Tfread((char*)(K1SEG_BASE+dataPhysStart),1,eword_swap(ptr->p_filesz),fp);
	if(ret!=eword_swap(ptr->p_filesz)) goto retry_free_fp_segtab;

	//init some sections such as bss
	/*slfsmm031212_note>maybe not need now,because the memory for user has
		be initialized in mmInitMemoryMapping( )*/
	leftzero=(long)eword_swap(ptr->p_memsz)-ret;
	#ifdef TASSISTMEMSET
	leftbase=(char*)((long)(K1SEG_BASE+dataPhysStart)+ret); //K1SEG
	TAmemset(leftbase, 0, leftzero);
	#else
	leftbase=(char*)((long)dataStart+ret); //KUSEG
	for(i=0;i<leftzero;i++){
		*leftbase=(char)0;
	leftbase++;
	}
	#endif
	/*slfsmm031212_note<*/
	/*slfsmm031026_mod>*/

	retCode=mmUserVmInit(codeStart, codeSize,dataStart, dataSize);
	if(retCode != MM_VMINITOK)
		goto retry_free_fp_segtab;

	//load the interpreter
	if(!load_elf_interp(elf_head,seg_table,fp,&pro_entry,&interp_load_addr))
		goto retry_free_fp_segtab;

	//set auxvec for creating thread
	load_addr=ptr_codedata[0]->p_vaddr-ptr_codedata[0]->p_offset;
	aux_vec.a_phdr=(unsigned long)load_addr+(unsigned long)elf_head->e_phoff;
	aux_vec.a_phent=(unsigned long)sizeof(Elf32_Phdr);
	aux_vec.a_phnum=(unsigned long)elf_head->e_phnum;
	aux_vec.a_base=(unsigned long)interp_load_addr;
	aux_vec.a_entry=(unsigned long)elf_head->e_entry;
	
	hmFree(seg_table);
	Tfclose(fp);
	//return elf_head->e_entry;
	return pro_entry;

retry_free_fp_segtab:
	hmFree(seg_table);
retry_free_fp:
	Tfclose(fp);
	ioConsolePutString("load_elf err:fileread.\n");
	goto command;
	
}

