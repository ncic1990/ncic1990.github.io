/*the following functions are implemented through virtual server*/
#include "KIOflag.h"
#include "KVirtServ.h"
#include "SoftIOConsole.c"

