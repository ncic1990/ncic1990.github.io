#ifndef REMOTESERV_H
#define REMOETSERV_H

#include "Support.h"
#include "LibcLinuxTypes.h"

/*remote server space layout*/
//moved to file KNetWorkCardInfo.h or UNetWorkCardInfo.h
#define RemoteServerSpaceSize	8*1024
#define RemoteServSpaceLLSize (RemoteServerSpaceSize/sizeof(uint64))
//buffer
#define RemoteServBufBase	RemoteServerSpaceBase
#define RemoteServBufOff (RemoteServBufBase-RemoteServerSpaceBase)
//note:when changed, be sure to change the corresponding item in remote server
#define RemoteServBufSize	4096	
//control registers
#define RemoteServCtlBase	(RemoteServerSpaceBase+RemoteServerSpaceSize-4)
#define RemoteServCtlOff  (RemoteServCtlBase-RemoteServerSpaceBase)
#define RemoteServCtlSize	4
//status registers:can be modified only in kernelmode(may be mod)
//and can be accessed only through instructions lw and sw
#define RemoteServStatusBase (RemoteServCtlBase-RemoteServCtlSize)
#define RemoteServStatusOff (RemoteServStatusBase-RemoteServerSpaceBase)
#define RemoteServStatusSize 4

/*status ports*/
#define VIRT_REMOTE_PHYS RemoteServStatusBase
#define VIRT_REMOTE_OFF (VIRT_REMOTE_PHYS-RemoteServSpaceBase)

/*control port:send and receive*/
#define PORT_S_R_PHYS RemoteServCtlBase
#define PORT_S_R_OFF (PORT_S_R_PHYS-RemoteServerSpaceBase)

#define SEND_PACKAGE 0
#define RECV_PACKAGE 1
#define CONNECT 2
#define DISCONNECT 3

//note:when changed, be sure to change the corresponding item in vmips
//note:a sigal package size should at least content package_header_t RDH and RDBH
#define NetWorkCardBufSize RemoteServBufSize

//server info
#define SERVERADDR "127.0.0.1"
#define SERVERPORT 9000	//default serverport

typedef union RServReqDataUnit{
	uint64 data64;
	struct twoparts{
		uint32 data32low;
		uint32 data32high;
	}data32;
}RServReqDataUnit_t;
typedef RServReqDataUnit_t RServRepDataUnit_t;
typedef RServReqDataUnit_t RServDataUnit_t;

#define UNITVAL(param) param.data32.data32low
#define UNITVALHIGH(param) param.data32.datahigh
#define UNITVALALL(param) param.data64

//address description structure
typedef struct addrdesc_struct{
	RServDataUnit_t addr;
	RServDataUnit_t port;
}addrdesc_t;

//package header
typedef struct package_header{
	addrdesc_t destaddr;
	addrdesc_t srcaddr;
	RServDataUnit_t packagelen;
	RServDataUnit_t packageflag;
}package_header_t;
//packageflag
#define FIRSTANDLAST -1
#define FIRSTPACKAGE 0
#define LASTPACKAGE 1
#define DEFMIDPACKAGE 2
//max data package body size
#define MAXDPBSIZE (NetWorkCardBufSize-sizeof(package_header_t))

//data set align
#define ORIGINDATASETALIGN sizeof(uint64)

//data set header structure
typedef struct ReqDataSetHeader{
	addrdesc_t destaddr;
	addrdesc_t srcaddr;
	RServReqDataUnit_t datasetlen;
}ReqDataSetHeader_t;
typedef ReqDataSetHeader_t ReqDH;
typedef ReqDataSetHeader_t ReplyDataSetHeader_t;
typedef ReplyDataSetHeader_t RepDH;
typedef ReqDH RDH;	//common used

//data set body header
typedef struct ReqDataSetBodyHeader{
	RServReqDataUnit_t servtype;
	RServReqDataUnit_t service;
}ReqDataSetBodyHeader_t;
typedef ReqDataSetBodyHeader_t ReqDBH;
typedef ReqDataSetBodyHeader_t ReplyDataSetBodyHeader_t;
typedef ReplyDataSetBodyHeader_t RepDBH;
typedef ReqDBH RDBH;	//common used

//data set body parameters
typedef struct DataSetParamDesc_struct{
	RServDataUnit_t paramval;
	//if not a pointer,it is -1;if paramval is a pointer,it shows the size of the struct
	RServDataUnit_t structlen; 
}DSParamDesc_t;
//some special structlen value
#define PARAM_NOTPOINTER -1
#define PARAM_POINTERNULL 0
//max parameters in dataset
#define MAXPARAMETERS 20
typedef struct ReqDataSetBodyParameters{
	RServReqDataUnit_t parameternum;
	DSParamDesc_t parameters[MAXPARAMETERS];
}ReqDataSetBodyParameters_t;
typedef ReqDataSetBodyParameters_t ReqDBP;
typedef ReqDataSetBodyParameters_t ReplyDataSetBodyParameters_t;
typedef ReplyDataSetBodyParameters_t RepDBP;
typedef ReqDBP RDBP;	//common used
//when can not get the service, the parameternum in reply data set is the following const
#define DEFCANNOTSERV -1
#define DEFDATASETSIZE 4096	//?? is it useful?

//parameter structure used when making a data set
typedef struct ParamItemDesc{	//for 32bit arch
	uint32 paramval;
	uint32 notpointer;
	uint32 align;	//when notpointer,align is invalid 
	uint32 len;	//when notpointer,len is invalid
	uint32 offset;	//when pointer,it is the offset of the para. it is not used by user
}ParamItemDesc_t;
//notpointer:true or false
//align: usually 1 or 8
#define CHARALIGN sizeof(uint8)
#define DWORDALIGN sizeof(uint64)
//for length checking when param is a pointer
#define PARAMCHECKING_DEFAULTLEN 0
typedef struct ParamsDesc{
	uint32 paramnum;
	ParamItemDesc_t parameters[MAXPARAMETERS];
}ParamsDesc_t;
//serv info descripton
typedef struct ServInfoDesc_struct{
	addrdesc_t destaddr;
	addrdesc_t srcaddr;
	uint32 type;
	uint32 service;
	ParamsDesc_t paramdesc;
}ServInfoDesc_t;
	

//request type and services
//libc request
#define LIBCREQ 0

#define fopenservno    0
#define fopenparams    2

#define freadservno    1
#define freadparams    3	//note:not 4

#define fwriteservno   2
#define fwriteparams   4

#define fcloseservno   3
#define fcloseparams   1

#define fseekservno    4
#define fseekparams    3

#define ftellservno    5
#define ftellparams    1

#define rewindservno   6
#define rewindparams   1

#define feofservno     7
#define feofparams     1

#define fgetcservno    8
#define fgetcparams    1

#define fgetsservno    9
#define fgetsparams    2

#define fputcservno    10
#define fputcparams    2

#define fputsservno    11
#define fputsparams    2

#define libcgetcwdservno 12
#define libcgetcwdparams 1

#define libcchdirservno	13
#define libcchdirparams	1

//linux syscall
#define LINUXSYSCALL 1

#define LinuxSyscallreadservno 3
#define LinuxSyscallreadparams 2

#define LinuxSyscallwriteservno 4
#define LinuxSyscallwriteparams 3

#define LinuxSyscallopenservno 5
#define LinuxSyscallopenparams 3

#define LinuxSyscallcloseservno 6
#define LinuxSyscallcloseparams 1

#define LinuxSyscallunlinkservno 10
#define LinuxSyscallunlinkparams 1

#define LinuxSyscalltimeservno 13
#define LinuxSyscalltimeparams 0

#define LinuxSyscalllseekservno 19
#define LinuxSyscalllseekparams 3

#define LinuxSyscallgetpidservno 20
#define LinuxSyscallgetpidparams 0

#define LinuxSyscallgetuidservno 24
#define LinuxSyscallgetuidparams 0

#define LinuxSyscallaccessservno 33
#define LinuxSyscallaccessparams 2

#define LinuxSyscallrenameservno 38
#define LinuxSyscallrenameparams 2

#define LinuxSyscalltimesservno 43
#define LinuxSyscalltimesparams 0

#define LinuxSyscallgetgidservno 47
#define LinuxSyscallgetgidparams 0

#define LinuxSyscallgeteuidservno 49
#define LinuxSyscallgeteuidparams 0

#define LinuxSyscallgetegidservno 50
#define LinuxSyscallgetegidparams 0

#define LinuxSyscallioctlservno 54
#define LinuxSyscallioctlparams 3

#define LinuxSyscallfcntlservno 55
#define LinuxSyscallfcntlparams 3

#define LinuxSyscallgetrlimitservno 76
#define LinuxSyscallgetrlimitparams 1

#define LinuxSyscallgetrusageservno 77
#define LinuxSyscallgetrusageparams 1

#define LinuxSyscallftruncateservno 93
#define LinuxSyscallftruncateparams 2

#define LinuxSyscallstatservno 106
#define LinuxSyscallstatparams 1

#define LinuxSyscalllstatservno 107
#define LinuxSyscalllstatparams 1

#define LinuxSyscallfstatservno 108
#define LinuxSyscallfstatparams 1

#define LinuxSyscallnewunameservno 122
#define LinuxSyscallnewunameparams 0

#define LinuxSyscallllseekservno 140
#define LinuxSyscallllseekparams 4

#define LinuxSyscallnewselectservno 142
#define LinuxSyscallnewselectparams 5 //somewhat special

#define LinuxSyscallftruncate64servno 212
#define LinuxSyscallftruncate64params 3 //somewhat special

#define LinuxSyscallstat64servno 213
#define LinuxSyscallstat64params 2

#define LinuxSyscalllstat64servno 214
#define LinuxSyscalllstat64params 2

#define LinuxSyscallfstat64servno 215
#define LinuxSyscallfstat64params 2

#define LinuxSyscallfcntl64servno 220
#define LinuxSyscallfcntl64params 3

//TopsyAssistantServer:some assistant functions used in Topsy
#define TOPSYASSISTREQ 2

#define ioConsolePutStringservno 0
#define ioConsolePutStringparams 1

#define ioConsolePutHexIntservno 1
#define ioConsolePutHexIntparams 1

#define stringoutservno 2
#define stringoutparams 1

#define stringinservno 3
#define stringinparams 1

#define redirectstdioservno 4
#define redirectstdioparams 3

#define deredirectstdioservno 5
#define deredirectstdioparams 0

#define changecwdservno 6
#define changecwdparams 1

#define recovercwdservno 7 
#define recovercwdparams 0 

#define printfnullservno 8
#define printfnullparams 1

#define printfstrservno 9
#define printfstrparams 2

#define printfnumservno 10
#define printfnumparams 2

#define TAgetcwdservno 11
#define TAgetcwdparams 2

#define TAlssimulationservno 12
#define TAlssimulationparams 1

#define TAgetenvservno 13
#define TAgetenvparams 2

#define TAchstdiobynameservno 14
#define TAchstdiobynameparams 4

#endif /*REMOETSERV_H*/

