#ifndef REMOTESERV_H
#define REMOTESERV_H

#include "sysinclude.h"

/*remote server space layout*/
#define RemoteServerSpaceBase	0x13000000
#define RemoteServerSpaceSize	(8*1024)
#define RemoteServSpaceLLSize (RemoteServerSpaceSize/sizeof(uint64))
//buffer
#define RemoteServBufBase	RemoteServerSpaceBase
#define RemoteServBufOff (RemoteServBufBase-RemoteServerSpaceBase)
//note:when changed, be sure to change the corresponding item in remote server
#define RemoteServBufSize	4096	
//control registers
#define RemoteServCtlBase	(RemoteServerSpaceBase+RemoteServerSpaceSize-4)
#define RemoteServCtlOff  (RemoteServCtlBase-RemoteServerSpaceBase)
#define RemoteServCtlSize	4
//status registers:can be modified only in kernelmode(may be mod)
//and can be accessed only through instructions lw and sw
#define RemoteServStatusBase (RemoteServCtlBase-RemoteServCtlSize)
#define RemoteServStatusOff (RemoteServStatusBase-RemoteServerSpaceBase)
#define RemoteServStatusSize 4

/*status ports*/
#define VIRT_REMOTE_PHYS RemoteServStatusBase
#define VIRT_REMOTE_OFF (VIRT_REMOTE_PHYS-RemoteServSpaceBase)

/*control port:send and receive*/
#define PORT_S_R_PHYS RemoteServCtlBase
#define PORT_S_R_OFF (PORT_S_R_PHYS-RemoteServerSpaceBase)

#define SEND_PACKAGE 0
#define RECV_PACKAGE 1
#define CONNECT 2
#define DISCONNECT 3

//server info
#define SERVERADDR "127.0.0.1"
#define SERVERPORT 9000	//default server port

typedef union RServReqDataUnit{
	uint64 data64;
	struct twoparts{
		uint32 data32low;
		uint32 data32high;
	}data32;
}RServReqDataUnit_t;
typedef RServReqDataUnit_t RServRepDataUnit_t;
typedef RServReqDataUnit_t RServDataUnit_t;

#define UNITVAL(param) param.data32.data32low
#define UNITVALHIGH(param) param.data32.datahigh
#define UNITVALALL(param) param.data64

//address description structure
typedef struct addrdesc_struct{
	RServDataUnit_t addr;
	RServDataUnit_t port;
}addrdesc_t;

//package header
typedef struct package_header{
	addrdesc_t destaddr;
	addrdesc_t srcaddr;
	RServDataUnit_t packagelen;
	RServDataUnit_t packageflag;
}package_header_t;

#endif /*REMOTESERV_H*/

