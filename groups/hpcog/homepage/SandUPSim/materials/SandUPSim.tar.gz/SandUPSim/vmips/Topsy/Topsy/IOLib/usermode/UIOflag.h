#ifndef UIOFLAG_H
#define UIOFLAG_H

#include "UVirtServ.h"
#include "URemoteServ.h"
#include "SoftIOConsoleOpt.h"

#ifndef IOALWAYSVIRT
//note:be sure not define the following as:
//#define IOCOMMONVIRTSERVFLAG (*((long*)VIRT_REMOTE_PHYS))
//because VIRT_REMOTE_PHYS is also a define
#define IOCOMMONVIRTSERVFLAG (*((long*)(VIRT_REMOTE_PHYS)))
#else
#define IOCOMMONVIRTSERVFLAG 1
#endif

#endif

