/*
	Copyright (c) 1996-1997 Swiss Federal Institute of Technology, 
	Computer Engineering and Networks Laboratory. All rights reserved.

	TOPSY - A Teachable Operating System. 
		Implementation of a tiny and simple micro kernel for
		teaching purposes.

	Permission to use, copy, modify, and distribute this software and its
	documentation for any purpose, without fee, and without written 
	agreement is hereby granted, provided that the above copyright notice 
	and the following two paragraphs appear in all copies of this software.


	
	File:                  $Source: /work/cvs/cvsroot/Topsy/Startup/Startup.c,v $
 	Author(s):             George Fankhauser
 	Affiliation:           ETH Zuerich, TIK
 	Version:               $Revision: 1.3 $
 	Creation Date:        
 	Last Date of Change:   $Date: 2003/11/25 13:33:29 $      by: $Author: slfsmm $
	
	
*/

#include "Startup.h"
#include "Memory.h"
#include "Threads.h"
#include "IO.h"
#include "IOHal.h"
#include "Configuration.h"
#include "hwparaforos.h"

#define SEGMAP 0xA01C0000
/* 
#define SEGMAP address -> SEGMAP is defined in the Makefile for startup 
and bootlinker in order to remain consistent */

void entry() {
      Address mmStack, tmStack;
      Address userJump = ((SegMapPtr)SEGMAP)->userJumpAddress;

	  /*slfsmm031107>get hardware parameters for os*/
	  //note:should be done before any IO/Libc/LinuxSyscall
	  gethwparaforos();
	  /*slfsmm031107<*/
	  
	  //ioConsolePutHexInt((unsigned long)userJump);
      initBasicExceptions();			    /* catch traps early */
      //ioConsoleInit();				    /* set baud 9600 etc. */
      ioConsolePutString(BOOTMESSAGE);    
      mmInit((SegMapPtr)SEGMAP, &mmStack, &tmStack);  
						    /* startup memory init */
	  
      tmInit(mmStack, tmStack, userJump);            /* startup thread init */
      PANIC("init returned");			  /* mm/tmInit never returns */
}

/* local dummy function needed by gcc. main() jumps always here first. this is
 * not really necessary, it's just for keeping the compiler happy
 */
static void __main() {}
