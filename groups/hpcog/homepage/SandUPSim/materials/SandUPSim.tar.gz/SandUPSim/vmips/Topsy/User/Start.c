/*
 *  This is the file that will start all the testing stuff
 *  It will start the two signal boxes and will also start the
 *  testing code.
 */


/*
 *  Topsy includes
 */

#include "Syscall.h"		/* Topsy system calls */
#include "UserSupport.h"	/* User library       */
#include "GateKeeper.h"		/* Gatekeepers        */
#include "Error.h"

void __main() {}		/* Needed for the linker */
void addcar(void);
void enterbridge(ThreadId sender);
void leavebridge(void);
void do_send(ThreadId dest, Message *msg);

ThreadId tty;
ThreadId gateN, gateS;  /* North and South gates */

int northwait;
int southwait;
int onbridge;
int nextcar;
int lastcar;

void main(ThreadArg arg)
{

	Message reply;
	ThreadId myid;
	ThreadId temp;
	ThreadId open = ANY;
        int i,rv;
	
	//add myown work
	int j=0; 
	//end add myown work
	
	ioOpen(IO_CONSOLE, &tty);	/* open the console       */
	ioInit(tty);		/* initialise the console */

	display(tty, "Start: Main Thread Started\n");	/* init message */

	/*
	 * Start the signal boxes
	 */

	if (tmStart
	    (&gateN, (ThreadMainFunction) GateKeeper, (ThreadArg) 0,
	     "GateNorth") == TM_STARTFAILED) {
		display(tty, "Start: thread start failed\n");
		tmExit();
	}

	printf(tty, "Start: Started gateN with id %d\n", (int) gateN);

	if (tmStart
	    (&gateS, (ThreadMainFunction) GateKeeper, (ThreadArg) 0,
	     "GateSouth") == TM_STARTFAILED) {
		display(tty, "Start: thread start failed\n");
		tmExit();
	}

	printf(tty, "Start: Started gateS with id %d\n", (int) gateS);

	/* 
	 * Initialise the signal boxes
	 */

	reply.msg.userMsg.p1 = gateS;

	if (tmMsgSend(gateN, &reply) == TM_STARTFAILED) {
		display(tty, "Start: send to gateN failed\n");
		tmExit();
	}

	display(tty, "Start: Initialised gateN\n");

	reply.msg.userMsg.p1 = gateN;

	if (tmMsgSend(gateS, &reply) == TM_STARTFAILED) {
		display(tty, "Start: send to gateS failed\n");
		tmExit();
	}

	display(tty, "Start: Initialised gateS\n");

	/*
	 * Testing code 
         */
        /* init the waiting cars */
        northwait = southwait = 0;
        onbridge = NONE;
        nextcar = CAR_ID_MIN;
        
        addcar();
        addcar();
        addcar();
        
        while (1){
                addcar();
                
                /* get a message */
                open = ANY;
                rv = tmMsgRecv(&open,ANYMSGTYPE,&reply,INFINITY);
                if (rv == TM_MSGRECVFAILED){
                        display(tty,"Start: tmMsgRecv failed\n");
                        break; /* Exit */
                }
                        
                /* if it ! car enter - throw it away */
                if (reply.msg.userMsg.p2 != CAR_ENTER){
                        display(tty,"Start: Illegal message - Ignored\n");
                        continue; /* Next... */
                }
                
                /* Remove it from the queue to be sent */
                enterbridge(open);
                
                /* If rand is true - new car arrives */
                switch (nextcar % 4){
                case 0:
                        /* nothing */
                        break;
                case 1: 
                        addcar();
                        /* FALLTHROUGH */
                case 2:
                        addcar();
                        /* FALLTHROUGH */
                case 3:
                        addcar();
                }

                /* Car on Bridge exits */
                leavebridge();
		j++;
        	printf(tty,"*********** %d *************\n",j);
		if(j==10)
			break;
        } 
	 
        printf(tty,"end of car run!\n");
}


void
addcar(void){
        int gate;
        Message smsg;
        int i;

        if ((northwait + southwait) > MAX_CARS){
                return;
        }
        
        smsg.msg.userMsg.p2 = CAR_ARRIVE;
        smsg.msg.userMsg.p3 = nextcar;

        /* Almost a random number generator */
        if (nextcar % 3){
                southwait ++;
                smsg.msg.userMsg.p1 = gateS;
                printf(tty,"Start: Car arrive at South\n");
        } else {
                northwait ++;
                smsg.msg.userMsg.p1 = gateN;
                printf(tty,"Start: Car arrive at North\n");
        }
        
        do_send(smsg.msg.userMsg.p1,&smsg);

        nextcar ++;
}

void
enterbridge(ThreadId sender){
        int *dir;
        int ns;

        printf(tty,"Start: Cars: North: %d ; South: %d\n",northwait,southwait);
        
        if (sender == gateN){
                /* car is at north end */
                dir = &northwait;
                ns = SOUTH; /* Heading south obviously */
                printf(tty,"Start: Allowing car from North\n");
        } else if (sender == gateS){
                /* car is at the south end */
                dir = &southwait;
                ns = NORTH;
                printf(tty,"Start: Allowing car from South\n");
        } else {
                /* Error */
                printf(tty,"Start: Invalid message to enter bridge\n");
                return;
        }

        if (onbridge != NONE){
                printf(tty,"Start: Error: There is a car on the bridge\n");
                return;
        }
        
        if (lastcar == ns){
                printf(tty,"Start: Error: Too many cars in same direction\n");
                return;
        }
        
        if (*dir < 1){
                printf(tty,"Start: Error: no cars waiting!\n");
                return;
        }
        

        (*dir) --;
        onbridge = ns;
}

void
leavebridge(void){
        Message smsg;
        ThreadId dest;

        if (onbridge == NORTH){
                printf(tty,"Start: Car leaving to North\n");
                dest = gateN;
        } else {
                printf(tty,"Start: Car leaving to South\n");
                dest = gateS;
        }
        
        smsg.msg.userMsg.p1 = dest;
        smsg.msg.userMsg.p2 = CAR_LEAVE;
        smsg.msg.userMsg.p3 = 0;

        if (northwait > 0 && southwait > 0)
                lastcar = onbridge;
        else
                lastcar = NONE;

        onbridge = NONE;
        
        do_send(dest,&smsg);
}

void
do_send(ThreadId dest,Message *msgp){
        int rv;
        
        rv = tmMsgSend(dest,msgp);

        if (rv == TM_STARTFAILED){
                printf(tty,"Start: Send to %d failed\n",(int)dest);
                tmExit();
        }
}
