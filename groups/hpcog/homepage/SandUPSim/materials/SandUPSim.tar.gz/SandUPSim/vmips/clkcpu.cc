/*
  * Added by zwl on Oct 16th, 2003, clkopcodeJumpTable emulation on clock level  
  *--------------------------------------------------------------------
  *
  */
  
//#include "cpzero.h"
#include <stdio.h>
#include "vmips.h"
#include "excnames.h"
#include "regnames.h"
#include "error.h"
//#include "cpu.h"
#include "clkcpu.h"
#include "addr.h"
#include "stub-dis.h"
//#include "tlb.h"
#include "cpone.h"
#include "clkcpone.h"
#include "pplstat.h"

/* add for debug */
//#define __DUMP_INST__  //for instruction execution flow print, getting rid of memory copy and utlb miss
//#define __DUMP_INST__2 //for a1 a3 print
//#define __CMP_DEBUG__ //during execution, auto compare the changed  register value with that of right execution flow
/* end -add for debug */

/* pointer to CLKCPU method returning void and taking two uint32's */
typedef void (CLKCPU::*clkemulate_funptr)(uint32); //

CLKCPU::CLKCPU()
	:CPU()
{
	delay_state = NORMAL;
	reg[REG_ZERO] = 0;
	for (int i=0; i<32; i++)
	{
		regflag[i]= 0;//to define the readable state of the according register
	}	
	if_id.tag=false; // to disable each stage latch
	id_ex.tag=false;
	ex_mem.tag=false;
	mem_wb.tag=false;	
	
	if_id.stall=false; // true for stalling the stage after the latch 
	id_ex.stall=false;
	ex_mem.stall=false;
	mem_wb.stall=false;
	
	_if_stock = false;// true for stocking the according pipeline stage 
	_id_stock = false;
	_mem_stock = false;
	
	_if_skip = false; // true for skip the according pipeline stage
	_id_skip = false;
	_ex_skip =false;
	
	flaga = false;//for decode stage to use
	flagb = false;
	pl_state = true;//successful decode
	
	if_delay_time = 0;//record the delay time at IF stage
	delay_time = 0;//record the delay time at MEM stage

	exception_if = false; //true for the according stage exception
	exception_ex = false;
	exception_mem = false;
	if_state = NORMAL;  //record the state of instruction in exception, normal or delayslot or delaying
	ex_state = NORMAL;
	mem_state = NORMAL;
	
	instr_count = 0; //instruction counts
	cycle_count = 0; //instruction cycles
	stall_count = 0;  // stall counts in all
	nraw = 0; // record the number of the raw 
	          //the only dependency need to be handled for mips
	sucDocode = false;
	ncount = 0;

//	pplstat->trace_start = false;
}

void
CLKCPU::clkattach(CPOne * cp1,  PPLSTAT *ps)
{
        if (cp1) 
       {
//        	cpone = cp1;
        	clkcpone = (CLKCPONE*) cp1;
        }
        if (ps)
        	pplstat = ps;
}

/* used to judge the register for temporaries
bool tempreg(uint16 temp)
{
	return(((temp >= 8) &&(temp <= 15)) || (temp == 24) || (temp == 25));	
}
*/
void
CLKCPU::exception(uint16 excCode, int mode, int coprocno)
{
/*	static uint32 last_epc = 0;
	static int last_prio = 0;
	int prio;
	uint32 base, vector, epc;
	bool delaying = (delay_state == DELAYSLOT);
*/
	if (machine->emustate)//only mark the exception in clock level simulation
	{

		LLbit = false;
		c_excCode = excCode; // arguments for passing
		c_mode = mode;
		c_coprocno = coprocno;
		curexcpending = exception_pending;
		exception_pending = true;
	}
	else
		CPU::exception(excCode, mode,coprocno); //exception handler in performance level simulation
}

void 
CLKCPU::clkexcphandle(uint16 excCode, int mode, int coprocno) // exception handler in clock level simulation
{
	static uint32 last_epc = 0;
	static int last_prio = 0;
	int prio;
	uint32 base, vector, epc;
	bool delaying = (delay_state == DELAYSLOT);

	if (opt_haltbreak) {
		if (excCode == Bp) {
			fprintf(stderr,"* BREAK instruction reached -- HALTING *\n");
			machine->halt();
		}
	}
	if (opt_haltibe) {
		if (excCode == IBE) {
			fprintf(stderr,"* Instruction bus error occurred -- HALTING *\n");
			machine->halt();
		}
	}

	/* step() ensures that next_epc will always contain the correct
	 * EPC whenever exception() is called.
	*/ 
	epc = next_epc;

	/* Prioritize exception -- if the last exception to occur _also_ was
	 * caused by this EPC, only report this exception if it has a higher
	 * priority.  Otherwise, exception handling terminates here,
	 * because only one exception will be reported per instruction
	 * (as per MIPS RISC Architecture, p. 6-35). Note that this only
	 * applies IFF the previous exception was caught during the current
	 * _execution_ of the instruction at this EPC, so we check that
	 * EXCEPTION_PENDING is true before aborting exception handling.
	 * (This flag is reset by each call to step().)
	*/ 
	prio = exception_priority(excCode, mode);
	if (epc == last_epc) {
		if (prio <= last_prio && exception_pending) {
			if (opt_excpriomsg) {
				fprintf(stderr,
					"(Ignoring additional lower priority exception...)\n");
			}
			return;
		} else {
			last_prio = prio;
		}
	}
	last_epc = epc;	
	/* Set processor to Kernel mode, disable interrupts, and save 
	 * exception PC.
	 */
	cpzero->enter_exception(epc,excCode,coprocno,delaying);

	/* Calculate the exception handler address; this is of the form BASE +
	 * VECTOR. The BASE is determined by whether we're using boot-time
	 * exception vectors, according to the BEV bit in the CP0 Status register.
	*/ 
	if (cpzero->use_boot_excp_address()) {
		base = 0xbfc00100;
	} else {
		base = 0x80000000;
	}

	/* Do we have a User TLB Miss exception? If so, jump to the
	 * User TLB Miss exception vector, otherwise jump to the
	 * common exception vector.
	 */
	if ((excCode == TLBL || excCode == TLBS) && ((cpzero->tlb) -> tlb_user_miss)) {
		vector = 0x000;
	} else {
		vector = 0x080;
	}

	if (opt_excmsg) {
		fprintf(stderr,"Exception %d (%s) triggered, EPC=%08x\n", excCode, 
			strexccode(excCode), epc);
		fprintf(stderr,
			" Priority is %d; delay state is %s; mem access mode is %s\n",
			prio, strdelaystate(delay_state), strmemmode(mode));
	}
	pc = base + vector;
}

/* emulation of instructions */
void
CLKCPU::cpzero_clkemulate(uint32 pc)
{
	cpzero->cpzero_clkemulate(pc);//need to be changed
}

/* Called when the program wants to use coprocessor COPROCNO, and there
 * isn't any implementation for that coprocessor.
 * Results in a Coprocessor Unusable exception, along with an error
 * message being printed if the coprocessor is marked usable in the
 * CP0 Status register.
 */

/*
void
CLKCPU::cop_unimpl (int coprocno, struct sID_EX id_ex, uint32 pc)
{
	if (cpzero->cop_usable (coprocno)) {
		* Since they were expecting this to work, the least we
		 * can do is print an error message. 
		fprintf (stderr, "CP%d instruction %x not implemented at pc=0x%x:\n",
				 coprocno, id_ex.instr, pc);
		call_disassembler (pc, id_ex.instr);
		exception (CpU, ANY, coprocno);//need to assure to use the CLkCPU::exception to record pc in if_id
	} else {
*/
		/* It's fair game to just throw an exception, if they
		 * haven't even bothered to twiddle the status bits first. 
		exception (CpU, ANY, coprocno);
	}
}
*/

void
CLKCPU::cpone_clkemulate(uint32 pc)
{
	/* If it's a cfc1 <reg>, $0 then we copy 0 into reg,
	 * which is supposed to mean there is NO cp1... 
	 * for now, though, ANYTHING else asked of cp1 results
	 * in the default "unimplemented" behavior. */
	if (cpzero->cop_usable (1) && id_ex.rs == 2 && id_ex.rd == 0) {
		 //reg[rt (instr)] = 0; /* No cp1. */
		 ex_mem.ALUoutput =0;//belong to writeback stage?      --TO BE ADDED
		 reg[mem_wb.rt] = ex_mem.ALUoutput;
	} else {
		 clkcpone->cpone_clkemulate(id_ex.instr,pc);
		// cop_unimpl (1, id_ex.instr, pc);
	}
}

void
CLKCPU::cptwo_clkemulate(uint32 pc)
{
	cop_unimpl (2, id_ex.instr, pc);
}

void
CLKCPU::cpthree_clkemulate(uint32 pc)
{
	cop_unimpl (3, id_ex.instr, pc);
}

/* Return the address to jump to as a result of the J-format
 * (jump) instruction INSTR at address PC.
 * (PC is the address of the jump instruction, and INSTR is
 * the jump instruction word.)
 */
 
uint32
CLKCPU::calc_jump_target(uint32 pc)
{
	/* Must use address of delay slot (pc + 4) to calculate. */
	return ((pc) & 0xf0000000) | (id_ex.targ << 2);
}

void
CLKCPU::j_clkemulate(uint32 pc)
{
	delay_state = DELAYING;
	delay_pc = calc_jump_target(pc);//need to be remember?
}

void
CLKCPU::jal_clkemulate(uint32 pc)
{
	delay_state = DELAYING;
	delay_pc = calc_jump_target(pc); 
	/* RA gets addr of instr after delay slot (2 words after this one). */
	reg[REG_RA] = pc + 4;
}

/* Take the PC-relative branch for which the offset is specified by
 * the immediate field of the branch instruction word INSTR, with
 * the program counter equal to PC.
 */

void
CLKCPU::branch(uint32 pc)//now use id_ex.imm, only to avoid changing
{
	delay_state = DELAYING;
	delay_pc = (pc) + (id_ex.s_imm << 2);
}

void
CLKCPU::beq_clkemulate(uint32 pc)
{
	if (id_ex.a == id_ex.b){
		branch(pc);
	}
}

void
CLKCPU::bne_clkemulate(uint32 pc)
{
	if (id_ex.a != id_ex.b){
		branch(pc);
	}
}

void
CLKCPU::blez_clkemulate(uint32 pc)
{
	if(id_ex.b !=0){
		exception(RI);
		return;
	}
	if (id_ex.a == 0 || (id_ex.a & 0x80000000)) {
		branch(pc);
	}
}

void
CLKCPU::bgtz_clkemulate(uint32 pc)
{

	if(id_ex.b !=0){
		exception(RI);
		return;
	}
	if (id_ex.a != 0 && (id_ex.a & 0x80000000)== 0) {
		branch(pc);
	}
}

void
CLKCPU::addi_clkemulate(uint32 pc)
{
	int32 a, b, sum;

	a = (int32)id_ex.a;
	b = id_ex.s_imm;
	sum = a + b;
	if ((a < 0 && b < 0 && !(sum < 0)) || (a >= 0 && b >= 0 && !(sum >= 0))) {
		exception(Ov);
		return;
	} else {
		ex_mem.ALUoutput = (uint32)sum;
	}
}

void
CLKCPU::addiu_clkemulate(uint32 pc)
{
	int32 a, b, sum;

	a = (int32)id_ex.a;
	b = id_ex.s_imm;
	sum = a + b;
	ex_mem.ALUoutput = (uint32)sum;
}

void
CLKCPU::slti_clkemulate(uint32 pc)
{
	int32 s_rs = id_ex.a;
	
	if (s_rs < id_ex.s_imm) {
		ex_mem.ALUoutput = 1;
	} else {
		ex_mem.ALUoutput = 0;
	}
}

void
CLKCPU::sltiu_clkemulate(uint32 pc)
{
	if (id_ex.a <(uint) id_ex.s_imm) {
		ex_mem.ALUoutput = 1;
	} else {
		ex_mem.ALUoutput = 0;
	}
}

void
CLKCPU::andi_clkemulate(uint32 pc)
{
	ex_mem.ALUoutput = (id_ex.a& 0x0ffff) & id_ex.imm;
}

void
CLKCPU::ori_clkemulate(uint32 pc)
{
	ex_mem.ALUoutput = id_ex.a | id_ex.imm;
}

void
CLKCPU::xori_clkemulate(uint32 pc)
{
	ex_mem.ALUoutput = id_ex.a  ^ id_ex.imm;
}

void
CLKCPU::lui_clkemulate(uint32 pc)
{
	ex_mem.ALUoutput = id_ex.imm << 16;
}

void
CLKCPU::lb_clkemulate(uint32 pc)
{
	uint32 virt, base;
	int32 offset;	 
	
	/* Calculate virtual address. */
	base = id_ex.a;
	offset = id_ex.s_imm;
	virt = base + offset;
	ex_mem.ALUoutput = virt;
}

void
CLKCPU::lh_clkemulate(uint32 pc)
{
	uint32 virt, base;
	int32 offset;
	
	/* Calculate virtual address. */
	base = id_ex.a;
	offset = id_ex.s_imm;
	virt = base + offset;
	ex_mem.ALUoutput = virt;

}

/* The lwr and lwl algorithms here are taken from SPIM 6.0,
 * since I didn't manage to come up with a better way to write them.
 * Improvements are welcome.
 */
 
//uint32 clklwr(uint32 regval, uint32 memval, uint8 offset)//directly copied from cpu.cc
//uint32 clklwl(uint32 regval, uint32 memval, uint8 offset)

void
CLKCPU::lwl_clkemulate(uint32 pc)
{
	uint32 virt, base; 
	int32 offset;

	/* Calculate virtual address. */
	base = id_ex.a;
	offset = id_ex.s_imm;
	virt = base + offset;
	ex_mem.ALUoutput = virt;
}

void
CLKCPU::lw_clkemulate(uint32 pc)
{
	uint32 virt, base;
	int32 offset;	
	
	/* Calculate virtual address. */
	base = id_ex.a;
	offset = id_ex.s_imm;
	virt = base + offset;
	ex_mem.ALUoutput = virt;
}

void
CLKCPU::lbu_clkemulate(uint32 pc)
{
	uint32  virt, base; 
	int32 offset;

	/* Calculate virtual address. */
	base = id_ex.a;
	offset = id_ex.s_imm;
	virt = base + offset;
	ex_mem.ALUoutput = virt;
}

void
CLKCPU::lhu_clkemulate(uint32 pc)
{
	uint32  virt, base; 
	int32 offset;

	/* Calculate virtual address. */
	base = id_ex.a;
	offset = id_ex.s_imm;
	virt = base + offset;
	ex_mem.ALUoutput = virt;
}

void
CLKCPU::lwr_clkemulate(uint32 pc)
{
	uint32 virt, base; 
	int32 offset;

	/* Calculate virtual address. */
	base = id_ex.a;
	offset = id_ex.s_imm;
	virt = base + offset;
	ex_mem.ALUoutput = virt;
}

void
CLKCPU::sb_clkemulate(uint32 pc)
{
	uint32 virt, base;
	int32 offset;

	/* Calculate virtual address. */
	base = id_ex.a;
	offset = id_ex.s_imm;
	virt = base + offset;
	ex_mem.ALUoutput = virt;
}

void
CLKCPU::sh_clkemulate(uint32 pc)
{
	uint32 virt, base;
	int32 offset;

	/* Calculate virtual address. */
	base = id_ex.a;
	offset = id_ex.s_imm;
	virt = base + offset;
	ex_mem.ALUoutput = virt;
}


//uint32 clkswl(uint32 regval, uint32 memval, uint8 offset)//copied directly from cpu.cc by zhangwl
//uint32 clkswr(uint32 regval, uint32 memval, uint8 offset)

void
CLKCPU::swl_clkemulate(uint32 pc)
{
	uint32 virt, base;
	int32 offset;

	/* Calculate virtual address. */
	base = id_ex.a;
	offset = id_ex.s_imm;
	virt = base + offset;
	ex_mem.ALUoutput = virt;
}

void
CLKCPU::sw_clkemulate(uint32 pc)
{
	uint32 virt, base;
	int32 offset;

	/* Calculate virtual address. */
	base = id_ex.a;
	offset = id_ex.s_imm;
	virt = base + offset;
	ex_mem.ALUoutput = virt;
}

void
CLKCPU::swr_clkemulate(uint32 pc)
{
	uint32 virt, base;
	int32 offset;

	/* Calculate virtual address. */
	base = id_ex.a;
	offset = id_ex.s_imm;
	virt = base + offset;
	ex_mem.ALUoutput = virt;
}

void 
CLKCPU::cache_clkemulate(uint32 pc)
{
	 uint32 virt, base, offset;
     int32  mode;
	 uint32 cacheop, select;
	 /*
	  *  change to support more cache ops : cmy 
	  * 
     mode = (instr >> 16) & 1;   // fetch the 16th bit of the instr
     int flush_tag = (instr >> 18) & 7;   // fetct the 20th~18th bit of the instr
     if ((flush_tag == 0 || flush_tag == 5 || flush_tag == 6) && opt_cacheable)
     addr->cache->flush(mode);
     else
     exception(RI);
	 */
	 	
	 select  = ((id_ex.instr) >> 16) & 3; // select I/D/T/S cache
	 mode = select & 1; // mode 2/3 are optional
	 cacheop = ((id_ex.instr) >> 18) & 3;
	 switch(cacheop) {
		case 0: // Index Invalidate
		case 1: // Load Tag to TagLo adn TagHi
		case 2: // Store Tag 
		case 3: // Not specified 
		case 4: // Hit Invalid
		case 7: // Fetch and Lock
			fprintf (stderr, "cpu instruction %x not implemented at pc=0x%x:\n",
				  id_ex.instr, pc);
			exception(RI);
			break;
		case 5: // Fill I cache; Hit WB&Invalidate Dcache
		case 6: // Hit WB for D Cache
			if(!opt_cacheable)  return;
			base = id_ex.a;//reg[rs(instr)];
			offset = id_ex.s_imm;//s_immed(instr);
			virt = base + offset;//????

			// should be flush(cacheop,select,addr) later !!
			addr->cache->flush(mode,1);
			break;
	 }
}

void
CLKCPU::ll_clkemulate(uint32 pc)
{
	uint32 virt, base;
	int32 offset;	
	
	/* Calculate virtual address. */
	base = id_ex.a;
	offset = id_ex.s_imm;
	virt = base + offset;
	ex_mem.ALUoutput = virt;
}

void
CLKCPU::lwc1_clkemulate(uint32 pc)
{
//	cop_unimpl (1, id_ex.instr, pc);
	 uint32 virt, base;//, word
        int32 offset;

        /* Calculate virtual address. */
        base = id_ex.a; // rs(instr)
        offset = id_ex.s_imm;//ed(instr)
        virt = base + offset;
	 ex_mem.ALUoutput = virt;
}

void
CLKCPU::lwc2_clkemulate(uint32 pc)
{
	cop_unimpl (2, id_ex.instr, pc);
}

void
CLKCPU::lwc3_clkemulate(uint32 pc)
{
	cop_unimpl (3, id_ex.instr, pc);
}

void
CLKCPU::sc_clkemulate(uint32 pc)
{
	uint32 virt, base;
	int32 offset;

	/* Calculate virtual address. */
	base = id_ex.a;
	offset = id_ex.s_imm;
	virt = base + offset;
	ex_mem.ALUoutput = virt;
}

void
CLKCPU::swc1_clkemulate(uint32 pc)
{
//	 cop_unimpl (1, id_ex.instr, pc);
        uint32 virt, base;//, data
        int32 offset;

        /* Calculate virtual address. */
        base = id_ex.a;//rs(instr)
        offset = id_ex.s_imm;//ed(instr)
        virt = base + offset;
	ex_mem.ALUoutput = virt;
}

void
CLKCPU::swc2_clkemulate(uint32 pc)
{
	cop_unimpl (2, id_ex.instr, pc);
}

void
CLKCPU::swc3_clkemulate(uint32 pc)
{
	cop_unimpl (3, id_ex.instr, pc);
}

//instructions of op=0x0, distingushed by funct
void
CLKCPU::sll_clkemulate(uint32 pc)
{
	ex_mem.ALUoutput = id_ex.b << id_ex.shamt;
}

int32
clksrl(int32 a, int32 b)//directly move here from cpu.cc by zhangwl
{
	if (b == 0) {
		return a;
	} else if (b == 32) {
		return 0;
	} else {
	return (a >> b) & ((1 << (32 - b)) - 1);
	}
}

int32
clksra(int32 a, int32 b)
{
	if (b == 0) {
		return a;
	} else {
	return (a >> b) | (((a >> 31) & 0x01) * (((1 << b) - 1) << (32 - b)));
	}
}

void
CLKCPU::srl_clkemulate(uint32 pc)
{
	ex_mem.ALUoutput = clksrl(id_ex.b, id_ex.shamt);
}

void
CLKCPU::sra_clkemulate(uint32 pc)
{
	ex_mem.ALUoutput = clksra(id_ex.b, id_ex.shamt);
}

void
CLKCPU::sllv_clkemulate(uint32 pc)
{
	ex_mem.ALUoutput = id_ex.b << (id_ex.a & 0x01f);
}

void
CLKCPU::srlv_clkemulate(uint32 pc)
{
	ex_mem.ALUoutput = clksrl(id_ex.b, id_ex.a & 0x01f);
}

void
CLKCPU::srav_clkemulate(uint32 pc)
{
	ex_mem.ALUoutput = clksra(id_ex.b, id_ex.a  & 0x01f);
}

void
CLKCPU::jr_clkemulate(uint32 pc)
{
	if (opt_haltjrra) {
		if (id_ex.rs == REG_RA) {
			fprintf(stderr,
				"** Procedure call return instr reached -- HALTING **\n");
			machine->halt();
		}
	}
	if (id_ex.b != 0) {
		exception(RI);
		return;
	}
	delay_state = DELAYING;
	delay_pc = id_ex.a;
}

void
CLKCPU::jalr_clkemulate(uint32 pc)
{
	delay_state = DELAYING;
	delay_pc = id_ex.a;

	/* RA gets addr of instr after delay slot (2 words after this one). */
//	reg[id_ex.rd] = pc + 4;
	ex_mem.ALUoutput = pc + 4;//belong to which stage????  question zhangwl 
	//should complete in this stage? 
}

void
CLKCPU::syscall_clkemulate(uint32 pc)
{
	exception(Sys);
}

void
CLKCPU::break_clkemulate(uint32 pc)
{
	exception(Bp);
}

void
CLKCPU::mfhi_clkemulate(uint32 pc)
{
	ex_mem.ALUoutput = hi; //question zhangwl  reg[id_ex.rd]  
}

void
CLKCPU::mthi_clkemulate(uint32 pc)
{
	if (id_ex.rd != 0) {
		exception(RI);
		return;
	}
	hi = id_ex.a;
}

void
CLKCPU::mflo_clkemulate(uint32 pc)
{
	ex_mem.ALUoutput = lo;//reg[id_ex.rd]
}

void
CLKCPU::mtlo_clkemulate(uint32 pc)
{
	if (id_ex.rd != 0) {
		exception(RI);
		return;
	}
	lo = id_ex.a;
}

void
CLKCPU::mult_clkemulate(uint32 pc)
{
	if (id_ex.rd != 0) {
		exception(RI);
		return;
	}
	mult64s(&hi, &lo, id_ex.a, id_ex.b);
}

//void CLKCPU::mult64(uint32 *hi, uint32 *lo, uint32 n, uint32 m)
//void CLKCPU::mult64s(uint32 *hi, uint32 *lo, int32 n, int32 m)

void
CLKCPU::multu_clkemulate(uint32 pc)
{

	if (id_ex.rd != 0) {
		exception(RI);
		return;
	}
	mult64(&hi, &lo, id_ex.a, id_ex.b);
}

void
CLKCPU::div_clkemulate(uint32 pc)
{
	int32 signed_rs = (int32)id_ex.a;
	int32 signed_rt = (int32)id_ex.b;
	if (signed_rt == 0)
	{
		exception(DZ);
		return;
	}
	lo = signed_rs / signed_rt;
	hi = signed_rs % signed_rt;
}

void
CLKCPU::divu_clkemulate(uint32 pc)
{

	if (id_ex.b == 0)
	{
		exception(DZ);
		return;
	}
	lo = id_ex.a / id_ex.b;
	hi = id_ex.a % id_ex.b;
}

void
CLKCPU::add_clkemulate(uint32 pc)
{
	int32 a, b, sum;

	a = (int32)id_ex.a;
	b = (int32)id_ex.b;
	sum = a + b;
	if ((a < 0 && b < 0 && !(sum < 0)) || (a >= 0 && b >= 0 && !(sum >= 0))) {
		exception(Ov);
		return;
	} else {
		ex_mem.ALUoutput = (uint32)sum;
	}
}

void
CLKCPU::addu_clkemulate(uint32 pc)
{
	int32 a, b, sum;

	a = (int32)id_ex.a;
	b = (int32)id_ex.b;
	sum = a + b;
	ex_mem.ALUoutput = (uint32)sum;
}

void
CLKCPU::sub_clkemulate(uint32 pc)
{
	int32 a, b, diff;

	a = (int32)id_ex.a;
	b = (int32)id_ex.b;
	diff = a - b;
	if ((a < 0 && !(b < 0) && !(diff < 0)) || (!(a < 0) && b < 0 && diff < 0)) {
		exception(Ov);
		return;
	} else {
		ex_mem.ALUoutput = (uint32)diff;
	}
}

void
CLKCPU::subu_clkemulate(uint32 pc)
{
	int32 a, b, diff;

	a = (int32)id_ex.a;
	b = (int32)id_ex.b;
	diff = a - b;
	ex_mem.ALUoutput = (uint32)diff;
}

void
CLKCPU::and_clkemulate(uint32 pc)
{
	ex_mem.ALUoutput = id_ex.a & id_ex.b;
}

void
CLKCPU::or_clkemulate(uint32 pc)
{
	ex_mem.ALUoutput = id_ex.a | id_ex.b;
}

void
CLKCPU::xor_clkemulate(uint32 pc)
{
	ex_mem.ALUoutput = id_ex.a ^ id_ex.b;
}

void
CLKCPU::nor_clkemulate(uint32 pc)
{
	ex_mem.ALUoutput = ~(id_ex.a | id_ex.b);
}

void
CLKCPU::slt_clkemulate(uint32 pc)
{
	int32 s_rs = (int32)id_ex.a;
	int32 s_rt = (int32)id_ex.b;
	if (s_rs < s_rt) {
		ex_mem.ALUoutput = 1;
	} else {
		ex_mem.ALUoutput = 0;
	}
}

void
CLKCPU::sltu_clkemulate(uint32 pc)
{
	if (id_ex.a < id_ex.b) {
		ex_mem.ALUoutput = 1;
	} else {
		ex_mem.ALUoutput = 0;
	}
}

void
CLKCPU::bltz_clkemulate(uint32 pc)
{
	if ((int32)id_ex.a < 0) {
		branch(pc);
	}
}

void
CLKCPU::bgez_clkemulate(uint32 pc)
{
	if ((int32)id_ex.a >= 0) {
		branch(pc);
	}
}

/* As with JAL, BLTZAL and BGEZAL cause RA to get the address of the
 * instruction two words after the current one (pc + 8).
 */
void
CLKCPU::bltzal_clkemulate(uint32 pc)
{
	reg[REG_RA] = pc + 4;
	if ((int32)id_ex.a < 0) {
		branch(pc);
	}
}

void
CLKCPU::bgezal_clkemulate(uint32 pc)
{
	reg[REG_RA] = pc + 4;
	if ((int32)id_ex.a >= 0) {
		branch(pc);
	}
}

/* reserved instruction */
void
CLKCPU::RI_clkemulate(uint32 pc)
{
	exception(RI);
}

/* Added by zwl on Sep 27th, 2003, five stages pipeline emulation on clock level  [[[[*/
/*--------------------------------------------------------------------*/

void 
CLKCPU::ifetch()
{
	/* Clear exception_pending flag if it was set by a
	 * prior instruction. */
	exception_pending = false;

	/* decrement Random register */
// commented by cmy
#ifndef LAZY_RANDOM
	cpzero->adjust_random();
#endif
	/* save address of instruction responsible for exceptions which may occur */
	if_epc = pc;

	if (if_state == DELAYSLOT)
		if_state = NORMAL;
	
	/* get  next instruction */
	addr ->fetch_instr(pc, &instr, &if_delay_time);

	if(pc == (unsigned int)DBGTracer::trcVar[1])  DBGTracer::pause();
	DBGTracer::pctrace.record(pc,instr);

	/* get physical address of next instruction 
	real_pc = cpzero->address_trans(pc,INSTFETCH,&cacheable, this);
	if (real_pc == 0xffffffff && exception_pending) {
		if (opt_excmsg) {
			fprintf(stderr,
				"** PC address translation caused the exception! **\n");
		}
		return;
	}*/
	//pplstat add for pipeline trace
	
	if (if_delay_time != 0)
	{
		_if_stock = true;
//		pplstat->SetInstr(0xffffffff); //if delay, record it like exception, but don't change the current pc
	}
	else{
//		pplstat->SetStage(IFMask);
//		pplstat->SetInstr(instr);
	}
	
	/* get next instruction */
//	instr = mem->fetch_word(real_pc,INSTFETCH,cacheable, this);
	/*check exception and do some preparation*/
	if (instr == 0xffffffff && exception_pending) {
		if (opt_excmsg) {
			fprintf(stderr, "** Instruction fetch caused the exception! **\n");
		}
		exception_if = true;

		return;
	}

	//add the instr to the inst queue, if it has blank space
	
	/* diagnostic output - display disassembly of instr */
	if (opt_instdump) {
		fprintf(stderr,"PC=0x%08x \t%08x ",pc,instr);
		call_disassembler(pc,instr);
	}

/*
	if (opt_instdump&& (pc < (unsigned int)0x80000000)) {
		static int inst_count = 0;
		static int aa=0;
		if(pc ==0x499e0c)
			inst_count ++;
	//		if(inst_count < 300000 ) {		}
	//		else exit(-1);
		if (aa==300000) exit(-1);	
		if(inst_count == 7 )
		{
			aa++;
			fprintf(stderr,"PC=0x%08x \t%08x ",pc,instr);//real_pc,
			call_disassembler(pc,instr);
		}
	}
*/
//	bool intsOnBefore = cpzero->interrupts_enabled();
	/* Jump to the appropriate emulation function. */
//	(this->*opcodeJumpTable[opcode(instr)])(instr, pc);
//	bool intsOnAfter = cpzero->interrupts_enabled(); 

	/* Register zero must always be zero; this instruction forces this. */
	reg[REG_ZERO] = 0;

	/* increment PC */
	pc = pc + 4;      

	instr_count ++; // record the instruction count

	if_id.pc=pc;
	if_id.instr=instr;// the head element of the inst queue, if it is not null
}


void 
CLKCPU::idecode()	
{
	if (pl_state) // the first time to decode
	{
		id_ex.pc=if_id.pc;
		id_ex.instr=if_id.instr;
		id_ex.op=opcode(if_id.instr);		
		switch(id_ex.op){
			case 0x00://funct R-Type
				id_ex.rs =rs(if_id.instr);
				id_ex.rt = rt(if_id.instr);
				id_ex.funct = funct(if_id.instr);
				//jr, jalr, mfhi, mthi, mflo, mtlo
				if (id_ex.funct == 0x08){
					id_ex.rd = rd(if_id.instr);
					if ((regflag[id_ex.rs] == 0) )
					{			
						id_ex.a = reg[id_ex.rs];
						flaga =true;
					}
					if ((regflag[id_ex.rd] == 0)  )// temply use
					{			
						id_ex.b = reg[id_ex.rd];
						flagb =true;
					}
					if(flaga && flagb)
					{
						flaga = false;
						flagb = false;
						pl_state = true;	
					}else{
						pl_state = false;//stall
						nraw ++;
					}
				}
				else if ((id_ex.funct == 0x09) ||(id_ex.funct == 0x11) || (id_ex.funct == 0x13))
				{
					id_ex.rd = rd(if_id.instr);
					if ((regflag[id_ex.rs] == 0) ) 
					{
						id_ex.a = reg[id_ex.rs];
						if (id_ex.funct == 0x09)
							regflag[id_ex.rd] ++;
						pl_state = true;					
					}
					else{ 
						pl_state = false;//stall	
						nraw ++;
					}
				}
				else if ((id_ex.funct == 0x10) ||(id_ex.funct == 0x12) )
				{
					id_ex.rd = rd(if_id.instr);
					regflag[id_ex.rd] ++;
					pl_state = true;					
				}else if ((id_ex.funct >= 0x18) && (id_ex.funct <= 0x1b))
				{	
					id_ex.rd = rd(if_id.instr);
					if ((regflag[id_ex.rs] == 0) )
					{			
						id_ex.a = reg[id_ex.rs];
						flaga =true;
					}
					if ((regflag[id_ex.rt] == 0)  )
					{			
						id_ex.b = reg[id_ex.rt];
						flagb =true;
					}
					if(flaga && flagb)
					{
						flaga = false;
						flagb = false;
						pl_state = true;	
					}
					else{ 
						pl_state = false;//stall
						nraw ++;
					}
				}					
				else{	
					id_ex.rd = rd(if_id.instr);
					if ((regflag[id_ex.rs] == 0) )
					{			
						id_ex.a = reg[id_ex.rs];
						flaga =true;
					}
					if ((regflag[id_ex.rt] == 0)  )
					{			
						id_ex.b = reg[id_ex.rt];
						flagb =true;
					}
					if(flaga && flagb)
					{
						flaga = false;
						flagb = false;
						regflag[id_ex.rd] ++;
						pl_state = true;	
					}
					else{ 
						pl_state = false;//stall
						nraw ++;
					}
					//or revise at the ex stage 
					
				}
				id_ex.shamt = shamt(if_id.instr);
				break;
			case 0x01://imm I-Type
					id_ex.rs =rs(if_id.instr);
					id_ex.rt =rt(if_id.instr);	
					if ((regflag[id_ex.rs] == 0) )
					{
						id_ex.a= reg[id_ex.rs];
						pl_state = true;					
					}
					else{
						pl_state = false;//stall
						nraw ++;
					}
					id_ex.s_imm= s_immed(if_id.instr);
				break;				
			case 0x02://jump J-Type
			case 0x03:
				id_ex.targ=jumptarg(if_id.instr);		
				pl_state = true;			
				break;
			case 0x04://branch instruction
			case 0x05:
			case 0x06:
			case 0x07:	
					id_ex.rs =rs(if_id.instr);
					id_ex.rt =rt(if_id.instr);	
					if ((regflag[id_ex.rs] == 0))
					{		
						id_ex.a = reg[id_ex.rs];
						flaga =true;
					}
					if ((regflag[id_ex.rt] == 0) )
					{			
						id_ex.b = reg[id_ex.rt];
						flagb =true;
					}
					if(flaga && flagb)
					{
						flaga = false;
						flagb = false;
						pl_state = true;
					}
					else{ 
						pl_state = false;//stall
						nraw ++;
					}
					id_ex.s_imm= s_immed(if_id.instr);
				break;
			case 0x10://cp0  R-Type + I-Type    //to be amended
				id_ex.rs = rs(if_id.instr);
				id_ex.rt = rt(if_id.instr);
				if (id_ex.rs == 0x08) //I-Type
				{
					pl_state = true;
					id_ex.s_imm= s_immed(if_id.instr);
				}
				//R-Type
				else if (id_ex.rs == 0x04)//mtc0
				{
					if ((regflag[id_ex.rt] == 0) )
					{
						id_ex.b = reg[id_ex.rt];
						pl_state = true;
					}				
					else{ 
						pl_state = false;//stall
						nraw ++;
					}
					id_ex.rd = rd(if_id.instr);
				}else if (id_ex.rs == 0x00)//mfc0
				{
					regflag[id_ex.rt] ++;
					id_ex.rd = rd(if_id.instr);
					pl_state = true;	
				}else if (id_ex.rs == 0x10)
				{
					id_ex.funct = funct(if_id.instr);
					pl_state = true;	
				}
				break;
			case 0x11:
					sucDocode = false;
					clkcpone->fpdecode(id_ex.instr, id_ex.pc);
				break;
			case 0x12:
			case 0x13://cpz, to be added
				break;
			case 0x31://lwc1
				id_ex.rs =rs(if_id.instr);
				id_ex.rt = rt(if_id.instr);
				id_ex.s_imm= s_immed(if_id.instr);
				sucDocode = false;
				if ((regflag[id_ex.rs] == 0) )
					{
						id_ex.a= reg[id_ex.rs];
						pl_state = true;
						(clkcpone->fregflag[(id_ex.rt)>>1]) ++;
						sucDocode = true;
					}					
					else{ 
						pl_state = false;//stall
						nraw ++;
					}
				break;		
			case 0x39://swc1
				id_ex.rs =rs(if_id.instr);
				id_ex.rt = rt(if_id.instr);
				id_ex.s_imm= s_immed(if_id.instr);
				if ((regflag[id_ex.rs] == 0) )
				{			
					id_ex.a = reg[id_ex.rs];
					flaga =true;
				}
				if ((clkcpone->fregflag[(id_ex.rt)>>1] == 0)  )
				{			
					id_ex.b = clkcpone->freg[(id_ex.rt)>>1].ir[(id_ex.rt)&1];
					flagb =true;
				}
				if(flaga && flagb)
				{
					flaga = false;
					flagb = false;
					pl_state = true;	
				}
				else{ 
					pl_state = false;//stall
					nraw ++;
				}
				break;				

			default: /*other, I-Type*/
				id_ex.rs =rs(if_id.instr);
				id_ex.rt = rt(if_id.instr);
				id_ex.s_imm= s_immed(if_id.instr);
				id_ex.imm= immed(if_id.instr);
				if (((id_ex.op >= 0x28) && (id_ex.op <= 0x2e)) || (id_ex.op == 0x22) || (id_ex.op == 0x26) || (id_ex.op == 0x38))//store instructions
				{
					if ((regflag[id_ex.rs] == 0) )
					{			
						id_ex.a = reg[id_ex.rs];
						flaga =true;
					}
					if ((regflag[id_ex.rt] == 0)  )
					{			
						id_ex.b = reg[id_ex.rt];
						flagb =true;
					}
					if(flaga && flagb)
					{
						flaga = false;
						flagb = false;
						if  ((id_ex.op == 0x22) || (id_ex.op == 0x26) || (id_ex.op == 0x38))
							regflag[id_ex.rt] ++;					
						pl_state = true;	
					}
					else{ 
						pl_state = false;//stall
						nraw ++;
					}

				}
				// logic and load instruction
				else if (((id_ex.op >= 0x08) && (id_ex.op <= 0x0f) )  ||
					      (((id_ex.op >= 0x20) && (id_ex.op <= 0x26)) 
						      && !((id_ex.op == 0x22) || (id_ex.op == 0x26)))
						  || (id_ex.op == 0x30))
				{
					if ((regflag[id_ex.rs] == 0) )
					{
						id_ex.a= reg[id_ex.rs];
						pl_state = true;
						regflag[id_ex.rt] ++;
					}					
					else{ 
						pl_state = false;//stall
						nraw ++;
					}
				}
				else	{ //other instruction, to be amended
					pl_state = true;	
				}
				break;
			}
		}
		else if ( !pl_state){  //waiting here when dependence occurs until the needed register readable
			switch(id_ex.op){
				case 0x00://funct R-Type
					//jr, jalr, mfhi, mthi, mflo, mtlo
					if (id_ex.funct == 0x08){
						if ((regflag[id_ex.rs] == 0) && !flaga)
						{			
							id_ex.a = reg[id_ex.rs];
							flaga =true;
						}
						if ((regflag[id_ex.rd] == 0) && !flagb )
						{			
							id_ex.b = reg[id_ex.rd];
							flagb =true;
						}
						if (flaga && flagb)
						{
							flaga = false;
							flagb = false;
							pl_state = true;	
						}else
							pl_state = false;//stall
					}
					else if ((id_ex.funct == 0x09) ||(id_ex.funct == 0x11) || (id_ex.funct == 0x13))
					{
						if ((regflag[id_ex.rs] == 0) )
						{
							id_ex.a = reg[id_ex.rs];
							if (id_ex.funct == 0x09)
								regflag[id_ex.rd] ++;
							pl_state = true;					
						}
						else 
							pl_state = false;//stall	
					}else if ((id_ex.funct >= 0x18) && (id_ex.funct <= 0x1b))
					{	
						id_ex.rd = rd(if_id.instr);
						if ((regflag[id_ex.rs] == 0) )
						{			
							id_ex.a = reg[id_ex.rs];
							flaga =true;
						}
						if ((regflag[id_ex.rt] == 0)  )
						{			
							id_ex.b = reg[id_ex.rt];
							flagb =true;
						}
						if(flaga && flagb)
						{
							flaga = false;
							flagb = false;
							pl_state = true;	
						}
						else{ 
							pl_state = false;//stall
							nraw ++;
						}
					}							
					else{					
						if (((regflag[id_ex.rs] == 0) ) && !flaga)
						{			
							id_ex.a = reg[id_ex.rs];
							flaga =true;
						}
						if (((regflag[id_ex.rt] == 0)  ) && !flagb)
						{			
							id_ex.b = reg[id_ex.rt];
							flagb =true;
						}
						if(flaga && flagb)
						{
							flaga = false;
							flagb = false;
							regflag[id_ex.rd] ++;
							pl_state = true;					
						}
						else 
							pl_state = false;//stall
					}
					break;
				case 0x01://imm I-Type
					if ((regflag[id_ex.rs] == 0) )
					{
						id_ex.a= reg[id_ex.rs];
						pl_state = true;					
					}
					else
						pl_state = false;//stall
					break;
//				case 0x02://jump J-Type
//				case 0x03:
				case 0x04:
				case 0x05:
				case 0x06:
				case 0x07:					
						if (((regflag[id_ex.rs] == 0) ) && !flaga)
						{			
							id_ex.a = reg[id_ex.rs];
							flaga =true;
						}
						if (((regflag[id_ex.rt] == 0) ) && !flagb)
						{			
							id_ex.b = reg[id_ex.rt];
							flagb =true;
						}
						if(flaga && flagb)
						{
							flaga = false;
							flagb = false;
							pl_state = true;					
						}
						else 
							pl_state = false;//stall								
					break;
				case 0x10://cp0  R-Type + I-Type    //to be amended
					//R-Type
					if (id_ex.rs == 0x04)//mtc0
					{
						if ((regflag[id_ex.rt] == 0) )
						{
							id_ex.b = reg[id_ex.rt];
							pl_state = true;
						}				
						else 
							pl_state = false;//stall
					}
					break;
				case 0x11:
					sucDocode = false;
					clkcpone->fpdecode(id_ex.instr, id_ex.pc);
					break;					
				/*
				case 0x11:
				case 0x12:
				case 0x13://cpz, to be added
					break;
				*/
				case 0x31://lwc1
					sucDocode = false;
					if ((regflag[id_ex.rs] == 0) )
						{
							id_ex.a= reg[id_ex.rs];
							pl_state = true;
							(clkcpone->fregflag[(id_ex.rt)>>1]) ++;
							sucDocode = true;
						}					
						else{ 
							pl_state = false;//stall
							nraw ++;
						}
					break;		
				case 0x39://swc1
					if ((regflag[id_ex.rs] == 0) && (!flaga))
					{			
						id_ex.a = reg[id_ex.rs];
						flaga =true;
					}
					if (((clkcpone->fregflag[(id_ex.rt)>>1]) == 0) && (!flagb) )
					{			
						id_ex.b = clkcpone->freg[(id_ex.rt)>>1].ir[(id_ex.rt)&1]; 
						flagb =true;
					}
					if(flaga && flagb)
					{
						flaga = false;
						flagb = false;
						pl_state = true;	
					}
					else{ 
						pl_state = false;//stall
						nraw ++;
					}
					break;					
				default: /*other, I-Type*/
					if (((id_ex.op >= 0x28) && (id_ex.op <= 0x2e)) || (id_ex.op == 0x22) || (id_ex.op == 0x26) || (id_ex.op == 0x38))//store instructions
					{
						if (((regflag[id_ex.rs] == 0) ) && !flaga)
						{			
							id_ex.a = reg[id_ex.rs];
							flaga =true;
						}
						if (((regflag[id_ex.rt] == 0) ) && !flagb)
						{			
							id_ex.b = reg[id_ex.rt];
							flagb =true;
						}
						if(flaga && flagb)
						{
							flaga = false;
							flagb = false;
						if  ((id_ex.op == 0x22) || (id_ex.op == 0x26) || (id_ex.op == 0x38))
							regflag[id_ex.rt] ++;
							pl_state = true;	
						}
						else 
							pl_state = false;//stall
					}
					else  if (  ((id_ex.op >= 0x08) && (id_ex.op <= 0x0f) )  ||
					      ( ((id_ex.op >= 0x20) && (id_ex.op <= 0x26)) 
						      && !((id_ex.op == 0x22) || (id_ex.op == 0x26)))
						  || (id_ex.op == 0x30))
					{
						if ((regflag[id_ex.rs] == 0) )
						{
							id_ex.a= reg[id_ex.rs];
							pl_state = true;	
							regflag[id_ex.rt] ++;
						}					
						else 
							pl_state = false;//stall
					}
					break;
			}
		}			
}

void 
CLKCPU::execute()
{	 
	static  const clkemulate_funptr clkopcodeJumpTable[] = {
		&CLKCPU::funct_clkemulate, &CLKCPU::regimm_clkemulate,
		&CLKCPU::j_clkemulate,     &CLKCPU::jal_clkemulate,
		&CLKCPU::beq_clkemulate,   &CLKCPU::bne_clkemulate,
		&CLKCPU::blez_clkemulate,  &CLKCPU::bgtz_clkemulate,
		&CLKCPU::addi_clkemulate,  &CLKCPU::addiu_clkemulate,
		&CLKCPU::slti_clkemulate,  &CLKCPU::sltiu_clkemulate,
		&CLKCPU::andi_clkemulate,  &CLKCPU::ori_clkemulate,
		&CLKCPU::xori_clkemulate,  &CLKCPU::lui_clkemulate,
		&CLKCPU::cpzero_clkemulate,&CLKCPU::cpone_clkemulate,
		&CLKCPU::cptwo_clkemulate, &CLKCPU::cpthree_clkemulate,
		&CLKCPU::RI_clkemulate,    &CLKCPU::RI_clkemulate,
		&CLKCPU::RI_clkemulate,    &CLKCPU::RI_clkemulate,
		&CLKCPU::RI_clkemulate,    &CLKCPU::RI_clkemulate,
		&CLKCPU::RI_clkemulate,    &CLKCPU::RI_clkemulate,
		&CLKCPU::RI_clkemulate,    &CLKCPU::RI_clkemulate,
		&CLKCPU::RI_clkemulate,    &CLKCPU::RI_clkemulate,
		&CLKCPU::lb_clkemulate,    &CLKCPU::lh_clkemulate,
		&CLKCPU::lwl_clkemulate,   &CLKCPU::lw_clkemulate,
		&CLKCPU::lbu_clkemulate,   &CLKCPU::lhu_clkemulate,
		&CLKCPU::lwr_clkemulate,   &CLKCPU::RI_clkemulate,
		&CLKCPU::sb_clkemulate,    &CLKCPU::sh_clkemulate,
		&CLKCPU::swl_clkemulate,   &CLKCPU::sw_clkemulate,
		&CLKCPU::RI_clkemulate,    &CLKCPU::RI_clkemulate,
		&CLKCPU::swr_clkemulate,   &CLKCPU::cache_clkemulate,//RI_clkemulate,
		&CLKCPU::ll_clkemulate,    &CLKCPU::lwc1_clkemulate,//left -load with lock
		&CLKCPU::lwc2_clkemulate,  &CLKCPU::lwc3_clkemulate, 
		&CLKCPU::RI_clkemulate,    &CLKCPU::RI_clkemulate,
		&CLKCPU::RI_clkemulate,    &CLKCPU::RI_clkemulate,
		&CLKCPU::sc_clkemulate,    &CLKCPU::swc1_clkemulate,//left -store with lock
		&CLKCPU::swc2_clkemulate,  &CLKCPU::swc3_clkemulate,
		&CLKCPU::RI_clkemulate,    &CLKCPU::RI_clkemulate,
		&CLKCPU::RI_clkemulate,    &CLKCPU::RI_clkemulate
	};

	exception_pending = false;
	ex_epc = id_ex.pc - 4;    
	
	bool intsOnBefore = cpzero->interrupts_enabled();
	/* Jump to the appropriate emulation function. */
	(this->*clkopcodeJumpTable[id_ex.op])(id_ex.pc);
	bool intsOnAfter = cpzero->interrupts_enabled();
	
	/* Register zero must always be zero; this instruction forces this. */
	reg[REG_ZERO] = 0;
	
	/* Check for a (hardware or software) interrupt (but only if
	 * this instruction did not turn on interrupts.) */
	if (intsOnBefore && intsOnAfter && cpzero->interrupt_pending()) {
		 exception(Int);
	}
	
	/* If there is an exception pending, we return now, so that we don't
	 * clobber the exception vector.
	*/ 
	if (exception_pending) {
		/* Instruction at beginning of exception handler is NOT in
		 * delay slot, no matter what the last instruction was.
		 */
		if (ex_state == DELAYSLOT)
			ex_epc = ex_epc - 4;
		exception_ex = true;
		for (int i=0; i<32; i++)
			regflag[i]= 0;
		ex_mem.tag = false;
		_if_skip = true;
		if_id.stall = true;
		return;
	}

	if (delay_state == DELAYING) {
		/* This instruction caused a branch to be taken.
		 * The next instruction is in the delay slot.
		 * The next instruction EPC will be PC - 4.
		 */ 
		if_epc = if_epc - 4;//exception happened in the delay slot
		if_state = DELAYSLOT;
		ex_state = DELAYSLOT;
		mem_state = DELAYSLOT;
		delay_state = NORMAL;
		pc = delay_pc;
	}  
	ex_mem.pc = id_ex.pc;//needed????
	ex_mem.op = id_ex.op;
	ex_mem.b = id_ex.b;
	ex_mem.rs = id_ex.rs;
	ex_mem.rt = id_ex.rt;
	ex_mem.rd = id_ex.rd;	
	ex_mem.funct = id_ex.funct;
	ex_mem.fmt = id_ex.fmt;
	
}

void
CLKCPU::memaccess()
{
//	uint8 delay_time;// should be placed in the ex_mem latch
	uint8 byte;
	uint16 halfword;
	uint32 cbyte,chalfword,memword,word;
	
	//load or store data
	exception_pending = false;
	mem_epc = ex_mem.pc - 4;
	mem_wb.pc = ex_mem.pc;
	
	switch(ex_mem.op)
	{
		//load instruction [0x20 .. 0x26]
		case 0x20://lb
			addr ->fetch_byte(ex_mem.ALUoutput, &byte, &delay_time);//belong to accessmem and writeback stage
			if ((byte & 0xff == 0xff) && exception_pending) 	
			{
				exception_mem = true;
				return;
			}
			/* Load target register with data. */
			mem_wb.lmd = (int8)byte;			
			break;
		case 0x21://lh
			addr ->fetch_half_word(ex_mem.ALUoutput, &halfword, &delay_time);
			if ((halfword & 0xffff == 0xffff) && exception_pending) 
			{
				exception_mem = true;
				return;
			}
			
			/* Load target register with data. */
			mem_wb.lmd = (int16)halfword;
			break;
		case 0x22://lwl
			addr ->fetch_wordl(ex_mem.ALUoutput, ex_mem.b, &memword, &delay_time);
			if (memword == 0xffffffff && exception_pending) 
			{
				exception_mem = true;
				return;
			}
			
			mem_wb.lmd = memword;
			break;	
		case 0x23://lw
		case 0x30://ll,temply handled as lw instruction
			addr ->fetch_word(ex_mem.ALUoutput,  &word, &delay_time);
			if (word == 0xffffffff && exception_pending)   
			{
				exception_mem = true;
				return;
			}
			
			mem_wb.lmd = word;
			break;
		case 0x24://lbu
			addr ->fetch_byte(ex_mem.ALUoutput, &byte, &delay_time);
			cbyte = byte & 0x000000ff;			
			if ((cbyte & 0xff == 0xff) && exception_pending) 
			{
				exception_mem = true;
				return;
			}
			
			mem_wb.lmd = cbyte;	
			break;
		case 0x25://lhu
			addr ->fetch_half_word(ex_mem.ALUoutput, &halfword, &delay_time);
			chalfword = halfword & 0x0000ffff;
			if ((chalfword & 0xffff == 0xffff) && exception_pending)
			{
				exception_mem = true;
				return;
			}
			
			/* Load target register with data. */
			mem_wb.lmd = chalfword;
			break;
		case 0x26://lwr
			addr ->fetch_wordr(ex_mem.ALUoutput, ex_mem.b, &memword, &delay_time);
			if (memword == 0xffffffff && exception_pending) 
			{
				exception_mem = true;
				return;
			}
			
			mem_wb.lmd = memword;
			break;

		case 0x31://lwc1
			addr ->fetch_word(ex_mem.ALUoutput,  &word, &delay_time);

      			 if (word == 0xffffffff && exception_pending) 
        		{
				exception_mem = true;
				return;
			}
			
			mem_wb.lmd = word;
			break;
		//store instruction [0x28 .. 0x2b, 0x2e]
		case 0x28://sb
			addr ->store_byte(ex_mem.ALUoutput, (ex_mem.b & 0x0ff), &delay_time);
			
			if (exception_pending) 	
			{
				exception_mem = true;
				return;
			}
			break;
		case 0x29://sh
			addr ->store_half_word( ex_mem.ALUoutput, (ex_mem.b & 0x0ffff), &delay_time);
			if (exception_pending) 	
			{
				exception_mem = true;
				return;
			}
			break;
		case 0x2a://swl
			addr->store_wordl(ex_mem.ALUoutput, ex_mem.b, &delay_time);
			if (exception_pending) 	
			{
				exception_mem = true;
				return;
			}
			break;
		case 0x2b://sw
			addr ->store_word(ex_mem.ALUoutput, ex_mem.b, &delay_time);
			if (exception_pending) 	
			{
				exception_mem = true;
				return;
			}
			break;		
		case 0x38://sc		
			if(LLbit){
				addr ->store_word(ex_mem.ALUoutput, ex_mem.b, &delay_time);
				reg[ex_mem.rt] = 1; // flag to indicate success
				LLbit = false;	
			}
			else 
				reg[ex_mem.rt] = 0; // never here when in single processor 
			if (regflag[ex_mem.rt] != 0)
				regflag[ex_mem.rt] --;
			if (exception_pending) 	
			{
				exception_mem = true;
				return;
			}
			break;
		case 0x2e://swr
			addr->store_wordr(ex_mem.ALUoutput, ex_mem.b, &delay_time);
			if (exception_pending) 	
			{
				exception_mem = true;
				return;
			}
			break;

		case 0x39://swc1
        		addr ->store_word(ex_mem.ALUoutput,  ex_mem.b, &delay_time);
			if (exception_pending) 	
			{
				exception_mem = true;
				return;
			}
			break;
			
		default: 
			break; 			
	}

	if (delay_time != 0)
		_mem_stock = true;
//	else
//		pplstat->SetStage(MEMMask);
	
	mem_wb.op = ex_mem.op;
	mem_wb.b = ex_mem.b;
	mem_wb.rs = ex_mem.rs;
	mem_wb.rt = ex_mem.rt;
	mem_wb.rd = ex_mem.rd;
	mem_wb.ALUoutput = ex_mem.ALUoutput;
	mem_wb.funct = ex_mem.funct;
	mem_wb.fmt = ex_mem.fmt;
}

void 
CLKCPU::writeback()
{
	switch(mem_wb.op)
	{
		case 0x00://R-Type instruction
			if(((mem_wb.funct <= 0x2b)&&(mem_wb.funct >= 0x20))||(mem_wb.funct <= 0x07)
				||(mem_wb.funct == 0x09)||(mem_wb.funct == 0x10)||(mem_wb.funct == 0x12))
			{
				reg[mem_wb.rd] = mem_wb.ALUoutput;
				if ( (regflag[mem_wb.rd] !=0))
					regflag[mem_wb.rd] --;

#ifdef __CMP_DEBUG__
				if (CPU::opt_barrier) {
					ncount ++;
					fprintf(stderr, "PC->%8x, Reg[%x]->%8x\n", (mem_wb.pc-4), mem_wb.rd,  reg[mem_wb.rd]);
					fflush ( stderr );
				}
#endif
			}
			break;
		case 0x08:// [0x08 .. 0x0f]://I-Type instruction
		case 0x09:
		case 0x0a:
		case 0x0b:
		case 0x0c:
		case 0x0d:
		case 0x0e:
		case 0x0f:
			reg[mem_wb.rt] = mem_wb.ALUoutput;

			if ( (regflag[mem_wb.rt] !=0))		
				regflag[mem_wb.rt] --;

#ifdef __CMP_DEBUG__
			if (CPU::opt_barrier) {
					ncount ++;
					fprintf(stderr, "PC->%8x, Reg[%x]->%8x\n", (mem_wb.pc-4), mem_wb.rt,  reg[mem_wb.rt]);
					fflush ( stderr );
				}
#endif
			break;
		case 0x20://[0x20 .. 0x26]://load instruction
		case 0x21:
		case 0x22:
		case 0x23:
		case 0x24:
		case 0x25:
		case 0x26:		
		case 0x30://ll
			reg[mem_wb.rt] = mem_wb.lmd;
			if ((regflag[mem_wb.rt] != 0))
				regflag[mem_wb.rt] --;		
			if (mem_wb.op == 0x30)
				LLbit = true; // always success in single processor, check align?

#ifdef __CMP_DEBUG__
			if (CPU::opt_barrier) {
					ncount ++;
					fprintf(stderr, "PC->%8x, Reg[%x]->%8x\n", (mem_wb.pc-4), mem_wb.rt,  reg[mem_wb.rt]);
					 fflush ( stderr );
				}
#endif			
			break;
		case 0x10://mfc0
			if (mem_wb.rs == 0x00){ 
				reg[mem_wb.rt] = mem_wb.ALUoutput; 
				if ((regflag[mem_wb.rt] != 0))
					regflag[mem_wb.rt] --;		
			}					
			break;			
		case 0x11://cfc1, mfc1, mtc1
			switch(mem_wb.fmt)
			{
				case F_cfc_op:
					if (mem_wb.rs == 31) {
				            reg[mem_wb.rt] = mem_wb.ALUoutput;
			         	}
					if (regflag[mem_wb.rt] != 0)
						regflag[mem_wb.rt] --;
					break;
				case F_mfc_op:
					reg[mem_wb.rt] = mem_wb.ALUoutput;
					if (regflag[mem_wb.rt] != 0)
						regflag[mem_wb.rt] --;

					break;
				case F_mtc_op:
					clkcpone->freg[(mem_wb.rs)>>1].ir[(mem_wb.rs)&1] = mem_wb.ALUoutput;
					if ((clkcpone->fregflag[(mem_wb.rs)>>1] )!= 0)
						(clkcpone->fregflag[(mem_wb.rs)>>1]) --;
					break;
			}
			break;
		case 0x31://lwc1
		    	/* Load target register with data. */
       		clkcpone->freg[(mem_wb.rt)>>1].ir[(mem_wb.rt)&1] = mem_wb.lmd;
			if ((clkcpone->fregflag[(mem_wb.rt)>>1]) != 0)
				(clkcpone->fregflag[(mem_wb.rt)>>1]) --;			    	
		    	break;

		default: 
			break; 		
	}
	
}

void
CLKCPU::clockstep()
{
	cycle_count ++;// record the real cycles
	
	pplstat->RefreshStages();

	// float point pipeline
	if (clkcpone->fex_wb.tag)
		clkcpone->fwb();

	if (clkcpone->fex2_3.tag)
		clkcpone->fex3();

	if (clkcpone->fex1_2.tag)
		clkcpone->fex2();


	//int pipeline	
#ifdef __CMP_DEBUG__
	if ((ncount == 0) && (!(opt_barrier)) && (pc<0x80000000))
	{
		CPU::opt_barrier =1;
		freopen("b.doc", "w+", stderr);
	}
#endif
	
 	/*write back*/ 		
	if (!mem_wb.stall){
		if (mem_wb.tag)
		{
		       writeback();
		       pplstat->SetStage(WBMask);
		       mem_wb.tag=false;     
		}
	}else
		mem_wb.stall = false;
	
#ifdef __CMP_DEBUG__
	if (ncount == 300)
	{
		DBGTracer::barrier();
		ncount = 0;
		freopen("b.doc", "w+", stderr);
	}
#endif

	if (!(machine->opt_clkcpu) && (switch_pc == mem_wb.pc)) { //switch to cpu
		printf("Switch to cpu......\n");
		machine->emustate = 0;
	}
	
	pplstat->SetnInst(instr_count);
	pplstat->SetnCycle(cycle_count);
	pplstat->SetnStall(stall_count);
	pplstat->SetnRaw(nraw);
		
	 /*memory access*/
	if (!ex_mem.stall){
		if (_mem_stock){
			delay_time --;
			if (delay_time == 0){
				 if (exception_mem) //handle exception occurred at memory access stage
				{
					for (int i=0; i<32; i++)
						regflag[i]= 0;
					if ((mem_state == DELAYSLOT) && (ex_state != DELAYSLOT))
						mem_epc = mem_epc -4;
					mem_wb.tag = false;
					if_id.stall = true;
					id_ex.stall = true;	

					pl_state = true;
					_mem_stock = false;
					_id_stock = false;								

					_if_stock = false;// true for stocking the according pipeline stage 
					_id_stock = false;
					_mem_stock = false;
					
					_if_skip = false; // true for skip the according pipeline stage
					_id_skip = false;
					_ex_skip =false;
					
					flaga = false;//for decode stage to use
					flagb = false;
					pl_state = true;//successful decode
					
					if_delay_time = 0;//record the delay time at IF stage
					delay_time = 0;//record the delay time at MEM stage

					exception_if = false; //true for the according stage exception
					exception_ex = false;
					if_state = NORMAL;  //record the state of instruction in exception, normal or delayslot or delaying
					ex_state = NORMAL;

                  			clkcpone->fcr31flag =0;

					if (sucDocode)
					{
						if (id_ex.op == 0x11)//cfc1, mfc1, mtc1		
							switch(id_ex.fmt)
							{
								case F_cfc_op:					
								case F_mfc_op:
									if (regflag[id_ex.rt] != 0)
										regflag[id_ex.rt] --;

									break;
								case F_mtc_op:
									if ((clkcpone->fregflag[(id_ex.rs)>>1] )!= 0)
										(clkcpone->fregflag[(id_ex.rs)>>1]) --;
									break;
							}
						if (id_ex.op == 0x31)//lwc1
						    	/* Load target register with data. */
							if ((clkcpone->fregflag[(id_ex.rt)>>1]) != 0)	
								(clkcpone->fregflag[(id_ex.rt)>>1]) --;	
						sucDocode = false;
					}

					if (ex_mem.op == 0x31)//lwc1
					    	/* Load target register with data. */
						if ((clkcpone->fregflag[(ex_mem.rt)>>1]) != 0)	 
							(clkcpone->fregflag[(ex_mem.rt)>>1]) --;	

					next_epc = mem_epc;
					if (mem_state == DELAYSLOT)
						delay_state = mem_state;
					exception_pending = curexcpending;
					clkexcphandle(c_excCode, c_mode, c_coprocno);
					exception_mem = false;
					if (mem_state == DELAYSLOT)
					{
						mem_state = NORMAL; 
						delay_state = NORMAL;
					}
				}else{	
					if ((ex_state != DELAYSLOT) && (mem_state == DELAYSLOT))
						mem_state = NORMAL;
					
					_mem_stock = false;
				   	ex_mem.tag=false;
					mem_wb.tag=true;	
				}

				pplstat->SetStage(MEMMask);
			}else{				
				_ex_skip = true;
				_id_skip = true;
				_if_skip = true;
				mem_wb.stall = true;
				stall_count ++;
			}
		}else if (ex_mem.tag){
			   	memaccess();	
			   	
#ifdef __DUMP_INST__       // used for debug to compare the instruction execution flow
	if (( ( (ex_mem.pc-4) < 0x80000000) ||( (ex_mem.pc-4) == 0x80000080)) 
		&& (!(cpzero->tlb->tlb_user_miss && exception_mem)) )
//		&& ((!(mem_state == DELAYSLOT) && (ex_state != DELAYSLOT))))//(
//		&& (!(( (ex_mem.pc-4) >= 0x42a1c0) && ( (ex_mem.pc-4) <= 0x42a2f0))))
	{
         	static int inst_count = 0;
//         	if ((ex_mem.pc-4)==0x45a550)//4624a0
          		inst_count ++;
          	if(inst_count > 41000000 ) exit(-1);
          	if(inst_count > 30000000 )				 
//          	if(inst_count !=0 )				 
			fprintf(stderr,"PC=0x%08x\n",(ex_mem.pc-4));//add for comparation
	}
#endif

				if (_mem_stock){
					_ex_skip = true;
					_id_skip = true;
					_if_skip = true;
					mem_wb.stall = true;
					stall_count ++;
			   	}else if (exception_mem) //handle exception occurred at memory access stage
				{
					pplstat->SetStage(MEMMask);
					for (int i=0; i<32; i++)
						regflag[i]= 0;//to define the readable state of the according register

					if ((mem_state == DELAYSLOT) && (ex_state != DELAYSLOT))
						mem_epc = mem_epc -4;
					mem_wb.tag = false;
					if_id.stall = true;
					id_ex.stall = true;						
					
					pl_state = true;
					_mem_stock = false;
					_id_stock = false;	

					_if_stock = false;// true for stocking the according pipeline stage 
					_id_stock = false;
					_mem_stock = false;
					
					_if_skip = false; // true for skip the according pipeline stage
					_id_skip = false;
					_ex_skip =false;
					
					flaga = false;//for decode stage to use
					flagb = false;
					pl_state = true;//successful decode
					
					if_delay_time = 0;//record the delay time at IF stage
					delay_time = 0;//record the delay time at MEM stage

					exception_if = false; //true for the according stage exception
					exception_ex = false;
					if_state = NORMAL;  //record the state of instruction in exception, normal or delayslot or delaying
					ex_state = NORMAL;

					clkcpone->fcr31flag =0;

					if (sucDocode)
					{
						if (id_ex.op == 0x11)//cfc1, mfc1, mtc1		
							switch(id_ex.fmt)
							{
								case F_cfc_op:					
								case F_mfc_op:
									if (regflag[id_ex.rt] != 0)
										regflag[id_ex.rt] --;

									break;
								case F_mtc_op:
									if ((clkcpone->fregflag[(id_ex.rs)>>1] )!= 0)
										(clkcpone->fregflag[(id_ex.rs)>>1]) --;
									break;
							}
						if (id_ex.op == 0x31)//lwc1
					    	/* Load target register with data. */
							if ((clkcpone->fregflag[(id_ex.rt)>>1]) != 0)
								(clkcpone->fregflag[(id_ex.rt)>>1]) --;	
						sucDocode = false;
					}

					if (ex_mem.op == 0x31)//lwc1
					    	/* Load target register with data. */
						if ((clkcpone->fregflag[(ex_mem.rt)>>1]) != 0)
							(clkcpone->fregflag[(ex_mem.rt)>>1]) --;	

					next_epc = mem_epc;
					if (mem_state == DELAYSLOT)
						delay_state = mem_state;
					exception_pending = curexcpending;
					clkexcphandle(c_excCode, c_mode, c_coprocno);
					exception_mem = false;
					if (mem_state == DELAYSLOT)
					{
						mem_state = NORMAL; 
						delay_state = NORMAL;
					}
				}else{
					if ((ex_state != DELAYSLOT) && (mem_state == DELAYSLOT))
						mem_state = NORMAL;
					
					pplstat->SetStage(MEMMask);
					ex_mem.tag=false;
					mem_wb.tag=true;	
			   	}
				
			}
		   	else	{
				if (exception_ex) //handle exception occurred at execute stage
				{
					
#ifdef __DUMP_INST__   // used for debug to compare the instruction execution flow
	if ( ((id_ex.pc-4) < 0x80000000) || ((id_ex.pc-4) == 0x80000080) )//(
//		&& (!(( (id_ex.pc-4) >= 0x42a1c0) && ( (id_ex.pc-4) <= 0x42a2f0))))
			fprintf(stderr,"PC=0x%08x\n",(id_ex.pc-4));//add for comparation
#endif
 					mem_wb.pc = id_ex.pc;//just prepare for switch to cpu
					next_epc = ex_epc;
					if (ex_state == DELAYSLOT)
						delay_state = ex_state;	
					
					pl_state = true;							

					_if_stock = false;// true for stocking the according pipeline stage 
					_id_stock = false;
					_mem_stock = false;
					
					_if_skip = false; // true for skip the according pipeline stage
					_id_skip = false;
					_ex_skip =false;
					
					flaga = false;//for decode stage to use
					flagb = false;
					pl_state = true;//successful decode
					
					if_delay_time = 0;//record the delay time at IF stage
					delay_time = 0;//record the delay time at MEM stage

					exception_if = false; //true for the according stage exception
					exception_mem = false;
					if_state = NORMAL;  //record the state of instruction in exception, normal or delayslot or delaying
					mem_state = NORMAL;

					exception_pending = curexcpending;
					clkexcphandle(c_excCode, c_mode, c_coprocno);
					exception_ex = false;	
					if (ex_state == DELAYSLOT)
					{
						ex_state = NORMAL; 
						delay_state = NORMAL;
					}
				}
				else if (exception_if) //handle exception occurred at instruction fetch stage
				{
					next_epc = if_epc;
					if (if_state == DELAYSLOT)
						delay_state = if_state;

					cpzero->tlb->tlb_user_miss = tlb_state;
					exception_pending = curexcpending; 
					clkexcphandle(c_excCode, c_mode, c_coprocno);
					_if_skip = false;
					if_id.stall = true;
					id_ex.stall = true;
					exception_if = false;
					if (if_state == DELAYSLOT)
					{
						if_state = NORMAL; 
						delay_state = NORMAL;
					}
				}
				
				pplstat->SetStage(MEMMask);
		   	}			
	}else{
		mem_wb.stall = ex_mem.stall;
		ex_mem.stall = false;
	}
	 
	/*execute*/
	if (!_ex_skip){
		if (!id_ex.stall){
			if (id_ex.tag){
				execute();
				if (!exception_ex)
				{
					if ((if_state != DELAYSLOT) && (ex_state == DELAYSLOT))
						ex_state = NORMAL;
				       id_ex.tag=false;
					ex_mem.tag=true;
				}

				pplstat->SetStage(EXMask);
			}
		}else{
			ex_mem.stall = id_ex.stall;
			id_ex.stall = false;
		}
	}
	else{
		_ex_skip = false;
	}


	if (clkcpone->fid_ex.tag)
		clkcpone->fex1();	


	/*instruction decode*/	 
	if (!_id_skip)
	{
		if (!if_id.stall)
		{
			if (if_id.tag)
			{
		       	idecode();
		       	_id_stock = ! pl_state;	
		       	if (_id_stock)
		       	{
					id_ex.stall = true;
					_if_skip = true;
					stall_count ++;
			       }else{
					  if (!(machine->opt_clkcpu)) { //switch to cpu
						printf("Prepare for switching to cpu......\n");
						if (!(((id_ex.op >= 0x01) && (id_ex.op <=0x07))//not the instruction with a delayslot
						      || ((id_ex.op == 0x00) && ((id_ex.funct == 0x08) || (id_ex.funct == 0x09))) //jr, jalr
						      || ((id_ex.op == 0x10) && (id_ex.rs == 0x08))//bc0x
						      || ((id_ex.op == 0x11) && (id_ex.fmt == 0x08))))//bc1x
						{
							 _if_skip = true;
							 switch_pc = id_ex.pc;
						}
						
					}
					pplstat->SetStage(IDMask);
					if_id.tag = false;
					id_ex.tag = true;
			       }
			}
		}else{
			id_ex.stall = if_id.stall;
			if_id.stall = false;			
		}
	}
	else{
		_id_skip = false;	
	}				
	 
	/*instruction fetch*/
	pplstat->SetPc(pc); //???? of not too much reference value
	if (! _if_skip)
	{			
		if (_if_stock){//when dependence occure at IF stage
			if_delay_time --;
			if (if_delay_time == 0){
				 if(exception_if)
				{
					tlb_state = cpzero->tlb->tlb_user_miss;
					_if_skip = true;
					if_id.tag = false;
				}else{
					_if_stock = false;
					if_id.tag=true;
				}
				pplstat->SetStage(IFMask);
				pplstat->SetInstr(instr); 
			}else{
				pplstat->SetInstr(0xffffffff); 
				if_id.stall = true;	
				stall_count ++;
			 }
		}else{
			ifetch(); //when dependence occure at other stage (2)
			if (_if_stock){//when dependence occure at IF stage
				if_id.stall = true;
				stall_count ++;
				pplstat->SetInstr(0xffffffff);
			}else if(exception_if)
			{
				pplstat->SetInstr(instr); 

				tlb_state = cpzero->tlb->tlb_user_miss;
				_if_skip = true;
				if_id.tag = false;
			}
			else{
				pplstat->SetStage(IFMask);
				pplstat->SetInstr(instr); 

				if_id.tag=true;
			}
		}
	}		
	else{   //when dependence occure at other stage (1)
		if ((!exception_if) && (machine->opt_clkcpu))
			_if_skip = false;
		if (exception_ex && !_id_skip)
		{
			if_id.stall = true;
			_if_skip = false;
		}
		pplstat->SetInstr(0xffffffff);
	}

	pplstat->SetClkStages();

	/*When needed, the log information of clock level emulation can be added here[[[[*/

}

/* end -Added by zwl on Sep 27th, 2003, five stages pipeline emulation on clock level  [[[[*/

void
CLKCPU::funct_clkemulate(uint32 pc)
{
	static const clkemulate_funptr clkfunctJumpTable[] = {
		&CLKCPU::sll_clkemulate,     &CLKCPU::RI_clkemulate,
		&CLKCPU::srl_clkemulate,     &CLKCPU::sra_clkemulate,
		&CLKCPU::sllv_clkemulate,    &CLKCPU::RI_clkemulate,
		&CLKCPU::srlv_clkemulate,    &CLKCPU::srav_clkemulate,
		&CLKCPU::jr_clkemulate,      &CLKCPU::jalr_clkemulate,
		&CLKCPU::RI_clkemulate,      &CLKCPU::RI_clkemulate,
		&CLKCPU::syscall_clkemulate, &CLKCPU::break_clkemulate,
		&CLKCPU::RI_clkemulate,      &CLKCPU::RI_clkemulate,
		&CLKCPU::mfhi_clkemulate,    &CLKCPU::mthi_clkemulate,
		&CLKCPU::mflo_clkemulate,    &CLKCPU::mtlo_clkemulate,
		&CLKCPU::RI_clkemulate,      &CLKCPU::RI_clkemulate,
		&CLKCPU::RI_clkemulate,      &CLKCPU::RI_clkemulate,
		&CLKCPU::mult_clkemulate,    &CLKCPU::multu_clkemulate,
		&CLKCPU::div_clkemulate,     &CLKCPU::divu_clkemulate,
		&CLKCPU::RI_clkemulate,      &CLKCPU::RI_clkemulate,
		&CLKCPU::RI_clkemulate,      &CLKCPU::RI_clkemulate,
		&CLKCPU::add_clkemulate,     &CLKCPU::addu_clkemulate,
		&CLKCPU::sub_clkemulate,     &CLKCPU::subu_clkemulate,
		&CLKCPU::and_clkemulate,     &CLKCPU::or_clkemulate,
		&CLKCPU::xor_clkemulate,     &CLKCPU::nor_clkemulate,
		&CLKCPU::RI_clkemulate,      &CLKCPU::RI_clkemulate,
		&CLKCPU::slt_clkemulate,     &CLKCPU::sltu_clkemulate,
		&CLKCPU::RI_clkemulate,      &CLKCPU::RI_clkemulate,
		&CLKCPU::RI_clkemulate,      &CLKCPU::RI_clkemulate,
		&CLKCPU::RI_clkemulate,      &CLKCPU::RI_clkemulate,
		&CLKCPU::RI_clkemulate,      &CLKCPU::RI_clkemulate,
		&CLKCPU::RI_clkemulate,      &CLKCPU::RI_clkemulate,
		&CLKCPU::RI_clkemulate,      &CLKCPU::RI_clkemulate,
		&CLKCPU::RI_clkemulate,      &CLKCPU::RI_clkemulate,
		&CLKCPU::RI_clkemulate,      &CLKCPU::RI_clkemulate,
		&CLKCPU::RI_clkemulate,      &CLKCPU::RI_clkemulate,
		&CLKCPU::RI_clkemulate,      &CLKCPU::RI_clkemulate
	};
	(this->*clkfunctJumpTable[id_ex.funct])(pc);
}

void
CLKCPU::regimm_clkemulate(uint32 pc)
{
	switch(id_ex.rt)
	{
		case 0: bltz_clkemulate(pc); break;
		case 1: bgez_clkemulate(pc); break;
		case 16: bltzal_clkemulate(pc); break;
		case 17: bgezal_clkemulate(pc); break;
		default: exception(RI); break; /* reserved instruction */
	}
}
CLKCPU::~CLKCPU() throw()
{
        delete(addr);
 //       fclose(fp);
//	    delete fp;
}


/* Returns the current program counter register. */
uint32
CLKCPU::debug_get_pc(void)
{
	if(! machine->emustate ) return pc;
	return if_id.pc - 4 ;
}

/* Sets the program counter register to the value given in NEWPC. */
void
CLKCPU::debug_set_pc(uint32 newpc)
{
	if(! machine->emustate 
	 && ( newpc != ( if_id.pc - 4) ) )
	pc = newpc;
}
	
