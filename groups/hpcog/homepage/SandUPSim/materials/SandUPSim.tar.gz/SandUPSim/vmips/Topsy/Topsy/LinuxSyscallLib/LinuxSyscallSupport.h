#ifndef LINUXSYSCALLSUPPORT_H
#define LINUXSYSCALLSUPPORT_H
#include "LibcLinuxTypes.h"

void CopyStat64Local(struct stat64formips* statlocalptr,long long * buf);

#endif

