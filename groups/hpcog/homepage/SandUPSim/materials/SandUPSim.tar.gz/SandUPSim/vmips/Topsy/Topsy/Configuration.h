/*
	Copyright (c) 1996-1997 Swiss Federal Institute of Technology, 
	Computer Engineering and Networks Laboratory. All rights reserved.

	TOPSY - A Teachable Operating System. 
		Implementation of a tiny and simple micro kernel for
		teaching purposes.

	Permission to use, copy, modify, and distribute this software and its
	documentation for any purpose, without fee, and without written 
	agreement is hereby granted, provided that the above copyright notice 
	and the following two paragraphs appear in all copies of this software.


	
	File:                  $Source: /work/cvs/cvsroot/Topsy/Topsy/Configuration.h,v $
 	Author(s):             George Fankhauser
 	Affiliation:           ETH Zuerich, TIK
 	Version:               $Revision: 1.3 $
 	Creation Date:         
 	Last Date of Change:   $Date: 2003/11/23 11:24:24 $      by: $Author: slfsmm $
	
	
*/
#ifndef _CONFIGURATION_H_
#define _CONFIGURATION_H_

/* general, messages, prompts, look and feel 
 */

#ifndef SIMOS

#define BOOTMESSAGE "Topsy 1.0 (c) 1996-1997, ETH Zurich, TIK\n($Id: Configuration.h,v 1.3 2003/11/23 11:24:24 slfsmm Exp $)\n\n"

#else

#define BOOTMESSAGE "\n" \
"Topsy 1.0 (c) 1996-1997, ETH Zurich, TIK\n" \
"SimOS and R4000 patches by Patryk Zadarnowski, University of NSW\n\n" \

#endif

#if defined(__MIPSEB__) || defined(__BIG_ENDIAN__)
#define TOPSY_BIG_ENDIAN
#endif


/* memory parameters 
 */
#define KERNELHEAPSIZE   (64*1024)   /* kernel heap size */


/* threads, IPC 
 */
#define TIMESLICE         30   /* how long a thread may run, in milliseconds */
#define NBPRIORITYLEVELS   3   /* 0 for highest priority */
#define MAXNBMSGINQUEUE   20   /* message queue length */
#define MAXNAMESIZE       24   /* max thread name size (in characters) */
/*slfsmm031121_mod>*/
//#define TM_DEFAULTTHREADSTACKSIZE   1024
#define TM_DEFAULTTHREADSTACKSIZE    8192
/*slfsmm031121_mod<*/

/* io features 
 */
#define NBCYCLESFORDELAY 10    /* each time a write occurs onto a driver, */
                               /* at least NULL-operations are performed  */

/*slfsmm031122_add>*/
//#define REMOTESYSCALL
/*slfsmm031122_add<*/

#endif





