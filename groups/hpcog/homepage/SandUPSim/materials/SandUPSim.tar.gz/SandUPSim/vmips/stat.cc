#include "DBGTracer.h"
#include "vmips.h"
#include "cpu.h"
#include "tlb.h"
#include "options.h"
#include "error.h"
#include "cache.h"
#include "memstatreg.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>


#define STEPGAP (4 * 1024)
#define PAGE_MASK 0xfffff000
int DBGTracer::tracing = 0;
CPU* DBGTracer::cpulist[16]={NULL};
gzFile DBGTracer::flist[16]={NULL};
uint  DBGTracer::trclen[16] = {0};
char* DBGTracer::appname = NULL;
uint16 DBGTracer::tracemask[16];
userinfo_t DBGTracer::usinfo;
FILE* DBGTracer::stepfp = NULL;
uint64 DBGTracer::stepcounter = 0;
//#define COMPACT
#define PLOTONE
#define L1DELAY 3
#define L2DELAY 7
#define MDELAY 105
#define recovertrace(mask, data, result) do  {	\
	uint8* p = data;								\
	if(mask & BoolMask)							\
	{											\
		result.boolval.content = *(uint16*)p;		\
		p += 2;								\
	}								\
	if(mask & CacheHitLevMask)			\
		{								\
		result.hitted_cache_level = * p;		\
		p ++;							\
		}			\
	if (mask & HitTimeMask)				\
		{								\
		result.hit_time = *(uint16*)p;		\
		p += 2;							\
		}			\
	if (mask & AddrMask)					\
		{								\
		result.addr = *(uint32*)p;		\
		p += 4;							\
		}			\
	if(mask & CounterMask)				\
		{								\
		result.counter = *(uint64*)p;		\
		p += 8;							\
		}								\
	if(mask & CachefcMask)				\
		{								\
		result.fc_hit_times = *(uint64*)p;	\
		p += 8;							\
		}								\
	if(mask & CachescMask)				\
		{								\
		result.sc_hit_times = *(uint64*)p;	\
		p += 8;							\
		}								\
	if(mask & CachemissMask)				\
		result.cache_miss_times = *(uint64*)p;	\
}while(0)


/*
enum MODE
{
	INVALID,
	INST,
	DATA
};
#define BUF_SIZE       1024 * 1024
#define UINT32_SIZE  32
#define ZERO_SIZE     4

static uint8 filebuf[BUF_SIZE];
static uint32 *buf_pos = (uint32*)filebuf;
static uint32 start_bits = 0;
static gzFile fp;
static uint32 prev_inst_addr = 0;
static uint32 times = 0;
static MODE last_mode = INVALID;
static uint32 buf_len;

#define radjust_start_pos do{	\
	if(start_bits == UINT32_SIZE)	\
	{			\
		start_bits = 0;	\
		buf_pos ++;	\
		if((uint8*)buf_pos - filebuf ==(int32) buf_len )	\
		{				\
			uint8 *tmp_buf = filebuf;		\
			uint8 *tmp_buf_pos = (uint8 *)buf_pos;	\
			uint32 remainder = buf_len % 4;		\
			for(uint32 i = 0; i < remainder; i ++)	\
				*(tmp_buf ++) = *(tmp_buf_pos ++);	\
			buf_len=gzread(fp, tmp_buf, BUF_SIZE- remainder);	\
			buf_len += remainder;			\
			buf_pos = (uint32*)filebuf;				\
		}						\
	}							\
}while(0)

#define get_bits(len, data) do{	\
	uint32 mask = (((uint32)1 << (len)) - 1) << start_bits;	\
	data = (*buf_pos & mask) >> start_bits;		\
	start_bits += (len);				\
	radjust_start_pos;				\
}while(0)	
	

#define get_times(data) do{ \
	if(start_bits <= UINT32_SIZE - ZERO_SIZE)	\
	{					\
		get_bits(ZERO_SIZE, data);	\
	}					\
	else					\
	{					\
		uint32 bits = UINT32_SIZE - start_bits;	\
		uint32 remainder_bits = ZERO_SIZE - bits;	\
		uint32 temp1,temp2;			\
		get_bits(bits,temp1);			\
		get_bits(remainder_bits,temp2);		\
		data = (temp2 << bits)| temp1;		\
	}						\
}while(0)

#define get_addr(data) do{ \
	if(start_bits == 0 )	\
	{					\
		data = *buf_pos ;		\
		start_bits = UINT32_SIZE;	\
		radjust_start_pos;		\
	}					\
	else					\
	{					\
		uint32 bits = UINT32_SIZE - start_bits;	\
		uint32 remainder = start_bits;	\
		uint32 temp1,temp2;			\
		get_bits(bits,temp1);			\
		get_bits(remainder,temp2);		\
		data = (temp2 << bits)| temp1;		\
	}						\
}while(0)
void read_prepare(char *name)
{	
	char buf[64];
	sprintf(buf, "%s_recdata.gz", name);
	fp = gzopen(buf, "rb");
	if(fp == NULL)
	{
		printf("fopen error!\n");
		exit(-1);
	}	
	buf_len=gzread(fp, filebuf, BUF_SIZE);
}

void read_post()
{
	gzclose(fp);
}
int read_file(uint32 *inst_addr, uint32 *data_addr)
{
	if(times)             //INST
	{
		*inst_addr = prev_inst_addr + 4;
		prev_inst_addr = *inst_addr;
		times --;
		*data_addr = 0;
		return 0;
	}
	uint32 mode;
	get_bits(1, mode);
	if(mode)                       //DATA
	{
		get_addr(*data_addr);
		*inst_addr = 0;        
		return 0;
	}
	//INST
	get_addr(*inst_addr);
	get_times(times);
	if(times == 0)
		return 1;
	prev_inst_addr = *inst_addr;
	times--;
	*data_addr = 0;
	return 0;	
}								


#define wadjust_start_pos do{	\
	if(start_bits == UINT32_SIZE)	\
	{			\
		start_bits = 0;	\
		buf_pos ++;	\
		if((uint8*)buf_pos - filebuf == BUF_SIZE)	\
		{				\
			gzwrite(fp,filebuf, BUF_SIZE);	\
			memset(filebuf, 0, BUF_SIZE);		\
			buf_pos = (uint32 *)filebuf;					\
		}							\
	}								\
}while(0)

#define set_bits(len,data) do{	\
	uint32 t = (data) & (((uint32)1 << (len)) - 1);	\
	t <<=  start_bits; 			\
	(*buf_pos) |= t;				\
	start_bits += (len);			\
	wadjust_start_pos;			\
}while(0)	
	

#define set_times(data) do{ \
	if(start_bits <= UINT32_SIZE - ZERO_SIZE)	\
	{			\
		set_bits(ZERO_SIZE, data);	\
	}				\
	else				\
	{				\
		uint32 bits = UINT32_SIZE - start_bits;	\
		uint32 remainder_bits = ZERO_SIZE - bits;	\
		set_bits(bits, data);		\
		set_bits(remainder_bits, (data) >> bits) ; \
	}		\
}while(0)

#define set_addr(data) do{ \
	if(start_bits == 0 )	\
	{			\
		*buf_pos = data;	\
		start_bits = UINT32_SIZE; 	\
		wadjust_start_pos;		\
	}					\
	else					\
	{					\
		uint32 bits = UINT32_SIZE - start_bits;	\
		uint32 remainder = start_bits;	\
		set_bits(bits, data);		\
		set_bits(remainder, (data) >>bits) ; \
	}		\
}while(0) 
void write_prepare(char * name)
{	
	char buf[64];
	sprintf(buf, "%s_recdata.gz", name);
	fp = gzopen(buf, "wb");
	if(fp == NULL)
	{
		printf("fopen error!\n");
		exit(-1);
	}
	memset(filebuf, 0, BUF_SIZE);
}

void write_post()
{	
	if(last_mode == INST && times)
		set_times(times);
	gzwrite(fp, filebuf, BUF_SIZE);
	memset(filebuf, 0, BUF_SIZE);
	gzwrite(fp, filebuf, BUF_SIZE);
	gzclose(fp);
}


void write_file(uint32 inst_addr,uint32 data_addr)
{
	if(!data_addr)    // this is a instr address
	{
		
		
		if(inst_addr == prev_inst_addr + 4 && last_mode == INST)
		{
			times ++;
			if(times == 15)
			{
				set_times(times);
				times = 0;  
				last_mode = INVALID;
			}
		}
		else 
		{
			if(last_mode == INST && times)
				set_times(times);
			set_bits(1, 0);
			set_addr(inst_addr);
			times = 1;
			last_mode = INST;
				
		}
		prev_inst_addr = inst_addr;
	}
	else
	{
		if(last_mode == INST && times)
			set_times(times);
		set_bits(1, 1);
		set_addr(data_addr);
		times = 0;
		last_mode = DATA;
	}
}
*/
void
DBGTracer::recMissTrace(CPU *cpu)
{
	static uint64 cou;
	uint8 *buf;
	cou ++;
	fprintf(stepfp, "%llu\t%llu\n", cou, stepcounter);
	buf = cpu ->memstat ->GetTracebuf();
	int tmplen = gzwrite(flist[0],buf, trclen[0]);				
	if(tmplen != (int)trclen[0])
		fprintf(stderr, "record error !!\n"), exit(-1);

}

int DBGTracer::recTrace(CPU * cpu) 
{	
	
	if(tracing) 
	{					
		uint8*  buf;				
		if(cpu ->opt_tracetofile)
			if(!cpu ->memstat ->stat_info.boolval.val.pbuf_hitted && 
				!cpu ->memstat ->stat_info.boolval.val.inst_or_data)
//			if(cpu ->memstat ->stat_info.boolval.val.cacheable)
			if(!cpu->memstat->stat_info.boolval.val.inst_or_data)
			{					
				buf = cpu ->memstat ->GetTracebuf();
				int tmplen = gzwrite(flist[0],buf, trclen[0]);				
				if(tmplen != (int)trclen[0])
					fprintf(stderr, "record error !!\n"), exit(-1);
			}				
		
	}
	return 0;
}
int DBGTracer::traceon(CPU * cpu) 
{
	int rc = tracing;
	fprintf(stderr, "Tracer on ...................\n");
	
	if( tracing == 0 )
	{
		tracemask[0] = 0xff; 		
		trclen[0] = cpu->memstat->SetTraceMask(tracemask[0]);
		cpu->memstat->TraceStart();
		// use this for clock count
		trcVar[15] = cpulist[0]->machine->num_instrs;
		
		tracing = 1;		 
		usinfo = cpu ->machine ->virtualservers ->UserInfo;
		appname = strtok(usinfo.appname, "/");
		if(cpu ->opt_detectmemsize)
		{
			detectmemsize(cpu);
			exit(0);
		}
		if(cpu ->opt_detectstream)
		{
			detectstream(cpu);
			analizestream(cpu);
			exit(-1);
		}
		if(cpu ->opt_traceplot)	
		{
			stat_plot(cpu);		
			exit(-1);
		}
		if(cpu->opt_statrate)
		{
			stat_rate(cpu);
			exit(-1);
		}
		if(cpu ->opt_fastmem)
		{
			cpu ->machine ->cache ->fast_mem_start();			
			stepfp = fopen("step.txt", "w");
			fast_mem(cpu);
			cpu ->machine ->cache ->fast_mem_end();
			exit(-1);		
		}
		if(cpu ->opt_posttrace)	
		{
			showPostTrace(cpu);
			stat_percent(cpu);
			exit(-1);
		}
		if(cpu ->opt_tracetofile)
		{						
			gzFile fp;
			char buf[64];
			sprintf(buf, "%s_rec_data.gz", appname);	
			if((fp = gzopen(buf, "wb")) == NULL)
				fatal_error("can't open %s file for write", buf);
			flist[0] = fp;
		}		
	}
	return rc;
}
int DBGTracer::traceoff(CPU * cpu) {
	int i;
	uint64 tmp1,tmp2;
	if( tracing) {
			 cpu->memstat ->TraceEnd();
			tracing = 0;
			fprintf(stderr, "tracer off .................\n");
			fprintf(stderr, "+-----------------------------------------------+\n");
			fprintf(stderr, "Clock steps: %lld\n",cpu->machine->num_instrs - trcVar[15]);
			tmp1 = cpu ->memstat ->dcache_miss_times;
			for (i = 0; i < cpu ->memstat ->cache_lev; i ++)
			{
				tmp2 = cpu ->memstat ->dcache_hit_times[i];
				fprintf(stderr, "%dst level data cache hit %u times\n", i, tmp2);
				tmp1 += tmp2;
			}
			fprintf(stderr, "total data cache referenced: %u\n", tmp1);
			fprintf(stderr, "total data cache miss %llu times\n", cpu ->memstat ->dcache_miss_times);
			fprintf(stderr, "total data pbuf miss %u times\n", cpu ->memstat ->pbuf_miss_times);
/*
			fprintf(stderr, "TLB hit %llu times\t TLB miss %llu times\n", cpu->memstat->tlb_hit_times, cpu->memstat->tlb_miss_times);

			fprintf(stderr, "\nCache hitted times:\n");

			for(i=0;i<cpu ->memstat ->cache_lev;i++)
				fprintf(stderr, "cache level %d hitted:  i: %lld times d:%lld times \n",
					i,cpu ->memstat ->dcache_hit_times[i],cpu ->memstat ->icache_hit_times[i]);
//			tmp = cpu->memstat->dcache_miss_times + cpu->memstat->icache_miss_times;
			fprintf(stderr, "icache missed %lld times, dcache missed %lld times\n", 
				cpu->memstat->icache_miss_times,cpu->memstat->dcache_miss_times);
*/

			fprintf(stderr, "+-----------------------------------------------+\n");			
			if(flist[0]) 
				gzclose(flist[0]); // sync log data to file
			if(stepfp)
				fclose(stepfp);			
			return 0;
		}
	else return 1;
}
#define PAGE_NUM 	65536
void 
DBGTracer::detectmemsize(CPU * cpu)
{
	
	gzFile gzfile;
	char buf[64];
	uint8 tracebuf[128];
	uint32 page[PAGE_NUM], i;
	uint32 memsize;
	STAT_INFO stat_info;		
	int len = cpu ->memstat ->SetTraceMask(tracemask[0]);
	sprintf(buf, "%s_rec_data.gz", appname);	
	gzfile = gzopen(buf, "rb");
	if(gzfile == NULL)
		fatal_error("can't open %s file for read", buf);
	for(i = 0; i < PAGE_NUM; i ++)
		page[i] = 0;
	while(gzread(gzfile, tracebuf, len) == len)
	{
		recovertrace(tracemask[0], tracebuf, stat_info);
		i = stat_info.addr / 4096;
		page[i] = 1;
	}
	gzclose(gzfile);
	memsize = 0;
	for(i = 0; i < PAGE_NUM; i ++)
		if(page[i] == 1)
			memsize += 4096;
	printf("%s used %u byte physics memory.\n", appname, memsize);

}
void
DBGTracer::detectstream(CPU * cpu)
{
	gzFile gzfile;
	char buf[64];
	uint64 tmpcounter;
	uint8 tracebuf[128];
	STAT_INFO stat_info;	
	int i, row, col, tmp;
	bool found;
	uint64 clkgap1, clkgap2, instgap1, instgap2;
	int len = cpu ->memstat ->SetTraceMask(tracemask[0]);
	sprintf(buf, "%s_rec_data.gz", appname);	
	gzfile = gzopen(buf, "rb");
	if(gzfile == NULL)
		fatal_error("can't open %s file for read", buf);
	streamtable *tableptr, *table = (streamtable *)malloc(sizeof(streamtable));
	streamtable *p;
	table ->next = NULL;	
	streampool pool;
	for(i = 0; i < WINSIZE; i ++)
		pool.valid[i] = false;
	pool.index = 0;
	while(gzread(gzfile, tracebuf, len) == len)
	{
		recovertrace(tracemask[0], tracebuf, stat_info);		
/*		if(stat_info.addr == 0x42d8400)
			printf("%llu\t",stat_info.counter);
		if(stat_info.addr == 0x42db800)
			printf("%llu\t",stat_info.counter);
		if(stat_info.addr == 0x42ded00)
			printf("%llu\n",stat_info.counter);
*/
//		if(!stat_info.boolval.val.inst_or_data)
//		{
			/*search for stream table*/
			found = false;
			tableptr = table ->next;
			p = table;
			while(tableptr != NULL)
			{
				tmpcounter = 0;
				if(tableptr ->index == stat_info.addr)
				{
					instgap1 = stat_info.counter - tableptr ->end_clock;
					if(instgap1 <= 5 * tableptr ->instgap)
					{
						found = true;						
						tableptr ->num ++;
						tableptr ->index += tableptr ->stride;	
					
						tableptr ->end_clock = stat_info.counter;
						tableptr ->instgap = (tableptr ->end_clock - tableptr ->start_clock) / (tableptr ->num - 1);
					
						tableptr ->squinstgap += instgap1*instgap1;
						if(instgap1 < tableptr ->mininstgap)
							tableptr ->mininstgap = instgap1;
						if(instgap1 > tableptr ->maxinstgap)
							tableptr ->maxinstgap = instgap1;					
						tableptr ->devinstgap = tableptr ->squinstgap - (tableptr ->num - 1) * tableptr ->instgap * tableptr ->instgap;
						tableptr ->devinstgap = (uint64)sqrt(tableptr ->devinstgap / (tableptr ->num - 1));

						clkgap1 = (stat_info.fc_hit_times - tableptr ->fc_hit_times) * L1DELAY +
										(stat_info.sc_hit_times - tableptr ->sc_hit_times) * L2DELAY +
										(stat_info.cache_miss_times - tableptr ->cache_miss_times ) * MDELAY + 
										tableptr ->end_clock - tableptr ->start_clock
										- (tableptr ->num - 2) * tableptr ->clockgap;
						if(tableptr ->minclkgap > clkgap1)
							tableptr ->minclkgap = clkgap1;
						if(tableptr ->maxclkgap < clkgap1)
							tableptr ->maxclkgap = clkgap1;
						tableptr ->squclkgap += clkgap1 * clkgap1;
						tableptr ->clockgap = ((tableptr ->num - 2) * tableptr ->clockgap + clkgap1) / (tableptr ->num - 1);
						tableptr ->devclkgap = tableptr ->squclkgap - (tableptr ->num - 1) * tableptr ->clockgap * tableptr ->clockgap;
						tableptr ->devclkgap = (uint64)sqrt(tableptr ->devclkgap / (tableptr ->num - 1));					
					}
					p->next = tableptr->next;
					tableptr->next = table->next;
					table->next = tableptr;	
					break;
				}		
				p = tableptr;
				tableptr = tableptr ->next;								tmpcounter++;
				if(tmpcounter >= 10000)
				{
					printf("search stopped\n");
					break;	
				}
			}			
			if(found)
				continue;
			
			/*not found in stream table, now search in the pool*/			
			pool.head[pool.index] = stat_info.addr;
			pool.valid[pool.index] = true;
			pool.counter[pool.index] = stat_info.counter;
			pool.fc_hit_times[pool.index] = stat_info.fc_hit_times;
			pool.sc_hit_times[pool.index] = stat_info.sc_hit_times;
			pool.cache_miss_times[pool.index] = stat_info.cache_miss_times;
			for(i = 0; i < WINSIZE - 1; i ++)
			{
			/*	if( i == pool.index)
					continue;*/
				if( i < pool.index)
					col = pool.index - i - 1;
				else
					col = WINSIZE -1 - (i - pool.index);
				if(!pool.valid[col])
					continue;				
				pool.array[i][pool.index] = pool.head[pool.index] - pool.head[col];				
				for(row = 0; row < WINSIZE - 1; row ++)
				{
					if(pool.array[row][col] == pool.array[i][pool.index])
					{
						tmp = col - row - 1;
						if(tmp < 0)
							tmp += WINSIZE;
						if(tmp < pool.index || tmp >col)
							continue;
						if(!pool.valid[tmp] || tmp == pool.index)
							continue;
						found = true;					
/*	*/						
						pool.valid[pool.index] = false;
						pool.valid[col] = false;						
						pool.valid[tmp] = false;
						/*add to the stream table*/
						tableptr = (streamtable*)malloc(sizeof(streamtable));
						
						tableptr ->strart_addr = pool.head[tmp];
						tableptr ->stride = pool.head[pool.index] - pool.head[col];
						tableptr ->num = 3;
						tableptr ->index = pool.head[pool.index] + tableptr ->stride;
						tableptr ->start_clock = pool.counter[tmp];
						tableptr ->end_clock = pool.counter[pool.index];
						tableptr ->fc_hit_times = pool.fc_hit_times[tmp];
						tableptr ->sc_hit_times = pool.sc_hit_times[tmp];
						tableptr ->cache_miss_times = pool.cache_miss_times[tmp];

						
						
						instgap1 = pool.counter[pool.index] - pool.counter[col];
						instgap2 = pool.counter[col] - pool.counter[tmp];
						if(instgap1 > instgap2)
						{
							tableptr ->maxinstgap = instgap1;
							tableptr ->mininstgap = instgap2;
						}
						else
						{
							tableptr ->maxinstgap = instgap2;
							tableptr ->mininstgap = instgap1;
						}
						tableptr ->squinstgap = instgap1 * instgap1 + instgap2 *instgap2;	
/*						if(tableptr ->strart_addr == 0x4046008 && tableptr ->start_clock == 270227345)
							{
							printf("%llu\t%llu\t%llu\n", pool.counter[tmp], pool.counter[col], pool.counter[pool.index]);
							printf("%8d\t%8d\t%8d\n", tmp, col, pool.index);
							printf("%x\t%x\t%x\n", pool.head[tmp], pool.head[col], pool.head[pool.index]);
							printf("%x\n", tableptr ->index);

							printf("instgap1:%llu,instgap2:%llu,squinstgap:%llu\n", instgap1, instgap2, tableptr ->squinstgap);
							}
*/						
						tableptr ->instgap = (pool.counter[pool.index] - pool.counter[tmp]) / 2;
						tableptr ->devinstgap = tableptr ->squinstgap - 2 * tableptr ->instgap * tableptr ->instgap;
						tableptr ->devinstgap = (uint64)sqrt(tableptr ->devinstgap / 2);

						tableptr ->clockgap = (pool.fc_hit_times[pool.index] - pool.fc_hit_times[tmp]) * L1DELAY
										+ (pool.sc_hit_times[pool.index] - pool.sc_hit_times[tmp]) * L2DELAY
										+ (pool.cache_miss_times[pool.index] - pool.cache_miss_times[tmp]) * MDELAY;
						tableptr ->clockgap = (tableptr ->clockgap + pool.counter[pool.index] - pool.counter[tmp]) / 2;
						clkgap1 = (pool.fc_hit_times[pool.index] - pool.fc_hit_times[col]) * L1DELAY
										+ (pool.sc_hit_times[pool.index] - pool.sc_hit_times[col]) * L2DELAY
										+ (pool.cache_miss_times[pool.index] - pool.cache_miss_times[col]) * MDELAY+
										pool.counter[pool.index] - pool.counter[col];
						clkgap2 = (pool.fc_hit_times[col] - pool.fc_hit_times[tmp]) * L1DELAY
										+ (pool.sc_hit_times[col] - pool.sc_hit_times[tmp]) * L2DELAY
										+ (pool.cache_miss_times[col] - pool.cache_miss_times[tmp]) * MDELAY +
										pool.counter[col] - pool.counter[tmp];
						tableptr ->maxclkgap = clkgap1>clkgap2?clkgap1:clkgap2;
						tableptr ->minclkgap = clkgap1<clkgap2?clkgap1:clkgap2;
						tableptr ->squclkgap = clkgap1 * clkgap1 + clkgap2 *clkgap2;
 						tableptr ->devclkgap = tableptr ->squclkgap -	2 * tableptr ->clockgap * tableptr ->clockgap;				
						tableptr ->devclkgap = (uint64)sqrt(tableptr ->devclkgap / 2);

						tableptr ->next = table ->next;
						table ->next = tableptr;
						/*add ends*/
						break;
					}					
				}
				if(found)
					break;				
			}
			pool.index ++;
			if(pool.index >= WINSIZE)
				pool.index = 0;

//		}		
	}
	gzclose(gzfile);
	tableptr = table ->next;
	i = 1;
	float inst_percent, clk_percent;
	FILE*fp = fopen("stream.txt", "w");
	while(tableptr)
		{
//		if(tableptr ->num >3)
			inst_percent = tableptr ->devinstgap / tableptr ->instgap;
			clk_percent = tableptr ->devclkgap / tableptr ->clockgap;
			fprintf(fp, "%dst:  str_clock:%llu\tend_clock:%llu\tstr_addr:0x%x  \tstride:%d\tlenght:%d\ninstgap:%llu\tmax instgap:%u\tmin instgap:%u\tdev instgap:%f\tinst percent:%f\nclkgap:%llu\tmax clkgap:%u\tmin clkgap:%u\tdev clkgap:%f\t clk percent:%f\n", 
				i++, tableptr ->start_clock, tableptr ->end_clock,tableptr ->strart_addr,tableptr ->stride, tableptr ->num,
				tableptr ->instgap, tableptr ->maxinstgap, tableptr ->mininstgap, tableptr ->devinstgap, inst_percent,
				tableptr ->clockgap, tableptr ->maxclkgap, tableptr ->minclkgap, tableptr ->devclkgap, clk_percent);
		tableptr = tableptr ->next;
		}
	
	fclose(fp);
}
void
DBGTracer::analizestream(CPU* cpu)
{
	FILE* fp = fopen("stream.txt", "r");
	int i, stride ;
	uint32 str_addr, num;
	uint32 total, hit, miss, streamele;
	uint64 str_clk, end_clk, instgap, clkgap;
	uint32 maxinstgap, mininstgap, maxclkgap, minclkgap;
	float devinstgap, devclkgap, inst_percent, clk_percent;;
	if(fp == NULL)
		fatal_error("can't open stream.txt for read, aborted\n");
	total = 0;
	hit = 0;
	miss = 0;
	streamele = 0;
	while (!feof(fp))
	{
		fscanf(fp, "%dst:  str_clock:%llu\tend_clock:%llu\tstr_addr:0x%x  \tstride:%d\tlenght:%d\ninstgap:%llu\tmax instgap:%u\tmin instgap:%u\tdev instgap:%f\tinst percent:%f\nclkgap:%llu\tmax clkgap:%u\tmin clkgap:%u\tdev clkgap:%f\t clk percent:%f\n",
			&i, &str_clk, &end_clk, &str_addr, &stride, &num, 
			&instgap,&maxinstgap, &mininstgap, &devinstgap, &inst_percent,
			&clkgap, &maxclkgap, &minclkgap, &devclkgap, &clk_percent);		
		hit += num - 3;
		streamele += num;
		miss ++;
	}
	fclose(fp);
	
	gzFile gzfp;
	int len = cpu->memstat->SetTraceMask(tracemask[0]);
	char buf[64];
	uint8 tracebuf[128];
	sprintf(buf, "%s_rec_data.gz", appname);
	if((gzfp = gzopen(buf, "rb")) == NULL)
		fatal_error("can't open %s file for read", buf);
	while(gzread(gzfp, tracebuf, len) == len) 
	 	total ++;
	gzclose(gzfp);
	printf("total referenced: %u\n", total);
	printf("total stream element number: %u\n", streamele);
	printf("total stream number: %u\n", miss);
	printf("prefetch hitted: %u\n", hit);
	printf("prefetch wasted: %u\n", miss);	
}
void 
DBGTracer::showPostTrace(CPU * cpu) 
{	
	
      int len = cpu->memstat->SetTraceMask(tracemask[0]);
	long long count = 0;
	static int limit = 0;
	STAT_INFO stat_info;
	uint8 tracebuf[128];
	gzFile fp;
	char buf[64];
	sprintf(buf, "%s_rec_data.gz", appname);	
	if((fp = gzopen(buf, "rb")) == NULL)
		fatal_error("can't open %s file for read", buf);
     while(gzread(fp, tracebuf, len) == len) 
	{		
    		recovertrace(tracemask[0], tracebuf, stat_info);			
    		if(limit <= 10)
			cpu->memstat->ShowTrace(tracemask[0],stat_info);
	    	count ++;
		limit ++;
		
    	}	
	fprintf(stderr, "%Ld records showed\n",count);
	fprintf(stderr, "---------------End of trace-----------------------\n");
	gzclose(fp);
}
void DBGTracer::stat_percent(CPU	* cpu)
{	
	uint64  inst_count = 0, data_count = 0 , total_count;	
	int len = cpu ->memstat ->SetTraceMask(tracemask[0]);
	STAT_INFO stat_info;
	uint8 tracebuf[128];
	gzFile fp;
	char buf[64];
	sprintf(buf, "%s_rec_data.gz", appname);	
	if((fp = gzopen(buf, "rb")) == NULL)
		fatal_error("can't open %s file for read", buf);
	while(gzread(fp, tracebuf, len) == len) 
      {		
	    	recovertrace(tracemask[0], tracebuf, stat_info);	
		if(stat_info.boolval.val.inst_or_data)
			inst_count ++;
		else  
			data_count ++;
    	}
	total_count = data_count + inst_count;	
	fprintf(stderr,"inst accessed %llu times, account for %4.2f%%\n", inst_count, (1.0 * inst_count /total_count) *100);
	fprintf(stderr, "data accessed %llu times, account for %4.2f%%\n", data_count, (1.0 * data_count /total_count) * 100);
	gzclose(fp);

}
void
DBGTracer::stat_rate(CPU * cpu)
{	
	uint32 addr;	
	FILE *tmpfp1, *tmpfp2, *tmpfp3, * tmpfp4, *tmpfp5;	
	uint64 code_arr[PAGE_NUM], data_arr[PAGE_NUM], brk_arr[PAGE_NUM], stack_arr[PAGE_NUM], mmap_arr[PAGE_NUM];
	char buf1[128], buf2[128], buf3[128], buf4[128], buf5[128];

	uint32 codesegbase = usinfo.usermmmapping.codeseg.physbase;
	uint32 codesegsize = usinfo.usermmmapping.codeseg.size;
	uint32 datasegbase = usinfo.usermmmapping.dataseg.physbase;
	uint32 datasegsize = usinfo.usermmmapping.dataseg.size;
	uint32 stackbase = usinfo.usermmmapping.stackseg.physbase;
	uint32 stacksize = usinfo.usermmmapping.stackseg.size;
	uint32 brkbase = usinfo.usermmmapping.brk_dynamic.physbase;
	uint32 brksize = usinfo.usermmmapping.brk_dynamic.size;
	uint32 mmmapbase = usinfo.usermmmapping.mmmap_dynamic.physbase;
	uint32 mmmapsize = usinfo.usermmmapping.mmmap_dynamic.size;
	fprintf(stderr, "app name:%s\n", appname);
	fprintf(stderr, "code seg base:0x%x\n", codesegbase);
	fprintf(stderr, "code seg size:0x%x\n", codesegsize);
	fprintf(stderr, "data seg base:0x%x\n", datasegbase);
	fprintf(stderr, "data seg size:0x%x\n", datasegsize);
	fprintf(stderr, "stack base:0x%x\n", stackbase);
	fprintf(stderr, "stack size:0x%x\n", stacksize);
	fprintf(stderr, "brk dynamic base:0x%x\n", brkbase);
	fprintf(stderr, "brk dynamic size:0x%x\n", brksize);
	fprintf(stderr, "mmmap dynamic base:0x%x\n", mmmapbase);
	fprintf(stderr, "mmmap dynamic size:0x%x\n", mmmapsize);
	
	sprintf(buf1, "%sdataseg.txt", appname);
	sprintf(buf2, "%sstack.txt", appname);
	sprintf(buf3, "%sbrk.txt", appname);
	sprintf(buf4, "%smmmap.txt", appname);
	sprintf(buf5, "%scodeseg.txt", appname);
	
	tmpfp1 = fopen(buf1, "w");	
	tmpfp2 = fopen (buf2, "w");
	tmpfp3 = fopen(buf3, "w");	
	tmpfp4 = fopen(buf4, "w");
	tmpfp5 = fopen(buf5, "w");
	int m;
	for( m = 0; m < PAGE_NUM; m ++)
	{
		code_arr[m] = 0;
		data_arr[m] = 0;
		brk_arr[m] = 0;
		mmap_arr[m] = 0;
		stack_arr[m] = 0;		
	}

	STAT_INFO stat_info;
	uint8 tracebuf[128];
	int len = cpu ->memstat ->SetTraceMask(tracemask[0]);
	gzFile fp;
	char tmpbuf[64];				
	sprintf(tmpbuf, "%s_plot_data.gz", appname);	
	if((fp = gzopen(tmpbuf, "rb")) == NULL)
		fatal_error("can't open %s file for read", tmpbuf);			
	while(gzread(fp, tracebuf, len) == len) 
      {		
	    	recovertrace(tracemask[0], tracebuf, stat_info);
		addr = stat_info.addr & PAGE_MASK;
		int index = addr / PAGESIZE;
		if(stat_info.boolval.val.inst_or_data)
		{
			if(addr >= codesegbase && addr <= codesegbase + codesegsize)
				code_arr[index]++;
		}
		else
		{
			if(addr >= datasegbase && addr <= datasegbase + datasegsize)
				data_arr[index]++;
			if(addr <= stackbase && addr >= stackbase - stacksize)
				stack_arr[index]++;
			if(addr >= brkbase && addr <= brkbase + brksize)
				brk_arr[index]++;
			if(addr >= mmmapbase && addr <= mmmapbase + mmmapsize)
				mmap_arr[index]++;
		}
	}	
	for(m = 0; m < PAGE_NUM; m ++)
	{
		if(code_arr[m] > 0)
		{
			addr = code_arr[m] * PAGESIZE;
			fprintf(tmpfp5, "addr:0x%x\t%llu\n", addr, code_arr[m]);
		}
		if(data_arr[m] > 0)
		{
			addr = data_arr[m] * PAGESIZE;
			fprintf(tmpfp1, "addr:0x%x\t%llu\n", addr, data_arr[m]);
		}
		if(stack_arr[m] > 0)
		{
			addr = stack_arr[m] * PAGESIZE;
			fprintf(tmpfp2, "addr:0x%x\t%llu\n", addr, stack_arr[m]);
		}
		if(brk_arr[m] > 0)
		{
			addr = brk_arr[m] * PAGESIZE;
			fprintf(tmpfp3, "addr:0x%x\t%llu\n", addr, brk_arr[m]);			
		}
		if(mmap_arr[m] > 0)
		{
			addr = mmap_arr[m] * PAGESIZE;
			fprintf(tmpfp4, "addr:0x%x\t%llu\n", addr, mmap_arr[m]);			
		}
	}
	fclose(tmpfp1);
	fclose(tmpfp2);
	fclose(tmpfp3);
	fclose(tmpfp4);
	fclose(tmpfp5);
}
void 
DBGTracer::stat_plot(CPU *cpu)
{		
	uint32 addr;	
	FILE *tmpfp1, *tmpfp2, *tmpfp3, * tmpfp4, *tmpfp5;	
	uint32 last_data = 0, last_stack = 0, last_brk = 0, last_mmmap = 0, last_code = 0;
	uint32 datanum = 0, stacknum = 0, brknum = 0, mmmapnum = 0, codenum = 0;;
	uint32 datacount = 0, stackcount = 0, brkcount = 0, mmmapcount = 0, codecount = 0;
	char buf[128];
	uint64 mycounter = 0;
	char buf1[128], buf2[128], buf3[128], buf4[128], buf5[128];

	uint32 codesegbase = usinfo.usermmmapping.codeseg.physbase;
	uint32 codesegsize = usinfo.usermmmapping.codeseg.size;
	uint32 datasegbase = usinfo.usermmmapping.dataseg.physbase;
	uint32 datasegsize = usinfo.usermmmapping.dataseg.size;
	uint32 stackbase = usinfo.usermmmapping.stackseg.physbase;
	uint32 stacksize = usinfo.usermmmapping.stackseg.size;
	uint32 brkbase = usinfo.usermmmapping.brk_dynamic.physbase;
	uint32 brksize = usinfo.usermmmapping.brk_dynamic.size;
	uint32 mmmapbase = usinfo.usermmmapping.mmmap_dynamic.physbase;
	uint32 mmmapsize = usinfo.usermmmapping.mmmap_dynamic.size;
	fprintf(stderr, "app name:%s\n", appname);
	fprintf(stderr, "code seg base:0x%x\n", codesegbase);
	fprintf(stderr, "code seg size:0x%x\n", codesegsize);
	fprintf(stderr, "data seg base:0x%x\n", datasegbase);
	fprintf(stderr, "data seg size:0x%x\n", datasegsize);
	fprintf(stderr, "stack base:0x%x\n", stackbase);
	fprintf(stderr, "stack size:0x%x\n", stacksize);
	fprintf(stderr, "brk dynamic base:0x%x\n", brkbase);
	fprintf(stderr, "brk dynamic size:0x%x\n", brksize);
	fprintf(stderr, "mmmap dynamic base:0x%x\n", mmmapbase);
	fprintf(stderr, "mmmap dynamic size:0x%x\n", mmmapsize);
	
	sprintf(buf1, "%sdataseg.txt", appname);
	sprintf(buf2, "%sstack.txt", appname);
	sprintf(buf3, "%sbrk.txt", appname);
	sprintf(buf4, "%smmmap.txt", appname);
	sprintf(buf5, "%scodeseg.txt", appname);
	
	tmpfp1 = fopen(buf1, "w");	
	tmpfp2 = fopen (buf2, "w");
	tmpfp3 = fopen(buf3, "w");	
	tmpfp4 = fopen(buf4, "w");
	tmpfp5 = fopen(buf5, "w");

	STAT_INFO stat_info;
	uint8 tracebuf[128];
	int len = cpu ->memstat ->SetTraceMask(tracemask[0]);
	gzFile fp;
	char tmpbuf[64];				
	sprintf(tmpbuf, "%s_plot_data.gz", appname);	
	if((fp = gzopen(tmpbuf, "rb")) == NULL)
		fatal_error("can't open %s file for read", tmpbuf);			
	while(gzread(fp, tracebuf, len) == len) 
      {		
	    	recovertrace(tracemask[0], tracebuf, stat_info);
		addr = stat_info.addr & PAGE_MASK;
		mycounter ++;
		if(stat_info.boolval.val.inst_or_data)
		{
			if(addr >= codesegbase && addr <= codesegbase + codesegsize)
				if((addr / STEPGAP) != (last_code / STEPGAP))
//				if(addr != last_code)
				{
					last_code = addr;
					codecount ++;
					#ifdef COMPACT
					fprintf(tmpfp5, "%u\t%u\n", codecount, addr);
					if(codecount % 1024 == 0)
					#else
					fprintf(tmpfp5, "%llu\t%u\n", mycounter, addr);
					if(mycounter % 1024 == 0)
					#endif										
					{
						#ifndef PLOTONE
						codenum ++;
						fclose(tmpfp5);
						sprintf(buf, "../statplotpl %scodeseg.txt %scode %04d", appname, appname, codenum);
						system(buf);
						tmpfp5 = fopen(buf5, "w");
						#endif
					}	
					
				}
		}
		else
		{
			if(addr >= datasegbase && addr <= datasegbase + datasegsize)
				if(addr / STEPGAP != last_data / STEPGAP)
//				if(addr != last_data);
				{
					last_data = addr;
					datacount ++;
					#ifdef COMPACT
					fprintf(tmpfp1, "%u\t%u\n", datacount, addr);
					if(datacount % 1024 == 0)
					#else
					fprintf(tmpfp1, "%llu\t%u\n", mycounter, addr);
					if(mycounter % 1024 == 0)
					#endif					
					{
						#ifndef PLOTONE					
						datanum ++;
						fclose(tmpfp1);
						sprintf(buf, "../statplotpl %sdataseg.txt %sdata %04d", appname, appname, datanum);
						system(buf);
						tmpfp1 = fopen(buf1, "w");
						#endif
					}						
				}
			if(addr <= stackbase && addr >= stackbase - stacksize)
				if(addr / STEPGAP != last_stack / STEPGAP)
//				if(addr != last_stack)
				{
					last_stack = addr;
					stackcount ++;
					#ifdef COMPACT					
					fprintf(tmpfp2, "%u\t%u\n", stackcount, addr);
					if(stackcount % 1024 == 0)
					#else
					fprintf(tmpfp2, "%llu\t%u\n", mycounter, addr);
					if(mycounter % 1024 == 0)
					#endif					
					{
						#ifndef PLOTONE
						stacknum ++;
						fclose(tmpfp2);
						sprintf(buf, "../statplotpl %sstack.txt %sstack %04d", appname, appname, stacknum);		
						system(buf);
						tmpfp2 = fopen(buf2, "w");
						#endif
					}
					
				}
			if(addr >= brkbase && addr <= brkbase + brksize)
				if(addr / STEPGAP != last_brk / STEPGAP)
//				if(addr != last_brk)
				{
					last_brk= addr;
					brkcount ++;
					#ifdef COMPACT
					fprintf(tmpfp3, "%u\t%u\n", brkcount, addr);
					if(brkcount % 1024 == 0)
					#else
					fprintf(tmpfp3, "%llu\t%u\n", mycounter, addr);
					if(mycounter % 1024 == 0)
					#endif					
					{
						#ifndef PLOTONE
						brknum ++;					
						fclose(tmpfp3);				
						sprintf(buf, "../statplotpl %sbrk.txt %sbrk %04d", appname, appname,  brknum);					
						system(buf);					
						tmpfp3 = fopen(buf3, "w");
						#endif
					}
					
				}
			if(addr >= mmmapbase && addr <= mmmapbase + mmmapsize)
				if(addr / STEPGAP != last_mmmap/ STEPGAP)
				if(addr != last_mmmap)
				{
					last_mmmap= addr;
					mmmapcount ++;
					#ifdef COMPACT
					fprintf(tmpfp4, "%u\t%u\n", mmmapcount, addr);
					if(mmmapcount % 1024 == 0)
					#else
					fprintf(tmpfp4, "%llu\t%u\n", mycounter, addr);
					if(mycounter% 1024 == 0)
					#endif					
					if(mmmapcount % 1024 == 0)
					{
						#ifndef PLOTONE
						mmmapnum ++;					
						fclose(tmpfp4);				
						sprintf(buf, "../statplotpl %smmmap.txt %smmmap %04d",  appname, appname, mmmapnum);				
						system(buf);					
						tmpfp4 = fopen(buf4, "w");
						#endif
					}
					
				}
		}

	}	
	if (ftell(tmpfp5) !=  0)
	{
		fclose(tmpfp5);
		sprintf(buf, "../statplotpl %scodeseg.txt %scode %04d", appname, appname, codenum);
		system(buf);
	}
	if(ftell(tmpfp1) != 0)
	{
		fclose(tmpfp1);
		sprintf(buf, "../statplotpl %sdataseg.txt %sdata %04d", appname, appname, datanum);
		system(buf);
	}
	if(ftell(tmpfp2) != 0)
	{
		fclose(tmpfp2);
		sprintf(buf, "../statplotpl %sstack.txt %sstack %04d", appname, appname,  stacknum);		
		system(buf);
	}
	if(ftell(tmpfp3) != 0)
	{
		fclose(tmpfp3);
		sprintf(buf, "../statplotpl %sbrk.txt %sbrk %04d",  appname, appname, brknum);					
		system(buf);	
	}
	if(ftell(tmpfp4) != 0)
	{
		fclose(tmpfp4);
		sprintf(buf, "../statplotpl %smmmap.txt %smmmap %04d" , appname, appname,  mmmapnum);				
		system(buf);	
	}
	gzclose(fp);	
/*	remove(buf1);
	remove(buf2);
	remove(buf3);
	remove(buf4);
	remove(buf5);
*/
}
void
DBGTracer::fast_mem(CPU *cpu)
{
	STAT_INFO stat_info;
	uint8 delay_time;
	uint8 tracebuf[128];
	int32 mode;
	uint32 data, addr;
	int len = cpu ->memstat ->SetTraceMask(tracemask[0]);
	CACHE* cache = cpu ->machine ->cache;
	char buf[64];
	gzFile fp, fp1;
	sprintf(buf, "%s_rec_data.gz", appname);	
	if((fp = gzopen(buf, "rb")) == NULL)
		fatal_error("can't open %s file for read", buf);
	sprintf(buf, "%s_plot_data.gz", appname);	
	if((fp1 = gzopen(buf, "wb")) == NULL)
		fatal_error("can't open %s file for write", buf );
	flist[0] = fp1;
	while(gzread(fp, tracebuf, len) == len) 
      {		
//	    	recovertrace(tracemask[0], tracebuf, stat_info);
		stepcounter ++;
		stat_info.boolval.content = *(uint16*)tracebuf;
		stat_info.addr = *(uint32*)(tracebuf + 2);
		if(stat_info.boolval.val.inst_or_data)
		{
			addr = stat_info.addr;
			mode = INSTFETCH;
		}
		else
		{
			addr = stat_info.addr;
			if(stat_info.boolval.val.read_or_write)
				mode = DATALOAD;
			else
				mode = DATASTORE;
		}	
		if(stat_info.boolval.val.cacheinv)
			cache ->invalidate(addr, 1, false);
		if(stat_info.boolval.val.read_or_write)
			cache ->read(addr, mode, &data, &delay_time);
		else
			cache ->write(addr, mode,data, &delay_time);
			
	}
	gzclose(fp1);
	gzclose(fp);
}

