#include "Configuration.h"
#include "tm-include.h"
#include "TMHal.h"

//#ifdef REMOTESYSCALL

void HandlingrsLinuxSyscall(ThreadId fromId,long syscallno, 
	ProcContextPtr contextPtr,long reserved,unsigned long int delayslot);


void HandleReturnValue(ProcContextPtr contextPtr,long ret);
void rsSysCallNotImplemented(ProcContextPtr contextPtr,long syscallno);
void rsSyscallCheatingRet(ProcContextPtr contextPtr,long syscallno,long ret);

void rsLinuxSyscallExit(ThreadId fromId,ProcContextPtr contextPtr,
	unsigned long int delayslot);//v0==4001
void rsLinuxSyscallRead(ProcContextPtr contextPtr);//v0==4003
void rsLinuxSyscallWrite(ProcContextPtr contextPtr);//v0==4004
void rsLinuxSyscallOpen(ProcContextPtr contextPtr);//v0==4005
void rsLinuxSyscallClose(ProcContextPtr contextPtr);//v0==4006
void rsLinuxSyscallunlink(ProcContextPtr contextPtr);//v0==4010
void rsLinuxSyscalltime(ProcContextPtr contextPtr);//v0==4013
void rsLinuxSyscalllseek(ProcContextPtr contextPtr);//v0==4019
void rsLinuxSyscallgetpid(ProcContextPtr contextPtr);//v0==4020
void rsLinuxSyscallgetuid(ProcContextPtr contextPtr);//v0==4024
void rsLinuxSyscallaccess(ProcContextPtr contextPtr);//v0==4033
void rsLinuxSyscallrename(ProcContextPtr contextPtr);//v0==4038
void rsLinuxSyscalltimes(ProcContextPtr contextPtr);//v0==4043
void rsLinuxSyscallbrk(ThreadId fromId,ProcContextPtr contextPtr,
	unsigned long int delayslot);//v0==4045
void rsLinuxSyscallgetgid(ProcContextPtr contextPtr);//v0==4047
void rsLinuxSyscallgeteuid(ProcContextPtr contextPtr);//v0==4049
void rsLinuxSyscallgetegid(ProcContextPtr contextPtr);//v0==4050
void rsLinuxSyscallioctl(ProcContextPtr contextPtr);//v0==4054
void rsLinuxSyscallfcntl(ProcContextPtr contextPtr);//v0==4055
void rsLinuxSyscallsetrlimit(ThreadId fromId,long syscallno,
	ProcContextPtr contextPtr,unsigned long int delayslot);//v0==4075
void rsLinuxSyscallgetrlimit(ProcContextPtr contextPtr);//v0==4076
void rsLinuxSyscallgetrusage(ProcContextPtr contextPtr);//v0==4077
void rsLinuxSyscallmmap(ThreadId fromId,ProcContextPtr contextPtr,
	unsigned long int delayslot);//v0==4090
void rsLinuxSyscallmunmap(ThreadId fromId,ProcContextPtr contextPtr,
	unsigned long int delayslot);//v0==4091
void rsLinuxSyscallftruncate(ProcContextPtr contextPtr);//v0==4093
void rsLinuxSyscallstat(ProcContextPtr contextPtr);//v0==4106
void rsLinuxSyscalllstat(ProcContextPtr contextPtr);//v0==4107
void rsLinuxSyscallfstat(ProcContextPtr contextPtr);//v0==4108
void rsLinuxSyscallnewuname(ProcContextPtr contextPtr);//v0==4122
void rsLinuxSyscallmprotect(ThreadId fromId,ProcContextPtr contextPtr,
	unsigned long int delayslot);//v0==4125
void rsLinuxSyscall_llseek(ProcContextPtr contextPtr);//v0==4140
void rsLinuxSyscall_newselect(ProcContextPtr contextPtr);//v0==4142
void rsLinuxSyscallnanosleep(ThreadId fromId,long syscallno,
	ProcContextPtr contextPtr,unsigned long int delayslot);//v0==4166
void rsLinuxSyscallrt_sigaction(ThreadId fromId,long syscallno,
	ProcContextPtr contextPtr,unsigned long int delayslot);//v0==4194
void rsLinuxSyscallrt_sigprocmask(ThreadId fromId,long syscallno,
	ProcContextPtr contextPtr,unsigned long int delayslot);//v0==4195
void rsLinuxSyscallmmap2(ThreadId fromId,ProcContextPtr contextPtr,
	unsigned long int delayslot);//v0==4210
void rsLinuxSyscallftruncate64(ProcContextPtr contextPtr);//v0==4212
void rsLinuxSyscallstat64(ProcContextPtr contextPtr);//v0==4213
void rsLinuxSyscalllstat64(ProcContextPtr contextPtr);//v0==4214
void rsLinuxSyscallfstat64(ProcContextPtr contextPtr);//v0==4215
void rsLinuxSyscallfcntl64(ProcContextPtr contextPtr);//v0==4220

//#endif

