/*  Definitions to support the float coprocessor.
  *  Copyright NCIC
  *
  * This file is part of Sand which originated from VMIP
  * add by zhangwl
*/

#include "excnames.h" // for exception defination
#include "clkcpone.h"
#include "pplstat.h"
#include <math.h>

typedef void (CLKCPONE::*emulate_funptr)(uint32, uint32);

CLKCPONE::CLKCPONE(CPU *m) 
	:CPOne((CPU *)m)//, CLKCPU()
{
	clkcpu = (CLKCPU*)m;
	fcr31flag = 0;
	for (int i = 0; i<16; i++)
		fregflag[i] = 0;
	fex_wb.tag = false;
	fex2_3.tag = false;
	fex1_2.tag = false;
	fid_ex.tag = false;
}

void
CLKCPONE::fpdecode(uint32 instr, uint32 pc)
{
	fid_ex.instr = instr;
	fid_ex.pc = pc;
	fmt = CPOne::format(instr);
	clkcpu->id_ex.fmt = fmt; //????
	fid_ex.fmt = fmt;
	if (fmt >= 0x10){
		fid_ex.funct = CPOne::funct(instr);// fmt > =0x10
		fid_ex.ftnum = ft(instr); 
	       fid_ex.fsnum  = fs(instr);
	       fid_ex.fdnum  = fd(instr);
	       if ((fid_ex.funct <= 0x03) || (fid_ex.funct >= 0x30))//fadd, fsub, fmul, fdiv and cmp
	       {
		       if ((fregflag[(fid_ex.ftnum)>>1] == 0) && (!(clkcpu->flaga)))
		       {
		       	fid_ex.ftctx = freg[fid_ex.ftnum>>1];
		       	clkcpu->flaga = true;
		       }
		       if ((fregflag[(fid_ex.fsnum)>>1] == 0) && (!(clkcpu->flagb)))
		       {
		       	fid_ex.fsctx = freg[fid_ex.fsnum>>1];
		       	clkcpu->flagb = true;
		       }
		       if (clkcpu->flaga && clkcpu->flagb)
		       {
				clkcpu->flaga = false;
				clkcpu->flagb = false;
		       	if (fid_ex.funct >= 0x30)//cmp instruction
		       		fcr31flag ++;
		       	else
					(fregflag[(fid_ex.fdnum)>>1])++;
				clkcpu->pl_state = true;
		       }
		       else 
		       	clkcpu->pl_state = false;
	       }
	       else if (fid_ex.funct == 0x24)//cvt.w
	       {
		       if ((fcr31flag == 0) && (!(clkcpu->flaga)))
		       {
		       	fid_ex.fcr31ctx = fcr31;
		       	clkcpu->flaga = true;
		       }
		       if ((fregflag[(fid_ex.fsnum)>>1] == 0) && (!(clkcpu->flagb)))
		       {
		       	fid_ex.fsctx = freg[(fid_ex.fsnum)>>1];
		       	clkcpu->flagb = true;
		       }
		       if (clkcpu->flaga && clkcpu->flagb)
		       {
				clkcpu->flaga = false;
				clkcpu->flagb = false;
				(fregflag[(fid_ex.fdnum)>>1]) ++;
				clkcpu->pl_state = true;
		       }
		       else 
		       	clkcpu->pl_state = false;

	       }
	       else{
		       if (fregflag[(fid_ex.fsnum)>>1] == 0) 
		       {
		       	fid_ex.fsctx = freg[(fid_ex.fsnum)>>1];
				(fregflag[(fid_ex.fdnum)>>1]) ++;
				clkcpu->pl_state = true;
		       }
		       else 
		       	clkcpu->pl_state = false;
	       }
	}
	else{// fmt <0x10
		clkcpu->id_ex.rt = ft(instr); 
	       clkcpu->id_ex.rs  = fs(instr);
	       switch (fmt){
			case F_bc_op: //bc1f, bc1t
				clkcpu->id_ex.imm = clkcpu->immed(instr);
				clkcpu->id_ex.s_imm = clkcpu->s_immed(instr);
				if (fcr31flag == 0)
				{
					fid_ex.fcr31ctx = fcr31;
					clkcpu->pl_state = true;					
				}
				else
					clkcpu->pl_state = false;
				break;
			case F_cfc_op:
				if (clkcpu->id_ex.rs == 31) {
					if (fcr31flag == 0)
					{
						fid_ex.fcr31ctx = fcr31;
						clkcpu->regflag[clkcpu->id_ex.rt] ++;
						clkcpu->pl_state = true;
						clkcpu->sucDocode = true;
					}
					else
						clkcpu->pl_state = false;
		        	 }
				break;
			case F_ctc_op:
				if (clkcpu->regflag[clkcpu->id_ex.rt] == 0)
				{
					clkcpu->id_ex.b =clkcpu->reg[clkcpu->id_ex.rt];
					fcr31flag ++;
					clkcpu->pl_state = true;
				}
				else 
					clkcpu->pl_state = false;				
				break;				
			case F_mfc_op:
				if (fregflag[(clkcpu->id_ex.rs)>>1] == 0)
				{
					clkcpu->id_ex.a = IntFGR(clkcpu->id_ex.rs);
					(clkcpu->regflag[clkcpu->id_ex.rt] )++;
					clkcpu->pl_state = true;
					clkcpu->sucDocode = true;
				}
				else
					clkcpu->pl_state = false;
				break;
			case F_mtc_op:
				if (clkcpu->regflag[clkcpu->id_ex.rt] == 0)
				{
					clkcpu->id_ex.b = clkcpu->reg[clkcpu->id_ex.rt];
					(fregflag[(clkcpu->id_ex.rs)>>1]) ++;
					clkcpu->pl_state = true;
					clkcpu->sucDocode = true;
				}
				else 
					clkcpu->pl_state = false;				
				break;	       	
	      }
	}
}

void 
CLKCPONE::cpone_clkemulate(uint32 instr, uint32 pc)
{
	if (fid_ex.fmt >= 0x10) {
		if (fid_ex.funct >= 0x30)
			fcmp_op_clkemulate(instr, pc);
		else
			fid_ex.tag = true;
		return;
	}
	switch(clkcpu->id_ex.fmt) {
		case F_bc_op:
			if( clkcpu->id_ex.rt & 01) { // bc1t
				if( (fid_ex.fcr31ctx) & F_CSR31_C) { //condition match 
					clkcpu->branch(pc);//instr, 
				}
				else if (clkcpu->id_ex.rt & 02 ) { //bc1tl skip next  inst
					clkcpu->pc += 4;
				}
			}
			else { //bc1f 
				if(!((fid_ex.fcr31ctx) & F_CSR31_C)) {// !match
						clkcpu->branch(pc);
				}
				else if (clkcpu->id_ex.rt & 02) {//bc1fl
						clkcpu->pc += 4;
				}
			}
			break;
		case F_cfc_op:
			if (clkcpu->id_ex.rs == 31) {
		            clkcpu->ex_mem.ALUoutput = fid_ex.fcr31ctx;
	         	}
			else 
	        	fundef_emulate(instr,pc); 
			break;
		case F_ctc_op:
			fcr31 = clkcpu->id_ex.b;
			if (fcr31flag != 0)
				fcr31flag --;
			break;
			
		case F_mfc_op:
			clkcpu->ex_mem.ALUoutput = clkcpu->id_ex.a;
			break;
		case F_mtc_op:
			clkcpu->ex_mem.ALUoutput = clkcpu->id_ex.b;
			break;
			
		case F_dmfc_op:
			fundef_emulate(instr,pc);
			break;
		case F_dmtc_op:
			fundef_emulate(instr,pc);
			break;
			
		default:
			fundef_emulate(instr,pc);
		break;
}


}

void
CLKCPONE::fex1()
{
	fex1_2 = fid_ex;
	fid_ex.tag = false;
	clkcpu->pplstat->SetStage(FEX1Mask);
}

void
CLKCPONE::fex2()
{
	fex2_3 = fex1_2;

	static const emulate_funptr opcodeJumpTable[] = {
		&CLKCPONE::fadd_clkemulate,&CLKCPONE::fsub_clkemulate,
		&CLKCPONE::fmul_clkemulate,&CLKCPONE::fdiv_clkemulate,
		&CLKCPONE::fsqrt_clkemulate,&CLKCPONE::fabs_clkemulate,
		&CLKCPONE::fmov_clkemulate,&CLKCPONE::fneg_clkemulate,
		&CLKCPONE::fround1_clkemulate,&CLKCPONE::ftrunc1_clkemulate,
		&CLKCPONE::fceill_clkemulate,&CLKCPONE::ffloorl_clkemulate,    /*0xa_emulate,0xb*/ 
		&CLKCPONE::fround_clkemulate,&CLKCPONE::ftrunc_clkemulate,
		&CLKCPONE::fceil_clkemulate,&CLKCPONE::ffloor_clkemulate,
		&CLKCPONE::fundef_emulate,&CLKCPONE::fmovc_clkemulate,
		&CLKCPONE::fmovz_clkemulate,&CLKCPONE::fmovn_clkemulate,
		&CLKCPONE::fundef_emulate,&CLKCPONE::frecip_clkemulate,
		&CLKCPONE::frsqrt_clkemulate,&CLKCPONE::fundef_emulate,    /*0x16_emulate,0x17*/
		&CLKCPONE::fundef_emulate,&CLKCPONE::fundef_emulate,
		&CLKCPONE::fundef_emulate,&CLKCPONE::fundef_emulate,
		&CLKCPONE::fundef_emulate,&CLKCPONE::fundef_emulate,
		&CLKCPONE::fundef_emulate,&CLKCPONE::fundef_emulate,
		&CLKCPONE::fcvts_clkemulate,&CLKCPONE::fcvtd_clkemulate,	  /*0x20_emulate,0x21*/
		&CLKCPONE::fcvte_clkemulate,&CLKCPONE::fundef_emulate,
		&CLKCPONE::fcvtw_clkemulate,&CLKCPONE:: fcvtl_clkemulate, 	  /*0x24_emulate,0x25*/
		&CLKCPONE::fundef_emulate,&CLKCPONE::fundef_emulate,
		&CLKCPONE::fundef_emulate,&CLKCPONE::fundef_emulate,
		&CLKCPONE::fundef_emulate,&CLKCPONE::fundef_emulate,
		&CLKCPONE::fundef_emulate,&CLKCPONE::fundef_emulate,
		&CLKCPONE::fundef_emulate,&CLKCPONE::fundef_emulate,
		&CLKCPONE::fcmp_op_clkemulate,&CLKCPONE::fcmp_op_clkemulate,	  /*0x30_emulate,0x31*/
		&CLKCPONE::fcmp_op_clkemulate,&CLKCPONE::fcmp_op_clkemulate,
		&CLKCPONE::fcmp_op_clkemulate,&CLKCPONE::fcmp_op_clkemulate,
		&CLKCPONE::fcmp_op_clkemulate,&CLKCPONE::fcmp_op_clkemulate,
		&CLKCPONE::fcmp_op_clkemulate,&CLKCPONE::fcmp_op_clkemulate,
		&CLKCPONE::fcmp_op_clkemulate,&CLKCPONE::fcmp_op_clkemulate,
		&CLKCPONE::fcmp_op_clkemulate,&CLKCPONE::fcmp_op_clkemulate,
		&CLKCPONE::fcmp_op_clkemulate,&CLKCPONE::fcmp_op_clkemulate    /*0x3e_emulate,0x3f*/
	};
	(this->*opcodeJumpTable[fex1_2.funct])(fex1_2.instr, fex1_2.pc);
	// note float point exception handling
	fex1_2.tag = false;
	clkcpu->pplstat->SetStage(FEX2Mask);
}

void
CLKCPONE::fex3()
{
	fex_wb = fex2_3;
	fex2_3.tag = false;
	clkcpu->pplstat->SetStage(FEX3Mask);
}

void
CLKCPONE::fwb()
{
       if (fex_wb.funct <= 0x07){
			if (fex_wb.fmt == FMT_S) {
				SingleFGR(fex_wb.fdnum) = fex_wb.ALUoutput.fr[(fex_wb.fdnum) & 1] ; //????
			}
			else{
				DoubleFGR(fex_wb.fdnum) = fex_wb.ALUoutput.dfr ;
			}
	}else if (fex_wb.funct <= 0x0b)
	{
		LongLongFGR(fex_wb.fdnum) = fex_wb.ALUoutput.llr;

	} else if (fex_wb.funct <= 0x0f)
	{
		IntFGR(fex_wb.fdnum) = fex_wb.ALUoutput.ir[(fex_wb.fdnum)&1];
	} 
	else if (fex_wb.funct == 0x20){
		SingleFGR(fex_wb.fdnum) = fex_wb.ALUoutput.fr[(fex_wb.fdnum) &1];
	}
	else if (fex_wb.funct == 0x21){
		DoubleFGR(fex_wb.fdnum) = fex_wb.ALUoutput.dfr;
	}
		
	else if (fex_wb.funct == 0x24){
		IntFGR(fex_wb.fdnum) = fex_wb.ALUoutput.ir[(fex_wb.fdnum)&1];	 
	} 
	
	if ((fregflag[(fex_wb.fdnum)>>1]) != 0)
		(fregflag[(fex_wb.fdnum)>>1]) --;
	fex_wb.tag = false;
	clkcpu->pplstat->SetStage(WBMask);
}

void
CLKCPONE::fadd_clkemulate(uint32 instr, uint32 pc)
{
	if(fex1_2.fmt == FMT_S) {
		fex2_3.ALUoutput.fr[(fex2_3.fdnum) &1] = fex1_2.fsctx.fr[(fex1_2.fsnum) &1]+ fex1_2.ftctx.fr[(fex1_2.ftnum) &1] ;
	}
	else {
		fex2_3.ALUoutput.dfr = fex1_2.fsctx.dfr+ fex1_2.ftctx.dfr ;
	}
}

void
CLKCPONE::fsub_clkemulate(uint32 instr, uint32 pc)
{
	if(fex1_2.fmt == FMT_S) {
		fex2_3.ALUoutput.fr[(fex2_3.fdnum) &1] = fex1_2.fsctx.fr[(fex1_2.fsnum) &1] -fex1_2.ftctx.fr[(fex1_2.ftnum) &1] ;
	}
	else {
		fex2_3.ALUoutput.dfr = fex1_2.fsctx.dfr -fex1_2.ftctx.dfr ;
	}
}

void
CLKCPONE::fmul_clkemulate(uint32 instr, uint32 pc)
{
	if(fex1_2.fmt == FMT_S) {
		fex2_3.ALUoutput.fr[(fex2_3.fdnum) &1] = fex1_2.fsctx.fr[(fex1_2.fsnum) &1] * fex1_2.ftctx.fr[(fex1_2.ftnum) &1] ;
	}
	else {
		fex2_3.ALUoutput.dfr = fex1_2.fsctx.dfr * fex1_2.ftctx.dfr ;
	}
}

void
CLKCPONE::fdiv_clkemulate(uint32 instr, uint32 pc)
{
	if(fex1_2.fmt == FMT_S) {
		if(fex1_2.ftctx.fr[(fex1_2.ftnum)&1] == 0.0 ) {//SingleFGR(ft(instr))
			fprintf(stderr,"FPE:divide by zero! 3\n");
			cpu->exception(FPE); //????
			return;
		}
		fex2_3.ALUoutput.fr[(fex2_3.fdnum) &1] = fex1_2.fsctx.fr[(fex1_2.fsnum) &1] / fex1_2.ftctx.fr[(fex1_2.ftnum) &1] ;
	}
	else {
		if(fex1_2.ftctx.dfr == 0.0 ) {
			fprintf(stderr,"FPE:divide by zero 4\n");
			cpu->exception(FPE);
			return;
		}
		fex2_3.ALUoutput.dfr = fex1_2.fsctx.dfr / fex1_2.ftctx.dfr ;
	}
}

void
CLKCPONE::fsqrt_clkemulate(uint32 instr, uint32 pc)
{
	if(fex1_2.fmt == FMT_S) {
		fex2_3.ALUoutput.fr[(fex2_3.fdnum) &1] = (float)sqrt( fex1_2.fsctx.fr[(fex1_2.fsnum) &1]);
	}
	else {
		fex2_3.ALUoutput.dfr = sqrt(fex1_2.fsctx.dfr);
	}

}

void
CLKCPONE::fabs_clkemulate(uint32 instr, uint32 pc)
{
	if(fex1_2.fmt == FMT_S) {
		fex2_3.ALUoutput.fr[(fex2_3.fdnum) &1] = (fex1_2.fsctx.fr[(fex1_2.fsnum) &1] > 0.0) ? fex1_2.fsctx.fr[(fex1_2.fsnum) &1] : - fex1_2.fsctx.fr[(fex1_2.fsnum) &1];
	}
	else {
		fex2_3.ALUoutput.dfr = (fex1_2.fsctx.dfr> 0.0) ? fex1_2.fsctx.dfr : - fex1_2.fsctx.dfr;
	}

}

void
CLKCPONE::fmov_clkemulate(uint32 instr, uint32 pc)
{
	if(fex1_2.fmt == FMT_S) {
		fex2_3.ALUoutput.fr[(fex2_3.fdnum) &1] = fex1_2.fsctx.fr[(fex1_2.fsnum) &1] ;
	}
	else {
		fex2_3.ALUoutput.dfr = fex1_2.fsctx.dfr;
	}
}

void
CLKCPONE::fneg_clkemulate(uint32 instr, uint32 pc)
{
	if(fex1_2.fmt == FMT_S) {
		fex2_3.ALUoutput.fr[(fex2_3.fdnum) &1] = - fex1_2.fsctx.fr[(fex1_2.fsnum) &1] ;
	}
	else {
		fex2_3.ALUoutput.dfr = - fex1_2.fsctx.dfr;
	}
}

void
CLKCPONE::fround1_clkemulate(uint32 instr, uint32 pc)
{
	if(fex1_2.fmt == FMT_S) {
		fex2_3.ALUoutput.llr = (long long) ((fex1_2.fsctx.fr[(fex1_2.fsnum) &1] > 0.0) ? fex1_2.fsctx.fr[(fex1_2.fsnum) &1] + 0.5 : fex1_2.fsctx.fr[(fex1_2.fsnum) &1] - 0.5);
 	}
	else {
		fex2_3.ALUoutput.llr =(long long) ((fex1_2.fsctx.dfr> 0.0) ? fex1_2.fsctx.dfr + 0.5 : fex1_2.fsctx.dfr- 0.5);
	} 
}

void
CLKCPONE::ftrunc1_clkemulate(uint32 instr, uint32 pc)
{
	if(fex1_2.fmt == FMT_S) {
		fex2_3.ALUoutput.llr = (long long) (fex1_2.fsctx.fr[(fex1_2.fsnum) &1] );
 	}
	else {
		fex2_3.ALUoutput.llr =(long long) (fex1_2.fsctx.dfr);
	} 

}

void
CLKCPONE::fceill_clkemulate(uint32 instr, uint32 pc)
{
	if(fex1_2.fmt == FMT_S) {
		fex2_3.ALUoutput.llr = (long long) ((fex1_2.fsctx.fr[(fex1_2.fsnum) &1] > 0.0) ? fex1_2.fsctx.fr[(fex1_2.fsnum) &1] +  SP_NEAR_ONE: fex1_2.fsctx.fr[(fex1_2.fsnum) &1]);
	}
	else {
		fex2_3.ALUoutput.llr =(long long) ((fex1_2.fsctx.dfr> 0.0) ? fex1_2.fsctx.dfr + DP_NEAR_ONE : fex1_2.fsctx.dfr);
	} 

}

void
CLKCPONE::ffloorl_clkemulate(uint32 instr, uint32 pc)
{
	if(fex1_2.fmt == FMT_S) {
		fex2_3.ALUoutput.llr = (long long) ((fex1_2.fsctx.fr[(fex1_2.fsnum) &1] > 0.0) ? fex1_2.fsctx.fr[(fex1_2.fsnum) &1] : fex1_2.fsctx.fr[(fex1_2.fsnum) &1] -SP_NEAR_ONE);
 	}
	else {
		fex2_3.ALUoutput.llr =(long long) ((fex1_2.fsctx.dfr> 0.0) ? fex1_2.fsctx.dfr : fex1_2.fsctx.dfr - DP_NEAR_ONE );
	} 
}

void
CLKCPONE::fround_clkemulate(uint32 instr, uint32 pc)
{
	if(fex1_2.fmt == FMT_S) {
		fex2_3.ALUoutput.ir[(fex2_3.fdnum)&1] = (int32) ((fex1_2.fsctx.fr[(fex1_2.fsnum) &1] > 0.0) ? fex1_2.fsctx.fr[(fex1_2.fsnum) &1] + 0.5 : fex1_2.fsctx.fr[(fex1_2.fsnum) &1] - 0.5);
 	}
	else {
		fex2_3.ALUoutput.ir[(fex2_3.fdnum)&1] =(int32) ((fex1_2.fsctx.dfr> 0.0) ? fex1_2.fsctx.dfr + 0.5 : fex1_2.fsctx.dfr- 0.5);
	} 
}

void
CLKCPONE::ftrunc_clkemulate(uint32 instr, uint32 pc)
{
	if(fex1_2.fmt == FMT_S) {
		fex2_3.ALUoutput.ir[(fex2_3.fdnum)&1] = (int32) (fex1_2.fsctx.fr[(fex1_2.fsnum) &1] );
 	}
	else {
		fex2_3.ALUoutput.ir[(fex2_3.fdnum)&1] =(int32) (fex1_2.fsctx.dfr);

	} 
}

void
CLKCPONE::fceil_clkemulate(uint32 instr, uint32 pc)
{
	if(fex1_2.fmt == FMT_S) {
		fex2_3.ALUoutput.ir[(fex2_3.fdnum)&1] = (int32) ((fex1_2.fsctx.fr[(fex1_2.fsnum) &1] > 0.0) ? fex1_2.fsctx.fr[(fex1_2.fsnum) &1] +  SP_NEAR_ONE: fex1_2.fsctx.fr[(fex1_2.fsnum) &1]);
 	}
	else {
		fex2_3.ALUoutput.ir[(fex2_3.fdnum)&1] =(int32) ((fex1_2.fsctx.dfr> 0.0) ? fex1_2.fsctx.dfr + DP_NEAR_ONE : fex1_2.fsctx.dfr);
	} 
}

void
CLKCPONE::ffloor_clkemulate(uint32 instr, uint32 pc)
{
	if(fex1_2.fmt == FMT_S) {
		fex2_3.ALUoutput.ir[(fex2_3.fdnum)&1] = (int32) ((fex1_2.fsctx.fr[(fex1_2.fsnum) &1] > 0.0) ? fex1_2.fsctx.fr[(fex1_2.fsnum) &1] : fex1_2.fsctx.fr[(fex1_2.fsnum) &1] -SP_NEAR_ONE);
	}
	else {
		fex2_3.ALUoutput.ir[(fex2_3.fdnum)&1] =(int32) ((fex1_2.fsctx.dfr> 0.0) ? fex1_2.fsctx.dfr  : fex1_2.fsctx.dfr - DP_NEAR_ONE);
	} 

}

void
CLKCPONE::fmovc_clkemulate(uint32 instr, uint32 pc)
{
    fundef_emulate(instr,pc);
}

void
CLKCPONE::fmovz_clkemulate(uint32 instr, uint32 pc)
{
     fundef_emulate(instr,pc);

}

void
CLKCPONE::fmovn_clkemulate(uint32 instr, uint32 pc)
{
     fundef_emulate(instr,pc);

}

void
CLKCPONE::frecip_clkemulate(uint32 instr, uint32 pc)
{
     fundef_emulate(instr,pc);

}

void
CLKCPONE::frsqrt_clkemulate(uint32 instr, uint32 pc)
{
     fundef_emulate(instr,pc);

}

void
CLKCPONE::fcvts_clkemulate(uint32 instr, uint32 pc)
{   
	if(fex1_2.fmt == FMT_D) //SingleFGR(fd(instr)) = (float) DoubleFGR(fs(instr));
		fex2_3.ALUoutput.fr[(fex2_3.fdnum) &1] = (float) fex1_2.fsctx.dfr;
	else if(fex1_2.fmt == FMT_W) //SingleFGR(fd(instr)) = (float) IntFGR(fs(instr));
		fex2_3.ALUoutput.fr[(fex2_3.fdnum) &1] = (float) fex1_2.fsctx.ir[(fex1_2.fsnum)&1];
	else if(fex1_2.fmt == FMT_L ) //SingleFGR(fd(instr)) = (float) LongLongFGR(fs(instr));
		fex2_3.ALUoutput.fr[(fex2_3.fdnum) &1] = (float) fex1_2.fsctx.llr;
	else fundef_emulate(instr,pc);

}

void
CLKCPONE::fcvtd_clkemulate(uint32 instr, uint32 pc)
{
	if(fex1_2.fmt == FMT_S) //DoubleFGR(fd(instr)) = (double) SingleFGR(fs(instr));
		fex2_3.ALUoutput.dfr = (double)fex1_2.fsctx.fr[(fex1_2.fsnum) &1];
	else if(fex1_2.fmt == FMT_W) //DoubleFGR(fd(instr)) = (double) IntFGR(fs(instr));
		fex2_3.ALUoutput.dfr = (double)fex1_2.fsctx.ir[(fex1_2.fsnum)&1];
	else if(fex1_2.fmt == FMT_L ) //DoubleFGR(fd(instr)) = (double) LongLongFGR(fs(instr));
		fex2_3.ALUoutput.dfr = (double)fex1_2.fsctx.llr;
	else fundef_emulate(instr,pc);
}
	 
void
CLKCPONE::fcvte_clkemulate(uint32 instr, uint32 pc)
{
     fundef_emulate(instr,pc);
}

void
CLKCPONE::fcvtw_clkemulate(uint32 instr, uint32 pc)
{
  // need read fcsr mode ?
  switch((fex1_2.fcr31ctx) & 0x3) {
   case 0: // Round to nearest    
	if(fex1_2.fmt == FMT_S) //IntFGR(fd(instr)) = (int)(SingleFGR(fs(instr)) > 0.0 ? SingleFGR(fs(instr)) + 0.5 : SingleFGR(fs(instr)) - 0.5) ;
		fex2_3.ALUoutput.ir[(fex2_3.fdnum)&1] = (int) ((fex1_2.fsctx.fr[(fex1_2.fsnum) &1] > 0.0) ? fex1_2.fsctx.fr[(fex1_2.fsnum) &1] + 0.5 : fex1_2.fsctx.fr[(fex1_2.fsnum) &1] - 0.5);
	else if(fex1_2.fmt == FMT_D) //IntFGR(fd(instr)) = (int) (DoubleFGR(fs(instr)) > 0.0 ? DoubleFGR(fs(instr)) + 0.5 : DoubleFGR(fs(instr)) - 0.5);
		fex2_3.ALUoutput.ir[(fex2_3.fdnum)&1] =(int) ((fex1_2.fsctx.dfr> 0.0) ? fex1_2.fsctx.dfr + 0.5 : fex1_2.fsctx.dfr- 0.5);
	else fundef_emulate(instr,pc);
	break;
   case 1: //Round toward 0 
	if(fex1_2.fmt == FMT_S) //IntFGR(fd(instr)) = (int) (SingleFGR(fs(instr))) ;
		fex2_3.ALUoutput.ir[(fex2_3.fdnum)&1] = (int) (fex1_2.fsctx.fr[(fex1_2.fsnum) &1] );
	else if(fex1_2.fmt == FMT_D) //IntFGR(fd(instr)) = (int) (DoubleFGR(fs(instr)) );
		fex2_3.ALUoutput.ir[(fex2_3.fdnum)&1] =(int) (fex1_2.fsctx.dfr);
	else fundef_emulate(instr,pc);   
   	break;
   case 2: //Round to +infinity
   	if(fex1_2.fmt == FMT_S) //IntFGR(fd(instr)) = (int) (SingleFGR(fs(instr)) > 0.0 ? SingleFGR(fs(instr)) : SingleFGR(fs(instr)) + SP_NEAR_ONE) ;
		fex2_3.ALUoutput.ir[(fex2_3.fdnum)&1] = (int) ((fex1_2.fsctx.fr[(fex1_2.fsnum) &1] > 0.0) ? fex1_2.fsctx.fr[(fex1_2.fsnum) &1] : fex1_2.fsctx.fr[(fex1_2.fsnum) &1] + SP_NEAR_ONE);
	else if(fex1_2.fmt == FMT_D) //IntFGR(fd(instr)) = (int) (DoubleFGR(fs(instr)) > 0.0 ? DoubleFGR(fs(instr)) : DoubleFGR(fs(instr)) + DP_NEAR_ONE);
		fex2_3.ALUoutput.ir[(fex2_3.fdnum)&1] =(int) ((fex1_2.fsctx.dfr> 0.0) ? fex1_2.fsctx.dfr : fex1_2.fsctx.dfr + DP_NEAR_ONE);
	else fundef_emulate(instr,pc);
   	break;
   case 3: // Round to -infinity 
   	if(fex1_2.fmt == FMT_S) //IntFGR(fd(instr)) = (int) (SingleFGR(fs(instr)) > 0.0 ? SingleFGR(fs(instr)) : SingleFGR(fs(instr)) - SP_NEAR_ONE) ;
		fex2_3.ALUoutput.ir[(fex2_3.fdnum)&1] = (int) ((fex1_2.fsctx.fr[(fex1_2.fsnum) &1] > 0.0) ? fex1_2.fsctx.fr[(fex1_2.fsnum) &1] : fex1_2.fsctx.fr[(fex1_2.fsnum) &1] - SP_NEAR_ONE);
	else if(fex1_2.fmt == FMT_D) //IntFGR(fd(instr)) = (int) (DoubleFGR(fs(instr)) > 0.0 ? DoubleFGR(fs(instr)) : DoubleFGR(fs(instr)) - DP_NEAR_ONE);
		fex2_3.ALUoutput.ir[(fex2_3.fdnum)&1] =(int) ((fex1_2.fsctx.dfr> 0.0) ? fex1_2.fsctx.dfr : fex1_2.fsctx.dfr - DP_NEAR_ONE);
    else fundef_emulate(instr,pc);   
   break;	
  }
}

void
CLKCPONE::fcvtl_clkemulate(uint32 instr, uint32 pc)
{
     fundef_emulate(instr,pc);

}
 
void
CLKCPONE::fcmp_op_clkemulate(uint32 instr, uint32 pc)
{
	bool cond;
	if(fid_ex.fmt == FMT_S) {
		switch(fid_ex.funct) {
			case  F_C_OBF   : cond = false;  break;
			case  F_C_UN    : cond = false; break;
			case  F_C_EQ    : cond = (fid_ex.fsctx.fr[(fid_ex.fsnum) &1] == fid_ex.ftctx.fr[(fid_ex.ftnum) &1] ) ;break;// SingleFGR(f1) == SingleFGR(f2)
			case  F_C_UEQ   : cond = (fid_ex.fsctx.fr[(fid_ex.fsnum) &1] != fid_ex.ftctx.fr[(fid_ex.ftnum) &1] ) ;break;
			case  F_C_OLT   : cond = (fid_ex.fsctx.fr[(fid_ex.fsnum) &1] < fid_ex.ftctx.fr[(fid_ex.ftnum) &1] ) ;break;
			case  F_C_ULT   : cond = (fid_ex.fsctx.fr[(fid_ex.fsnum) &1] < fid_ex.ftctx.fr[(fid_ex.ftnum) &1] ) ;break;
			case  F_C_OLE   : cond = ( fid_ex.fsctx.fr[(fid_ex.fsnum) &1] <= fid_ex.ftctx.fr[(fid_ex.ftnum) &1] ) ;break;
			case  F_C_ULE   : cond = ( fid_ex.fsctx.fr[(fid_ex.fsnum) &1] <= fid_ex.ftctx.fr[(fid_ex.ftnum) &1] ) ;break;
			case  F_C_SF    : cond = false; break;
			case  F_C_NGLE  : cond = false; break;
			case  F_C_SEQ   : cond = ( fid_ex.fsctx.fr[(fid_ex.fsnum) &1] == fid_ex.ftctx.fr[(fid_ex.ftnum) &1] ) ;break;
			case  F_C_NGL   : cond = ( fid_ex.fsctx.fr[(fid_ex.fsnum) &1] == fid_ex.ftctx.fr[(fid_ex.ftnum) &1] ) ;break;
			case  F_C_LT    : cond = ( fid_ex.fsctx.fr[(fid_ex.fsnum) &1] < fid_ex.ftctx.fr[(fid_ex.ftnum) &1] ) ;break;
			case  F_C_NGE   : cond = (fid_ex.fsctx.fr[(fid_ex.fsnum) &1] < fid_ex.ftctx.fr[(fid_ex.ftnum) &1] ) ;break;
			case  F_C_LE    : cond = ( fid_ex.fsctx.fr[(fid_ex.fsnum) &1] <= fid_ex.ftctx.fr[(fid_ex.ftnum) &1] ) ;break;
			case  F_C_NGT  :  cond = (fid_ex.fsctx.fr[(fid_ex.fsnum) &1] <= fid_ex.ftctx.fr[(fid_ex.ftnum) &1] ) ;break;
			default:
							// shld not be here! ASSERT(1) 
							break;
		}
	}
	else if(fid_ex.fmt == FMT_D) {
		switch(fid_ex.funct) {
			case  F_C_OBF   : cond = false;  break;
			case  F_C_UN    : cond = false; break;
			case  F_C_EQ    : cond = (fid_ex.fsctx.dfr == fid_ex.ftctx.dfr) ;break;
			case  F_C_UEQ   : cond = ( fid_ex.fsctx.dfr != fid_ex.ftctx.dfr) ;break;
			case  F_C_OLT   : cond = ( fid_ex.fsctx.dfr < fid_ex.ftctx.dfr) ;break;
			case  F_C_ULT   : cond = ( fid_ex.fsctx.dfr <fid_ex.ftctx.dfr) ;break;
			case  F_C_OLE   : cond = ( fid_ex.fsctx.dfr <= fid_ex.ftctx.dfr) ;break;
			case  F_C_ULE   : cond = ( fid_ex.fsctx.dfr <= fid_ex.ftctx.dfr) ;break;
			case  F_C_SF    : cond = false; break;
			case  F_C_NGLE  : cond = false; break;
			case  F_C_SEQ   : cond = ( fid_ex.fsctx.dfr == fid_ex.ftctx.dfr) ;break;
			case  F_C_NGL   : cond = ( fid_ex.fsctx.dfr == fid_ex.ftctx.dfr) ;break;
			case  F_C_LT    : cond = ( fid_ex.fsctx.dfr < fid_ex.ftctx.dfr) ;break;
			case  F_C_NGE   : cond = ( fid_ex.fsctx.dfr < fid_ex.ftctx.dfr) ;break;
			case  F_C_LE    : cond = ( fid_ex.fsctx.dfr <= fid_ex.ftctx.dfr) ;break;
			case  F_C_NGT  :  cond = (fid_ex.fsctx.dfr <= fid_ex.ftctx.dfr) ;break;
			default:
							// shld not be here! ASSERT(1) 
				break;
		}
		
	}
	else {
		fundef_emulate(instr,pc);
		return;
		}
	cond ? fcr31 |= F_CSR31_C : fcr31 &= ~F_CSR31_C ;
	if (fcr31flag != 0)
		fcr31flag --;
}

/*void
CLKCPONE::fundef_emulate(uint32 instr, uint32 pc)
{
	fprintf(stderr,"FP:Not defined yet:");
	cpu->cop_unimpl(1,instr,pc);
}*/
 
