/* Definitions to support the system control coprocessor.
   Copyright 2001, 2003 Brian R. Gaeke.

This file is part of VMIPS.

VMIPS is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 2 of the License, or (at your
option) any later version.

VMIPS is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
for more details.

You should have received a copy of the GNU General Public License along
with VMIPS; if not, write to the Free Software Foundation, Inc.,
59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.  */

#ifndef _CPZERO_H_
#define _CPZERO_H_

//#include "stat.h"
//#include "tlb.h"
#include "sysinclude.h"
#include "cpzeroreg.h"
#include "intctrl.h"
class DeviceExc;
class IntCtrl;
class CPU; /* avoid circular dependency */
class CLKCPU;
class TLB;
class vmips;

class CPZero
{
friend class TLB;
friend class VirtServRange;
protected:
	/*slfsmm031107_mod>the tlb entry number can be modified through config file*/
	/* (0) Index fields */
	uint32 Index_Index_MASK;
	uint32 Index_MASK;
	/* (1) Random fields */
	uint32 Random_Random_MASK;
	uint32 Random_MASK;
	uint32 Random_UPPER_BOUND;
	uint32 Random_LOWER_BOUND;
	uint32 Random_Seed; // use a seed to assure random to be determin
	/*slfsmm031107_mod<*/

private:
	vmips* machine;
	CPU *cpu;
	CLKCPU *clkcpu;
	IntCtrl *intc;

	void mfc0_emulate(uint32 instr, uint32 pc);
	void mtc0_emulate(uint32 instr, uint32 pc);
	void bc0x_emulate(uint32 instr, uint32 pc);
	void tlbr_emulate(uint32 instr, uint32 pc);
	void tlbwi_emulate(uint32 instr, uint32 pc);
	void tlbwr_emulate(uint32 instr, uint32 pc);
	void tlbp_emulate(uint32 instr, uint32 pc);
	void rfe_emulate(uint32 instr, uint32 pc);
//	void load_addr_trans_excp_info(uint32 va, uint32 vpn, TLB_ENTRY *match);
//	TLBEntry *find_matching_tlb_entry(uint32 asid, uint32 asid);
//	uint32 tlb_translate(uint32 seg, uint32 vaddr, int mode,
//		bool *cacheable, DeviceExc *client);

public:
//	bool tlb_miss_user;
	/* Convention says that CP0's condition is TRUE if the memory write-back
	 * buffer is empty. Because memory writes are fast as far as
	 * the emulation is concerned, the write buffer is always empty for CP0.
	 */
	 //added by zhangwl on Oct 21th
	void mfc0_clkemulate(uint32 pc);
	void mtc0_clkemulate(uint32 pc);
	void bc0x_clkemulate(uint32 pc);
/*	void tlbr_clkemulate(uint32 instr, uint32 pc);
	void tlbwi_clkemulate(uint32 instr, uint32 pc);
	void tlbwr_clkemulate(uint32 instr, uint32 pc);
	void tlbp_clkemulate(uint32 instr, uint32 pc);*/
//	void rfe_clkemulate(uint32 instr, uint32 pc);
	void cpzero_clkemulate(uint32 pc);//added by zhangwl on Oct 21th	
	//end -added by zhangwl on Oct 21th
	
	uint32 reg[32];
    TLB *tlb;
	static const bool cpCond = true;

	CPZero(CPU *m = NULL, IntCtrl *i = NULL);
	/*slfsmm031107_mod_add>*/
	void attach(vmips* vm,CPU *m = NULL, IntCtrl *i = NULL, TLB* t = NULL);
	void SetHWConfig( );
	/*slfsmm031107_mod_add<*/
	void reset(void);
//	bool kernel_mode(void);
	uint32 address_trans(uint32 vaddr, int mode, bool *cacheable,
		DeviceExc *client);
//	uint32 getIP(void);
	void enter_exception(uint32 pc, uint32 excCode, uint32 ce, bool dly);
	bool use_boot_excp_address(void);
	bool caches_isolated(void);
	bool caches_swapped(void);
	bool cop_usable (int coprocno);
	void cpzero_emulate(uint32 instr, uint32 pc);
	void dump_regs(FILE *f);
	void dump_tlb(FILE *f);
	void dump_regs_and_tlb(FILE *f);
	void adjust_random(void);
//	bool interrupts_enabled(void);
//	bool interrupt_pending(void);
	void read_debug_info(uint32 *status, uint32 *bad, uint32 *cause);
	void write_debug_info(uint32 status, uint32 bad, uint32 cause);
	/* TLB translate VADDR without exceptions.  Returns true if a valid
	 * TLB mapping is found, false otherwise. If VADDR has no valid mapping,
	 * PADDR is written with 0xffffffff, otherwise it is written with the
	 * translation.
	 */
//	bool debug_tlb_translate(uint32 vaddr, uint32 *paddr);
inline uint32 getIP(void)
		{
			    uint32 HwIP = 0, IP = 0;
			    if (intc != NULL) {
			        HwIP = intc->calculateIP(); /* Check for a hardware interrupt. */
					    }
			    IP = (reg[Cause] & Cause_IP_SW_MASK) | HwIP;
			    return IP;
		}

inline bool interrupts_enabled(void)
{
	return (reg[Status] & Status_IEc_MASK);
}
/* Yow!! Are we in KERNEL MODE yet?? ...Read the Status register. */
inline bool kernel_mode(void)
{
	return !(reg[Status] & Status_KUc_MASK);
}


inline bool interrupt_pending(void)
{
    if (! interrupts_enabled())
       return false;   /* Can't very well argue with IEc == 0... */
    /* Mask IP with the interrupt mask, and return true if nonzero: */
    return ((getIP () & (reg[Status] & Status_IM_MASK)) != 0);
}


};

#endif /* _CPZERO_H_ */
