/*This is the TLB module of sand simulator, which is developed by
ASL group of NCIC;
Copyright 2003 by ASL NCIC */
#ifndef _STAT_REG
#define _STAT_REG

/*The following define the mask of the bool field*/
#define CacheHitMask   0x0001          // bit 0
#define TlbHitMask     0x0002          // bit 1
#define TlbINVMask   0x0004          // bit 2
#define TlbModifyMask  0x0008          // bit 3
#define VBufHitMask        0x0010          // bit 4
#define PBufHitMask        0x0020          // bit 5
#define BlockHitMask       0x0040          // bit 6
#define PageFaultMask  0x0080          // bit 7
#define CacheableMask  0x0100             // bit 8
#define ReadOrWrite	   0x0200              //bit 9
#define InstOrData          0x0400             //bit 10
#define CacheInvMask    0x0800              //bit 11
/* bit 13~15 to be defined */

/*The following define the control mask*/
#define BoolMask       0x01          // bit 0, its content is stored in 2 bytes
#define CacheHitLevMask    0x02          // bit 1, its content is stored in 1 bytes
#define HitTimeMask        0x04          // bit 2, its content is stored in 2 bytes
#define AddrMask       0x08          // bit 3, its content is stored in 4 bytes
#define CounterMask   0x10         // bit 4, its content is stored in 8 bytes
 #define CachefcMask   0x20       //bit 5, its content is stored in 8 bytes
 #define CachescMask    0x40       //bit 6, its content is stored in 8 bytes
 #define CachemissMask  0x80       //bit 7, its content is stored in 8 bytes
#endif // _STAT_REG

