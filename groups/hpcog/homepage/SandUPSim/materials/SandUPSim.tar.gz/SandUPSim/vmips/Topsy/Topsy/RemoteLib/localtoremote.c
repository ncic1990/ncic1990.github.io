//global varialbles
long rmt_errno;
ServInfoDesc_t localservinfo;

#define CHECKPTR_1_RETVAL(ptr1,msg1,retval)\
do{\
	if(!checkpointer(ptr1,msg1)) return retval;\
}while(0)

#define CHECKPTR_2_RETVAL(ptr1,msg1,ptr2,msg2,retval)\
do{\
	if(!checkpointer(ptr1,msg1)) return retval;\
	if(!checkpointer(ptr2,msg2)) return retval;\
}while(0)

#define CHECKPTR_1_NORETVAL(ptr1,msg1)\
do{\
	if(!checkpointer(ptr1,msg1)) return;\
}while(0)
	
#define CHECKPTR_2_NORETVAL(ptr1,msg1,ptr2,msg2)\
do{\
	if(!checkpointer(ptr1,msg1)) return;\
	if(!checkpointer(ptr2,msg2)) return;\
}while(0)

#define OUTPUTMSG(string)\
do{\
	ioConsolePutString("..........");\
	ioConsolePutString(string);\
	ioConsolePutString("..........\n");\
}while(0)

#define COMMONDECLARE\
	ParamsDesc_t* paramsdesptr=&localservinfo.paramdesc;

#define REMOTECALL(type,service,paramsdesptr)\
do{\
	getServAddress(&localservinfo);\
	setServType(&localservinfo,type,service);\
	ConnectToServer();\
	SendServRequest(&localservinfo);\
}while(0)

#define WAITFORREPLY(paramsdesptr)\
do{\
	switchAddresses(&localservinfo);\
	RecvServReply(&localservinfo);\
}while(0)

#define RELEASE( )\
do{\
	DisConnectFromServer();\
}while(0)


#include "RemoteServLibc.c"
#include "RemoteServLinux.c"
#include "RemoteServAssist.c"

