/*
	Copyright (c) 1996-1997 Swiss Federal Institute of Technology, 
	Computer Engineering and Networks Laboratory. All rights reserved.

	TOPSY - A Teachable Operating System. 
		Implementation of a tiny and simple micro kernel for
		teaching purposes.

	Permission to use, copy, modify, and distribute this software and its
	documentation for any purpose, without fee, and without written 
	agreement is hereby granted, provided that the above copyright notice 
	and the following two paragraphs appear in all copies of this software.


	
	File:                  $Source: /work/cvs/cvsroot/Topsy/Memory/MMVirtualMemory.h,v $
 	Author(s):             George Fankhauser
 	Affiliation:           ETH Zuerich, TIK
 	Version:               $Revision: 1.6 $
 	Creation Date:         
 	Last Date of Change:   $Date: 2004/03/09 01:27:27 $      by: $Author: slfsmm $
	
	
*/

#ifndef _MMVIRTUALMEMORY_H_
#define _MMVIRTUALMEMORY_H_

#include "Topsy.h"
#include "Memory.h"
#include "Threads.h"
#include "List.h"
/*slfsmm003_add>*/
#include "tm-include.h"
/*slfsmm003_add<*/

#define MM_VMINITOK	0
#define MM_VMINITFAILED 1

#define MM_VMEXACT	2
#define MM_VMINSIDE	3

/*slfsmm1>*/
//typedef enum {VM_FREED, VM_ALLOCATED}  RegionStatus;
typedef enum {VM_FREED, VM_ALLOCATED,VM_STACK,VM_HEAP}  RegionStatus;
/*slfsmm1<*/

typedef struct RegionDesc_t {
    /* RegionStatus is implicitely known from which list the region is in */
    unsigned long int  startPage;
    unsigned long int  numOfPages;
    ProtectionMode     pmode;
    ThreadId           owner;
} RegionDesc;

typedef RegionDesc* Region;

typedef struct AddressSpaceDesc_t {
    List               regionList;
    List               freeList;
    unsigned long int  startPage; 
    unsigned long int  endPage;
} AddressSpaceDesc;

typedef AddressSpaceDesc* AddressSpacePtr;

/*slfsmm1>*/
/*move from file "MMVirtualMemory.c"*/
/*slfsmm003_mov>move from file "MMVirtualMemory.c"*/
static AddressSpaceDesc addressSpaces[ADDRESSSPACES];
/*slfsmm003_mov<*/
/*slfsmm1<*/

Address mmVmGetHeapAddress(Address kernelDataStart, 
			   unsigned long int kernelDataSize);
Error  mmVmInit(Address kernelCodeStart, unsigned long int kernelCodeSize,
		Address kernelDataStart, unsigned long int kernelDataSize,
		Address userCodeStart, unsigned long int userCodeSize,
		Address userDataStart, unsigned long int userDataSize,
		Address* mmStack, Address* tmStack);

//added by sgz 2003-10-20
Error  mmUserVmInit(Address userCodeStart, unsigned long int userCodeSize,
		Address userDataStart, unsigned long int userDataSize);
//end added

Error mmVmAlloc(Address* addressPtr, unsigned long int size, ThreadId owner);
Error mmVmFree(Address address, ThreadId claimsToBeOwner);
Error mmVmMove(Address* addressPtr, ThreadId newOwner);
Error mmVmProtect(Address startAdr, unsigned long int size,
		ProtectionMode pmode, ThreadId owner);
Error mmVmCleanup(ThreadId id);
void ClearUpUserList(List* listptr);
void ClearUpUserAddressSpace( );
/*slfsmm031022_add>handling the page(not logical page)*/
unsigned long NotLogical_RoundToPageUp(unsigned long addr);
unsigned long NotLogical_RoundUp(unsigned long addr);
unsigned long NotLogical_Round(unsigned long addr);
unsigned long NotLogical_RoundToPage(unsigned long addr);
/*slfsmm031022_add<*/
/*slfsmm1>*/
#define USERALLOCREGION 0
#define USERFREEREGION 1
Region getUserRegionByAddr(Address address,int mode);
/*slfsmm1<*/
/*slfsmm002>*/
/*slfsmm003_mod>*/
long brk(unsigned long brk,ThreadId sender);
long mmap(unsigned long addr, unsigned long len, unsigned long prot,
         unsigned long flags, unsigned long fd, unsigned long offset,ThreadId sender);
long munmap(unsigned long addr, unsigned long len,ThreadId sender);
long mmap2(unsigned long addr, unsigned long len, unsigned long prot,
          unsigned long flags, unsigned long fd, unsigned long pgoff,ThreadId sender);
/*slfsmm003_mod<*/
/*slfsmm003_add>*/
long do_brk(unsigned long brk);
long do_mmap(unsigned long addr, unsigned long len,unsigned long prot,
	unsigned long flags, unsigned long fd, unsigned long pgoff,ThreadId sender);
long do_mmap_pgoff(unsigned long file, unsigned long addr, unsigned long len,
	unsigned long prot, unsigned long flags, unsigned long pgoff,ThreadId sender);
long do_unmap(unsigned long addr, unsigned long len,ThreadId sender);
void HandlingTLSyscallReturn(Thread* sender,long ret);
/*slfsmm003_add<*/
/*slfsmm031027_add>*/
long mprotect(unsigned long start, unsigned int len, unsigned long prot,ThreadId sender);
long do_mprotect(unsigned long start, unsigned int len, unsigned long prot,ThreadId sender);
/*slfsmm031027_add<*/
/*slfsmm002<*/
#endif

