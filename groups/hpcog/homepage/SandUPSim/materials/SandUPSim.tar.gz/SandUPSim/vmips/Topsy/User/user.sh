#!/bin/sh
../../vmipstool --assemble -o usersetup.o usersetup.S
../../vmipstool --compile -c user.c  -I../IO -I../Topsy/ -I../Memory -I../Threads -I../Topsy/mips 
../../vmipstool --ld-script=user_ld.scr --link -o user.elf usersetup.o user.o ../Topsy/mips/SyscallMsg.o
/work/mips/bin/mipsel-dsag-linux-gnu-objcopy -O binary user.elf user.bin
/work/mips/bin/mipsel-dsag-linux-gnu-objcopy -O srec user.elf user.srec
