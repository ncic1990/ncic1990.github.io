#ifndef SOFTIOCONSOLE_H
#define SOFTIOCONSOLE_H
#include "LibcLinuxTypes.h"

void ioConsolePutString(const char* s) ; //to stderr
void ioConsolePutHexInt(int x) ; //to stderr
char* stringin(char* string,long maxcount); //to stderr
void stringout(char* string); //to stderr
//when returning 0:failed  1:ok
long RedirectStdIO(long stdinto, long stdoutto, long stderrto);
void DeRedirectStdIO( );
//when returning 0:failed  1:ok
long ChangeCWD(const char* pathname);
void RecoverCWD( );
void printfnull(const char* str); //to stdout
void printfstr(const char* mode, const char* str); //to stdout
void printfnum(const char* mode, long num); //to stdout
void* TAmemset(void* base, int c, int count);
long TAgetcwd(char* buf, long size, long mode);
void TAlssimulation(char* format);
char* TAgetenv(char* envname,char* buf,long maxlen);
void TAmmmappinginfotovmips(mmmapping_t* mappingptr);
void TAappnametovmips(char* appname);
void TAinvalidatecache( );
void dbgopen( );
void dbgclose( );
void dbgprintfnull(const char* str); //to stdout of virtserv
void dbgprintfstr(const char* mode, const char* str); //to stdout of virtserv
void dbgprintfnum(const char* mode, long num); //to stdout of virtserv
long TAchstdiobyname(char* stdinname,char* stdoutname,
	char* stderrname,bool inheritflag);
//the return value is the envc
long TAgetallenv(char* buf,long maxlen);
	
#endif

