#include "KVirtServ.h"

//dump the cpu:regs cpzero:regs and tlb entries in virtual server
#define kerneldumpregs( )\
do{\
__asm__ __volatile__(\
	".set\tnoreorder\n\t"\
	".set\tnoat\n\t"\
	"li\t$26,%0\n"\
	"li\t$27,%1\n"\
	"sb\t$27,($26)\n"\
	".set\tat\n\t"\
	".set\treorder"\
	:\
	:"i"(OutputServer),"i"(dumpregservno)\
	);\
}while(0)

