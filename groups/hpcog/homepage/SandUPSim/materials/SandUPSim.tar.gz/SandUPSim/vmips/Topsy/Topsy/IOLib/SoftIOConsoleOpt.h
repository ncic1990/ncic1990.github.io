#ifndef SOFTIOCONSOLEOPT_H
#define SOFTIOCONSOLEOPT_H

//#define IOALWAYSVIRT
#define OPENVIRTDBG

#endif

