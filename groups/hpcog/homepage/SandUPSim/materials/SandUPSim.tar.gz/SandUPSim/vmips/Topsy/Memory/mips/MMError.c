/*
	Copyright (c) 1996-1997 Swiss Federal Institute of Technology, 
	Computer Engineering and Networks Laboratory. All rights reserved.

	TOPSY - A Teachable Operating System. 
		Implementation of a tiny and simple micro kernel for
		teaching purposes.

	Permission to use, copy, modify, and distribute this software and its
	documentation for any purpose, without fee, and without written 
	agreement is hereby granted, provided that the above copyright notice 
	and the following two paragraphs appear in all copies of this software.


	
	File:                  $Source: /work/cvs/cvsroot/Topsy/Memory/mips/MMError.c,v $
 	Author(s):             George Fankhauser
 	Affiliation:           ETH Zuerich, TIK
 	Version:               $Revision: 1.10 $
 	Creation Date:         
 	Last Date of Change:   $Date: 2003/12/09 07:58:26 $      by: $Author: slfsmm $
	
	
*/

#include "MMError.h"
#include "Threads.h"
#include "Messages.h"
#include "TMHal.h"
/*slfsmm1>*/
/*slfsmm003_del>*/
//#include "TMThread.h"
/*slfsmm003_del<*/
#include "MemoryLayout.h"
#include "MMVirtualMemory.h"
#include "KSupportInlineAsm.h"
/*slfsmm003_add>*/
extern HashList threadHashList;
/*slfsmm003_add<*/
/*slfsmm1<*/

/*slfsmm031031_add>*/
extern long totalmemory;
extern long PHYSMEM;
extern long USERMEM;
extern long PAGETABLEPHYSBASE;
/*slfsmm031031_add<*/

static void mmBusError(ThreadId currentThread);
static void mmAddressErrorS(ThreadId currentThread);
static void mmAddressErrorL(ThreadId currentThread);
static void mmTLBError(ThreadId currentThread);
static void mmTLBMError(ThreadId currentThread);
static void mmUTLBError(ThreadId currentThread);
static void mmError(ThreadId currentThread, char* errorString);


void mmInstallErrorHandlers(void)
{
    tmSetExceptionHandler(TLB_MOD, mmTLBMError);
    tmSetExceptionHandler(TLB_LOAD, mmTLBError);
    tmSetExceptionHandler(TLB_STORE, mmTLBError);
    tmSetExceptionHandler(UTLB_MISS, mmUTLBError);
    tmSetExceptionHandler(ADDR_ERR_LOAD, mmAddressErrorL);
    tmSetExceptionHandler(ADDR_ERR_STORE, mmAddressErrorS);
    tmSetExceptionHandler(BUSERR_INSTR, mmBusError);
    tmSetExceptionHandler(BUSERR_DATA, mmBusError);
}


static void mmError(ThreadId currentThread, char* errorString)
{
    Message msg;
    
    msg.id = TM_KILL;
    msg.from = MMTHREADID;
    msg.msg.tmKill.id = currentThread;
    
    ioConsolePutString(errorString);
    /* immediate in-kernel delivery without syscall
     * kSend does a schedule after the message arrived
     */
    kSend(TMTHREADID, &msg); 
}

static void mmBusError(ThreadId currentThread)
{
	kerneldumpregs();
	mmError(currentThread, "bus error.\n");
}


static void mmAddressErrorL(ThreadId currentThread)
{
	kerneldumpregs();
    mmError(currentThread, "address error load.\n");
}

static void mmAddressErrorS(ThreadId currentThread)
{
	kerneldumpregs();
    mmError(currentThread, "address error store.\n");
}

static void mmTLBError(ThreadId currentThread)
{
    List list;
	Region freeRegion,stackRegion;
	Address badvaddr=(Address)exceptionContext[EC_BADVADDR];
	/*slfsmm031031_mod>to get more memory for user and kernel*/
	unsigned long * pagetablebase=(unsigned long *)(K1SEG_BASE+PAGETABLEPHYSBASE);
	/*slfsmm031031_mod<*/
	unsigned long pagetableentry;
	Thread* current;
	
	if(THREAD_MODE(currentThread)!=USER){
		kerneldumpregs();
		ioConsolePutString("tlb exception error: Kernel modifies the user thread!\n");
		return;
	}
	
	if(((long)badvaddr & 0xfffff000)==0){
		kerneldumpregs();
		mmError(currentThread, "tlb exception error: NULL pointer!\n");
		return;
	}
	
	ioConsolePutString("tlb exception msg: Invalid page refrence! badvaddr: ");
	ioConsolePutHexInt(badvaddr);
    if ((hashListGet( threadHashList, (void**)(&current), 
		      currentThread)) != HASHOK) {
		ioConsolePutString("tlb exception error: Can not find the thread by ID!\n");
		return;
    }

	if((Address)(current->contextPtr->stackPointer)>badvaddr){
		kerneldumpregs();
		mmError(currentThread, "tlb exception error: badvaddr is not in stack!\n");
		return;
	}
    
    stackRegion=getUserRegionByAddr(current->stackStart,USERALLOCREGION);
	if(stackRegion==NULL){
		mmError(currentThread, "tlb exception error: Can not find the stack region!\n");
		return;
	}

	/*I am not sure!
	if(stackRegion->startPage*LOGICALPAGESIZE-FAULTALLOWOFF > badvaddr){
		mmError(currentThread, "tlb error: The offset to fixed is too large!\n");
		return;
	}
	*/

	freeRegion=getUserRegionByAddr((Address)((((unsigned long)badvaddr)>>PAGEBITS)
					*PAGESIZE-4),USERFREEREGION);
	if((freeRegion==NULL)||(freeRegion->numOfPages<LOGICALPAGESPERPAGE)){
		kerneldumpregs();
		mmError(currentThread, "tlb exception error: Not enough space for expanding stack!\n");
		return;
	}

	if(freeRegion->numOfPages==LOGICALPAGESPERPAGE){
	    listRemove(addressSpaces[USER].freeList, (void*)freeRegion, NULL);
		/*slfsmm004_add>*/
		hmFree(freeRegion);
		/*slfsmm004_add<*/
	}
	else
		freeRegion->numOfPages-=LOGICALPAGESPERPAGE;
	stackRegion->startPage-=LOGICALPAGESPERPAGE;
	stackRegion->numOfPages+=LOGICALPAGESPERPAGE;
	current->stackEnd-=PAGESIZE;

	pagetablebase+=(unsigned long)badvaddr/PAGESIZE;
	pagetableentry=*pagetablebase;
	*(pagetablebase)=*(pagetablebase-1);
	*(pagetablebase-1)=pagetableentry;
	replaceTLBEntry(*(pagetablebase));

	ioConsolePutString("tlb exception msg:Fixed!\n");
			
}

static void mmTLBMError(ThreadId currentThread)
{
	kerneldumpregs();
    mmError(currentThread, "tlb mod error.\n");
}

static void mmUTLBError(ThreadId currentThread)
{
    mmError(currentThread, "user tlb refill happen.\n");
    TLBMissR3K();
}
