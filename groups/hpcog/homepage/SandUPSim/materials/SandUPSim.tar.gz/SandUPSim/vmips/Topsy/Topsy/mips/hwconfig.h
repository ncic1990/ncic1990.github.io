#ifndef HWCONFIG_H
#define HWCONFIG_H

#define RemoteServerSpacePhysBase	0x13000000
#define RemoteServerPhysSize 8*1024

#define VirtualServerSpacePhysBase 0x12000800
#define SpimConsolePhysBase 0x12000000
#define Spim_Virt_PhysSize 4*1024

#endif

