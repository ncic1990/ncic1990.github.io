#include "LibcLinuxTypes.h"
#include "Support.h"
#include "LinuxSyscallmman.h"
#include "LinuxSyscallErrno.h"

#include "RemoteServConst.h"
#include "KRemoteServ.h"
#include "DBGRemoteServ.h"
#include "RemoteServCommon.c"
#include "HALayer.c"
#include "SRLayer.c"
#include "AppLayer.c"
#include "localtoremote.c"

/*Initialization*/
#include "Klocaltoremoteinit.h"
extern long VIRTSERVFLAG;
//note: this function can be called only after executing gethwparaforos( )
void InitRemoteServ(stdio_t* stdioinfoptr)
{	
	//init virtual network card
__asm__ __volatile__(
	".set\tnoreorder\n\t"
	".set\tnoat\n\t"
	"li\t$26,%0\n"
	"sw\t%1,0($26)\n"
	".set\tat\n\t"
	".set\treorder"
	:
	:"i"(VIRT_REMOTE_PHYS),
	 "r"(VIRTSERVFLAG)
	);

	//init remote server: software environment
	if(!VIRTSERVFLAG)
		rsTAchstdiobyname(stdioinfoptr->stdinname,stdioinfoptr->stdoutname,
			stdioinfoptr->stderrname,stdioinfoptr->stdioinherit);
}

