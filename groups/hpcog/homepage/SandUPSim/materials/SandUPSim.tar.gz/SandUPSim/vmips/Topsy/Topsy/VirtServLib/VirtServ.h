#ifndef VIRTSERV_H
#define VIRTSERV_H

#define ErrNotInServRange -10000
#define ErrNoSuchServNo  -10001


/*LocalVirtualServer: topsy gets local servers from it.*/
#define LocalVirtualServerDownOff 0
#define LocalVirtualServerOff VirtualServerSpace-1-LocalVirtualServerDownOff
#define LocalVirtualServer VirtualServerBase-LocalVirtualServerDownOff

#define fopenservno    0
#define freadservno    1
#define fwriteservno   2
#define fcloseservno   3
#define fseekservno    4
#define ftellservno    5
#define rewindservno   6
#define feofservno     7
#define fgetcservno    8
#define fgetsservno    9
#define fputcservno    10
#define fputsservno    11
#define libcgetcwdservno	12
#define libcchdirservno	13

/*OutputServer: output some information for such as debugging*/
#define OutputServerDownOff 1
#define OutputServerOff VirtualServerSpace-1-OutputServerDownOff
#define OutputServer VirtualServerBase-OutputServerDownOff

#define dumpregservno  0
#define errmsgservno   1
#define tracerservno   2
/*LinuxSyscallServer: handling the Linux syscall*/
#define LinuxSyscallServerDownOff 2
#define LinuxSyscallServerOff VirtualServerSpace-1-LinuxSyscallServerDownOff
#define LinuxSyscallServer VirtualServerBase-LinuxSyscallServerDownOff

#define LinuxSyscallreadservno 3
#define LinuxSyscallwriteservno 4
#define LinuxSyscallopenservno 5
#define LinuxSyscallcloseservno 6
#define LinuxSyscallunlinkservno 10
#define LinuxSyscalltimeservno 13
#define LinuxSyscalllseekservno 19
#define LinuxSyscallgetpidservno 20
#define LinuxSyscallgetuidservno 24
#define LinuxSyscallaccessservno 33
#define LinuxSyscallrenameservno 38
#define LinuxSyscalltimesservno 43
#define LinuxSyscallgetgidservno 47
#define LinuxSyscallgeteuidservno 49
#define LinuxSyscallgetegidservno 50
#define LinuxSyscallioctlservno 54
#define LinuxSyscallfcntlservno 55
#define LinuxSyscallgetrlimitservno 76
#define LinuxSyscallgetrusageservno 77
#define LinuxSyscallftruncateservno 93
#define LinuxSyscallstatservno 106
#define LinuxSyscalllstatservno 107
#define LinuxSyscallfstatservno 108
#define LinuxSyscallnewunameservno 122
#define LinuxSyscallllseekservno 140
#define LinuxSyscallnewselectservno 142
#define LinuxSyscallftruncate64servno 212
#define LinuxSyscallstat64servno 213
#define LinuxSyscalllstat64servno 214
#define LinuxSyscallfstat64servno 215
#define LinuxSyscallfcntl64servno 220

/*TopsyAssistantServer:some assistant functions used in Topsy*/
#define TopsyAssistantServerDownOff 3
#define TopsyAssistantServerOff VirtualServerSpace-1-TopsyAssistantServerDownOff
#define TopsyAssistantServer VirtualServerBase-TopsyAssistantServerDownOff

#define ioConsolePutStringservno 0
#define ioConsolePutHexIntservno 1
#define stringoutservno 2
#define stringinservno 3
#define redirectstdioservno 4
#define deredirectstdioservno 5
#define changecwdservno 6
#define recovercwdservno 7 
#define printfnullservno 8
#define printfstrservno 9
#define printfnumservno 10
#define memsetservno 11
#define TAgetcwdservno 12
#define TAlssimulationservno 13
#define TAgetenvservno 14
#define TAmmmappinginfoservno 15
#define TAappnameservno 16
#define TAinvalidcacheservno 17
#define TAgetallenvservno 18

/*other vitual server*/

#endif

