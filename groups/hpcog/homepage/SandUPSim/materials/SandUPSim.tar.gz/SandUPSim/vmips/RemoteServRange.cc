#include "sysinclude.h"
#include "accesstypes.h"
#include "RemoteServRange.h"

//#define WALKPATH
//#define DEBUGSOCKET
//#define DBGSTATUSPORTS

/* Initialization: create a dummy Range object. */
RemoteServRange::RemoteServRange(uint32 port) throw()
    : Range(RemoteServerSpaceBase, RemoteServerSpaceSize, NULL, DEVICE, MEM_READ_WRITE)
{
	fprintf(stderr,"Mapping RemoteServRange to phys address:0x%x    size:0x%x\n",RemoteServerSpaceBase,RemoteServerSpaceSize);
	serverport=port==INVALIDPORT? SERVERPORT:port;
	fprintf(stderr,"Remote server port: %d.\n",serverport);
}

RemoteServRange::~RemoteServRange() throw()
{
	if(sockfd) close(sockfd);
}

/*base fetch and store operations*/
void
RemoteServRange::store_byte(uint32 offset, uint8 data, DeviceExc *client)
{
	if((offset<RemoteServBufSize))
		((uint8*)RemoteServRangeMem)[offset]=data;
	else{
		fprintf(stderr,"RemoteServError:store_halfwork Error:Not in the buffer range!\n");
		}
}

uint8
RemoteServRange::fetch_byte(uint32 offset, DeviceExc *client)
{
	if((offset<RemoteServBufSize))
		return ((uint8 *)RemoteServRangeMem)[offset];
	else{
		fprintf(stderr,"RemoteServError:fetch_byte Error:Not in the buffer range!\n");
		return 0;
		}
}

void
RemoteServRange::store_halfword(uint32 offset, uint16 data, DeviceExc *client)
{
	if((offset<RemoteServBufSize))
		((uint16 *)RemoteServRangeMem)[offset/2]=data;
	else{
		fprintf(stderr,"RemoteServError:store_halfwork Error:Not in the buffer range!\n");
		}
}

uint16
RemoteServRange::fetch_halfword(uint32 offset, DeviceExc *client)
{
	if((offset<RemoteServBufSize))
		return ((uint16 *)RemoteServRangeMem)[offset/2];
	else{
		fprintf(stderr,"RemoteServError:fetch_halfwork Error:Not in the buffer range!\n");
		return 0;
		}
}

//only this function can operate the control ports 
//and only this funcion and fetch_word can access status ports
void
RemoteServRange::store_word(uint32 offset, uint32 data, DeviceExc *client)
{
	#ifdef WALKPATH
	fprintf(stderr,"RemoteServMsg:store_word entry: offset->0x%x, data->%d\n",offset,data);
	#endif
	
	if((offset<RemoteServBufSize))//storing buffer
		((uint32 *)RemoteServRangeMem)[offset/4]=data;
	else if((offset<=RemoteServCtlOff)&&//accessing control ports
		(offset>RemoteServCtlOff-RemoteServCtlSize))
		HandleCtrlCommands(offset,data);
	else if((offset<=RemoteServStatusOff)&&//writing status ports
		(offset>RemoteServStatusOff-RemoteServStatusSize)){
		#ifdef DBGSTATUSPORTS
		fprintf(stderr,"RemoteServRange:store_word:writing status ports...\n");
		fprintf(stderr,"offset->0x%x, retval->0x%x\n",offset,data);
		#endif
		((uint32 *)RemoteServRangeMem)[offset/4]=data;
	}
	else{
		fprintf(stderr,"RemoteServError:store_word Error:Not in the buffer range!\n");
		}
}

uint32
RemoteServRange::fetch_word(uint32 offset, int mode, DeviceExc *client)
{
	#ifdef WALKPATH
	fprintf(stderr,"RemoteServMsg:fetch_word entry: offset->0x%x, data->%d\n",offset,((uint32 *)RemoteServRangeMem)[offset/4]);
	#endif
	
	if(offset<RemoteServBufSize)//reading buffer
		return ((uint32 *)RemoteServRangeMem)[offset/4];
	else if((offset<=RemoteServStatusOff)&&//reading status ports
		(offset>RemoteServStatusOff-RemoteServStatusSize)){
		#ifdef DBGSTATUSPORTS
		fprintf(stderr,"RemoteServRange:fetch_word:reading status ports...\n");
		fprintf(stderr,"offset->0x%x, retval->0x%x\n",offset,((uint32 *)RemoteServRangeMem)[offset/4]);
		#endif
		return ((uint32 *)RemoteServRangeMem)[offset/4];
	}
	else{//error
		fprintf(stderr,"RemoteServError:fetch_word Error:Not in the buffer range!\n");
		return 0;
		}
}

/*handle the control ports*/
void 
RemoteServRange::HandleCtrlCommands(uint32 offset, uint32 data)
{
	#ifdef WALKPATH
	fprintf(stderr,"RemoteServMsg:HandleCtrlCommands...\n");
	#endif
	
	switch(offset){
		case PORT_S_R_OFF:
			HandleSRPortCommands(data);
			break;
		default:
			fprintf(stderr,"RemoteServError:control port offset 0x%x does not exist!\n",offset);
			break;
	}
}

/*handle the send and receive port commands*/
void 
RemoteServRange::HandleSRPortCommands(uint32 data)
{
	#ifdef WALKPATH
	fprintf(stderr,"RemoteServMsg:HandleSRPortCommands...\n");
	#endif

	switch(data){
		case SEND_PACKAGE:
			SendPackage();
			break;
		case RECV_PACKAGE:
			RecvPackage();
			break;
		case CONNECT:
			ConnectToServer();
			break;
		case DISCONNECT:
			DisconnectFromServer();
			break;
		default:
			fprintf(stderr,"RemoteServError:HandleSRPortCommands:command %d does not exist!\n",data);
			break;
	}
}

//three assistant functions
int 
RemoteServRange::ConnectToServer( )
{
	struct sockaddr_in servaddr;
	int rc = 0;

	#ifdef WALKPATH
	fprintf(stderr,"RemoteServMsg:ConnectToServer...\n");
	#endif
	
	if((sockfd = socket(AF_INET, SOCK_STREAM, 0))<0){
		fprintf(stderr,"RemoteServErr:can not create client socket!\n");
		return 0;
	}
	
	bzero(&servaddr, sizeof(servaddr));
	servaddr.sin_family = AF_INET;
	servaddr.sin_port = htons(serverport);
	if(inet_pton(AF_INET, SERVERADDR, &servaddr.sin_addr)<=0){
		fprintf(stderr,"RemoteServErr:client can not create the servaddr!\n");
		close(sockfd);
		return 0;
	}

	if((rc = connect(sockfd, (struct sockaddr *) &servaddr, sizeof(servaddr)))<0){
		fprintf(stderr,"RemoteServErr:client can not connect to server!\n");
		close(sockfd);
		return 0;
	}
	return sockfd;

}
long 
RemoteServRange::readn(int fd, void* vptr, long n)
{
	long nleft=n;
	long nread;
	char* ptr=(char*)vptr;

	while(nleft>0){
		if((nread=read(fd,ptr,nleft))<0){
			if(errno==EINTR)
				nread=0;
			else
				return -1;
		}else if(nread==0)
			break;
		nleft-=nread;
		ptr+=nread;
	}
	return (n-nleft);
}
long 
RemoteServRange::writen(int fd, const void* vptr, long n)
{
	long nleft=n;
	long nwrite;
	const char* ptr=(char*)vptr;

	while(nleft>0){
		if((nwrite=write(fd,ptr,nleft))<0){
			if(errno==EINTR)
				nwrite=0;
			else 
				return -1;
		}
		nleft-=nwrite;
		ptr+=nwrite;
	}
	return (n-nleft);
}
bool 
RemoteServRange::PackageLengthChecking(package_header_t* pheader)
{
	if(UNITVAL(pheader->packagelen)<=RemoteServBufSize) return true;
	fprintf(stderr,"RemoteServErr: PackageLengthChecking: packagelen is greater than RemoteServBufSize!\n");
	return false;
}

void 
RemoteServRange::SendPackage( )
{
	#ifdef WALKPATH
	fprintf(stderr,"RemoteServMsg:SendPackage...\n");
	#endif
	
	int rc = 0;
	package_header_t* pheader=(package_header_t*)RemoteServRangeMem;

	if(sockfd==0){
		fprintf(stderr,"RemoteServMsg:SendPackage:sockfd is NULL!\n");
		return;
	}
	if(!PackageLengthChecking(pheader)) return;
	rc=writen(sockfd,RemoteServRangeMem,UNITVAL(pheader->packagelen));
	if(rc!=UNITVAL(pheader->packagelen)){
		fprintf(stderr,"RemoteServErr:SendPackage:The package can not be sent all!\n");
		return;
	}

	#ifdef DEBUGSOCKET
	fprintf(stderr,"RemoteServMsg:SendPackage OK! %d bytes are sent.\n",rc);
	#endif
}

void 
RemoteServRange::RecvPackage( )
{
	#ifdef WALKPATH
	fprintf(stderr,"RemoteServMsg:RecvPackage...\n");
	#endif
		
	int rc = 0;
	int left;
	package_header_t* pheader=(package_header_t*)RemoteServRangeMem;

	if(sockfd==0){
		fprintf(stderr,"RemoteServMsg:RecvPackage:sockfd is NULL!\n");
		return;
	}
	rc=readn(sockfd,pheader,sizeof(package_header_t));
	if(rc!=sizeof(package_header_t)){
		fprintf(stderr,"RemoteServErr:RecvPackage:can not get the package header!\n");
		return;
	}
	if(!PackageLengthChecking(pheader)) return;
	left=UNITVAL(pheader->packagelen)-sizeof(package_header_t);
	if(left<0){
		fprintf(stderr,"RemoteServErr:RecvPackage:The package length is less than the header!\n");
		return;
	}
	rc=readn(sockfd,(char*)RemoteServRangeMem+sizeof(package_header_t),left);
	if(rc!=left){
		fprintf(stderr,"RemoteServErr:RecvPackage:The package can not be received all!\n");
		return;
	}

	#ifdef DEBUGSOCKET
	fprintf(stderr,"RemoteServMsg:RecvPackage OK! %d bytes are received.\n",
		UNITVAL(pheader->packagelen));
	#endif
}

void 
RemoteServRange::DisconnectFromServer()
{	
	#ifdef WALKPATH
	fprintf(stderr,"RemoteServMsg:DisconnectFromServer...\n");
	#endif
	if(sockfd) close(sockfd);
}

