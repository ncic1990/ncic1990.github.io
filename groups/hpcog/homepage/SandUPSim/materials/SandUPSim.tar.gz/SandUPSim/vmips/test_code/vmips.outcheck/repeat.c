/*use -O2 to compile, the loop will only has two instruction repeated*/

#include "spimconsreg.h"

#define IOBASE SPIM_ADDR //0xb2000000
#define IS_READY(ctrl) (((*(ctrl)) & CTL_RDY) != 0)

void entry(void)
{

	register int i,c;
	for(i=0;i< 1000000;i++)
		c+=i;	
	/*
	char *p = "Hello, world!\n";
	volatile long *data_reg = (long *)(IOBASE+DISPLAY_1_DATA);
	volatile long *control_reg = (long *)(IOBASE+DISPLAY_1_CONTROL);

	while (*p != '\0') {
		do { 0; } while (! IS_READY(control_reg));
		*data_reg = (long) *p++;
	}
	*/
}
