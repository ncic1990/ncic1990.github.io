/* Pipeline Trace
 * added by zhangwl
*/
#ifndef _PPLSTAT_H
#define _PPLSTAT_H

#include "sysinclude.h"

//class DeviceExc;

/*The following define the mask of each pipeline stage*/
#define IFMask     0x01          // bit 0
#define IDMask     0x02          // bit 1
#define EXMask     0x04          // bit 2
#define MEMMask  0x08          // bit 3
#define WBMask    0x10          // bit 4

#define FEX1Mask   0x0100       // bit 8
#define FEX2Mask   0x0200       // bit 9
#define FEX3Mask   0x0400       // bit 10
#define FWBMask    0x0800       // bit 11
// should consider fp instr additionally
/* bit 5~7, 12~31 are reserved */

/*The following define the control mask*/
#define StagesMask       0x01          // bit 0, according contents need 13 bytes
#define NinstrMask    	   0x02          // bit 1, according contents need 4 bytes
#define NcycleMask       0x04          // bit 2, according contents need 4 bytes
#define NstallMask         0x08          // bit 3, according contents need 4 bytes
#define NrawMask          0x10          // bit 4, according contents need 4 bytes
/*Other bits to be added accordingly*/

struct CLKTRACE_INFO // a double direction list????
{
/*       
       bool exception_if,         // whether exception occurs at IF stage
       	exception_ex,       // whether exception occurs at EX stage 
       	exception_mem;   // whether exception occurs at MEM stage
*/   
	uint32 pc;			  // the current pc of this clock
	uint32 instr;                   // fetched instruction in this clock
	uint32 stagestate;         // use 5 low bits to record the status of each stage in one logic clock
						  // from left to right: WB, MEM, EX, ID, IF,  
						  // 0 for stall and 1 for the according stage
						  
	CLKTRACE_INFO *next;     //????
	CLKTRACE_INFO *prev;					 
};

struct PPLSTAT_INFO
{
	struct CLKTRACE_INFO *stagesinfo; //pipeline stage trace info
	int instr_count,             // the traced instruction counts
	    cycle_count,             // the traced cycles
	    stall_count;              // the stall counts during trace
       int nraw;                        // the instruction count of raw during trace

};
class  PPLSTAT
{
	friend class CLKCPU;
	friend class CLKCPONE;
private:
	bool trace_start;
	uint8 ppl_mask;
	PPLSTAT_INFO  pplstat_info;
	uint32  boolval;
public:
	uint8* buf;
	CLKTRACE_INFO *p;
	PPLSTAT();
	~PPLSTAT();
/*	inline void SetPc(uint32 pc);
	inline void SetInstr(uint32 instr);//need?
	inline void SetnInst(int instr_count);
	inline void SetnCycle(int cycle_count);
	inline void SetnStall(int stall_count);
	inline void SetnRaw(int nraw);
	inline void SetStage(uint32 set_mask);
	 inline void SetClkStages(uint32 instr);
*/

inline void 
SetPc(uint32 pc)
{
	if (trace_start && (ppl_mask & StagesMask))
		p->pc = pc;

}

inline void 
SetInstr(uint32 instr)
{
	if (trace_start && (ppl_mask & StagesMask))
		p->instr = instr;
}

inline void 
SetStage(uint32 set_mask)
{
	if (trace_start)
		boolval = boolval & set_mask;
}

 inline void
SetClkStages()//uint32 instr
{
	if (trace_start)
	{
		p->stagestate = boolval;
		pplstat_info.stagesinfo->next = p;
		p->next = NULL;
	 	if (pplstat_info.stagesinfo != NULL)
	 		p->prev = pplstat_info.stagesinfo;
	 	pplstat_info.stagesinfo = p;
	 // 	pplstat_info.stagesinfo->instr = instr;
	 //	pplstat_info.stagesinfo->pc = pc;
	}
 }
 
inline void 
SetnInst(int instr_count)
{
	if (trace_start && (ppl_mask & NinstrMask))
		pplstat_info.instr_count = instr_count;
}

inline void 
SetnCycle(int cycle_count)
{
	if (trace_start && (ppl_mask & NcycleMask))
		pplstat_info.cycle_count = cycle_count;
}

inline void 
SetnStall(int stall_count)
{
	if (trace_start && (ppl_mask & NstallMask))
		pplstat_info.stall_count = stall_count;
}

inline void 
SetnRaw(int nraw)
{
	if (trace_start && (ppl_mask & NrawMask))
		pplstat_info.nraw = nraw;
}

inline void
RefreshStages()
{
	if (trace_start)
	{
		boolval = 0x00000000;
	    p = new CLKTRACE_INFO;
	}
//	pplstat_info.stagesinfo->instr = -1;
}

//	void RefreshStages();
 	void TraceStart();	
        int  SetTraceMask(uint8 mask);
        void GetTracebuf(uint8*  data);
        void ShowTrace();
        PPLSTAT_INFO RecoverTrace(uint8 mask, uint8* data);
        void TraceEnd();
};
#endif // _PPLSTAT_H
