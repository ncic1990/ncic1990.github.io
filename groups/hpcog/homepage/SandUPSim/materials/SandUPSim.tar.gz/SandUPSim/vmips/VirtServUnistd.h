#ifndef _ASM_I386_UNISTD_H_
#define _ASM_I386_UNISTD_H_

/*
 * This file contains the system call numbers.
 */

#define __NR_tlexit		  1
#define __NR_tlfork		  2
#define __NR_tlread		  3
#define __NR_tlwrite		  4
#define __NR_tlopen		  5
#define __NR_tlclose		  6
#define __NR_tlwaitpid		  7
#define __NR_tlcreat		  8
#define __NR_tllink		  9
#define __NR_tlunlink		 10
#define __NR_tlexecve		 11
#define __NR_tlchdir		 12
#define __NR_tltime		 13
#define __NR_tlmknod		 14
#define __NR_tlchmod		 15
#define __NR_tllchown		 16
#define __NR_tlbreak		 17
#define __NR_tloldstat		 18
#define __NR_tllseek		 19
#define __NR_tlgetpid		 20
#define __NR_tlmount		 21
#define __NR_tlumount		 22
#define __NR_tlsetuid		 23
#define __NR_tlgetuid		 24
#define __NR_tlstime		 25
#define __NR_tlptrace		 26
#define __NR_tlalarm		 27
#define __NR_tloldfstat		 28
#define __NR_tlpause		 29
#define __NR_tlutime		 30
#define __NR_tlstty		 31
#define __NR_tlgtty		 32
#define __NR_tlaccess		 33
#define __NR_tlnice		 34
#define __NR_tlftime		 35
#define __NR_tlsync		 36
#define __NR_tlkill		 37
#define __NR_tlrename		 38
#define __NR_tlmkdir		 39
#define __NR_tlrmdir		 40
#define __NR_tldup		 41
#define __NR_tlpipe		 42
#define __NR_tltimes		 43
#define __NR_tlprof		 44
#define __NR_tlbrk		 45
#define __NR_tlsetgid		 46
#define __NR_tlgetgid		 47
#define __NR_tlsignal		 48
#define __NR_tlgeteuid		 49
#define __NR_tlgetegid		 50
#define __NR_tlacct		 51
#define __NR_tlumount2		 52
#define __NR_tllock		 53
#define __NR_tlioctl		 54
#define __NR_tlfcntl		 55
#define __NR_tlmpx		 56
#define __NR_tlsetpgid		 57
#define __NR_tlulimit		 58
#define __NR_tloldolduname	 59
#define __NR_tlumask		 60
#define __NR_tlchroot		 61
#define __NR_tlustat		 62
#define __NR_tldup2		 63
#define __NR_tlgetppid		 64
#define __NR_tlgetpgrp		 65
#define __NR_tlsetsid		 66
#define __NR_tlsigaction		 67
#define __NR_tlsgetmask		 68
#define __NR_tlssetmask		 69
#define __NR_tlsetreuid		 70
#define __NR_tlsetregid		 71
#define __NR_tlsigsuspend		 72
#define __NR_tlsigpending		 73
#define __NR_tlsethostname	 74
#define __NR_tlsetrlimit		 75
#define __NR_tlgetrlimit		 76	/* Back compatible 2Gig limited rlimit */
#define __NR_tlgetrusage		 77
#define __NR_tlgettimeofday	 78
#define __NR_tlsettimeofday	 79
#define __NR_tlgetgroups		 80
#define __NR_tlsetgroups		 81
#define __NR_tlselect		 82
#define __NR_tlsymlink		 83
#define __NR_tloldlstat		 84
#define __NR_tlreadlink		 85
#define __NR_tluselib		 86
#define __NR_tlswapon		 87
#define __NR_tlreboot		 88
#define __NR_tlreaddir		 89
#define __NR_tlmmap		 90
#define __NR_tlmunmap		 91
#define __NR_tltruncate		 92
#define __NR_tlftruncate		 93
#define __NR_tlfchmod		 94
#define __NR_tlfchown		 95
#define __NR_tlgetpriority	 96
#define __NR_tlsetpriority	 97
#define __NR_tlprofil		 98
#define __NR_tlstatfs		 99
#define __NR_tlfstatfs		100
#define __NR_tlioperm		101
#define __NR_tlsocketcall		102
#define __NR_tlsyslog		103
#define __NR_tlsetitimer		104
#define __NR_tlgetitimer		105
#define __NR_tlstat		106
#define __NR_tllstat		107
#define __NR_tlfstat		108
#define __NR_tlolduname		109
#define __NR_tliopl		110
#define __NR_tlvhangup		111
#define __NR_tlidle		112
#define __NR_tlvm86old		113
#define __NR_tlwait4		114
#define __NR_tlswapoff		115
#define __NR_tlsysinfo		116
#define __NR_tlipc		117
#define __NR_tlfsync		118
#define __NR_tlsigreturn		119
#define __NR_tlclone		120
#define __NR_tlsetdomainname	121
#define __NR_tluname		122
#define __NR_tlmodify_ldt		123
#define __NR_tladjtimex		124
#define __NR_tlmprotect		125
#define __NR_tlsigprocmask	126
#define __NR_tlcreate_module	127
#define __NR_tlinit_module	128
#define __NR_tldelete_module	129
#define __NR_tlget_kernel_syms	130
#define __NR_tlquotactl		131
#define __NR_tlgetpgid		132
#define __NR_tlfchdir		133
#define __NR_tlbdflush		134
#define __NR_tlsysfs		135
#define __NR_tlpersonality	136
#define __NR_tlafs_syscall	137 /* Syscall for Andrew File System */
#define __NR_tlsetfsuid		138
#define __NR_tlsetfsgid		139
#define __NR_tl_llseek		140
#define __NR_tlgetdents		141
#define __NR_tl_newselect		142
#define __NR_tlflock		143
#define __NR_tlmsync		144
#define __NR_tlreadv		145
#define __NR_tlwritev		146
#define __NR_tlgetsid		147
#define __NR_tlfdatasync		148
#define __NR_tl_sysctl		149
#define __NR_tlmlock		150
#define __NR_tlmunlock		151
#define __NR_tlmlockall		152
#define __NR_tlmunlockall		153
#define __NR_tlsched_setparam		154
#define __NR_tlsched_getparam		155
#define __NR_tlsched_setscheduler		156
#define __NR_tlsched_getscheduler		157
#define __NR_tlsched_yield		158
#define __NR_tlsched_get_priority_max	159
#define __NR_tlsched_get_priority_min	160
#define __NR_tlsched_rr_get_interval	161
#define __NR_tlnanosleep		162
#define __NR_tlmremap		163
#define __NR_tlsetresuid		164
#define __NR_tlgetresuid		165
#define __NR_tlvm86		166
#define __NR_tlquery_module	167
#define __NR_tlpoll		168
#define __NR_tlnfsservctl		169
#define __NR_tlsetresgid		170
#define __NR_tlgetresgid		171
#define __NR_tlprctl              172
#define __NR_tlrt_sigreturn	173
#define __NR_tlrt_sigaction	174
#define __NR_tlrt_sigprocmask	175
#define __NR_tlrt_sigpending	176
#define __NR_tlrt_sigtimedwait	177
#define __NR_tlrt_sigqueueinfo	178
#define __NR_tlrt_sigsuspend	179
#define __NR_tlpread		180
#define __NR_tlpwrite		181
#define __NR_tlchown		182
#define __NR_tlgetcwd		183
#define __NR_tlcapget		184
#define __NR_tlcapset		185
#define __NR_tlsigaltstack	186
#define __NR_tlsendfile		187
#define __NR_tlgetpmsg		188	/* some people actually want streams */
#define __NR_tlputpmsg		189	/* some people actually want streams */
#define __NR_tlvfork		190
#define __NR_tlugetrlimit		191	/* SuS compliant getrlimit */
#define __NR_tlmmap2		192
#define __NR_tltruncate64		193
#define __NR_tlftruncate64	194
#define __NR_tlstat64		195
#define __NR_tllstat64		196
#define __NR_tlfstat64		197
#define __NR_tllchown32		198
#define __NR_tlgetuid32		199
#define __NR_tlgetgid32		200
#define __NR_tlgeteuid32		201
#define __NR_tlgetegid32		202
#define __NR_tlsetreuid32		203
#define __NR_tlsetregid32		204
#define __NR_tlgetgroups32	205
#define __NR_tlsetgroups32	206
#define __NR_tlfchown32		207
#define __NR_tlsetresuid32	208
#define __NR_tlgetresuid32	209
#define __NR_tlsetresgid32	210
#define __NR_tlgetresgid32	211
#define __NR_tlchown32		212
#define __NR_tlsetuid32		213
#define __NR_tlsetgid32		214
#define __NR_tlsetfsuid32		215
#define __NR_tlsetfsgid32		216
#define __NR_tlpivot_root		217
#define __NR_tlmincore		218
#define __NR_tlmadvise		219
#define __NR_tlmadvise1		219	/* delete when C lib stub is removed */
#define __NR_tlgetdents64		220
#define __NR_tlfcntl64		221
#define __NR_tlsecurity		223	/* syscall for security modules */
#define __NR_tlgettid		224
#define __NR_tlreadahead		225
#define __NR_tlsetxattr		226
#define __NR_tllsetxattr		227
#define __NR_tlfsetxattr		228
#define __NR_tlgetxattr		229
#define __NR_tllgetxattr		230
#define __NR_tlfgetxattr		231
#define __NR_tllistxattr		232
#define __NR_tlllistxattr		233
#define __NR_tlflistxattr		234
#define __NR_tlremovexattr	235
#define __NR_tllremovexattr	236
#define __NR_tlfremovexattr	237
#define __NR_tltkill		238
#define __NR_tlsendfile64		239
#define __NR_tlfutex		240
#define __NR_tlsched_setaffinity	241
#define __NR_tlsched_getaffinity	242
#define __NR_tlset_thread_area	243
#define __NR_tlget_thread_area	244
#define __NR_tlio_setup		245
#define __NR_tlio_destroy		246
#define __NR_tlio_getevents	247
#define __NR_tlio_submit		248
#define __NR_tlio_cancel		249
#define __NR_tlalloc_hugepages	250
#define __NR_tlfree_hugepages	251
#define __NR_tlexit_group		252
#define __NR_tllookup_dcookie	253
#define __NR_tlset_tid_address	258

/* user-visible error numbers are in the range -1 - -124: see <asm-i386/errno.h> */

#define __syscall_return(type, res) \
do { \
	if ((unsigned long)(res) >= (unsigned long)(-125)) { \
		errno = -(res); \
		res = -1; \
	} \
	return (type) (res); \
} while (0)

/* XXX - _foo needs to be __foo, while __NR_bar could be _NR_bar. */
#define _syscall0(type,name) \
type name(void) \
{ \
long __res; \
__asm__ volatile ("int $0x80" \
	: "=a" (__res) \
	: "0" (__NR_##name)); \
__syscall_return(type,__res); \
}

#define _syscall1(type,name,type1,arg1) \
type name(type1 arg1) \
{ \
long __res; \
__asm__ volatile ("int $0x80" \
	: "=a" (__res) \
	: "0" (__NR_##name),"b" ((long)(arg1))); \
__syscall_return(type,__res); \
}

#define _syscall2(type,name,type1,arg1,type2,arg2) \
type name(type1 arg1,type2 arg2) \
{ \
long __res; \
__asm__ volatile ("int $0x80" \
	: "=a" (__res) \
	: "0" (__NR_##name),"b" ((long)(arg1)),"c" ((long)(arg2))); \
__syscall_return(type,__res); \
}

#define _syscall3(type,name,type1,arg1,type2,arg2,type3,arg3) \
type name(type1 arg1,type2 arg2,type3 arg3) \
{ \
long __res; \
__asm__ volatile ("int $0x80" \
	: "=a" (__res) \
	: "0" (__NR_##name),"b" ((long)(arg1)),"c" ((long)(arg2)), \
		  "d" ((long)(arg3))); \
__syscall_return(type,__res); \
}

#define _syscall4(type,name,type1,arg1,type2,arg2,type3,arg3,type4,arg4) \
type name (type1 arg1, type2 arg2, type3 arg3, type4 arg4) \
{ \
long __res; \
__asm__ volatile ("int $0x80" \
	: "=a" (__res) \
	: "0" (__NR_##name),"b" ((long)(arg1)),"c" ((long)(arg2)), \
	  "d" ((long)(arg3)),"S" ((long)(arg4))); \
__syscall_return(type,__res); \
} 

#define _syscall5(type,name,type1,arg1,type2,arg2,type3,arg3,type4,arg4, \
	  type5,arg5) \
type name (type1 arg1,type2 arg2,type3 arg3,type4 arg4,type5 arg5) \
{ \
long __res; \
__asm__ volatile ("int $0x80" \
	: "=a" (__res) \
	: "0" (__NR_##name),"b" ((long)(arg1)),"c" ((long)(arg2)), \
	  "d" ((long)(arg3)),"S" ((long)(arg4)),"D" ((long)(arg5))); \
__syscall_return(type,__res); \
}

#define _syscall6(type,name,type1,arg1,type2,arg2,type3,arg3,type4,arg4, \
	  type5,arg5,type6,arg6) \
type name (type1 arg1,type2 arg2,type3 arg3,type4 arg4,type5 arg5,type6 arg6) \
{ \
long __res; \
__asm__ volatile ("push %%ebp ; movl %%eax,%%ebp ; movl %1,%%eax ; int $0x80 ; pop %%ebp" \
	: "=a" (__res) \
	: "i" (__NR_##name),"b" ((long)(arg1)),"c" ((long)(arg2)), \
	  "d" ((long)(arg3)),"S" ((long)(arg4)),"D" ((long)(arg5)), \
	  "0" ((long)(arg6))); \
__syscall_return(type,__res); \
}

#ifdef __KERNEL_SYSCALLS__

/*
 * we need this inline - forking from kernel space will result
 * in NO COPY ON WRITE (!!!), until an execve is executed. This
 * is no problem, but for the stack. This is handled by not letting
 * main() use the stack at all after fork(). Thus, no function
 * calls - which means inline code for fork too, as otherwise we
 * would use the stack upon exit from 'fork()'.
 *
 * Actually only pause and fork are needed inline, so that there
 * won't be any messing with the stack from main(), but we define
 * some others too.
 */
#define __NR__exit __NR_exit
static inline _syscall0(int,pause)
static inline _syscall0(int,sync)
static inline _syscall0(pid_t,setsid)
static inline _syscall3(int,write,int,fd,const char *,buf,off_t,count)
static inline _syscall3(int,read,int,fd,char *,buf,off_t,count)
static inline _syscall3(off_t,lseek,int,fd,off_t,offset,int,count)
static inline _syscall1(int,dup,int,fd)
static inline _syscall3(int,execve,const char *,file,char **,argv,char **,envp)
static inline _syscall3(int,open,const char *,file,int,flag,int,mode)
static inline _syscall1(int,close,int,fd)
static inline _syscall1(int,_exit,int,exitcode)
static inline _syscall3(pid_t,waitpid,pid_t,pid,int *,wait_stat,int,options)
static inline _syscall1(int,delete_module,const char *,name)

static inline pid_t wait(int * wait_stat)
{
	return waitpid(-1,wait_stat,0);
}

#endif

/*
 * "Conditional" syscalls
 *
 * What we want is __attribute__((weak,alias("sys_ni_syscall"))),
 * but it doesn't work on all toolchains, so we just do it by hand
 */
#define cond_syscall(x) asm(".weak\t" #x "\n\t.set\t" #x ",sys_ni_syscall");

#endif /* _ASM_I386_UNISTD_H_ */

