#ifndef KFLAG_H
#define KFLAG_H

#include "KVirtServ.h"
#include "servlibopt.h"

#ifndef ALWAYSVIRT
extern long VIRTSERVFLAG;
#define COMMONVIRTSERVFLAG VIRTSERVFLAG
#else
#define COMMONVIRTSERVFLAG 1
#endif

#endif

