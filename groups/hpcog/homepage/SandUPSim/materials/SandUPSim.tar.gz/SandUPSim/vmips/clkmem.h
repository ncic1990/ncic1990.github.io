/*This is the Addr module of sand simulator, which is developed by
ASL group of NCIC;
Copyright 2003 by ASL NCIC */

#ifndef _CLKMEM_
#define  _CLKMEM_

#include "mapper.h"
#include "clkmemreg.h"

#define CLKMAX  0xffffffffffffffffUL

class ClkMem
{
private:
	typedef enum
	{
		READ,
		WRITE,
		/*
		ACTIVE,
		PRECHARGE,
		*/
		REFRESH,
		IDLE
	}state_t;
	typedef enum
	{
		READCMD, 
		WRITECMD
		/*,
		ACTIVECMD,
		TERMINATECMD,
		REFRESHCMD,
		PRECHARGECMD */
	}cmd_t;
	typedef struct
	{
		state_t  stat;
		int row;             // record the active row number
		uint64 lefttime;	// time left to implement the current operation	
	}bank_t;
	
	caddr_t  address;
	bool started;
	uint64  clock ;     /*the even value represents the rising edge, and odd value represents the down edge */
	uint16 rfcounter;
	Mapper *mapper;
	
	int currentbank;  /*point to the current operation bank*/
	int currentrow;   /*point to the current operaton row*/	
	uint64 lasttime;  /*last operation time*/	
	
	
	bank_t  bank[BANKNUM];

	void initialize();
	void refresh();	
	void step();
	uint64 difftime(uint64 ptime, uint64 ctime);
	void addrparse(uint32 addr,int *bank, int *row);
	int bankdelay(cmd_t cmd);  //time needed between command between different bank
	int srowdelay(cmd_t cmd);
	int drowdelay(cmd_t cmd);
	int operationdelay(cmd_t cmd, bool bst);
	int totaldelay(uint32 addr, cmd_t cmd, bool bst);
public:
	ClkMem(bool opt_clkmem = false);
	void getclock();
	void getaddress();
	void attach(Mapper * m = NULL);
	void startdram();
	void enddram();
	bool getdramstart();
	
	int  getbslen();
	uint32  getmemsize();
	int getfreq();
	
	void fetchword(uint32 addr, uint32* data, uint8 *delay_time);
	void fetchhword(uint32 addr, uint16* data, uint8 *delay_time);
	void fetchbyte(uint32 addr, uint8* data, uint8 *delay_time);
	void storeword(uint32 addr, uint32 data, uint8* delay_time);
	void storehword(uint32 addr, uint16 data, uint8 *delay_time);
	void storebyte(uint32 addr, uint8 data, uint8* delay_time);
	
	void readdram(uint32 addr, uint64 *data,  uint8 *delay_time);
	void writedram(uint32 addr, uint64 *data,  uint8 * delay_time);
};
#endif /*_CLKMEM_*/
