#ifndef LINUXSYSCALLOPT_H
#define LINUXSYSCALLOPT_H

//#define SYSCALLINLINE

#endif

