#include "rslinuxsyscall.h"
#include "localtoremote.h"
#include "MMVirtualMemory.h"
#include "LibcLinuxTypes.h"
#include "LinuxSyscallUnistd.h"
#include "LinuxSyscallErrno.h"

//#ifdef REMOTESYSCALL
/*slfsmm031122_add>for remote syscall*/
extern long rmt_errno;

//#define WALKPATH
//#define DEBUGREMOTESYSCALL

void HandlingrsLinuxSyscall(ThreadId fromId,long syscallno, 
	ProcContextPtr contextPtr,long reserved,unsigned long int delayslot)
//note:varialble delayslot is ignored
{
	#ifdef WALKPATH
	ioConsolePutString("Handling remote Linux syscall entry...\n");
	#endif
	switch(syscallno){
		case __NR_sys_exit:
			rsLinuxSyscallExit(fromId,contextPtr,delayslot);//v0==4001
			break;
		case __NR_sys_read:
			rsLinuxSyscallRead(contextPtr);//v0==4003
			break;
		case __NR_sys_write:
			rsLinuxSyscallWrite(contextPtr);//v0==4004
			break;
		case __NR_sys_open:
			rsLinuxSyscallOpen(contextPtr);//v0==4005
			break;
		case __NR_sys_close:
			rsLinuxSyscallClose(contextPtr);//v0==4006
			break;
		case __NR_sys_unlink:
			rsLinuxSyscallunlink(contextPtr);//v0==4010
			break;
		case __NR_sys_time:
			rsLinuxSyscalltime(contextPtr);//v0==4013
			break;
		case __NR_sys_lseek:
			rsLinuxSyscalllseek(contextPtr);//v0==4019
			break;
		case __NR_sys_getpid:
			rsLinuxSyscallgetpid(contextPtr);//v0==4020
			break;
		case __NR_sys_getuid:
			rsLinuxSyscallgetuid(contextPtr);//v0==4024
			break;
		case __NR_sys_access:
			rsLinuxSyscallaccess(contextPtr);//v0==4033
			break;
		case __NR_sys_rename:
			rsLinuxSyscallrename(contextPtr);//v0==4038
			break;
		case __NR_sys_times:
			rsLinuxSyscalltimes(contextPtr);//v0==4043
			break;
		case __NR_sys_brk:
			rsLinuxSyscallbrk(fromId,contextPtr,delayslot);//v0==4045
			break;
		case __NR_sys_getgid:
			rsLinuxSyscallgetgid(contextPtr);//v0==4047
			break;
		case __NR_sys_geteuid:
			rsLinuxSyscallgeteuid(contextPtr);//v0==4049
			break;
		case __NR_sys_getegid:
			rsLinuxSyscallgetegid(contextPtr);//v0==4050
			break;
		case __NR_sys_ioctl:
			rsLinuxSyscallioctl(contextPtr);//v0==4054
			break;
		case __NR_sys_fcntl:
			rsLinuxSyscallfcntl(contextPtr);//v0==4055
			break;
		case __NR_sys_setrlimit:
			rsLinuxSyscallsetrlimit(fromId,syscallno,contextPtr,delayslot);//v0==4075
			break;
		case __NR_sys_getrlimit:
			rsLinuxSyscallgetrlimit(contextPtr);//v0==4076
			break;
		case __NR_sys_getrusage:
			rsLinuxSyscallgetrusage(contextPtr);//v0==4077
			break;
		case __NR_sys_mmap:
			rsLinuxSyscallmmap(fromId,contextPtr,delayslot);//v0==4090
			break;
		case __NR_sys_munmap:
			rsLinuxSyscallmunmap(fromId,contextPtr,delayslot);//v0==4091
			break;
		case __NR_sys_ftruncate:
			rsLinuxSyscallftruncate(contextPtr);//v0==4093
			break;
		case __NR_sys_stat:
			rsLinuxSyscallstat(contextPtr);//v0==4106
			break;
		case __NR_sys_lstat:
			rsLinuxSyscalllstat(contextPtr);//v0==4107
			break;
		case __NR_sys_fstat:
			rsLinuxSyscallfstat(contextPtr);//v0==4108
			break;
		case __NR_sys_uname:
			rsLinuxSyscallnewuname(contextPtr);//v0==4122
			break;
		case __NR_sys_mprotect:
			rsLinuxSyscallmprotect(fromId,contextPtr,delayslot);//v0==4125
			break;
		case __NR_sys__llseek:
			rsLinuxSyscall_llseek(contextPtr);//v0==4140
			break;
		case __NR_sys__newselect:
			rsLinuxSyscall_newselect(contextPtr);//v0==4142
			break;
		case __NR_sys_nanosleep:
			rsLinuxSyscallnanosleep(fromId,syscallno,contextPtr,delayslot);//v0==4166
			break;
		case __NR_sys_rt_sigaction:
			rsLinuxSyscallrt_sigaction(fromId,syscallno,contextPtr,delayslot);//v0==4194
			break;
		case __NR_sys_rt_sigprocmask:
			rsLinuxSyscallrt_sigprocmask(fromId,syscallno,contextPtr,delayslot);//v0==4195
			break;
		case __NR_sys_mmap2:
			rsLinuxSyscallmmap2(fromId,contextPtr,delayslot);//v0==4210
			break;
		case __NR_sys_ftruncate64:
			rsLinuxSyscallftruncate64(contextPtr);//v0==4212
			break;
		case __NR_sys_stat64:
			rsLinuxSyscallstat64(contextPtr);//v0==4213
			break;
		case __NR_sys_lstat64:
			rsLinuxSyscalllstat64(contextPtr);//v0==4214
			break;
		case __NR_sys_fstat64:
			rsLinuxSyscallfstat64(contextPtr);//v0==4215
			break;
		case __NR_sys_fcntl64:
			rsLinuxSyscallfcntl64(contextPtr);//v0==4220
			break;
		default:
			rsSysCallNotImplemented(contextPtr,syscallno);
			break;
	}
}

#define SYSCALLARG(n) ((long)contextPtr->argument[n])

unsigned long SYSCALLARG_STACK(ProcContextPtr contextPtr,unsigned long which)
{
	unsigned long* stackarr=(long*)contextPtr->stackPointer;
	return stackarr[which];
}

void HandleReturnValue(ProcContextPtr contextPtr,long ret)
{
	if(ret>=0){
		contextPtr->argument[3]=(Register)0;
		contextPtr->returnValue[0]=(Register)ret;
	}else{
		contextPtr->argument[3]=(Register)1;
		contextPtr->returnValue[0]=(Register)rmt_errno;
	}
}

void rsSysCallNotImplemented(ProcContextPtr contextPtr,long syscallno)
{
	ioConsolePutString("client msg:System call not implemented! Syscall number is : 4000+0x");
	ioConsolePutHexInt(syscallno-4000);
	long ret=-1;
	rmt_errno=ENOSYS;
	HandleReturnValue(contextPtr,ret);
}

void rsSyscallCheatingRet(ProcContextPtr contextPtr,long syscallno,long ret)
{
	ioConsolePutString("client msg:Cheating system call. Syscall number is : 4000+0x");
	ioConsolePutHexInt(syscallno-4000);
	HandleReturnValue(contextPtr,ret);
}

void rsLinuxSyscallExit(ThreadId fromId,ProcContextPtr contextPtr,
	unsigned long int delayslot)//v0==4001
{
	Message message={TMTHREADID,TM_EXIT};
	
	#ifdef DEBUGREMOTESYSCALL
	ioConsolePutString("Linux syscall exit...\n");
	#endif

	//hehe,cheating
	message.msg.tmKill.id=(ThreadId)SYSCALLARG(0);
	msgDispatcher(fromId,&message,0,SYSCALL_SEND_OP,delayslot);
}

void rsLinuxSyscallRead(ProcContextPtr contextPtr)//v0==4003
{
	#ifdef DEBUGREMOTESYSCALL
	ioConsolePutString("Linux syscall read...\n");
	#endif
	long ret=rslinuxread(SYSCALLARG(0), (char*)SYSCALLARG(1),SYSCALLARG(2));
	HandleReturnValue(contextPtr,ret);
}

void rsLinuxSyscallWrite(ProcContextPtr contextPtr)//v0==4004
{
	#ifdef DEBUGREMOTESYSCALL
	ioConsolePutString("Linux syscall write...\n");
	#endif
	long ret=rslinuxwrite(SYSCALLARG(0), (char*)SYSCALLARG(1),SYSCALLARG(2));
	HandleReturnValue(contextPtr,ret);
}

void rsLinuxSyscallOpen(ProcContextPtr contextPtr)//v0==4005
{
	#ifdef DEBUGREMOTESYSCALL
	ioConsolePutString("Linux syscall open...\n");
	#endif
	long ret=rslinuxopen((char*)SYSCALLARG(0), SYSCALLARG(1),SYSCALLARG(2));
	HandleReturnValue(contextPtr,ret);
}

void rsLinuxSyscallClose(ProcContextPtr contextPtr)//v0==4006
{
	#ifdef DEBUGREMOTESYSCALL
	ioConsolePutString("Linux syscall close...\n");
	#endif
	long ret=rslinuxclose(SYSCALLARG(0));
	HandleReturnValue(contextPtr,ret);
}

void rsLinuxSyscallunlink(ProcContextPtr contextPtr)//v0==4010
{
	#ifdef DEBUGREMOTESYSCALL
	ioConsolePutString("Linux syscall unlink...\n");
	#endif
	long ret=rslinuxunlink((char*)SYSCALLARG(0));
	HandleReturnValue(contextPtr,ret);
}

void rsLinuxSyscalltime(ProcContextPtr contextPtr)//v0==4013
{
	#ifdef DEBUGREMOTESYSCALL
	ioConsolePutString("Linux syscall time...\n");
	#endif
	long ret=rslinuxtime((int*)SYSCALLARG(0));
	HandleReturnValue(contextPtr,ret);
}

void rsLinuxSyscalllseek(ProcContextPtr contextPtr)//v0==4019
{
	#ifdef DEBUGREMOTESYSCALL
	ioConsolePutString("Linux syscall lseek...\n");
	#endif
	long ret=rslinuxlseek(SYSCALLARG(0), SYSCALLARG(1),SYSCALLARG(2));
	HandleReturnValue(contextPtr,ret);
}

void rsLinuxSyscallgetpid(ProcContextPtr contextPtr)//v0==4020
{
	#ifdef DEBUGREMOTESYSCALL
	ioConsolePutString("Linux syscall getpid...\n");
	#endif
	long ret=rslinuxgetpid();
	HandleReturnValue(contextPtr,ret);
}

void rsLinuxSyscallgetuid(ProcContextPtr contextPtr)//v0==4024
{
	#ifdef DEBUGREMOTESYSCALL
	ioConsolePutString("Linux syscall getuid...\n");
	#endif
	long ret=rslinuxgetuid();
	HandleReturnValue(contextPtr,ret);
}

void rsLinuxSyscallaccess(ProcContextPtr contextPtr)//v0==4033
{
	#ifdef DEBUGREMOTESYSCALL
	ioConsolePutString("Linux syscall access...\n");
	#endif
	long ret=rslinuxaccess((char*)SYSCALLARG(0),SYSCALLARG(1));
	HandleReturnValue(contextPtr,ret);
}

void rsLinuxSyscallrename(ProcContextPtr contextPtr)//v0==4038
{
	#ifdef DEBUGREMOTESYSCALL
	ioConsolePutString("Linux syscall rename...\n");
	#endif
	long ret=rslinuxrename((char*)SYSCALLARG(0),(char*)SYSCALLARG(1));
	HandleReturnValue(contextPtr,ret);
}

void rsLinuxSyscalltimes(ProcContextPtr contextPtr)//v0==4043
{
	#ifdef DEBUGREMOTESYSCALL
	ioConsolePutString("Linux syscall times...\n");
	#endif
	long ret=rslinuxtimes((struct tms*)SYSCALLARG(0));
	HandleReturnValue(contextPtr,ret);
}

void rsLinuxSyscallbrk(ThreadId fromId,ProcContextPtr contextPtr,
	unsigned long int delayslot)//v0==4045
{
	#ifdef DEBUGREMOTESYSCALL
	ioConsolePutString("Linux syscall brk...\n");
	#endif
	brk(SYSCALLARG(0), fromId);
}

void rsLinuxSyscallgetgid(ProcContextPtr contextPtr)//v0==4047
{
	#ifdef DEBUGREMOTESYSCALL
	ioConsolePutString("Linux syscall getgid...\n");
	#endif
	long ret=rslinuxgetgid( );
	HandleReturnValue(contextPtr,ret);
}

void rsLinuxSyscallgeteuid(ProcContextPtr contextPtr)//v0==4049
{
	#ifdef DEBUGREMOTESYSCALL
	ioConsolePutString("Linux syscall geteuid...\n");
	#endif
	long ret=rslinuxgeteuid( );
	HandleReturnValue(contextPtr,ret);
}

void rsLinuxSyscallgetegid(ProcContextPtr contextPtr)//v0==4050
{
	#ifdef DEBUGREMOTESYSCALL
	ioConsolePutString("Linux syscall getegid...\n");
	#endif
	long ret=rslinuxgetegid( );
	HandleReturnValue(contextPtr,ret);
}

void rsLinuxSyscallioctl(ProcContextPtr contextPtr)//v0==4054
{
	#ifdef DEBUGREMOTESYSCALL
	ioConsolePutString("Linux syscall ioctl...\n");
	#endif
	long ret=rslinuxioctl(SYSCALLARG(0),SYSCALLARG(1),SYSCALLARG(2));
	HandleReturnValue(contextPtr,ret);
}

void rsLinuxSyscallfcntl(ProcContextPtr contextPtr)//v0==4055
{
	#ifdef DEBUGREMOTESYSCALL
	ioConsolePutString("Linux syscall fcntl...\n");
	#endif
	long ret=rslinuxfcntl(SYSCALLARG(0), SYSCALLARG(1),SYSCALLARG(2));
	HandleReturnValue(contextPtr,ret);
}

void rsLinuxSyscallsetrlimit(ThreadId fromId,long syscallno,
	ProcContextPtr contextPtr,unsigned long int delayslot)//v0==4075
{
	#ifdef DEBUGREMOTESYSCALL
	ioConsolePutString("Linux syscall setrlimit...\n");
	#endif
	long ret=0;
	rmt_errno=0;
	rsSyscallCheatingRet(contextPtr,syscallno,ret);
}

void rsLinuxSyscallgetrlimit(ProcContextPtr contextPtr)//v0==4076
{
	#ifdef DEBUGREMOTESYSCALL
	ioConsolePutString("Linux syscall getrlimit...\n");
	#endif
	long ret=rslinuxgetrlimit(SYSCALLARG(0), (struct rlimitformips *)SYSCALLARG(1));
	HandleReturnValue(contextPtr,ret);
}

void rsLinuxSyscallgetrusage(ProcContextPtr contextPtr)//v0==4077
{
	#ifdef DEBUGREMOTESYSCALL
	ioConsolePutString("Linux syscall getrusage...\n");
	#endif
	long ret=rslinuxgetrusage(SYSCALLARG(0), (struct rusageformips*)SYSCALLARG(1));
	HandleReturnValue(contextPtr,ret);
}

void rsLinuxSyscallmmap(ThreadId fromId,ProcContextPtr contextPtr,
	unsigned long int delayslot)//v0==4090
{
	#ifdef DEBUGREMOTESYSCALL
	ioConsolePutString("Linux syscall mmap...\n");
	#endif
	unsigned long* stackarr=(long*)contextPtr->stackPointer;
	unsigned long arg4=stackarr[4];
	unsigned long arg5=stackarr[5];
	mmap(SYSCALLARG(0), SYSCALLARG(1),SYSCALLARG(2),SYSCALLARG(3),
		arg4,arg5,fromId);
}

void rsLinuxSyscallmunmap(ThreadId fromId,ProcContextPtr contextPtr,
	unsigned long int delayslot)//v0==4091
{
	#ifdef DEBUGREMOTESYSCALL
	ioConsolePutString("Linux syscall munmap...\n");
	#endif
	munmap(SYSCALLARG(0), SYSCALLARG(1),fromId);
}

void rsLinuxSyscallftruncate(ProcContextPtr contextPtr)//v0==4093
{
	#ifdef DEBUGREMOTESYSCALL
	ioConsolePutString("Linux syscall ftruncate...\n");
	#endif
	long ret=rslinuxftruncate(SYSCALLARG(0), SYSCALLARG(1));
	HandleReturnValue(contextPtr,ret);
}

void rsLinuxSyscallstat(ProcContextPtr contextPtr)//v0==4106
{
	#ifdef DEBUGREMOTESYSCALL
	ioConsolePutString("Linux syscall stat...\n");
	#endif
	long ret=rslinuxstat((char*)SYSCALLARG(0), (struct statformips*)SYSCALLARG(1));
	HandleReturnValue(contextPtr,ret);
}

void rsLinuxSyscalllstat(ProcContextPtr contextPtr)//v0==4107
{
	#ifdef DEBUGREMOTESYSCALL
	ioConsolePutString("Linux syscall lstat...\n");
	#endif
	long ret=rslinuxlstat((char*)SYSCALLARG(0), (struct statformips*)SYSCALLARG(1));
	HandleReturnValue(contextPtr,ret);
}

void rsLinuxSyscallfstat(ProcContextPtr contextPtr)//v0==4108
{
	#ifdef DEBUGREMOTESYSCALL
	ioConsolePutString("Linux syscall fstat...\n");
	#endif
	long ret=rslinuxfstat(SYSCALLARG(0), (struct statformips*)SYSCALLARG(1));
	HandleReturnValue(contextPtr,ret);
}

void rsLinuxSyscallnewuname(ProcContextPtr contextPtr)//v0==4122
{
	#ifdef DEBUGREMOTESYSCALL
	ioConsolePutString("Linux syscall newuname...\n");
	#endif
	long ret=rslinuxnewuname((new_utsname_formips*)SYSCALLARG(0));
	HandleReturnValue(contextPtr,ret);
}

void rsLinuxSyscallmprotect(ThreadId fromId,ProcContextPtr contextPtr,
	unsigned long int delayslot)//v0==4125
{
	#ifdef DEBUGREMOTESYSCALL
	ioConsolePutString("Linux syscall mprotect...\n");
	#endif
	mprotect(SYSCALLARG(0), SYSCALLARG(1),SYSCALLARG(2),fromId);
}

void rsLinuxSyscall_llseek(ProcContextPtr contextPtr)//v0==4140
{
	#ifdef DEBUGREMOTESYSCALL
	ioConsolePutString("Linux syscall llseek...\n");
	#endif
	unsigned long arg4=SYSCALLARG_STACK(contextPtr,4);
	long ret=rslinuxllseek(SYSCALLARG(0), SYSCALLARG(1),
		SYSCALLARG(2), (loff_t*)SYSCALLARG(3),arg4);
	HandleReturnValue(contextPtr,ret);
}

void rsLinuxSyscall_newselect(ProcContextPtr contextPtr)//v0==4142
{
	#ifdef DEBUGREMOTESYSCALL
	ioConsolePutString("Linux syscall newselect...\n");
	#endif
	unsigned long arg4=SYSCALLARG_STACK(contextPtr,4);
	long ret=rslinuxselect(SYSCALLARG(0), (fd_set*)SYSCALLARG(1),
		(fd_set*)SYSCALLARG(2), (fd_set*)SYSCALLARG(3),(struct timeval *)arg4);
	HandleReturnValue(contextPtr,ret);
}

void rsLinuxSyscallnanosleep(ThreadId fromId,long syscallno,
	ProcContextPtr contextPtr,unsigned long int delayslot)//v0==4166
{
	#ifdef DEBUGREMOTESYSCALL
	ioConsolePutString("Linux syscall nanosleep...\n");
	#endif
	long ret=0;
	rmt_errno=0;
	rsSyscallCheatingRet(contextPtr,syscallno,ret);
}

void rsLinuxSyscallrt_sigaction(ThreadId fromId,long syscallno,
	ProcContextPtr contextPtr,unsigned long int delayslot)//v0==4194
{
	#ifdef DEBUGREMOTESYSCALL
	ioConsolePutString("Linux syscall rt_sigaction...\n");
	#endif
	long ret=0;
	rmt_errno=0;
	rsSyscallCheatingRet(contextPtr,syscallno,ret);
}

void rsLinuxSyscallrt_sigprocmask(ThreadId fromId,long syscallno,
	ProcContextPtr contextPtr,unsigned long int delayslot)//v0==4195
{
	#ifdef DEBUGREMOTESYSCALL
	ioConsolePutString("Linux syscall rt_sigprocmask...\n");
	#endif
	long ret=0;
	rmt_errno=0;
	rsSyscallCheatingRet(contextPtr,syscallno,ret);
}

void rsLinuxSyscallmmap2(ThreadId fromId,ProcContextPtr contextPtr,
	unsigned long int delayslot)//v0==4210
{
	#ifdef DEBUGREMOTESYSCALL
	ioConsolePutString("Linux syscall mmap2...\n");
	#endif
	unsigned long* stackarr=(long*)contextPtr->stackPointer;
	unsigned long arg4=stackarr[4];
	unsigned long arg5=stackarr[5];
	mmap(SYSCALLARG(0), SYSCALLARG(1),SYSCALLARG(2),SYSCALLARG(3),
		arg4,arg5,fromId);
}

void rsLinuxSyscallftruncate64(ProcContextPtr contextPtr)//v0==4212
{
	#ifdef DEBUGREMOTESYSCALL
	ioConsolePutString("Linux syscall ftruncate64...\n");
	#endif
	loff_t length;
	long* lenbuf=(long*)&length;
	lenbuf[0]=SYSCALLARG(2);//note:not 1:should be careful!
	lenbuf[1]=SYSCALLARG(3);//note:not 2:should be careful!
	long ret=rslinuxftruncate64(SYSCALLARG(0), length);
	HandleReturnValue(contextPtr,ret);
}

void rsLinuxSyscallstat64(ProcContextPtr contextPtr)//v0==4213
{
	#ifdef DEBUGREMOTESYSCALL
	ioConsolePutString("Linux syscall stat64...\n");
	#endif
	long ret=rslinuxstat64((char*)SYSCALLARG(0), (struct stat64formips*)SYSCALLARG(1),SYSCALLARG(2));
	HandleReturnValue(contextPtr,ret);
}

void rsLinuxSyscalllstat64(ProcContextPtr contextPtr)//v0==4214
{
	#ifdef DEBUGREMOTESYSCALL
	ioConsolePutString("Linux syscall lstat64...\n");
	#endif
	long ret=rslinuxlstat64((char*)SYSCALLARG(0), (struct stat64formips*)SYSCALLARG(1),SYSCALLARG(2));
	HandleReturnValue(contextPtr,ret);
}

void rsLinuxSyscallfstat64(ProcContextPtr contextPtr)//v0==4215
{
	#ifdef DEBUGREMOTESYSCALL
	ioConsolePutString("Linux syscall fstat64...\n");
	#endif
	long ret=rslinuxfstat64(SYSCALLARG(0), (struct stat64formips*)SYSCALLARG(1),SYSCALLARG(2));
	HandleReturnValue(contextPtr,ret);
}

void rsLinuxSyscallfcntl64(ProcContextPtr contextPtr)//v0==4220
{
	#ifdef DEBUGREMOTESYSCALL
	ioConsolePutString("Linux syscall fcntl64...\n");
	#endif
	long ret=rslinuxfcntl64(SYSCALLARG(0), SYSCALLARG(1),SYSCALLARG(2));
	HandleReturnValue(contextPtr,ret);
}
/*slfsmm031122_add<*/
//#endif

