#ifndef GLOBALOPT_H
#define GLOBALOPT_H

#define TASSISTMEMSET //using topsy assistant memset

#endif
