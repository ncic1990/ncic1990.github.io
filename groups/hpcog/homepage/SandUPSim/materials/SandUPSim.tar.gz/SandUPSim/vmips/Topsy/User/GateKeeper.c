/*
 * GateKeeper.c
 *
 */

#include "Syscall.h"		/* Topsy system calls    */
#include "UserSupport.h"	/* User supprt functions */
#include "GateKeeper.h"

ThreadId tty; /* the serial server */

static int Send(ThreadId p1, int p2, int p3);
static void Terminate(ThreadId tid, const char *errMsg);
static int Recv(ThreadId from, Message * reply);

static int Recv(ThreadId from, Message * reply)
{
	if (tmMsgRecv(&from, ANYMSGTYPE, reply, INFINITY) ==
	    TM_MSGRECVFAILED)
		return -1;

	return 0;
}

/* Send a message using Topsy IPC.
 *
 * Parameters:
 *     p1, p2, p3 - UserMessage contents.
 * Returns:
 *     On succesfull send of message, 0, otherwise -1.
 */
static int Send(ThreadId p1, int p2, int p3)
{
	Message sendMsg;

	sendMsg.msg.userMsg.p1 = p1;
	sendMsg.msg.userMsg.p2 = p2;
	sendMsg.msg.userMsg.p3 = p3;

	if (tmMsgSend(p1, &sendMsg) != TM_MSGSENDOK)
		return -1;

	return 0;
}

/* Terminate a given thread and display debugging information.
 * 
 * Parameters:
 *     tid - ThreadID of thread to terminate.
 *     errMsg - error message to be displayed.
 * Returns:
 *     Does not return
 */
static void Terminate(ThreadId tid, const char *errMsg)
{
	if (tid == ANY)
		printf(tty, "(TID = Unknown) ");
	else
		printf(tty, "(TID = %d) ", tid);

	printf(tty, "Thread terminated due to error (%s).\n", errMsg);

	tmExit();
}

void GateKeeper()
{
	Message reply;		/* Received message                         */
	UserMessage *msg;	/* Points to UserMessage component of reply */
	ThreadId this, parent;	/* TIDs of parent and this                  */
	ThreadId otherGate;	/* TID of the other gate-keeper             */

	msg = &reply.msg.userMsg;

	ioOpen(IO_CONSOLE, &tty);	/* Open the console       */
	ioInit(tty);		/* Initialise the console */

	/* Get TID of parent and this */

	if (tmGetInfo(SELF, INFO_ID, &reply) < 0)
		Terminate(ANY, "Can't get TID of paren\n");

	this = reply.msg.tmInfoReply.info[0];
	parent = reply.msg.tmInfoReply.info[1];

	/* Get TID of other from parent */

	if (Recv(parent, &reply))
		Terminate(this, "Can't Get TID of partner\n");

	otherGate = msg->p1;
	printf(tty,
	       "(TID = %d) Got the TID of the other gatekeeper - %d.\n",
	       this, otherGate);

	for (;;) {
                Recv(parent, &reply);
                if (msg->p2 != CAR_ARRIVE)
                        continue;
                printf(tty,"%d: Car waiting\n",this);
        
                /* Just let it in */ 
                Send(parent,CAR_ENTER,0);
	}
}
