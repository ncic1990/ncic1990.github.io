#ifndef VIRTSERVENTRY_H
#define VIRTSERVENTRY_H
#include "LibcLinuxTypes.h"

long virt_errno;

FILE *vslibcfopen(const char *filename,const char *mode);
long vslibcfread( void *buffer, long size, long count, FILE *stream );
long vslibcfwrite( const void *buffer, long size, long count, FILE *stream );
int vslibcfclose( FILE *stream );
int vslibcfseek( FILE *stream, long offset, int origin );
long int vslibcftell(FILE* stream);
void vslibcrewind(FILE* stream);
int vslibcfeof(FILE* stream);
int vslibcfgetc(FILE* stream);
char* vslibcfgets(char* s,int n,FILE* stream);
int vslibcfputc(int c,FILE* stream);
int vslibcfputs(const char* s,FILE*stream);
char* vslibcgetcwd(char* buf, long size);
int vslibcchdir(const char* path);

int vslinuxread(unsigned int fd, char * buf, long count);//v0==4003
int vslinuxwrite(unsigned int fd, const char * buf, long count);//v0==4004
long vslinuxopen(const char * filename, int flags, int mode);//v0==4005
long vslinuxclose(unsigned int fd);//v0==4006
long vslinuxunlink(const char* pathname);//v0==4010
long vslinuxtime(int* tloc);//v0==4013
long vslinuxlseek(unsigned int fd, long offset, unsigned int origin);//v0==4019
long vslinuxgetpid(void);//v0==4020
long vslinuxgetuid(void);//v0==4024
long vslinuxaccess(const char * filename, int mode);//v0==4033
long vslinuxrename(const char * oldname, const char * newname);//v0==4038
long vslinuxtimes(struct tms* tbuf);//v0==4043
long vslinuxgetgid(void);//v0==4047
long vslinuxgeteuid(void);//v0==4049
long vslinuxgetegid(void);//v0==4050
long vslinuxioctl(unsigned int fd, unsigned int cmd, unsigned long arg);//v0==4054
long vslinuxfcntl(unsigned int fd, unsigned int cmd, unsigned long arg);//v0==4055
long vslinuxgetrlimit(unsigned int resource, struct rlimitformips *rlim);//v0==4076
long vslinuxgetrusage(int who, struct rusageformips*ru);//v0==4077
long vslinuxftruncate(unsigned int fd, unsigned long length);//v0==4093
long vslinuxstat(char * filename, struct statformips* statbuf);//v0==4106
long vslinuxlstat(char * filename, struct statformips* statbuf);//v0==4107
long vslinuxfstat(unsigned int fd, struct statformips* statbuf);//v0==4108
long vslinuxnewuname(new_utsname_formips * name);//v0==4122
long vslinuxllseek(unsigned int fd, unsigned long offset_high, 
	unsigned long offset_low, loff_t * result, unsigned int origin);//v0==4140
long vslinuxnewselect(int n, fd_set *inp, fd_set *outp, fd_set *exp, struct timeval *tvp);//v0==4142
long vslinuxftruncate64(unsigned int fd, loff_t length);//v0==4212
long vslinuxstat64(char * filename, struct stat64formips * statbuf, long flags);//v0==4213
long vslinuxlstat64(char * filename, struct stat64formips * statbuf, long flags);//v0==4214
long vslinuxfstat64(unsigned long fd, struct stat64formips * statbuf, long flags);//v0==4215
long vslinuxfcntl64(long fd,long cmd,long arg);//v0==4220

/* syscall used for debugging : cmy */
int tracerserver(int cmd);
/* Copy from vmips debugtrigger.h for command: cmy */
#define DBG_INSTDUMP_ON         1
#define DBG_INSTDUMP_OFF        2
#define DBG_TRACE_ON            3
#define DBG_TRACE_OFF           4

#endif
