/* Definitions to support the system float coprocessor.
 *  Clock level cp1 simulation
 *  added by zhangwl on Nov 11th, 2003
 */
#ifndef _CLKCPONE_H_
#define _CLKCPONE_H_
#include "sysinclude.h"
#include "deviceexc.h"
#include "debug.h"
#include "cpone.h"
#include "cpu.h"
#include "clkcpu.h"
#include "accesstypes.h"

//class DeviceExc;

class CLKCPONE:public CPOne//, public CLKCPU
{
	friend class CLKCPU;
//	friend class PPLSTAT;
private:
/*	FReg freg[16];
	CPU *cpu;
	uint32 fcsr;
	uint32 fcr0;
	uint32 fcr25;
	uint32 fcr26;
	uint32 fcr28;
	uint32 fcr31;
*/
	CLKCPU *clkcpu;
	//PPLSTAT *pplstat;
protected:
	void 	fadd_clkemulate(uint32 instr, uint32 pc);
	void 	fsub_clkemulate(uint32 instr, uint32 pc);
	void 	fmul_clkemulate(uint32 instr, uint32 pc);
	void 	fdiv_clkemulate(uint32 instr, uint32 pc);
	void 	fsqrt_clkemulate(uint32 instr, uint32 pc);
	void 	fabs_clkemulate(uint32 instr, uint32 pc);
	void 	fmov_clkemulate(uint32 instr, uint32 pc);
	void 	fneg_clkemulate(uint32 instr, uint32 pc);
	void 	fround1_clkemulate(uint32 instr, uint32 pc);
	void 	ftrunc1_clkemulate(uint32 instr, uint32 pc);
	void 	fceill_clkemulate(uint32 instr, uint32 pc);
	void 	ffloorl_clkemulate(uint32 instr, uint32 pc); /*0xa_emulate;0xb*/ 
	void 	fround_clkemulate(uint32 instr, uint32 pc);
	void 	ftrunc_clkemulate(uint32 instr, uint32 pc);
	void 	fceil_clkemulate(uint32 instr, uint32 pc);
	void 	ffloor_clkemulate(uint32 instr, uint32 pc);
	void 	fmovc_clkemulate(uint32 instr, uint32 pc);
	void 	fmovz_clkemulate(uint32 instr, uint32 pc);
	void 	fmovn_clkemulate(uint32 instr, uint32 pc);
	void 	frecip_clkemulate(uint32 instr, uint32 pc);
	void 	frsqrt_clkemulate(uint32 instr, uint32 pc);
	void 	fcvts_clkemulate(uint32 instr, uint32 pc);
	void 	fcvtd_clkemulate(uint32 instr, uint32 pc);	 
	void 	fcvte_clkemulate(uint32 instr, uint32 pc);
	void 	fcvtw_clkemulate(uint32 instr, uint32 pc);
	void 	fcvtl_clkemulate(uint32 instr, uint32 pc); 
	void 	fcmp_op_clkemulate(uint32 instr, uint32 pc);
//	void 	fundef_emulate(uint32 instr, uint32 pc); 
public:
	CLKCPONE(CPU *m = NULL);
	~CLKCPONE();
	void cpone_clkemulate(uint32 instr, uint32 pc);
	void fex1();
	void fex2();
	void fex3();
	void fwb();
	void fpdecode(uint32 instr, uint32 pc);
	struct FID_EX{
		uint32 pc;
		uint32 instr;
//		uint16 op;
		uint16 fsnum;
		uint16 ftnum;
		uint16 fdnum;
		FReg fsctx;//union type
		FReg ftctx;
		uint16 fmt;
		uint16 funct;
//		int16 s_imm;//to be affirm
//		uint16 imm;
		FReg ALUoutput;
		uint32 fcr31ctx;		
		bool stall;
		bool tag;
		}fid_ex, fex1_2, fex2_3, fex_wb;
	int fcr31flag;
//	uint32 fcr31ctx;
	int fregflag[16];
/*	void reset(void);
	bool cop_usable (int coprocno);
//	void cpone_emulate(uint32 instr, uint32 pc);
	void dump_regs(FILE *f);
	void adjust_random(void);
	void read_debug_info(uint32 *status, uint32 *bad, uint32 *cause);
	void write_debug_info(uint32 status, uint32 bad, uint32 cause);
        uint16 fs(const uint32 instr) const;
        uint16 ft(const uint32 instr) const;
        uint16 fd(const uint32 instr) const;
	uint16 funct(const uint32 instr) const;
	uint16 format(const uint32 instr) const;
	uint16 opcode(const uint32 instr) const;
	uint16 fmt;
*/
};

#endif /* _CPONE_H_ */
