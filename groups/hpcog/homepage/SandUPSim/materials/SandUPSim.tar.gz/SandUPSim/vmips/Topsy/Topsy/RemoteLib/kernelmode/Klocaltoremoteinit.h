#ifndef KLOCALTOREMOTE_H
#define KLOCALTOREMOTE_H

#include "hwparaforos.h"

void InitRemoteServ(stdio_t* stdioinfoptr);

#endif/*LOCALTOREMOTE_H*/

