/* Print a friendly message to the serial console. */
//#include "spimconsreg.h"
#define IOBASE 0x802000
#define DISPLAY_1_CONTROL   0x08
#define DISPLAY_1_DATA      0x0C
#define CTL_RDY   0x00000001
#include "Syscall.h"
#include "Messages.h"

#define IS_READY(ctrl) (((*(ctrl)) & CTL_RDY) != 0)

int main(void)
{
	char *p = "Welcome,Hello world!\n";
	char *p1 = "Welcome,Hello world!\n";
	Message mst={-2,0,};

	long *testvar=(long *)0x5b000;
	tmMsgSend( -2, &mst);

	*testvar='@';
	volatile long *data_reg = (long *)(IOBASE+DISPLAY_1_DATA);
	volatile long *control_reg = (long *)(IOBASE+DISPLAY_1_CONTROL);

	do { 0; } while (! IS_READY(control_reg)); 
		*data_reg = (long) *testvar;   
	while (*p != '\0') {
		do { 0; } while (! IS_READY(control_reg));  
		*data_reg = (long) *p++;
	}
	
	do { 0; } while (! IS_READY(control_reg)); 
		*data_reg = (long) *testvar;   
	while (*p1 != '\0') {
		do { 0; } while (! IS_READY(control_reg));  
		*data_reg = (long) *p1++;
	}
	return 0;
}
