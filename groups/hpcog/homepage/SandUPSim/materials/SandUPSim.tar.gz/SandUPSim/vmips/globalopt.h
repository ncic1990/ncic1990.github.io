#ifndef GLOBALOPT_H
#define GLOBALOPT_H

#define TLBSHORTCUT //tlb address translation short cut of user space virtual address
#define USERVIRTBASE 0
#define USERVIRTEND 0x7fffffff
#define PAGETABLEOFF 0x200000
#define PAGESHIFT 12

#define MEMACCSHORTCUT //memory access short cut of physics address between 0 and 256M

#endif

