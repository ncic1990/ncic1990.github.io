/*the following functions are implemented through virtual server or remote server*/
#include "SoftIOConsole.h"
#include "VirtIOSupport.c"
#include "RemoteIOSupport.c"
#include "SoftIOConsoleOpt.h"

extern long serv_errno;
extern long virt_errno;
extern long rmt_errno;

void ioConsolePutString(const char* s) 
{	
	if(IOCOMMONVIRTSERVFLAG){
		long arg1=(long)s;
		VIRT_IO_ARG1(TopsyAssistantServer,ioConsolePutStringservno,
			VirtualServerRegBase,arg1);
	}else
		rsTAioConsolePutString((char*)s);
}
void ioConsolePutHexInt(int x) 
{
	if(IOCOMMONVIRTSERVFLAG){
		long arg1=(long)x;
		VIRT_IO_ARG1(TopsyAssistantServer,ioConsolePutHexIntservno,
			VirtualServerRegBase,arg1);
	}else
		rsTAioConsolePutHexInt(x);
}

char* stringin(char* string,long maxcount)
{
	char* retval;

	if(IOCOMMONVIRTSERVFLAG){
		long arg1=(long)string;
		long arg2=maxcount;
		VIRT_IO_ARG2_RET2(TopsyAssistantServer,stringinservno,
			VirtualServerRegBase,arg1,arg2,retval,serv_errno);
	}else{
		retval=rsTAstringin(string,maxcount);
		serv_errno=rmt_errno;
	}
	return retval;
}

void stringout(char* string)
{
	if(IOCOMMONVIRTSERVFLAG){
		long arg1=(long)string;
		VIRT_IO_ARG1(TopsyAssistantServer,stringoutservno,
			VirtualServerRegBase,arg1);
	}else
		rsTAstringout(string);
}

long RedirectStdIO(long stdinto, long stdoutto, long stderrto)
{	
	long retval;
	
	if(IOCOMMONVIRTSERVFLAG){
		VIRT_IO_ARG3_RET2(TopsyAssistantServer,redirectstdioservno,
			VirtualServerRegBase,stdinto,stdoutto,stderrto,retval,serv_errno);
	}else{
		retval=rsTARedirectStdIO(stdinto, stdoutto, stderrto);
		serv_errno=rmt_errno;
	}
	return retval;
}

void DeRedirectStdIO( )
{
	if(IOCOMMONVIRTSERVFLAG){
		VIRT_IO_ARG0(TopsyAssistantServer,deredirectstdioservno);
	}else{
		rsTADeRedirectStdIO();
	}
}

long ChangeCWD(const char* pathname)
{
	long retval;
	
	if(IOCOMMONVIRTSERVFLAG){
		VIRT_IO_ARG1_RET2(TopsyAssistantServer,changecwdservno,
			VirtualServerRegBase,pathname,retval,serv_errno);
	}else{
		retval=rsTAChangeCWD(pathname);
		serv_errno=rmt_errno;
	}
	return retval;
}

void RecoverCWD( )
{
	if(IOCOMMONVIRTSERVFLAG){
		VIRT_IO_ARG0(TopsyAssistantServer,recovercwdservno);
	}else{
		rsTARecoverCWD();
	}
}

void printfnull(const char* str)
{
	if(IOCOMMONVIRTSERVFLAG){
		VIRT_IO_ARG1(TopsyAssistantServer,printfnullservno,
			VirtualServerRegBase,str);
	}else{
		rsTAprintfnull(str);
	}
}

void printfstr(const char* mode, const char* str)
{
	if(IOCOMMONVIRTSERVFLAG){
		VIRT_IO_ARG2(TopsyAssistantServer,printfstrservno,
			VirtualServerRegBase,mode,str);
	}else{
		rsTAprintfstr(mode,str);
	}
}

void printfnum(const char* mode, long num)
{
	if(IOCOMMONVIRTSERVFLAG){
		VIRT_IO_ARG2(TopsyAssistantServer,printfnumservno,
			VirtualServerRegBase,mode,num);
	}else{
		rsTAprintfnum(mode,num);
	}
}

void* TAmemset(void* base, int c, int count)
{
	void* ret;
	VIRT_IO_ARG3_RET2(TopsyAssistantServer, memsetservno, 
		VirtualServerRegBase, base, c, count, ret, serv_errno);
	return ret;
}

long TAgetcwd(char* buf, long size, long mode)
{
	long ret;
	if(IOCOMMONVIRTSERVFLAG){
		VIRT_IO_ARG3_RET2(TopsyAssistantServer, TAgetcwdservno, 
			VirtualServerRegBase, buf, size, mode, ret, serv_errno);
	}else{
		ret=rsTAgetcwd(buf,size,mode);
		serv_errno=rmt_errno;
	}
	return ret;
}

void TAlssimulation(char* format)
{
	if(IOCOMMONVIRTSERVFLAG){
		VIRT_IO_ARG1(TopsyAssistantServer,TAlssimulationservno,
			VirtualServerRegBase,format);
	}else{
		rsTAlssimulation(format);
	}
}

char* TAgetenv(char* envname,char* buf,long maxlen)
{
	char* ret;
	if(IOCOMMONVIRTSERVFLAG){
		VIRT_IO_ARG3_RET2(TopsyAssistantServer, TAgetenvservno, 
			VirtualServerRegBase, envname, buf, maxlen, ret, serv_errno);
	}else{
		ret=rsTAgetenv(envname,buf,maxlen);
		serv_errno=rmt_errno;
	}
	return ret;
}

void TAmmmappinginfotovmips(mmmapping_t* mappingptr)
{
	VIRT_IO_ARG1(TopsyAssistantServer, TAmmmappinginfoservno, 
		VirtualServerRegBase, mappingptr);
}

void TAappnametovmips(char* appname)
{
	VIRT_IO_ARG1(TopsyAssistantServer, TAappnameservno, 
		VirtualServerRegBase, appname);
}

void TAinvalidatecache( )
{
	VIRT_IO_ARG0(TopsyAssistantServer, TAinvalidcacheservno);
}

/*for virtserv debug begins>*/
bool flag_dbgopen;
void dbgopen( )
{
	flag_dbgopen=true;
}
void dbgclose( )
{
	flag_dbgopen=false;
}
void dbgprintfnull(const char* str) //to stdout of virtserv
{
	#ifdef OPENVIRTDBG
	if(flag_dbgopen)
		VIRT_IO_ARG1(TopsyAssistantServer,printfnullservno,
			VirtualServerRegBase,str);
	#endif
}

void dbgprintfstr(const char* mode, const char* str) //to stdout of virtserv
{
	#ifdef OPENVIRTDBG
	if(flag_dbgopen)
		VIRT_IO_ARG2(TopsyAssistantServer,printfstrservno,
			VirtualServerRegBase,mode,str);
	#endif
}

void dbgprintfnum(const char* mode, long num) //to stdout of virtserv
{
	#ifdef OPENVIRTDBG
	if(flag_dbgopen)
		VIRT_IO_ARG2(TopsyAssistantServer,printfnumservno,
			VirtualServerRegBase,mode,num);
	#endif
}
/*for virtserv debug ends<*/

long TAchstdiobyname(char* stdinname,char* stdoutname,
	char* stderrname,bool inheritflag)
{
	long retval;
	
	if(IOCOMMONVIRTSERVFLAG){
		ioConsolePutString("VirtServ msg:vsTAchstdiobyname is not implemented yet!\n");
	}else{
		retval=rsTAchstdiobyname(stdinname,stdoutname,stderrname,inheritflag);
		serv_errno=rmt_errno;
	}
	return retval;
}

long TAgetallenv(char* buf,long maxlen)
{
	long ret;
	if(IOCOMMONVIRTSERVFLAG){
		VIRT_IO_ARG2_RET2(TopsyAssistantServer, TAgetallenvservno, 
			VirtualServerRegBase, buf, maxlen, ret, serv_errno);
	}else{
		ioConsolePutString("RemoteServ msg:rsTAgetallenv is not implemented yet!\n");
		ret=0;
	}
	return ret;
}

