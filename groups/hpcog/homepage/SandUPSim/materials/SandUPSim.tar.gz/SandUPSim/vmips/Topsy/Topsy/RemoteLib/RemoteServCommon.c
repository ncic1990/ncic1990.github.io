//assistant functions for buffer operations
bool checkpointer(void* buf,char* msg)
{
	if(buf) return true;
	#ifndef REMOTESERVQUIET
	ioConsolePutString(msg);
	ioConsolePutString(" is NULL!\n");
	#endif
	return false;
}

uint32 up2exp(uint32 input)
{
	int i;
	uint32 count=1;
	for(i=0;i<32;i++){
		if(count>=input)
			return count;
		count=count<<1;
	}
	#ifndef REMOTESERVQUIET
	ioConsolePutString("client err:up2exp:There must be something wrong!\n");
	#endif
}

bool setPackageHeader(package_header_t* packageheader, 
	ServInfoDesc_t* servinfoptr, uint32 packagelen, uint32 packageflag)
{
	if(!packageheader){
		#ifndef REMOTESERVQUIET
		ioConsolePutString("client err:setPackageHeader:packageheader is NULL!\n");
		#endif
		return false;
	}
	packageheader->destaddr=servinfoptr->destaddr;
	packageheader->srcaddr=servinfoptr->srcaddr;
	UNITVAL(packageheader->packagelen)=packagelen;
	UNITVAL(packageheader->packageflag)=packageflag;
	return true;
}

RDH* getbuffer_RDH(char* buf)
{
	if(!buf) {
		#ifndef REMOTESERVQUIET
		ioConsolePutString("client err:getbuffer_RDH:buffer is NULL!\n");
		#endif
		return NULL;
	}
	return (RDH*)buf;
}
bool setbuffer_RDH(char* buf,ServInfoDesc_t* servinfoptr, uint32 datasetlen)
{
	if(!buf) {
		#ifndef REMOTESERVQUIET
		ioConsolePutString("client err:setbuffer_RDH:buffer is NULL!\n");
		#endif
		return false;
	}
	RDH* rdheader=(RDH*)buf;
	rdheader->destaddr=servinfoptr->destaddr;
	rdheader->srcaddr=servinfoptr->srcaddr;
	UNITVAL(rdheader->datasetlen)=datasetlen;
	return true;
}
bool setRDH(RDH* rdheader,ServInfoDesc_t* servinfoptr, uint32 datasetlen)
{
	if(!rdheader){
		#ifndef REMOTESERVQUIET
		ioConsolePutString("client err:setRDH:rdheader is NULL!\n");
		#endif
		return false;
	}
	rdheader->destaddr=servinfoptr->destaddr;
	rdheader->srcaddr=servinfoptr->srcaddr;
	UNITVAL(rdheader->datasetlen)=datasetlen;
	return true;
}
RDBH* getbuffer_RDBH(char* buf)
{
	if(!buf) {
		#ifndef REMOTESERVQUIET
		ioConsolePutString("client err:getbuffer_RDBH:buffer is NULL!\n");
		#endif
		return NULL;
	}
	return (ReqDBH*)(buf+sizeof(RDH));
}
bool setbuffer_RDBH(char* buf,ServInfoDesc_t* servinfoptr)
{
	if(!buf) {
		#ifndef REMOTESERVQUIET
		ioConsolePutString("client err:setbuffer_RDBH:buffer is NULL!\n");
		#endif
		return false;
	}
	RDBH* rdbheader=(RDBH*)(buf+sizeof(RDH));
	UNITVAL(rdbheader->servtype)=servinfoptr->type;
	UNITVAL(rdbheader->service)=servinfoptr->service;
	return true;
}
bool setRDBH(RDBH* rdbheader, ServInfoDesc_t* servinfoptr)
{
	if(!rdbheader){
		#ifndef REMOTESERVQUIET
		ioConsolePutString("client err:setRDBH:rdbheader is NULL!\n");
		#endif
		return false;
	}
	UNITVAL(rdbheader->servtype)=servinfoptr->type;
	UNITVAL(rdbheader->service)=servinfoptr->service;
	return true;
}
RDBP* getbuffer_Params(char* buf)
{
	if(!buf) {
		#ifndef REMOTESERVQUIET
		ioConsolePutString("client err:getbuffer_Params:buffer is NULL!\n");
		#endif
		return NULL;
	}
	return (RDBP*)(buf+sizeof(RDH)+sizeof(RDBH));
}
bool setbuffer_Params(char* buf,ParamsDesc_t* paramsdesc)
{
	uint32 count;
	
	if(!buf) {
		#ifndef REMOTESERVQUIET
		ioConsolePutString("client err:setbuffer_Params:buffer is NULL!\n");
		#endif
		return false;
	}
	if(!paramsdesc) {
		#ifndef REMOTESERVQUIET
		ioConsolePutString("client err:setbuffer_Params:paramsdesc is NULL!\n");
		#endif
		return false;
	}
	RDBP* rdbparams=(RDBP*)(buf+sizeof(RDH)+sizeof(RDBH));
	UNITVAL(rdbparams->parameternum)=paramsdesc->paramnum;
	if(paramsdesc->paramnum==DEFCANNOTSERV) return true;
	for(count=0;count<paramsdesc->paramnum;count++){
		if(paramsdesc->parameters[count].notpointer){
			UNITVAL(rdbparams->parameters[count].paramval)=paramsdesc->parameters[count].paramval;
			UNITVAL(rdbparams->parameters[count].structlen)=PARAM_NOTPOINTER;
			continue;
		}
		UNITVAL(rdbparams->parameters[count].structlen)=paramsdesc->parameters[count].len;
		if((long)UNITVAL(rdbparams->parameters[count].structlen)==(long)PARAM_POINTERNULL){
			UNITVAL(rdbparams->parameters[count].paramval)=paramsdesc->parameters[count].paramval;
			continue;
		}
		UNITVAL(rdbparams->parameters[count].paramval)=paramsdesc->parameters[count].offset;
		byteCopy((char*)rdbparams+paramsdesc->parameters[count].offset,
			(char*)paramsdesc->parameters[count].paramval,paramsdesc->parameters[count].len);
	}
	return true;
}
bool getParamsContent(RDBP* rdbparams,ParamsDesc_t* paramsdesc)
{
	uint32 count;
	if(!checkpointer((char*)rdbparams,"client err:getParamsContent:rdbparams")) return false;
	if(!checkpointer((char*)paramsdesc,"client err:getParamsContent:paramsdesc")) return false;
	if(UNITVAL(rdbparams->parameternum)!=paramsdesc->paramnum){
		#ifndef REMOTESERVQUIET
		ioConsolePutString("client err:getParamsContent:params num invalid!\n");
		ioConsolePutString("client err:getParamsContent:\n");
		ioConsolePutString("received params num:");
		ioConsolePutHexInt(UNITVAL(rdbparams->parameternum));
		ioConsolePutString("required params num:");
		ioConsolePutHexInt(paramsdesc->paramnum);
		#endif
		return false;
	}
	if(paramsdesc->paramnum==DEFCANNOTSERV){
		#ifndef REMOTESERVQUIET
		ioConsolePutString("client err:There must be something wrong in server!\n");
		#endif
		return false;
	}
	for(count=0;count<paramsdesc->paramnum;count++){
		if(paramsdesc->parameters[count].notpointer){
			if((long)UNITVAL(rdbparams->parameters[count].structlen)!=PARAM_NOTPOINTER){
				#ifndef REMOTESERVQUIET
				ioConsolePutString("client err:getParamsContent:expecting a notpointer value but not!\n");
				#endif
				return false;
			}
			*((uint32*)paramsdesc->parameters[count].paramval)=UNITVAL(rdbparams->parameters[count].paramval);
			continue;
		}
		if(((long)paramsdesc->parameters[count].len!=PARAMCHECKING_DEFAULTLEN)
			&&((long)UNITVAL(rdbparams->parameters[count].structlen)!=PARAM_POINTERNULL)
			&&((long)paramsdesc->parameters[count].len!=
			(long)UNITVAL(rdbparams->parameters[count].structlen))){
			#ifndef REMOTESERVQUIET
			ioConsolePutString("client err:getParamsContent:length checking err!\n");
			#endif
			return false;
		}
		paramsdesc->parameters[count].offset=UNITVAL(rdbparams->parameters[count].paramval);
		paramsdesc->parameters[count].len=UNITVAL(rdbparams->parameters[count].structlen);
	}
	return true;
}
bool setParamsContent(RDBP* rdbparams, ParamsDesc_t* paramsdesc)
{
	uint32 count;
	
	if(!rdbparams){
		#ifndef REMOTESERVQUIET
		ioConsolePutString("client err:setParamsContent:rdbparams is NULL!\n");
		#endif
		return false;
	}
	if(!paramsdesc){
		#ifndef REMOTESERVQUIET
		ioConsolePutString("clent err:setParamsContent:paramsdesc is NULL!\n");
		#endif
		return false;
	}
	UNITVAL(rdbparams->parameternum)=paramsdesc->paramnum;
	if(paramsdesc->paramnum==DEFCANNOTSERV) return true;
	for(count=0;count<paramsdesc->paramnum;count++){
		if(paramsdesc->parameters[count].notpointer){
			UNITVAL(rdbparams->parameters[count].paramval)=paramsdesc->parameters[count].paramval;
			UNITVAL(rdbparams->parameters[count].structlen)=PARAM_NOTPOINTER;
			continue;
		}
		UNITVAL(rdbparams->parameters[count].structlen)=paramsdesc->parameters[count].len;
		if((long)UNITVAL(rdbparams->parameters[count].structlen)==(long)PARAM_POINTERNULL){
			UNITVAL(rdbparams->parameters[count].paramval)=paramsdesc->parameters[count].paramval;
			continue;
		}
		UNITVAL(rdbparams->parameters[count].paramval)=paramsdesc->parameters[count].offset;
	}
	return true;
}

