/*
	Copyright (c) 1996-1997 Swiss Federal Institute of Technology, 
	Computer Engineering and Networks Laboratory. All rights reserved.

	TOPSY - A Teachable Operating System. 
		Implementation of a tiny and simple micro kernel for
		teaching purposes.

	Permission to use, copy, modify, and distribute this software and its
	documentation for any purpose, without fee, and without written 
	agreement is hereby granted, provided that the above copyright notice 
	and the following two paragraphs appear in all copies of this software.


	File:                  $Source: /work/cvs/cvsroot/Topsy/IO/Drivers/SimOSConsole.c,v $
 	Author(s):             George Fankhauser
 	Affiliation:           ETH Zuerich, TIK
 	Version:               $Revision: 1.1.1.1 $
 	Creation Date:         
 	Last Date of Change:   $Date: 2003/09/22 08:43:46 $      by: $Author: sgz $
	
	
*/

#include "Drivers/SimOSConsole.h"
#include "Messages.h"
#include "IODevice.h"

#define CONSOLE_BUFFER_SIZE 128

/* There is no reason why this should not be static. BTW, read_pos and
 * write_pos store the total number of characters read/written, which,
 * theoretically, is a bug (as they may overflow), but, in practice, I
 * doubt anyone is going to ever send 2GB of characters in a single session,
 * and the code is much cleaner this way. -- PZ */
static char console_buffer[CONSOLE_BUFFER_SIZE];
static int  read_pos = 0, write_pos = 0;

/* Interrupt handler. */
void simos_console_handler(IODevice this) 
{
    if (write_pos - read_pos >= CONSOLE_BUFFER_SIZE)
	WARNING("Console buffer overflow\n");
    else {
	console_buffer[write_pos++ % CONSOLE_BUFFER_SIZE]
	    = simos_console->data;
    }
}

/* Initialization routine. */
Error simos_console_init(IODevice this) 
{
    simos_console->intr_status = CONS_INT_RX; /* Enable console interrupts. */
    return IO_INITOK;
}

/* Read data from the buffer. */
Error simos_console_read(IODevice this, ThreadId threadId, 
			 char* buffer, long int* size) 
{
    int i = 0;
    while (read_pos < write_pos && write_pos - read_pos < *size)
	buffer[i++] = buffer[read_pos++ % CONSOLE_BUFFER_SIZE];
    *size = i;
    return IO_READOK;
}


Error simos_console_write(IODevice this, ThreadId threadId,
			  char* buffer, long int* size) 
{
    while ((*size) > 0) {
	simos_console->data = *buffer++;
	--*size;
    }
    return IO_WRITEOK;
}

Error simos_console_close(IODevice this) 
{
    /* this message is forwarded from ioThread */
    
    /* release buffers if any */
    
    /* disable console interrupts */
    simos_console->intr_status = 0;

    return IO_CLOSEOK;
}
