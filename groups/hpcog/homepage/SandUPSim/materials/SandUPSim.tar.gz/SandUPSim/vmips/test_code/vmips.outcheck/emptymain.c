/* This is primarily useful for testing the setup.S loader program. */

void entry(void)
{

}

