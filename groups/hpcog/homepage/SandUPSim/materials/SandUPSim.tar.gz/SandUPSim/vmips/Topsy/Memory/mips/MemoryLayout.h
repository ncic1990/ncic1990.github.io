/*
	Copyright (c) 1996-1997 Swiss Federal Institute of Technology, 
	Computer Engineering and Networks Laboratory. All rights reserved.

	TOPSY - A Teachable Operating System. 
		Implementation of a tiny and simple micro kernel for
		teaching purposes.

	Permission to use, copy, modify, and distribute this software and its
	documentation for any purpose, without fee, and without written 
	agreement is hereby granted, provided that the above copyright notice 
	and the following two paragraphs appear in all copies of this software.


	
	File:                  $Source: /work/cvs/cvsroot/Topsy/Memory/mips/MemoryLayout.h,v $
 	Author(s):             George Fankhauser
 	Affiliation:           ETH Zuerich, TIK
 	Version:               $Revision: 1.11 $
 	Creation Date:         
 	Last Date of Change:   $Date: 2004/03/09 15:12:28 $      by: $Author: slfsmm $
	
	
*/

#include "cpu.h"

#define KB 1024
#define MB (1024*KB)
#define GB (1024*MB)

/* available memory */
//#define PHYSMEM (12*1024*1024)   /* 12 megs */
#define KERNELMEM (2*MB)
//#define USERMEM (8*MB)     /*  8 megs */
#define PAGETABLEMEM (2*MB)
#define ASS3USERMEM (50*MB) /* 50 Megs */

/*the layout of the user space*/
#define USERPHYSMEMPHYSBASE (PHYS_BASE+KERNELMEM+PAGETABLEMEM)
#define USERSPACESIZE (2*1024*1024*1024)
/*for mapping virtual server*/
#define USERVIRTSERVSIZE (8*KB)
#define USERVIRTSERVBASE (KUSEG_BASE+KUSEG_SIZE-USERVIRTSERVSIZE)
/*for mapping network card*/
#define USERNETWOKCARDSPACE (8*KB)
#define NETCARDHIGHUSERBASE   (USERVIRTSERVBASE-USERNETWOKCARDSPACE/2)
#define NETCARDLOWUSERBASE	(NETCARDHIGHUSERBASE-USERNETWOKCARDSPACE/2)
/*the upper user space is mapping to devices,and the base is :*/
#define USERDEVICEBASE NETCARDLOWUSERBASE
/*hole between device mapping and user stack*/
#define DEV_STACK_HOLE_SIZE (16*MB)
/*initial user stack size*/
#define INITSTACKSIZE (16*MB)
#define USERSTACKBASE (USERDEVICEBASE-DEV_STACK_HOLE_SIZE-INITSTACKSIZE)
#define FAULTALLOWOFF 32
//#define MAXSTACKSIZE 16*1024
/*the hole for catching the expansion of stack*/
//#define SPACEHOLE (4*1024)
/*the heap*/
#define DYNAMICCONST 4
/*user data*/
/*maybe hole*/
/*user code*/
/*available user virtual space for catching NULL pointer*/
#define USERVIRTSPACERESEV (4*KB)
/*TLB directmapping space*/
#define TLBMAPPINGSIZE (TLB_SIZE*4*KB)

/* PAGESIZE is the machines real page size */
#define PAGEBITS             12
#define PAGESIZE            (1 << PAGEBITS)
#define PAGE_SHIFT 			PAGEBITS
#define PAGEFRAMEMASK       (0xffffffff << PAGEBITS)
#define PAGEMASK            (~PAGEFRAMEMASK)
#define PAGENUMBER(addr)    (((unsigned long)addr) >> PAGEBITS)
#define PAGEREMAINDER(addr) (((unsigned long)addr) & PAGEMASK)
#define PAGE_ALIGN(addr)	(((addr) + PAGESIZE - 1) & PAGEFRAMEMASK)

/* logical page size is the granularity of vm regions 
 * this may be smaller on a direct mapped memory system. 
 * if paging is used LOGICAL and PHYSICAL have to be the same size 
 */
 
/*slfsmm1>*/
#define LOGICALPAGEBITS             8
//#define LOGICALPAGEBITS             12
/*slfsmm1<*/
#define LOGICALPAGESIZE            (1 << LOGICALPAGEBITS)
/*slfsmm1>*/
#define LOGICALPAGESPERPAGE   PAGESIZE/LOGICALPAGESIZE
/*slfsmm1<*/
#define LOGICALPAGEFRAMEMASK       (0xffffffff << LOGICALPAGEBITS)
#define LOGICALPAGEMASK            (~LOGICALPAGEFRAMEMASK)
#define LOGICALPAGENUMBER(addr)    (((unsigned long)addr) >> LOGICALPAGEBITS)
#define LOGICALPAGEREMAINDER(addr) (((unsigned long)addr) & LOGICALPAGEMASK)

/* used as a boot and later as an exception stack */
#define BOOTSTACKSIZE	PAGESIZE
#define BOOTSTACKBOTTOM	(K0SEG_BASE)//old K0SEG_BASE
#define BOOTSTACKTOP	(BOOTSTACKBOTTOM+BOOTSTACKSIZE-4)

#define TASK_SIZE (0x7fff8000UL)

