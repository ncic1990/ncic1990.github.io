#ifndef REMOTESERVRANGE_H
#define REMOTESERVRANGE_H

/*writen by slfsmm for remote services*/

#include "range.h"
#include "RemoteServ.h"

class RemoteServRange : public Range {
public:
    RemoteServRange(uint32 port) throw();
	virtual ~RemoteServRange() throw();
	/*base fetch and store operations*/
    virtual void store_byte(uint32 offset, uint8 data, DeviceExc *client);
	virtual uint8 fetch_byte(uint32 offset, DeviceExc *client);
	virtual void store_halfword(uint32 offset, uint16 data, DeviceExc *client);
	virtual uint16 fetch_halfword(uint32 offset, DeviceExc *client);
	virtual void store_word(uint32 offset, uint32 data, DeviceExc *client);
	virtual uint32 fetch_word(uint32 offset, int mode, DeviceExc *client);

private:
	/*memory space for RemoteServRange*/
	uint64 RemoteServRangeMem[RemoteServSpaceLLSize];
	int sockfd;
	#define INVALIDPORT -1
	uint32 serverport;
	void HandleCtrlCommands(uint32 offset, uint32 data);
	
	void HandleSRPortCommands(uint32 data);
	int ConnectToServer();
	long readn(int fd, void* vptr, long n);
	long writen(int fd, const void* vptr, long n);
	bool PackageLengthChecking(package_header_t* pheader);
	void SendPackage( );
	void RecvPackage( );
	void DisconnectFromServer();

};

#endif /*REMOTESERVRANGE_H*/

