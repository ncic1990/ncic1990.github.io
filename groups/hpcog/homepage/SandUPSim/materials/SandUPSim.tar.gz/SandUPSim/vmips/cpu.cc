/* MIPS R3000 CPU emulation.
   Copyright 2001, 2002, 2003 Brian R. Gaeke.

This file is part of VMIPS.

VMIPS is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 2 of the License, or (at your
option) any later version.

VMIPS is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
for more details.

You should have received a copy of the GNU General Public License along
with VMIPS; if not, write to the Free Software Foundation, Inc.,
59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.  */

#include <stdio.h>
#include "cpu.h"
#include "vmips.h"
#include "options.h"
#include "regnames.h"
#include "excnames.h"
#include "cpzeroreg.h"
#include "error.h"
#include "remotegdb.h"
#include "stub-dis.h"
#include "tlb.h"

#include "memstat.h"
#include "cache.h"
#include "addr.h"

/* add by zhangwl for debug */
// #define __DUMP_INST__  //for instruction execution flow print, getting rid of memory copy and utlb miss
// #define __CMP_DEBUG__ //during execution, as reference when auto compare the changed  register value
/* end -add by zhangwl for debug */

/* pointer to CPU method returning void and taking two uint32's */
typedef void (CPU::*emulate_funptr)(uint32, uint32);

char *const
CPU::strdelaystate(const int state)
{
	static char *statestr[] = { "NORMAL", "DELAYING", "DELAYSLOT" };

	return statestr[state];
}

CPU::CPU()
{
       
	delay_state = NORMAL;
	reg[REG_ZERO] = 0;
	ncount = 0;
	LLbit = false; // initialize to  false(no pending ll-sc) cmy
	/*modified by xjw 2003.10.15*/
//	attach(mch,m,cp0);

}

void
CPU::attach(vmips *mch, Mapper *m, CPZero *cp0, Addr * adr, Memstat* ms)
{
	if (mch) {
		machine = mch;
		opt_excmsg = machine->opt->option("excmsg")->flag;
		opt_excpriomsg = machine->opt->option("excpriomsg")->flag;
		opt_haltbreak = machine->opt->option("haltbreak")->flag,
		opt_haltibe = machine->opt->option("haltibe")->flag;
		opt_haltjrra = machine->opt->option("haltjrra")->flag;
		opt_instdump = machine->opt->option("instdump")->flag;
		opt_cacheable = machine ->opt ->option("cacheable")->flag;
		opt_tracetofile = machine ->opt ->option("tracetofile")->flag;
		opt_traceplot = machine ->opt ->option("traceplot") ->flag;
		opt_posttrace = machine ->opt ->option("posttrace") ->flag;
		opt_fastmem = machine ->opt ->option("fastmem") ->flag;
		opt_detectstream = machine ->opt ->option("detectstream") ->flag;
		opt_detectmemsize = machine ->opt ->option("detectmemsize") ->flag;
		opt_statrate = machine->opt->option("statrate")->flag;
		opt_barrier     = machine ->opt ->option("barrier")->flag;
	}
	if (m) mem = m;
	if (cp0) cpzero = cp0;
	if (adr) addr = adr;
	if (ms) memstat = ms;			
	/*modified by xjw 2003.10.15*/
/*	addr= new Addr(this); */
}

void
CPU::attach(CPOne * cp1)
{
        if (cp1) cpone = cp1;
}

void
CPU::reset(void)
{
#ifdef INTENTIONAL_CONFUSION
	int r;
	for (r = 0; r < 32; r++) {
		reg[r] = random();
	}
#endif /* INTENTIONAL_CONFUSION */
	reg[REG_ZERO] = 0;
	pc = 0xbfc00000;
	cpzero->reset();
}

void
CPU::dump_regs(FILE *f)
{
	int i;

	fprintf(f,"Reg Dump: [ PC=%08x  LastInstr=%08x  HI=%08x  LO=%08x\n",
		pc,instr,hi,lo);
	fprintf(f,"            DelayState=%s  DelayPC=%08x  NextEPC=%08x\n",
		strdelaystate(delay_state), delay_pc, next_epc);
	for (i = 0; i < 32; i++) {
		fprintf(f," R%02d=%08x ",i,reg[i]);
		if (i % 5 == 4) {
			fputc('\n',f);
		} else if (i == 31) {
			fprintf(f, " ]\n");
		}
	}
}

void
CPU::dump_regs_and_stack(FILE *f)
{
	uint32 stackphys;

	dump_regs(f);
	if ((cpzero->tlb) -> debug_tlb_translate(reg[REG_SP], &stackphys)) {
		mem->dump_stack(f, stackphys);
	} else {
		fprintf(f, "Stack: (not mapped in TLB)\n");
	}
}

uint32 
CPU::GetGenReg(uint8 regno)
{
	return reg[regno];
}

void
CPU::SetGenReg(uint8 regno,long data)
{
	reg[regno]=(uint32)data;
}

Mapper*
CPU::GetMapper( )
{
	return mem;
}

CPZero* 
CPU::GetCP0( )
{
	return cpzero;
}
Addr* 
CPU::GetAddr( )
{
	return addr;
}

bool 
CPU::Get_opt_cacheable( )
{
	return opt_cacheable;
}

/* Instruction decoding */
/*****
uint16
CPU::opcode(const uint32 i) const
{
	return (i >> 26) & 0x03f;
}

uint16
CPU::rs(const uint32 i) const
{
	return (i >> 21) & 0x01f;
}

uint16
CPU::rt(const uint32 i) const
{
	return (i >> 16) & 0x01f;
}

uint16
CPU::rd(const uint32 i) const
{
	return (i >> 11) & 0x01f;
}

uint16
CPU::immed(const uint32 i) const
{
	return i & 0x0ffff;
}

short
CPU::s_immed(const uint32 i) const
{
	return i & 0x0ffff;
}

uint16
CPU::shamt(const uint32 i) const
{
	return (i >> 6) & 0x01f;
}

uint16
CPU::funct(const uint32 i) const
{
	return i & 0x03f;
}

uint32
CPU::jumptarg(const uint32 i) const
{
	return i & 0x03ffffff;
}
*****/
/* exception handling */
char *const
CPU::strexccode(const uint16 excCode)
{
	char *const exception_strs[] =
	{
		/* 0 */ "Interrupt",
		/* 1 */ "TLB modification exception",
		/* 2 */ "TLB exception (load or instr fetch)",
		/* 3 */ "TLB exception (store)",
		/* 4 */ "Address error exception (load or instr fetch)",
		/* 5 */ "Address error exception (store)",
		/* 6 */ "Instruction bus error",
		/* 7 */ "Data (load or store) bus error",
		/* 8 */ "SYSCALL exception",
		/* 9 */ "Breakpoint32 exception (BREAK instr)",
		/* 10 */ "Reserved instr exception",
		/* 11 */ "Coprocessor Unusable",
		/* 12 */ "Arithmetic Overflow",
		/* 13 */ "Trap (R4k/R6k only)",
		/* 14 */ "LDCz or SDCz to uncached address (R6k)",
		/* 14 */ "Virtual Coherency Exception (instr) (R4k)",
		/* 15 */ "Machine check exception (R6k)",
		/* 15 */ "Floating-point32 exception (R4k)",
		/* 16 */ "Divide zero exception", //"Exception 16 (reserved)", //changed by zhangwl
		/* 17 */ "Exception 17 (reserved)",
		/* 18 */ "Exception 18 (reserved)",
		/* 19 */ "Exception 19 (reserved)",
		/* 20 */ "Exception 20 (reserved)",
		/* 21 */ "Exception 21 (reserved)",
		/* 22 */ "Exception 22 (reserved)",
		/* 23 */ "Reference to WatchHi/WatchLo address detected (R4k)",
		/* 24 */ "Exception 24 (reserved)",
		/* 25 */ "Exception 25 (reserved)",
		/* 26 */ "Exception 26 (reserved)",
		/* 27 */ "Exception 27 (reserved)",
		/* 28 */ "Exception 28 (reserved)",
		/* 29 */ "Exception 29 (reserved)",
		/* 30 */ "Exception 30 (reserved)",
		/* 31 */ "Virtual Coherency Exception (data) (R4k)"
	};

	return exception_strs[excCode];
}

char *const
CPU::strmemmode(const int memmode)
{
	char *const memmode_strs[] =
	{
		"instruction fetch", /* INSTFETCH */
		"data load", /* DATALOAD */
		"data store", /* DATASTORE */
		"not applicable" /* ANY */
	};

	return memmode_strs[memmode];
}

int
CPU::exception_priority(uint16 excCode, int mode)
{
	/* See doc/excprio for an explanation of this table. */
	struct excPriority *p, prio[] = {      //need to add DZ exception zhangwl
		{1, AdEL, INSTFETCH},
		{2, TLBL, INSTFETCH}, {2, TLBS, INSTFETCH},
		{3, IBE, ANY},
		{4, Ov, ANY}, {4, Tr, ANY}, {4, Sys, ANY},
		{4, Bp, ANY}, {4, RI, ANY}, {4, CpU, ANY},
		{5, AdEL, DATALOAD}, {5, AdES, ANY},
		{6, TLBL, DATALOAD}, {6, TLBS, DATALOAD},
		{6, TLBL, DATASTORE}, {6, TLBS, DATASTORE},
		{7, Mod, ANY},
		{8, DBE, ANY},
		{9, Int, ANY},
		{0, ANY, ANY} /* catch-all */
	};

	for (p = prio; p->priority != 0; p++) {
		if (excCode == p->excCode || p->excCode == ANY) {
			if (mode == p->mode || p->mode == ANY) {
				return p->priority;
			} else if (opt_excpriomsg) {
				fprintf(stderr,
					"exception code matches but mode %d != table %d\n",
					mode,p->mode);
			}
		} else if (opt_excpriomsg) {
			fprintf(stderr, "exception code %d != table %d\n", excCode,
				p->excCode);
		}
	}
	return 0;
}

void
CPU::exception(uint16 excCode, int mode, int coprocno)
{
	static uint32 last_epc = 0;
	static int last_prio = 0;
	int prio;
	uint32 base, vector, epc;
	bool delaying = (delay_state == DELAYSLOT);

	if (opt_haltbreak) {
		if (excCode == Bp) {
			fprintf(stderr,"* BREAK instruction reached -- HALTING *\n");
			machine->halt();
		}
	}
	if (opt_haltibe) {
		if (excCode == IBE) {
			fprintf(stderr,"* Instruction bus error occurred -- HALTING *\n");
			machine->halt();
		}
	}

	/* exception will break ll & sc atomicity; cmy 031229 */
    LLbit = false;
	/* step() ensures that next_epc will always contain the correct
	 * EPC whenever exception() is called.
	 */
	epc = next_epc;

	/* Prioritize exception -- if the last exception to occur _also_ was
	 * caused by this EPC, only report this exception if it has a higher
	 * priority.  Otherwise, exception handling terminates here,
	 * because only one exception will be reported per instruction
	 * (as per MIPS RISC Architecture, p. 6-35). Note that this only
	 * applies IFF the previous exception was caught during the current
	 * _execution_ of the instruction at this EPC, so we check that
	 * EXCEPTION_PENDING is true before aborting exception handling.
	 * (This flag is reset by each call to step().)
	 */
	prio = exception_priority(excCode, mode);
	if (epc == last_epc) { 
		if (prio <= last_prio && exception_pending) {
			if (opt_excpriomsg) 
			{
				fprintf(stderr,
					"(Ignoring additional lower priority exception...)\n");
			}
			return;
		} else {
			last_prio = prio;
		}
	}
	last_epc = epc;

	/* Set processor to Kernel mode, disable interrupts, and save 
	 * exception PC.
	 */
	cpzero->enter_exception(epc,excCode,coprocno,delaying);

	/* Calculate the exception handler address; this is of the form BASE +
	 * VECTOR. The BASE is determined by whether we're using boot-time
	 * exception vectors, according to the BEV bit in the CP0 Status register.
	 */
	if (cpzero->use_boot_excp_address()) {
		base = 0xbfc00100;
	} else {
		base = 0x80000000;
	}

	/* Do we have a User TLB Miss exception? If so, jump to the
	 * User TLB Miss exception vector, otherwise jump to the
	 * common exception vector.
	 */
	if ((excCode == TLBL || excCode == TLBS) && ((cpzero->tlb) -> tlb_user_miss)) {
		vector = 0x000;
	} else {
		vector = 0x080;
	}

	if (opt_excmsg) {
		fprintf(stderr,"Exception %d (%s) triggered, EPC=%08x\n", excCode, 
			strexccode(excCode), epc);
		fprintf(stderr,
			" Priority is %d; delay state is %s; mem access mode is %s\n",
			prio, strdelaystate(delay_state), strmemmode(mode));
	}
	pc = base + vector;
	exception_pending = true;
}

/* emulation of instructions */
void
CPU::cpzero_emulate(uint32 instr, uint32 pc)
{
	cpzero->cpzero_emulate(instr, pc);
}

/* Called when the program wants to use coprocessor COPROCNO, and there
 * isn't any implementation for that coprocessor.
 * Results in a Coprocessor Unusable exception, along with an error
 * message being printed if the coprocessor is marked usable in the
 * CP0 Status register.
 */
void
CPU::cop_unimpl (int coprocno, uint32 instr, uint32 pc)
{
	if (cpzero->cop_usable (coprocno)) {
		/* Since they were expecting this to work, the least we
		 * can do is print an error message. */
		fprintf (stderr, "CP%d instruction %x not implemented at pc=0x%x:\n",
				 coprocno, instr, pc);
		call_disassembler (pc, instr);
		exception (CpU, ANY, coprocno);
	} else {
		/* It's fair game to just throw an exception, if they
		 * haven't even bothered to twiddle the status bits first. */
		exception (CpU, ANY, coprocno);
	}
}

void
CPU::cpone_emulate(uint32 instr, uint32 pc)
{
	/* If it's a cfc1 <reg>, $0 then we copy 0 into reg,
	 * which is supposed to mean there is NO cp1... 
	 * for now, though, ANYTHING else asked of cp1 results
	 * in the default "unimplemented" behavior. */
	if (cpzero->cop_usable (1) && rs (instr) == 2 && rd (instr) == 0) {
		reg[rt (instr)] = 0; /* No cp1. */
	} else {
		// add cpone:float support :cmy
		 cpone->cpone_emulate(instr,pc);
		//cop_unimpl (1, instr, pc);
	}
}

void
CPU::cptwo_emulate(uint32 instr, uint32 pc)
{
	cop_unimpl (2, instr, pc);
}

void
CPU::cpthree_emulate(uint32 instr, uint32 pc)
{
	cop_unimpl (3, instr, pc);
}

/* Return the address to jump to as a result of the J-format
 * (jump) instruction INSTR at address PC.
 * (PC is the address of the jump instruction, and INSTR is
 * the jump instruction word.)
 */
uint32
CPU::calc_jump_target(uint32 instr, uint32 pc)
{
	/* Must use address of delay slot (pc + 4) to calculate. */
	return ((pc + 4) & 0xf0000000) | (jumptarg(instr) << 2);
}

void
CPU::j_emulate(uint32 instr, uint32 pc)
{
	delay_state = DELAYING;
	delay_pc = calc_jump_target(instr, pc);
}

void
CPU::jal_emulate(uint32 instr, uint32 pc)
{
	delay_state = DELAYING;
	delay_pc = calc_jump_target(instr, pc);
	/* RA gets addr of instr after delay slot (2 words after this one). */
	reg[REG_RA] = pc + 8;
}

/* Take the PC-relative branch for which the offset is specified by
 * the immediate field of the branch instruction word INSTR, with
 * the program counter equal to PC.
 */
void
CPU::branch(uint32 instr, uint32 pc)
{
	delay_state = DELAYING;
	delay_pc = (pc + 4) + (s_immed(instr) << 2);
}

void
CPU::beq_emulate(uint32 instr, uint32 pc)
{
	if (reg[rs(instr)] == reg[rt(instr)]) {
		branch(instr, pc);
	}
}

void
CPU::bne_emulate(uint32 instr, uint32 pc)
{
	if (reg[rs(instr)] != reg[rt(instr)]) {
		branch(instr, pc);
	}
}

void
CPU::blez_emulate(uint32 instr, uint32 pc)
{
	if (rt(instr) != 0) {
		exception(RI);
	}
	if (reg[rs(instr)] == 0 || (reg[rs(instr)] & 0x80000000)) {
		branch(instr, pc);
	}
}

void
CPU::bgtz_emulate(uint32 instr, uint32 pc)
{
	if (rt(instr) != 0) {
		exception(RI);
		return;
	}
	if (reg[rs(instr)] != 0 && (reg[rs(instr)] & 0x80000000) == 0) {
		branch(instr, pc);
	}
}

void
CPU::addi_emulate(uint32 instr, uint32 pc)
{
	int32 a, b, sum;

	a = (int32)reg[rs(instr)];
	b = s_immed(instr);
	sum = a + b;
	if ((a < 0 && b < 0 && !(sum < 0)) || (a >= 0 && b >= 0 && !(sum >= 0))) {
		exception(Ov);
		return;
	} else {
		reg[rt(instr)] = (uint32)sum;
	}

#ifdef __CMP_DEBUG__	
	if (opt_barrier){
		ncount ++;
		fprintf(stderr, "PC->%8x, Reg[%x]->%8x\n", pc, rt(instr),  reg[rt(instr)]);
		fflush(stderr);
	}
#endif
}

void
CPU::addiu_emulate(uint32 instr, uint32 pc)
{
	int32 a, b, sum;

	a = (int32)reg[rs(instr)];
	b = s_immed(instr);
	sum = a + b;
	reg[rt(instr)] = (uint32)sum;

#ifdef __CMP_DEBUG__
	if (opt_barrier){
		ncount ++;
		fprintf(stderr, "PC->%8x, Reg[%x]->%8x\n", pc, rt(instr),  reg[rt(instr)]);
		fflush(stderr);
	}
#endif	
}

void
CPU::slti_emulate(uint32 instr, uint32 pc)
{
	int32 s_rs = reg[rs(instr)];

	if (s_rs < s_immed(instr)) {
		reg[rt(instr)] = 1;
	} else {
		reg[rt(instr)] = 0;
	}

#ifdef __CMP_DEBUG__
	if (opt_barrier){
		ncount ++;
		fprintf(stderr, "PC->%8x, Reg[%x]->%8x\n", pc, rt(instr),  reg[rt(instr)]);
		fflush(stderr);
	}
#endif	
}

void
CPU::sltiu_emulate(uint32 instr, uint32 pc)
{
		// change from immed to s_immed
	if (reg[rs(instr)] < (uint)s_immed(instr)) {
		reg[rt(instr)] = 1;
	} else {
		reg[rt(instr)] = 0;
	}

#ifdef __CMP_DEBUG__	
	if (opt_barrier){
		ncount ++;
		fprintf(stderr, "PC->%8x, Reg[%x]->%8x\n", pc, rt(instr),  reg[rt(instr)]);
		fflush(stderr);
	}
#endif	
}

void
CPU::andi_emulate(uint32 instr, uint32 pc)
{
	reg[rt(instr)] = (reg[rs(instr)] & 0x0ffff) & immed(instr);

#ifdef __CMP_DEBUG__	
	if (opt_barrier){
		ncount ++;
		fprintf(stderr, "PC->%8x, Reg[%x]->%8x\n", pc, rt(instr),  reg[rt(instr)]);
		fflush(stderr);
	}
#endif	
}

void
CPU::ori_emulate(uint32 instr, uint32 pc)
{
	reg[rt(instr)] = reg[rs(instr)] | immed(instr);

#ifdef __CMP_DEBUG__	
	if (opt_barrier){
		ncount ++;
		fprintf(stderr, "PC->%8x, Reg[%x]->%8x\n", pc, rt(instr),  reg[rt(instr)]);
		fflush(stderr);
	}
#endif	
}

void
CPU::xori_emulate(uint32 instr, uint32 pc)
{
	reg[rt(instr)] = reg[rs(instr)] ^ immed(instr);

#ifdef __CMP_DEBUG__	
	if (opt_barrier){
		ncount ++;
		fprintf(stderr, "PC->%8x, Reg[%x]->%8x\n", pc, rt(instr),  reg[rt(instr)]);
		fflush(stderr);
	}
#endif	
}

void
CPU::lui_emulate(uint32 instr, uint32 pc)
{
	reg[rt(instr)] = immed(instr) << 16;

#ifdef __CMP_DEBUG__
	if (opt_barrier){
		ncount ++;
		fprintf(stderr, "PC->%8x, Reg[%x]->%8x\n", pc, rt(instr),  reg[rt(instr)]);
		fflush(stderr);
	}
#endif	
}

void
CPU::lb_emulate(uint32 instr, uint32 pc)
{
	uint32 virt, base;
	uint8 byte; // need sign extend cmy
	int32 offset;	 
	uint8 delay_time;

	/* Calculate virtual address. */
	base = reg[rs(instr)];
	offset = s_immed(instr);
	virt = base + offset;
	/* modified by xjw 2003.10.15 */
	addr ->fetch_byte(virt, &byte, &delay_time);
	if(byte == 0xff && exception_pending) 
		return ;
	/* Load target register with data. */
	reg[rt(instr)] = (int8)byte;

#ifdef __CMP_DEBUG__	
	if (opt_barrier){
		ncount ++;
		fprintf(stderr, "PC->%8x, Reg[%x]->%8x\n", pc, rt(instr),  reg[rt(instr)]);
		fflush(stderr);
	}
#endif	
}

void
CPU::lh_emulate(uint32 instr, uint32 pc)
{
	uint32 virt, base;
	uint16 halfword; //need sign extend : cmy
	int32 offset;
	 
	uint8 delay_time;

	/* Calculate virtual address. */
	base = reg[rs(instr)];
	offset = s_immed(instr);
	virt = base + offset;

	/*
	modified by xjw 2003.10.15
	*/

	addr ->fetch_half_word(virt, &halfword, &delay_time);
	if ((halfword & 0xffff == 0xffff) && exception_pending) return;

	/* Load target register with data. */
	reg[rt(instr)] = (int16)halfword;

#ifdef __CMP_DEBUG__	
	if (opt_barrier){
		ncount ++;
		fprintf(stderr, "PC->%8x, Reg[%x]->%8x\n", pc, rt(instr),  reg[rt(instr)]);
		fflush(stderr);
	}
#endif	
}

/* The lwr and lwl algorithms here are taken from SPIM 6.0,
 * since I didn't manage to come up with a better way to write them.
 * Improvements are welcome.
 */


void
CPU::lwl_emulate(uint32 instr, uint32 pc)
{
	uint32 virt,  base, memword;	
	int32 offset;
       uint8 delay_time;

	/* Calculate virtual address. */
	base = reg[rs(instr)];
	offset = s_immed(instr);
	virt = base + offset;
	/* We request the word containing the byte-address requested. */
	/*
	modified by xjw 2003.10.15
	*/
	addr ->fetch_wordl(virt, reg[rt(instr)], &memword, &delay_time);
	/*slfsmm031027_add_bug>*/
      if(memword == 0xffffffff && exception_pending)  return;
	/*slfsmm031027_add_bug<*/
	reg[rt(instr)] = memword;

#ifdef __CMP_DEBUG__	
	if (opt_barrier){
		ncount ++;
		fprintf(stderr, "PC->%8x, Reg[%x]->%8x\n", pc, rt(instr),  reg[rt(instr)]);
		fflush(stderr);
	}
#endif	
}

void
CPU::lw_emulate(uint32 instr, uint32 pc)
{
	uint32 virt, base, word;
	int32 offset;
	
	uint8 delay_time;

	/* Calculate virtual address. */
	base = reg[rs(instr)];
	offset = s_immed(instr);
	virt = base + offset;

       /*
	modified by xjw 2003.10.15
	*/
	addr ->fetch_word(virt,  &word, &delay_time);
       if(word == 0xffffffff && exception_pending)
       	return;

	reg[rt(instr)] = word;

#ifdef __CMP_DEBUG__	
	if (opt_barrier){
		ncount ++;
		fprintf(stderr, "PC->%8x, Reg[%x]->%8x\n", pc, rt(instr),  reg[rt(instr)]);
		fflush(stderr);
	}
#endif	
}

void
CPU::ll_emulate(uint32 instr, uint32 pc)
{
	uint32 virt, base, word;
	int32 offset;
	
	uint8 delay_time;

	/* Calculate virtual address. */
	base = reg[rs(instr)];
	offset = s_immed(instr);
	virt = base + offset;

    /*
	modified by xjw 2003.10.15
	load lock need special process in MP: cmy 031228
	*/
	addr ->fetch_word(virt,  &word, &delay_time);
       if(word == 0xffffffff && exception_pending)
       	return;

	reg[rt(instr)] = word;
	LLbit = true; // always success in single processor, check align?
#ifdef __CMP_DEBUG__	
	if (opt_barrier){
		ncount ++;
		fprintf(stderr, "PC->%8x, Reg[%x]->%8x\n", pc, rt(instr),  reg[rt(instr)]);
		fflush(stderr);
	}
#endif	
}

void
CPU::lbu_emulate(uint32 instr, uint32 pc)
{
	uint32 virt, base;
	int32 offset;
	uint8 byte;
	uint8 delay_time;
	/* Calculate virtual address. */
	base = reg[rs(instr)];
	offset = s_immed(instr);
	virt = base + offset;

	/* Translate virtual address to physical address. */
	addr ->fetch_byte(virt, &byte, &delay_time);
	/*
	modified by xjw 2003.10.15
	*/
	if ((byte & 0xff == 0xff) && exception_pending) return;
       
	/* Load target register with data. */
	reg[rt(instr)] = byte;

#ifdef __CMP_DEBUG__	
	if (opt_barrier){
		ncount ++;
		fprintf(stderr, "PC->%8x, Reg[%x]->%8x\n", pc, rt(instr),  reg[rt(instr)]);
		fflush(stderr);
	}
#endif	
}

void
CPU::lhu_emulate(uint32 instr, uint32 pc)
{
	uint32 virt, base;
	uint16 halfword;
	int32 offset;
	uint8 delay_time;


	/* Calculate virtual address. */
	base = reg[rs(instr)];
	offset = s_immed(instr);
	virt = base + offset;

	/*
	modified by xjw 2003.10.15
	*/
	addr ->fetch_half_word(virt, &halfword, &delay_time);
	if ((halfword & 0xffff == 0xffff) && exception_pending) return;

	/* Load target register with data. */
	reg[rt(instr)] = halfword;

#ifdef __CMP_DEBUG__	
	if (opt_barrier){
		ncount ++;
		fprintf(stderr, "PC->%8x, Reg[%x]->%8x\n", pc, rt(instr),  reg[rt(instr)]);
		fflush(stderr);
	}
#endif	
}

void
CPU::lwr_emulate(uint32 instr, uint32 pc)
{
	uint32 virt,  base, memword;
	int32 offset;
        uint8 delay_time;

	/* Calculate virtual address. */
	base = reg[rs(instr)];
	offset = s_immed(instr);
	virt = base + offset;
	/* We request the word containing the byte-address requested. */

	/* 
	modified by xjw 2003.10.15
	*/
	addr ->fetch_wordr(virt, reg[rt(instr)], &memword, &delay_time);
	/*slfsmm031027_add_bug>*/
    	if(memword == 0xffffffff && exception_pending)  return;
	/*slfsmm031027_add_bug<*/
	reg[rt(instr)] = memword;

#ifdef __CMP_DEBUG__	
	if (opt_barrier){
		ncount ++;
		fprintf(stderr, "PC->%8x, Reg[%x]->%8x\n", pc, rt(instr),  reg[rt(instr)]);
		fflush(stderr);
	}
#endif	
}

void
CPU::sb_emulate(uint32 instr, uint32 pc)
{
	uint32 virt, base;
	uint8 data;
	int32 offset;

	uint8 delay_time;

	/* Load data from register. */
	data = reg[rt(instr)] & 0x0ff;

	/* Calculate virtual address. */
	base = reg[rs(instr)];
	offset = s_immed(instr);
	virt = base + offset;
	/*
	modified by xjw 2003.10.15
	 */
	addr ->store_byte(virt, data, &delay_time);
}

void
CPU::sh_emulate(uint32 instr, uint32 pc)
{
	uint32 virt, base;
	uint16 data;
	int32 offset;

	uint8  delay_time;

	/* Load data from register. */
	data = reg[rt(instr)] & 0x0ffff;

	/* Calculate virtual address. */
	base = reg[rs(instr)];
	offset = s_immed(instr);
	virt = base + offset;

	/*
	modified by xjw
	*/
	addr ->store_half_word( virt, data, &delay_time);
}



void
CPU::swl_emulate(uint32 instr, uint32 pc)
{
	uint32 virt,  base, regdata;
	int32 offset;
	uint8 delay_time;

	/* Load data from register. */
	regdata = reg[rt(instr)];

	/* Calculate virtual address. */
	base = reg[rs(instr)];
	offset = s_immed(instr);
	virt = base + offset;
	/* We request the word containing the byte-address requested. */

	addr ->store_wordl(virt, regdata,  &delay_time);
	
	/*
	modified by xjw  2003.10.15
	
	*/
}

void
CPU::sw_emulate(uint32 instr, uint32 pc)
{
	uint32 virt, base, data;
	int32 offset;

	uint8   delay_time;

	/* Load data from register. */
	data = reg[rt(instr)];

	/* Calculate virtual address. */
	base = reg[rs(instr)];
	offset = s_immed(instr);
	virt = base + offset;

	/*
	modified by xjw 2003.10.15
	*/
	addr ->store_word(virt,  data, &delay_time);
}

void
CPU::sc_emulate(uint32 instr, uint32 pc)
{
	uint32 virt, base, data;
	int32 offset;

	uint8   delay_time;

	/* Load data from register. */
	data = reg[rt(instr)];

	/* Calculate virtual address. */
	base = reg[rs(instr)];
	offset = s_immed(instr);
	virt = base + offset;

	/*
	modified by xjw 2003.10.15
	*/
	if(LLbit) {
		addr ->store_word(virt,  data, &delay_time);
		LLbit = false;
		reg[rt(instr)] = 1; // flag to indicate success cmy 031228
	}
	else 
		reg[rt(instr)] = 0; // never here when in single processor 
}

void 
CPU::cache_emulate(uint32 instr, uint32 pc)
{
	 uint32 virt, base, offset;
     int32  mode;
	 uint32 cacheop, select;
	 /*
	  *  change to support more cache ops : cmy 
	  * 
     mode = (instr >> 16) & 1;   // fetch the 16th bit of the instr
     int flush_tag = (instr >> 18) & 7;   // fetct the 20th~18th bit of the instr
     if ((flush_tag == 0 || flush_tag == 5 || flush_tag == 6) && opt_cacheable)
     addr->cache->flush(mode);
     else
     exception(RI);
	 */
	 	
	 select  = ((instr) >> 16) & 3; // select I/D/T/S cache
	 mode = select & 1; // mode 2/3 are optional
	 cacheop = ((instr) >> 18) & 3;
	 switch(cacheop) {
		case 0: // Index Invalidate
		case 1: // Load Tag to TagLo adn TagHi
		case 2: // Store Tag 
		case 3: // Not specified 
		case 4: // Hit Invalid
		case 7: // Fetch and Lock
			fprintf (stderr, "cpu instruction %x not implemented at pc=0x%x:\n",
				  instr, pc);
			exception(RI);
			break;
		case 5: // Fill I cache; Hit WB&Invalidate Dcache
		case 6: // Hit WB for D Cache
			if(!opt_cacheable)  return;
			base = reg[rs(instr)];
			offset = s_immed(instr);
			virt = base + offset;

			// should be flush(cacheop,select,addr) later !!
			addr->cache->flush(mode,1);
			break;
	 }
}

void
CPU::swr_emulate(uint32 instr, uint32 pc)
{
	uint32 virt,  base, regdata ;
	int32 offset;

	uint8 delay_time;
	/* Load data from register. */
	regdata = reg[rt(instr)];

	/* Calculate virtual address. */
	base = reg[rs(instr)];
	offset = s_immed(instr);
	virt = base + offset;
	/* We request the word containing the byte-address requested. */
	
	/*
	
      modified by xjw  2003.10.15	
	
	*/
	addr ->store_wordr(virt, regdata, &delay_time);
	
}

void
CPU::lwc1_emulate(uint32 instr, uint32 pc)
{
	// add support ;cmy
	//cop_unimpl (1, instr, pc);
	    uint32 virt, base, word;
        int32 offset;
		uint8 delay_time;
        /* Calculate virtual address. */
        base = reg[rs(instr)];
        offset = s_immed(instr);
        virt = base + offset;

        /* This virtual address must be word-aligned. */
        if (virt % 4 != 0) {
                exception(AdEL,DATALOAD);
                return;
        }
		addr ->fetch_word(virt,  &word, &delay_time);

        if (word == 0xffffffff && exception_pending) return;
        /* Load target register with data. */
        cpone->IntFGR(rt(instr)) = word;

}

void
CPU::lwc2_emulate(uint32 instr, uint32 pc)
{
	cop_unimpl (2, instr, pc);
}

void
CPU::lwc3_emulate(uint32 instr, uint32 pc)
{
	cop_unimpl (3, instr, pc);
}

void
CPU::swc1_emulate(uint32 instr, uint32 pc)
{  
	// cop_unimpl (1, instr, pc);
	// add by cmy
        uint32 virt, base, data;
        int32 offset;
        uint8 delay_time;


        /* Load data from register. */
        data =  cpone->IntFGR(rt(instr));

        /* Calculate virtual address. */
        base = reg[rs(instr)];
        offset = s_immed(instr);
        virt = base + offset;

        /* This virtual address must be word-aligned. */
        if (virt % 4 != 0) {
                exception(AdES,DATASTORE);
                return;
        }
        addr ->store_word(virt,  data, &delay_time);
}

void
CPU::swc2_emulate(uint32 instr, uint32 pc)
{
	cop_unimpl (2, instr, pc);
}

void
CPU::swc3_emulate(uint32 instr, uint32 pc)
{
	cop_unimpl (3, instr, pc);
}

void
CPU::sll_emulate(uint32 instr, uint32 pc)
{
	reg[rd(instr)] = reg[rt(instr)] << shamt(instr);

#ifdef __CMP_DEBUG__
	if (opt_barrier){
		ncount ++;
		fprintf(stderr, "PC->%8x, Reg[%x]->%8x\n", pc, rd(instr),  reg[rd(instr)]);
		fflush(stderr);
	}
#endif
}

int32
srl(int32 a, int32 b)
{
	if (b == 0) {
		return a;
	} else if (b == 32) {
		return 0;
	} else {
	return (a >> b) & ((1 << (32 - b)) - 1);
	}
}

int32
sra(int32 a, int32 b)
{
	if (b == 0) {
		return a;
	} else {
	return (a >> b) | (((a >> 31) & 0x01) * (((1 << b) - 1) << (32 - b)));
	}
}

void
CPU::srl_emulate(uint32 instr, uint32 pc)
{
	reg[rd(instr)] = srl(reg[rt(instr)], shamt(instr));

#ifdef __CMP_DEBUG__
	if (opt_barrier){
		ncount ++;
		fprintf(stderr, "PC->%8x, Reg[%x]->%8x\n", pc, rd(instr),  reg[rd(instr)]);
		fflush(stderr);
	}
#endif
}

void
CPU::sra_emulate(uint32 instr, uint32 pc)
{
	reg[rd(instr)] = sra(reg[rt(instr)], shamt(instr));

#ifdef __CMP_DEBUG__
	if (opt_barrier){
		ncount ++;
		fprintf(stderr, "PC->%8x, Reg[%x]->%8x\n", pc, rd(instr),  reg[rd(instr)]);
		fflush(stderr);
	}
#endif
}

void
CPU::sllv_emulate(uint32 instr, uint32 pc)
{
	reg[rd(instr)] = reg[rt(instr)] << (reg[rs(instr)] & 0x01f);

#ifdef __CMP_DEBUG__
	if (opt_barrier){
		ncount ++;
		fprintf(stderr, "PC->%8x, Reg[%x]->%8x\n", pc, rd(instr),  reg[rd(instr)]);
		fflush(stderr);
	}
#endif
}

void
CPU::srlv_emulate(uint32 instr, uint32 pc)
{
	reg[rd(instr)] = srl(reg[rt(instr)], reg[rs(instr)] & 0x01f);

#ifdef __CMP_DEBUG__
	if (opt_barrier){
		ncount ++;
		fprintf(stderr, "PC->%8x, Reg[%x]->%8x\n", pc, rd(instr),  reg[rd(instr)]);
		fflush(stderr);
	}
#endif
}

void
CPU::srav_emulate(uint32 instr, uint32 pc)
{
	reg[rd(instr)] = sra(reg[rt(instr)], reg[rs(instr)] & 0x01f);

#ifdef __CMP_DEBUG__
	if (opt_barrier){
		ncount ++;
		fprintf(stderr, "PC->%8x, Reg[%x]->%8x\n", pc, rd(instr),  reg[rd(instr)]);
		fflush(stderr);
	}
#endif
}

void
CPU::jr_emulate(uint32 instr, uint32 pc)
{
	if (opt_haltjrra) {
		if (rs(instr) == REG_RA) {
			fprintf(stderr,
				"** Procedure call return instr reached -- HALTING **\n");
			machine->halt();
		}
	}
	if (reg[rd(instr)] != 0) {
		exception(RI);
	}
	delay_state = DELAYING;
	delay_pc = reg[rs(instr)];
}

void
CPU::jalr_emulate(uint32 instr, uint32 pc)
{
	delay_state = DELAYING;
	delay_pc = reg[rs(instr)];
	/* RA gets addr of instr after delay slot (2 words after this one). */
	reg[rd(instr)] = pc + 8;

#ifdef __CMP_DEBUG__	
	if (opt_barrier){
		ncount ++;
		fprintf(stderr, "PC->%8x, Reg[%x]->%8x\n", pc, rd(instr),  reg[rd(instr)]);
		fflush(stderr);
	}
#endif
}

void
CPU::syscall_emulate(uint32 instr, uint32 pc)
{
	exception(Sys);
}

void
CPU::break_emulate(uint32 instr, uint32 pc)
{
	exception(Bp);
}

void
CPU::mfhi_emulate(uint32 instr, uint32 pc)
{
	reg[rd(instr)] = hi;

#ifdef __CMP_DEBUG__
	if (opt_barrier){
		ncount ++;
		fprintf(stderr, "PC->%8x, Reg[%x]->%8x\n", pc, rd(instr),  reg[rd(instr)]);
		fflush(stderr);
	}
#endif 
}

void
CPU::mthi_emulate(uint32 instr, uint32 pc)
{
	if (rd(instr) != 0) {
		exception(RI);
		return;
	}
	hi = reg[rs(instr)];
}

void
CPU::mflo_emulate(uint32 instr, uint32 pc)
{
	reg[rd(instr)] = lo;

#ifdef __CMP_DEBUG__
	if (opt_barrier){
		ncount ++;
		fprintf(stderr, "PC->%8x, Reg[%x]->%8x\n", pc, rd(instr),  reg[rd(instr)]);
		fflush(stderr);
	}
#endif
}

void
CPU::mtlo_emulate(uint32 instr, uint32 pc)
{
	if (rd(instr) != 0) {
		exception(RI);
		return;
	}
	lo = reg[rs(instr)];
}

void
CPU::mult_emulate(uint32 instr, uint32 pc)
{
	if (rd(instr) != 0) {
		exception(RI);
		return;
	}
	mult64s(&hi, &lo, reg[rs(instr)], reg[rt(instr)]);
}

void
CPU::mult64(uint32 *hi, uint32 *lo, uint32 n, uint32 m)
{
#ifdef HAVE_LONG_LONG
	uint64 result;
	result = ((uint64)n) * ((uint64)m);
	*hi = (uint32) (result >> 32);
	*lo = (uint32) result;
#else /* HAVE_LONG_LONG */
	/*           n = (w << 16) | x ; m = (y << 16) | z
	 *     w x   g = a + e ; h = b + f ; p = 65535
	 *   X y z   c = (z * x) mod p
	 *   -----   b = (z * w + ((z * x) div p)) mod p
	 *   a b c   a = (z * w + ((z * x) div p)) div p
	 * d e f     f = (y * x) mod p
	 * -------   e = (y * w + ((y * x) div p)) mod p
	 * i g h c   d = (y * w + ((y * x) div p)) div p
	 */
	uint16 w,x,y,z,a,b,c,d,e,f,g,h,i;
	uint32 p;
	p = 65536;
	w = (n >> 16) & 0x0ffff;
	x = n & 0x0ffff;
	y = (m >> 16) & 0x0ffff;
	z = m & 0x0ffff;
	c = (z * x) % p;
	b = (z * w + ((z * x) / p)) % p;
	a = (z * w + ((z * x) / p)) / p;
	f = (y * x) % p;
	e = (y * w + ((y * x) / p)) % p;
	d = (y * w + ((y * x) / p)) / p;
	h = (b + f) % p;
	g = ((a + e) + ((b + f) / p)) % p;
	i = d + (((a + e) + ((b + f) / p)) / p);
	*hi = (i << 16) | g;
	*lo = (h << 16) | c;
#endif /* HAVE_LONG_LONG */
}

void
CPU::mult64s(uint32 *hi, uint32 *lo, int32 n, int32 m)
{
#ifdef HAVE_LONG_LONG
	int64 result;
	result = ((int64)n) * ((int64)m);
	*hi = (uint32) (result >> 32);
	*lo = (uint32) result;
#else /* HAVE_LONG_LONG */
	int32 result_sign = (n<0)^(m<0);
	int32 n_abs = n;
	int32 m_abs = m;

	if (n_abs < 0) n_abs = -n_abs;
	if (m_abs < 0) m_abs = -m_abs;

	mult64(hi,lo,n_abs,m_abs);
	if (result_sign)
	{
		*hi = ~*hi;
		*lo = ~*lo;
		if (*lo & 0x80000000)
		{
			*lo += 1;
			if (!(*lo & 0x80000000))
			{
				*hi += 1;
			}
		}
		else
		{
			*lo += 1;
		}
	}
#endif /* HAVE_LONG_LONG */
}

void
CPU::multu_emulate(uint32 instr, uint32 pc)
{
	if (rd(instr) != 0) {
		exception(RI);
		return;
	}
	mult64(&hi, &lo, reg[rs(instr)], reg[rt(instr)]);
}

void
CPU::div_emulate(uint32 instr, uint32 pc)
{
	int32 signed_rs = (int32)reg[rs(instr)];
	int32 signed_rt = (int32)reg[rt(instr)];
	if (signed_rt == 0)
	{
		exception(DZ);
		return;
	}

	lo = signed_rs / signed_rt;
	hi = signed_rs % signed_rt;
}

void
CPU::divu_emulate(uint32 instr, uint32 pc)
{
	if (reg[rt(instr)] == 0)
	{
		exception(DZ);
		return;
	}

	lo = reg[rs(instr)] / reg[rt(instr)];
	hi = reg[rs(instr)] % reg[rt(instr)];
}

void
CPU::add_emulate(uint32 instr, uint32 pc)
{
	int32 a, b, sum;
	a = (int32)reg[rs(instr)];
	b = (int32)reg[rt(instr)];
	sum = a + b;
	if ((a < 0 && b < 0 && !(sum < 0)) || (a >= 0 && b >= 0 && !(sum >= 0))) {
		exception(Ov);
		return;
	} else {
		reg[rd(instr)] = (uint32)sum;
	}

#ifdef __CMP_DEBUG__	
	if (opt_barrier){
		ncount ++;
		fprintf(stderr, "PC->%8x, Reg[%x]->%8x\n", pc, rd(instr),  reg[rd(instr)]);
		fflush(stderr);
	}
#endif	
}

void
CPU::addu_emulate(uint32 instr, uint32 pc)
{
	int32 a, b, sum;
	a = (int32)reg[rs(instr)];
	b = (int32)reg[rt(instr)];
	sum = a + b;
	reg[rd(instr)] = (uint32)sum;

#ifdef __CMP_DEBUG__	
	if (opt_barrier){
		ncount ++;
		fprintf(stderr, "PC->%8x, Reg[%x]->%8x\n", pc, rd(instr),  reg[rd(instr)]);
		fflush(stderr);
	}
#endif
}

void
CPU::sub_emulate(uint32 instr, uint32 pc)
{
	int32 a, b, diff;
	a = (int32)reg[rs(instr)];
	b = (int32)reg[rt(instr)];
	diff = a - b;
	if ((a < 0 && !(b < 0) && !(diff < 0)) || (!(a < 0) && b < 0 && diff < 0)) {
		exception(Ov);
		return;
	} else {
		reg[rd(instr)] = (uint32)diff;
	}

#ifdef __CMP_DEBUG__
	if (opt_barrier){
		ncount ++;
		fprintf(stderr, "PC->%8x, Reg[%x]->%8x\n", pc, rd(instr),  reg[rd(instr)]);
		fflush(stderr);
	}
#endif
}

void
CPU::subu_emulate(uint32 instr, uint32 pc)
{
	int32 a, b, diff;
	a = (int32)reg[rs(instr)];
	b = (int32)reg[rt(instr)];
	diff = a - b;
	reg[rd(instr)] = (uint32)diff;

#ifdef __CMP_DEBUG__
	if (opt_barrier){
		ncount ++;
		fprintf(stderr, "PC->%8x, Reg[%x]->%8x\n", pc, rd(instr),  reg[rd(instr)]);
		fflush(stderr);
	}
#endif
}

void
CPU::and_emulate(uint32 instr, uint32 pc)
{
	reg[rd(instr)] = reg[rs(instr)] & reg[rt(instr)];

#ifdef __CMP_DEBUG__
	if (opt_barrier){
		ncount ++;
		fprintf(stderr, "PC->%8x, Reg[%x]->%8x\n", pc, rd(instr),  reg[rd(instr)]);
		fflush(stderr);
	}
#endif
}

void
CPU::or_emulate(uint32 instr, uint32 pc)
{
	reg[rd(instr)] = reg[rs(instr)] | reg[rt(instr)];

#ifdef __CMP_DEBUG__
	if (opt_barrier){
		ncount ++;
		fprintf(stderr, "PC->%8x, Reg[%x]->%8x\n", pc, rd(instr),  reg[rd(instr)]);
		fflush(stderr);
	}
#endif
}

void
CPU::xor_emulate(uint32 instr, uint32 pc)
{
	reg[rd(instr)] = reg[rs(instr)] ^ reg[rt(instr)];

#ifdef __CMP_DEBUG__
	if (opt_barrier){
		ncount ++;
		fprintf(stderr, "PC->%8x, Reg[%x]->%8x\n", pc, rd(instr),  reg[rd(instr)]);
		fflush(stderr);
	}
#endif
}

void
CPU::nor_emulate(uint32 instr, uint32 pc)
{
	reg[rd(instr)] = ~(reg[rs(instr)] | reg[rt(instr)]);

#ifdef __CMP_DEBUG__
	if (opt_barrier){
		ncount ++;
		fprintf(stderr, "PC->%8x, Reg[%x]->%8x\n", pc, rd(instr),  reg[rd(instr)]);
		fflush(stderr);
	}
#endif
}

void
CPU::slt_emulate(uint32 instr, uint32 pc)
{
	int32 s_rs = (int32)reg[rs(instr)];
	int32 s_rt = (int32)reg[rt(instr)];
	if (s_rs < s_rt) {
		reg[rd(instr)] = 1;
	} else {
		reg[rd(instr)] = 0;
	}

#ifdef __CMP_DEBUG__
	if (opt_barrier){
		ncount ++;
		fprintf(stderr, "PC->%8x, Reg[%x]->%8x\n", pc, rd(instr),  reg[rd(instr)]);
		fflush(stderr);
	}
#endif
}

void
CPU::sltu_emulate(uint32 instr, uint32 pc)
{
	if (reg[rs(instr)] < reg[rt(instr)]) {
		reg[rd(instr)] = 1;
	} else {
		reg[rd(instr)] = 0;
	}

#ifdef __CMP_DEBUG__
	if (opt_barrier){
		ncount ++;
		fprintf(stderr, "PC->%8x, Reg[%x]->%8x\n", pc, rd(instr),  reg[rd(instr)]);
		fflush(stderr);
	}
#endif
}

void
CPU::bltz_emulate(uint32 instr, uint32 pc)
{
	if ((int32)reg[rs(instr)] < 0) {
		branch(instr, pc);
	}
}

void
CPU::bgez_emulate(uint32 instr, uint32 pc)
{
	if ((int32)reg[rs(instr)] >= 0) {
		branch(instr, pc);
	}
}

/* As with JAL, BLTZAL and BGEZAL cause RA to get the address of the
 * instruction two words after the current one (pc + 8).
 */
void
CPU::bltzal_emulate(uint32 instr, uint32 pc)
{
	reg[REG_RA] = pc + 8;
	if ((int32)reg[rs(instr)] < 0) {
		branch(instr, pc);
	}
}

void
CPU::bgezal_emulate(uint32 instr, uint32 pc)
{
	reg[REG_RA] = pc + 8;
	if ((int32)reg[rs(instr)] >= 0) {
		branch(instr, pc);
	}
}

/* reserved instruction */
void
CPU::RI_emulate(uint32 instr, uint32 pc)
{
	exception(RI);
}

/* dispatching */
void
CPU::step()
{
	uint8 delay_time;
	static const emulate_funptr opcodeJumpTable[] = {
		&CPU::funct_emulate, &CPU::regimm_emulate,
		&CPU::j_emulate,     &CPU::jal_emulate,
		&CPU::beq_emulate,   &CPU::bne_emulate,
		&CPU::blez_emulate,  &CPU::bgtz_emulate,
		&CPU::addi_emulate,  &CPU::addiu_emulate,
		&CPU::slti_emulate,  &CPU::sltiu_emulate,
		&CPU::andi_emulate,  &CPU::ori_emulate,
		&CPU::xori_emulate,  &CPU::lui_emulate,
		&CPU::cpzero_emulate,&CPU::cpone_emulate,
		&CPU::cptwo_emulate, &CPU::cpthree_emulate,
		&CPU::RI_emulate,    &CPU::RI_emulate,
		&CPU::RI_emulate,    &CPU::RI_emulate,
		&CPU::RI_emulate,    &CPU::RI_emulate,
		&CPU::RI_emulate,    &CPU::RI_emulate,
		&CPU::RI_emulate,    &CPU::RI_emulate,
		&CPU::RI_emulate,    &CPU::RI_emulate,
		&CPU::lb_emulate,    &CPU::lh_emulate,
		&CPU::lwl_emulate,   &CPU::lw_emulate,
		&CPU::lbu_emulate,   &CPU::lhu_emulate,
		&CPU::lwr_emulate,   &CPU::RI_emulate,
		&CPU::sb_emulate,    &CPU::sh_emulate,
		&CPU::swl_emulate,   &CPU::sw_emulate,
		&CPU::RI_emulate,    &CPU::RI_emulate,
		&CPU::swr_emulate,   &CPU::cache_emulate,
		&CPU::ll_emulate,    &CPU::lwc1_emulate,
		&CPU::lwc2_emulate,  &CPU::lwc3_emulate,
		&CPU::RI_emulate,    &CPU::RI_emulate,
		&CPU::RI_emulate,    &CPU::RI_emulate,
		&CPU::sc_emulate,    &CPU::swc1_emulate,
		&CPU::swc2_emulate,  &CPU::swc3_emulate,
		&CPU::RI_emulate,    &CPU::RI_emulate,
		&CPU::RI_emulate,    &CPU::RI_emulate
	};

	/* Clear exception_pending flag if it was set by a
	 * prior instruction. */
	exception_pending = false;

	/* decrement Random register */
//  commented by cmy 11	
#ifndef LAZY_RANDOM
	cpzero->adjust_random();
#endif
	/* save address of instruction responsible for exceptions which may occur */
	if (delay_state != DELAYSLOT) {
		next_epc = pc;
	}

	/* 
	modified by xjw 2003.10.15
	*/	
	uint temp_pc = pc;	
	if((unsigned int)DBGTracer::trcVar[1] == pc) DBGTracer::pause();
	addr ->fetch_instr(pc, &instr, &delay_time);	
	/* add by cmy, trace after instr fetch 
	 * use temp_pc for exception will change pc*/
#ifdef _DEBUGGING_ // cost too much	
	DBGTracer::pctrace.record(temp_pc,instr);
#endif	
	if(DBGTracer::tracing && 
		addr ->inmem(memstat ->stat_info.addr)) 
	{		
		DBGTracer::recTrace(this);
		memstat ->RefreshTrace();
	//	DBGTracer::pause();
	}
//	else if (DBGTracer::tracing)
//		memstat ->RefreshTrace();

	if (instr == 0xffffffff && exception_pending) {
		if (opt_excmsg) {
			fprintf(stderr, "** Instruction fetch caused the exception! **\n");
		}
		delay_state = NORMAL; // bug slfsmm.
		return;
	}
	
	/* diagnostic output - display disassembly of instr */	
	if (opt_instdump&& (pc < (unsigned int)0x80000000)) {
//		static int inst_count = 0;
		{
        fprintf(stderr,"PC=0x%08x \t%08x ",pc,instr);//real_pc,
		call_disassembler(pc,instr);	
		}
	}

#ifdef __CMP_DEBUG__
	if ((ncount == 0) && (!(opt_barrier)) && (pc<0x80000000))
	{
		opt_barrier = 1;
		freopen("a.doc", "w+", stderr);
	}
#endif

	bool intsOnBefore = cpzero->interrupts_enabled();
	/* Jump to the appropriate emulation function. */
	(this->*opcodeJumpTable[opcode(instr)])(instr, pc);
	
	/*  cmy: if has memory access then trace */
	if(DBGTracer::tracing && !memstat->stat_info.boolval.val.inst_or_data
		&& 	addr ->inmem(memstat ->stat_info.addr) && memstat ->stat_info.addr) {
		DBGTracer::recTrace(this);
		memstat ->RefreshTrace();
	//	DBGTracer::pause();
	}
	
	bool intsOnAfter = cpzero->interrupts_enabled();

	/* Register zero must always be zero; this instruction forces this. */
	reg[REG_ZERO] = 0;

	/* Check for a (hardware or software) interrupt (but only if
	 * this instruction did not turn on interrupts.) */
	if (intsOnBefore && intsOnAfter && cpzero->interrupt_pending()) {
		exception(Int);
	}
#ifdef __DUMP_INST__   // used for debug to compare the instruction execution flow
	if (((pc < 0x80000000) || (pc == 0x80000080)) && (!(cpzero->tlb->tlb_user_miss)))// used for debug to compare the instruction execution flow
{
		static int inst_count = 0;
//		if (pc == 0x45a550)
//          		inst_count ++;
//          	if(inst_count > 41000000 ) exit(-1);
//        	if(inst_count > 30000000 )	
//		if (inst_count != 0)
			fprintf(stderr,"PC=0x%08x\n",pc);
}
#endif

	/* If there is an exception pending, we return now, so that we don't
	 * clobber the exception vector.
	 */
	if (exception_pending) {
		/* Instruction at beginning of exception handler is NOT in
		 * delay slot, no matter what the last instruction was.
		 */
		delay_state = NORMAL;
		return;
	}

#ifdef __CMP_DEBUG__
	if (ncount == 300)
	{
		DBGTracer::barrier();
		ncount = 0;
		freopen("a.doc", "w+", stderr);
	}
#endif

	/* increment PC */
	if (delay_state == DELAYING) {
		/* This instruction caused a branch to be taken.
		 * The next instruction is in the delay slot.
		 * The next instruction EPC will be PC - 4.
		 */
		delay_state = DELAYSLOT;
		pc = pc + 4;
	} else if (delay_state == DELAYSLOT) {
		/* This instruction was executed in a delay slot.
		 * The next instruction is on the other end of the branch.
		 * The next instruction EPC will be PC.
		 */
		delay_state = NORMAL;
		pc = delay_pc;
	} else if (delay_state == NORMAL) {
		/* No branch; next instruction is next word.
		 * Next instruction EPC is PC.
		 */		 
		pc = pc + 4;
		if (machine->opt_clkcpu) { //switch to clkcpu
			printf("Switch to clkcpu......\n");
			machine->emustate = 1;
		}

	}
}

inline 
void
CPU::funct_emulate(uint32 instr, uint32 pc)
{
	static const emulate_funptr functJumpTable[] = {
		&CPU::sll_emulate,     &CPU::RI_emulate,
		&CPU::srl_emulate,     &CPU::sra_emulate,
		&CPU::sllv_emulate,    &CPU::RI_emulate,
		&CPU::srlv_emulate,    &CPU::srav_emulate,
		&CPU::jr_emulate,      &CPU::jalr_emulate,
		&CPU::RI_emulate,      &CPU::RI_emulate,
		&CPU::syscall_emulate, &CPU::break_emulate,
		&CPU::RI_emulate,      &CPU::RI_emulate,
		&CPU::mfhi_emulate,    &CPU::mthi_emulate,
		&CPU::mflo_emulate,    &CPU::mtlo_emulate,
		&CPU::RI_emulate,      &CPU::RI_emulate,
		&CPU::RI_emulate,      &CPU::RI_emulate,
		&CPU::mult_emulate,    &CPU::multu_emulate,
		&CPU::div_emulate,     &CPU::divu_emulate,
		&CPU::RI_emulate,      &CPU::RI_emulate,
		&CPU::RI_emulate,      &CPU::RI_emulate,
		&CPU::add_emulate,     &CPU::addu_emulate,
		&CPU::sub_emulate,     &CPU::subu_emulate,
		&CPU::and_emulate,     &CPU::or_emulate,
		&CPU::xor_emulate,     &CPU::nor_emulate,
		&CPU::RI_emulate,      &CPU::RI_emulate,
		&CPU::slt_emulate,     &CPU::sltu_emulate,
		&CPU::RI_emulate,      &CPU::RI_emulate,
		&CPU::RI_emulate,      &CPU::RI_emulate,
		&CPU::RI_emulate,      &CPU::RI_emulate,
		&CPU::RI_emulate,      &CPU::RI_emulate,
		&CPU::RI_emulate,      &CPU::RI_emulate,
		&CPU::RI_emulate,      &CPU::RI_emulate,
		&CPU::RI_emulate,      &CPU::RI_emulate,
		&CPU::RI_emulate,      &CPU::RI_emulate,
		&CPU::RI_emulate,      &CPU::RI_emulate,
		&CPU::RI_emulate,      &CPU::RI_emulate
	};
	(this->*functJumpTable[funct(instr)])(instr, pc);
}

void
CPU::regimm_emulate(uint32 instr, uint32 pc)
{
	switch(rt(instr))
	{
		case 0: bltz_emulate(instr, pc); break;
		case 1: bgez_emulate(instr, pc); break;
		case 16: bltzal_emulate(instr, pc); break;
		case 17: bgezal_emulate(instr, pc); break;
		default: exception(RI); break; /* reserved instruction */
	}
}

/* Debug functions.
 *
 * These functions are primarily intended to support the Debug class,
 * which interfaces with GDB's remote serial protocol.
 */

/* Copy registers into an ASCII-encoded packet of hex numbers to send
 * to the remote GDB, and return the packet (allocated with malloc).
 */
char *
CPU::debug_registers_to_packet(void)
{
	char *packet = new char [PBUFSIZ];
	int i, r;

	/* order of regs:  (gleaned from gdb/gdb/config/mips/tm-mips.h)
	 * 
	 * cpu->reg[0]...cpu->reg[31]
	 * cpzero->reg[Status]
	 * cpu->lo
	 * cpu->hi
	 * cpzero->reg[BadVAddr]
	 * cpzero->reg[Cause]
	 * cpu->pc
     * fpu stuff: 35 zeroes (Unimplemented registers read as
     *  all bits zero.)
     */
	packet[0] = '\0';
	r = 0;
	for (i = 0; i < 32; i++) {
		Debug::packet_push_word(packet, reg[i]); r++;
	}
	uint32 sr, bad, cause;
	cpzero->read_debug_info(&sr, &bad, &cause);
	Debug::packet_push_word(packet, sr); r++;
	Debug::packet_push_word(packet, lo); r++;
	Debug::packet_push_word(packet, hi); r++;
	Debug::packet_push_word(packet, bad); r++;
	Debug::packet_push_word(packet, cause); r++;
	Debug::packet_push_word(packet, debug_get_pc()); r++;
	for (; r < 90; r++) { /* unimplemented regs at end */
		Debug::packet_push_word(packet, 0);
	}
	return packet;
}

/* Copy the register values in the ASCII-encoded hex PACKET received from
 * the remote GDB and store them in the appropriate registers.
 */
void
CPU::debug_packet_to_registers(char *packet)
{
	int i;

	for (i = 0; i < 32; i++) {
		reg[i] = Debug::packet_pop_word(&packet);
	}
	uint32 sr, bad, cause;
	sr = Debug::packet_pop_word(&packet);
	lo = Debug::packet_pop_word(&packet);
	hi = Debug::packet_pop_word(&packet);
	bad = Debug::packet_pop_word(&packet);
	cause = Debug::packet_pop_word(&packet);
	pc = Debug::packet_pop_word(&packet);
	cpzero->write_debug_info(sr, bad, cause);
}

/* Returns the exception code of any pending exception, or 0 if no
 * exception is pending.
 */
uint8
CPU::pending_exception(void)
{
	uint32 sr, bad, cause;

	if (! exception_pending) return 0;
	cpzero->read_debug_info(&sr, &bad, &cause);
	return ((cause & Cause_ExcCode_MASK) >> 2);
}

/* Sets the program counter register to the value given in NEWPC. */
void
CPU::debug_set_pc(uint32 newpc)
{
	pc = newpc;
}

/* Returns the current program counter register. */
uint32
CPU::debug_get_pc(void)
{
	return pc;
}

/* Fetch LEN bytes starting from virtual address ADDR into the packet
 * PACKET, sending exceptions (if any) to CLIENT. Returns -1 if an exception
 * was encountered, 0 otherwise.  If an exception was encountered, the
 * contents of PACKET are undefined, and CLIENT->exception() will have
 * been called.
 */
int
CPU::debug_fetch_region(uint32 addr, uint32 len, char *packet,
	DeviceExc *client)
{
	uint8 byte;
	uint32 real_addr;
	bool cacheable = false;

	for (; len; addr++, len--) {
		real_addr = cpzero->address_trans(addr, DATALOAD, &cacheable, client);
		/* Stop now and return an error code if translation
		 * caused an exception.
		 */
		if (real_addr == 0xffffffff && client->exception_pending) {
			return -1;
		}
		byte = mem->fetch_byte(real_addr, true, client);
		/* Stop now and return an error code if the fetch
		 * caused an exception.
		 */
		if (byte == 0xff && client->exception_pending) {
			return -1;
		}
		Debug::packet_push_byte(packet, byte);
	}
	return 0;
}

/* Store LEN bytes starting from virtual address ADDR from data in the packet
 * PACKET, sending exceptions (if any) to CLIENT. Returns -1 if an exception
 * was encountered, 0 otherwise.  If an exception was encountered, the
 * contents of the region of virtual memory from ADDR to ADDR+LEN are undefined,
 * and CLIENT->exception() will have been called.
 */
int
CPU::debug_store_region(uint32 addr, uint32 len, char *packet,
	DeviceExc *client)
{
	uint8 byte;
	uint32 real_addr;
	bool cacheable = false;

	for (; len; addr++, len--) {
		byte = Debug::packet_pop_byte(&packet);
		real_addr = cpzero->address_trans(addr, DATALOAD, &cacheable, client);
		if (real_addr == 0xffffffff && client->exception_pending) {
			return -1;
		}
		mem->store_byte(real_addr, byte, true, client);
		if (client->exception_pending) {
			return -1;
		}
	}
	return 0;
}
CPU::~CPU()
{
        delete(addr);
 //       fclose(fp);
//	delete fp;
}
