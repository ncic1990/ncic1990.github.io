#ifndef REMOTESERVCONST_H
#define REMOTESERVCONST_H

/*consts for Topsy assistant*/
//redirection return value
#define REDIRECTOK 1
#define REDIRECTFAILED 0
//change stdio and inherit
#define TACHSTDIOBYNAMEOK 1
#define TACHSTDIOBYNAMEFAILED 0
//change cwd return value
#define CWDOK 1
#define CWDFAILED 0
//get cwd const
#define TAGETCWDOK 0
#define TAGETCWDFAILED -1
#define TAGETCWDABSOLUTE 1
#define TAGETCWDDIRNAME 0

#endif/*REMOTESERVCONST_H*/

