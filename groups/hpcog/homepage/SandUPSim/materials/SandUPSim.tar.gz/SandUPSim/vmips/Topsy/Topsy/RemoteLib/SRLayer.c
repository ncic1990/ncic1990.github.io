//send and receive layer
uint32 calsizeofRDBP(ParamsDesc_t* paramsdesc, uint32* contentsize);
bool SendServRequest(ServInfoDesc_t* servinfoptr)
{
	if(!checkpointer(servinfoptr,"client err:SendServRequest:servinfoptr")) return false;
	ParamsDesc_t* paramsdesc=&servinfoptr->paramdesc;

	package_header_t* packageheader=(package_header_t*)NetWorkCardBuf;
	RDH* rdheader=(RDH*)(packageheader+1);
	RDBH* rdbheader=(RDBH*)(rdheader+1);
	RDBP* rdbparams=(RDBP*)(rdbheader+1);
	uint32 contentsize;
	uint32 datasetlen=sizeof(RDH)+sizeof(RDBH)+calsizeofRDBP(paramsdesc,&contentsize);
	uint32 bufpoint,bufoff,bufleft;
	uint32 paramscount,paramlencount;
	uint32 sendlen,tempoff;

	setRDH(rdheader,servinfoptr,datasetlen);
	setRDBH(rdbheader,servinfoptr);
	//if there is only one package
	if(datasetlen<=MAXDPBSIZE){
		setbuffer_Params((char*)rdheader,paramsdesc);
		setPackageHeader(packageheader,servinfoptr,
			sizeof(package_header_t)+datasetlen,FIRSTANDLAST);
		if(!SendPackage()) return false;
		return true;
	}
	//else
	setParamsContent(rdbparams,paramsdesc);
	setPackageHeader(packageheader,servinfoptr,
		sizeof(package_header_t)+MAXDPBSIZE,FIRSTPACKAGE);
	bufpoint=(uint32)rdheader;
	bufoff=sizeof(RDH)+sizeof(RDBH)+contentsize;
	bufleft=MAXDPBSIZE-bufoff;
	
	for(paramscount=0;paramscount<paramsdesc->paramnum;paramscount++){
		if(paramsdesc->parameters[paramscount].notpointer) continue;
		if((long)paramsdesc->parameters[paramscount].len==PARAM_POINTERNULL) 
			continue;
		tempoff=(sizeof(RDH)+sizeof(RDBH)+paramsdesc->parameters[paramscount].offset)%MAXDPBSIZE;
		if(tempoff>=bufoff)
			bufoff=tempoff, bufleft=MAXDPBSIZE-bufoff;
		else{
			if(!SendPackage()) return false;
			setPackageHeader(packageheader,servinfoptr,
				sizeof(package_header_t)+MAXDPBSIZE,DEFMIDPACKAGE);
			bufoff=0, bufleft=MAXDPBSIZE;
		}
		paramlencount=paramsdesc->parameters[paramscount].len;
		tempoff=0;
		while(paramlencount>0){
			sendlen=bufleft>paramlencount? paramlencount: bufleft;
			byteCopy((Address)(bufpoint+bufoff), (Address)(paramsdesc->parameters[paramscount].paramval+tempoff), sendlen);
			if(paramlencount>bufleft){
				if(!SendPackage()) return false;
				setPackageHeader(packageheader,servinfoptr,
					sizeof(package_header_t)+MAXDPBSIZE,DEFMIDPACKAGE);
				bufoff=0, bufleft=MAXDPBSIZE;
				tempoff+=sendlen, paramlencount-=sendlen;
			}else{
				bufoff+=sendlen, bufleft-=sendlen;
				break;
			}
		}
	}
	setPackageHeader(packageheader,servinfoptr,
		sizeof(package_header_t)+bufoff,LASTPACKAGE);
	if(!SendPackage()) return false;
	return true;
}

#define ADDRCHECKING(stditemptr,checkeditemptr)\
do{\
	if(UNITVAL(stditemptr->srcaddr.addr)!=UNITVAL(checkeditemptr->srcaddr.addr))\
		goto failed;\
	if(UNITVAL(stditemptr->srcaddr.port)!=UNITVAL(checkeditemptr->srcaddr.port))\
		goto failed;\
	if(UNITVAL(stditemptr->destaddr.addr)!=UNITVAL(checkeditemptr->destaddr.addr))\
		goto failed;\
	if(UNITVAL(stditemptr->destaddr.port)!=UNITVAL(checkeditemptr->destaddr.port))\
		goto failed;\
	return true;\
}while(0)
bool PackageAddrChecking(ServInfoDesc_t* servinfoptr, package_header_t* packageheader)
{
	ADDRCHECKING(servinfoptr,packageheader);
failed:
	#ifndef REMOTESERVQUIET
	ioConsolePutString("client err: SRLayer: PackageAddrChecking:addr checking err!\n");
	#endif
	return false;
}
bool DatasetAddrChecking(ServInfoDesc_t* servinfoptr, RDH* rdheader)
{
	ADDRCHECKING(servinfoptr,rdheader);
failed:
	#ifndef REMOTESERVQUIET
	ioConsolePutString("client err: SRLayer: DatasetAddrChecking:addr checking err!\n");
	#endif
	return false;
}
bool ServTypeChecking(ServInfoDesc_t* servinfoptr, RDBH* rdbheader)
{
	if((long)servinfoptr->type!=(long)UNITVAL(rdbheader->servtype))
		goto failed;
	if((long)servinfoptr->service!=(long)UNITVAL(rdbheader->service))
		goto failed;
	return true;
failed:
	#ifndef REMOTESERVQUIET
	ioConsolePutString("client err: SRLayer: ServTypeChecking:type checking err!\n");
	#endif
	return false;
}
bool RecvServReply(ServInfoDesc_t* servinfoptr)
{
	if(!checkpointer(servinfoptr,"client err:RecvServReply:servinfoptr")) return false;
	ParamsDesc_t* paramsdesc=&servinfoptr->paramdesc;
	
	package_header_t* packageheader=(package_header_t*)NetWorkCardBuf;
	RDH* rdheader=(RDH*)(packageheader+1);
	RDBH* rdbheader=(RDBH*)(rdheader+1);
	RDBP* rdbparams=(RDBP*)(rdbheader+1);
	uint32 datasetlen,datasetlencount;
	uint32 bufpoint,bufoff,bufleft;
	uint32 paramscount,paramlencount;
	uint32 recvlen,tempoff;

	if(!RecvPackage()) return false;
	//package checking
	if((UNITVAL(packageheader->packageflag)!=FIRSTPACKAGE)&&
		(UNITVAL(packageheader->packageflag)!=FIRSTANDLAST)){
		#ifndef REMOTESERVQUIET
		ioConsolePutString("client err:RecvServReply:expecting a first package but not!\n");
		ioConsolePutString("client err:RecvServReply:the flag is:");
		ioConsolePutHexInt(UNITVAL(packageheader->packageflag));
		#endif
		return false;
	}
	if(UNITVAL(packageheader->packagelen)<sizeof(package_header_t)+sizeof(RDH)+sizeof(RDBH)){
		#ifndef REMOTESERVQUIET
		ioConsolePutString("client err: SRLayer: RecvServReply:the length of the first package is too small!\n");
		#endif
		return false;
	}
	if(!PackageAddrChecking(servinfoptr,packageheader)) return false;
	//dataset checking
	if(!DatasetAddrChecking(servinfoptr,rdheader)) return false;
	if(!ServTypeChecking(servinfoptr,rdbheader)) return false;
	if(!getParamsContent(rdbparams, paramsdesc)) return false;
	bufpoint=(uint32)rdheader;
	bufoff=sizeof(RDH)+sizeof(RDBH)
		+paramsdesc->paramnum*sizeof(DSParamDesc_t)+sizeof(RServDataUnit_t);
	bufleft=MAXDPBSIZE-bufoff;
	datasetlen=UNITVAL(rdheader->datasetlen);
	datasetlencount=bufoff;
	
	for(paramscount=0;paramscount<paramsdesc->paramnum;paramscount++){
		if(paramsdesc->parameters[paramscount].notpointer) continue;
		if((long)paramsdesc->parameters[paramscount].len==(long)PARAM_POINTERNULL) 
			continue;
		tempoff=(sizeof(RDH)+sizeof(RDBH)+paramsdesc->parameters[paramscount].offset)%MAXDPBSIZE;
		if(tempoff>=bufoff)
			bufoff=tempoff, bufleft=MAXDPBSIZE-bufoff;
		else{
			if(!RecvPackage()) return false;
			if(!PackageAddrChecking(servinfoptr,packageheader)) return false;
			bufoff=0, bufleft=MAXDPBSIZE;
		}
		datasetlencount=sizeof(RDH)+sizeof(RDBH)+paramsdesc->parameters[paramscount].offset+
			paramsdesc->parameters[paramscount].len;
		paramlencount=paramsdesc->parameters[paramscount].len;
		tempoff=0;
		while(paramlencount>0){
			recvlen=bufleft>paramlencount? paramlencount: bufleft;
			byteCopy((Address)(paramsdesc->parameters[paramscount].paramval+tempoff),(Address)(bufpoint+bufoff),recvlen);
			if(paramlencount>bufleft){
				if(!RecvPackage()) return false;
				if(!PackageAddrChecking(servinfoptr,packageheader)) return false;
				bufoff=0, bufleft=MAXDPBSIZE;
				tempoff+=recvlen, paramlencount-=recvlen;
			}else{
				bufoff+=recvlen, bufleft-=recvlen;
				break;
			}
		}
	}
	if((UNITVAL(packageheader->packageflag)!=LASTPACKAGE)&&
		(UNITVAL(packageheader->packageflag)!=FIRSTANDLAST)){
		#ifndef REMOTESERVQUIET
		ioConsolePutString("client err:RecvServReply:expecting a last package but not!\n");
		#endif
		return false;
	}
	if(datasetlen!=datasetlencount){
		#ifndef REMOTESERVQUIET
		ioConsolePutString("client err:RecvServReply:datasetlen invalid!\n");
		ioConsolePutString("declare datasetlen:");
		ioConsolePutHexInt(datasetlen);
		ioConsolePutString("real datasetlen:");
		ioConsolePutHexInt(datasetlencount);
		#endif
		return false;
	}
	#ifdef DEBUGSR
	ioConsolePutString("client msg:RecvServReply succeed!\n");
	#endif
	return true;
}

