/* system include file,this is part of sand simulator
Copyright 2003,2005 HPCOG. NCIC. ICT
Date:2003.9.15   */

#ifndef _CACHE_H_
#define _CACHE_H_
#include "memstat.h"
#include "clkmem.h"
#include "error.h"
class  Mapper;
class CPU;

#define HITLEV1DLI   1
#define HITLEV1DLD   3
#define HITLEV2DL   7
#define HITLEV3DL   10
#define HITOFFCHIP   15

#define PAGEMASK 0xfffff000
#define PAGESIZE (4 * 1024)

struct memcache_entry
{
	bool v;
	bool d;
	memcache_entry *prev,*next;
	uint32 tag;	
	int32 revindex;
};
typedef struct 
{
	memcache_entry *table;
	uint32* data;
	uint32 entry_num;
	
	memcache_entry *hd;
	memcache_entry *freehd;
	
	uint32 *barray;    // the array for bin search
} memcache_t;

union cache_union
{
	uint64  content;
	struct info
	{
		unsigned v : 1;              // validate bit 
		unsigned d : 1;              // dirty bit
		unsigned w : 1;              // way prediction bit
		unsigned prot: 4;            // protect field
		unsigned asid: 8;       
		unsigned zero: 17;
		unsigned tag : 32;
	} lut;
};
typedef struct
{
	uint32 tag_width;
	uint32 index_width;
	uint32 offset_width;
	uint32 tagmask;
	uint32 indexmask;
	uint32 offsetmask;
}cache_prof_t;
struct cache_config
{
	bool onchip;                  // 1 if onchip otherwise 0
	//	bool separated;                // 1 if D_cache and I_cache is separated
	//	bool data_or_instr;            // 1 if Date cache otherwise 0. But if the cache is not separated, this is ignored
	bool write_allocated;           // 1 if write allocated otherwise 0
	bool back_or_through;          // 1 if write back otherwise 0
	bool virtual_indexed;           // 1 if virtual indexed otherwise 0
	bool virtual_tagged;            // 1 if virtual tagged otherwise 0
	int organize_policy;            // 0 if N way associative, 1 if pseudo associative, 2 if way predictive
	int associative_number;         // set the number of association if the cache is associative
	int replace_policy;             // 0 if RANDOM, 1 if LRU, 2 if FIFO
	int entry_number;        // the number of instruction cache line and the daa cache line;
	int entry_size;           // size of per cache line of instruction and data cache;	
	uint32 *cache_counter;
	uint32 *cache_lru;
	uint32* cache_data;         // pointer to the instructin cache and the data cache
	cache_union* cache_table;  // pointer to the cache table;
	cache_prof_t prof;
};
struct cache_one_level
{
	cache_config content;
	cache_one_level* next;
};
class CACHE
{
private:
	int level;
	uint8 **delaytime;
	uint8 memdelay;
	cache_one_level *cache;
	Memstat* memstat;
	Mapper  * mapper;
	CPU *cpu;
	ClkMem *clkmem;
	uint32 memsize;
	
	memcache_t memcache;
	uint32 last_memcache;

	bool fastmem;
	
	void config_from_file(char* path_name);
	void initialize();
	bool inmem(uint32 addr);
	void reset();
	int log2(int N);
	uint32 raddr_parse(uint32 tag, uint32 index, int32 mode, int lev);
	inline bool n_ass_probe(uint32 addr, int32 mode, int lev, uint32 ** pdata, cache_union** ptable);
	bool pseudo_ass_probe(uint32 addr, int32 mode, int lev, uint32 ** pdata, cache_union ** ptable);
	bool way_predict_probe(uint32 addr, int32 mode, int lev, uint32 ** pdata, cache_union ** ptable);
	bool probe_one_level(uint32 addr, int32 mode, int lev, uint32 ** pdata, cache_union ** ptable);
	inline bool probe(uint32 addr, int32 mode, uint32 **pdata, cache_union ** ptable, int *hit_lev);
	int my_random(int upper_bound);
	void random_replace(uint32 addr, int mode, int lev, uint32* data, uint8 *delay_time);
	void lilo_replace(uint32 addr, int mode, int lev, uint32* data, uint8 *delay_time);
	int lru_search(uint32 *lru,  int N);
//void lru_set(uint32 addr, uint32 mode, int lev,int number);
	void lru_replace(uint32 addr, int mode, int lev, uint32* data, uint8 *delay_time);
	void pseudo_replace(uint32 addr, int mode, int lev, uint32* data, uint8 *delay_time);
	void way_predict_replace(uint32 addr, int mode, int lev, uint32* data, uint8 *delay_time);
	void replace_one_level(uint32 addr, int mode, int lev, uint32* data, uint8 *delay_time);
	void upperdownfill(uint32 addr, int mode, int cur_lev, uint8 *delay_time);         //down fill the cache entry from level 0 to current level, not include current level
	void downfill_one_level(uint32 addr, int mode, int cur_lev, uint8 *delay_time);      // down fill the cache entry of current level
	void upfill(uint32 addr, int mode, int cur_lev, uint8 *delay_time);  // upfill the cache entry from current level to level 0
	
	uint32  adjust(uint32 addr);
	void cache_to_memcache(uint32 addr, int mode, uint8 * delay_time);
	void memcache_to_cache(uint32 addr, int mode, uint8 * delay_time);
	uint32  mem_to_memcache(uint32 addr,int mode,  uint8 *delay_time);
	void memcache_to_mem(uint32 addr, uint8* delay_time);
	bool probe_memcache(uint32 addr, uint8* delay_time, uint32 *index);
	void inv_memcache(uint32 addr, uint8 * delay_time, bool flushable);
	void flush_memcache(uint32 addr);
public:
	CACHE();
	CACHE(char * configdir);
	void fast_mem_start();
	void fast_mem_end();
	void attach(CPU* p = NULL,  Mapper* m = NULL, Memstat *ms = NULL,ClkMem* c = NULL);
	void read(uint32 addr, int32 mode, uint32 *data, uint8 *delay_time);
	void write(uint32 addr, int32 mode, uint32 data, uint8 *delay_time);
	void flush(uint32 start_addr, uint32 len);
	void flush(int mode);
	void invalidate(uint32 start_addr, uint32 len, bool flushable);
	void invalidate();
	virtual ~CACHE();
};
#endif /*_CACHE_H_*/
	
	
	
	
