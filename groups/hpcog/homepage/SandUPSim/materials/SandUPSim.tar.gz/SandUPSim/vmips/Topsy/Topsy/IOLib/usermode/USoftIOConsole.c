/*the following functions are implemented through virtual server*/
#include "UIOflag.h"
#include "UVirtServ.h"
#include "SoftIOConsole.c"

