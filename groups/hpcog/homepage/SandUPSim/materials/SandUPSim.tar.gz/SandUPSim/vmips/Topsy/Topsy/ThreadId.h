#define MMTHREADID  -1     /* Memory Manager Thread Id. */
#define TMTHREADID  -2     /* Thread Manager Thread Id. */
#define IOTHREADID  -3     /* Input/Output Manager Thread Id. */

