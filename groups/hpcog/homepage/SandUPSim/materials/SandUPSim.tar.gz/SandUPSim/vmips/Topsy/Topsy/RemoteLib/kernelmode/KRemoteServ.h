#ifndef KREMOTESERV_H
#define KREMOTESERV_H

#define RemoteServerSpaceBase	0xb3000000

#include "RemoteServ.h"

#endif

