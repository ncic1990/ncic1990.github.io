#ifndef KVIRTSERV_H
#define KVIRTSERV_H

#define VirtualServerSpaceBase 0xb2000800
#define VirtualServerSpace 2048
#define VirtualServerBase 0xb2000fff
#define VirtualServerNum 16
#define VirtualServerBufBase 0xb2000800
#define VirtualServerBufNum 254
#define VirtualServerRegBase 0xb2000fec
#define FirstRegInBuf 507

#include "VirtServ.h"

#endif

