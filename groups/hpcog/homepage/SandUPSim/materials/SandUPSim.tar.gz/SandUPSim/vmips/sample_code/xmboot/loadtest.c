#include "lib.h"

void entry(void)
{
	printf("Hello, world!\n");
}

