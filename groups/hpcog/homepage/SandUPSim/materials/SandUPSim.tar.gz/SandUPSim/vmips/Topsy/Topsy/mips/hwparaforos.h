#ifndef HWPARAFOROS_H
#define HWPARAFOROS_H

/*slfsmm031107_add>the memory layout of parameters for os*/
#include "cpu.h"
#include "MemoryLayout.h"

#define HWPARABASE 0x400000
#define PARASIZE    4
#define MEMSIZEIND  0 //the index of parameter memory size for os
#define TLBENTNUMIND 1 //the index of parameter tlb entry num for os
#define TLBENTRESEVENUMIND 2 //the index of parameter tlb entry num reserved for os
#define VIRTSERV 3//if true start virtserv, otherwise remoteserv
#define STDINNAME 4
#define STDOUTNAME 5
#define STDERRNAME 6
#define STDIOINHERIT 7
//other index of parameters

//the stdionames are all physical address, so should be converted before used!!
typedef struct stdio_struct{
	char* stdinname;
	char* stdoutname;
	char* stderrname;
	long stdioinherit;
}stdio_t;

struct hwparalayout_t{
	long memsize;
	long tlbentrynum;
	long tlbentrynumreserved;
	long virtservflag;
	stdio_t stdioinfo;
	//other parameters
};
/*slfsmm031107_add<*/

void gethwparaforos( );

#endif/*HWPARAFOROS_H*/

