/**
 * $Header: /work/cvs/cvsroot/vmips/tlb.h,v 1.10 2003/12/01 15:36:18 xjw Exp $
 */
/*This is the TLB module of sand simulator, which is developed by
ASL group of NCIC;
Copyright 2003 by ASL NCIC */

#ifndef _TLB_H
#define _TLB_H


#include "sysinclude.h"
#include "memstat.h"
#define LAZY_RANDOM
/*slfsmm031107_add>*/
class vmips;
/*slfsmm031107_add<*/

class CPZero;
class DeviceExc;

/* This define the tlb entry format*/

typedef union
{
	uint64  content;
	struct
	{
		uint8      z0   ;
		unsigned g    : 1 ;   //global
		unsigned v    : 1 ;   //dirty
		unsigned d    : 1 ;   //validate
		unsigned n    : 1 ;    //cacheable
		unsigned pfn  : 20;
		unsigned z1   : 6 ;
		unsigned asid : 6 ;
		unsigned vpn  : 20;   
	}entry;
	uint32 hilo[2];
}TLB_ENTRY;       

/*slfsmm031107_mod_mov>*/
//#define TLB_ENTRYS 64
/*slfsmm031107_mod_mov<*/
class TLB
{   
private:
	CPZero * cp0;
	Memstat * memstat;
	vmips* machine;
	int lastmatch;

	int* a;
	void adjust(uint8 index, uint32 vpn);
	int binsearch(uint32 vpn, uint32 asid);
	
public:
	
	
	/*slfsmm031107_mod_mov_add>*/
	uint32 TLB_ENTRYS;
	uint32 TLB_ENTRYSRESERVED;
	//TLB_ENTRY tlb_entry[TLB_ENTRYS];
	TLB_ENTRY* tlb_entry;
	/*slfsmm031107_mod_mov_add<*/
    bool tlb_user_miss;
	
	TLB();
	/*slfsmm031107_mod>*/
	//void attach(CPZero *p = NULL, Memstat * ms = NULL);
	void attach(vmips* m,CPZero *p = NULL, Memstat * ms = NULL);
	/*slfsmm031107_mod<*/
	void load_addr_trans_excp_info(uint32 va, uint32 vpn, TLB_ENTRY *match);
	void tlbr_emulate(uint32 instr, uint32 pc);
	void tlbwi_emulate(uint32 instr, uint32 pc);
	void tlbwr_emulate(uint32 instr, uint32 pc);
	void tlbp_emulate(uint32 instr, uint32 pc);
	TLB_ENTRY *find_matching_tlb_entry(uint32 vpn, uint32 asid);
	uint32 addr_translate(uint32 seg, uint32 vaddr, int mode,
		bool *cacheable, DeviceExc *client);
	bool debug_tlb_translate(uint32 vaddr, uint32 *paddr);
};
#endif /* _TLB_H */
