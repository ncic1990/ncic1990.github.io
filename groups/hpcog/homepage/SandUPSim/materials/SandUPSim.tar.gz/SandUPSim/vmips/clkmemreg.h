/*
#define BYTETYPE 0
#define HALFTYPE 1
#define WORDTYPE 2
#define LINETYPE 3
*/

#define MEMSIZE (256 * 1024 * 1024)
#define CLKFREQ   4
#define REFRESHGAP 1560
#define BANKNUM   4
#define BRIDGEDELAY  4
#define BURSTLEN 8

#define TRCD  2             // row to colom delay
#define TCAS 2              // time need between read command and data out
#define TRP  3                // time need between precharge and active
#define TRC     0              // time needed between active command between in same bank;
#define TRRD    0             // time need between active command between different bank
#define TRFC  14           // time needed by refresh
#define TWR   2             //time need between write and precharge
#define TDQSS 1           // time need beteen write command and data
#define TWTR 1             // time need by write to read
