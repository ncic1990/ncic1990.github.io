/*This is the Addr module of sand simulator, which is developed by
ASL group of NCIC;
Copyright 2003 by ASL NCIC */

#include "sysinclude.h"
#include "clkmem.h"
#include "range.h"
#include "addr.h"
#include "error.h"

ClkMem::ClkMem(bool opt_clkmem )
{
	started = opt_clkmem;	
	initialize();
}
void
ClkMem::startdram()
{
	started = true;
}
void
ClkMem::enddram()
{
	started = false;
}
int 
ClkMem::getfreq()
{
	return CLKFREQ;
}
int 
ClkMem::getbslen()
{
	return BURSTLEN;
}
uint32
ClkMem::getmemsize()
{
	return MEMSIZE;
}
void
ClkMem::initialize()
{
	for(int i = 0; i < BANKNUM; i ++)
	{		
		bank[i].stat = IDLE;
		bank[i].row = 0;
		bank[i].lefttime = 0;
	}
	clock = 0;
	rfcounter = 0;
	currentbank = 0;
	currentrow = 0;
	lasttime = 0;
}
bool
ClkMem::getdramstart()
{
	return started;
}
void
ClkMem::attach(Mapper * m )
{
	mapper = m;	
}
void 
ClkMem::getaddress()
{	
	Range* l;	
	l = mapper ->find_mapping_range(0x00000000);
	address = l ->address;
}
void 
ClkMem::getclock()
{
	static uint8  counter;
	if((++ counter ) % CLKFREQ == 0)
	{
		if( (++ clock) >= CLKMAX)
			clock = 0;	
		if(( ++ rfcounter) >= REFRESHGAP)
		{
			rfcounter = 0;
			refresh();
		}
		step();
		counter = 0;
	}
}
void 
ClkMem::step()
{
	for(int i = 0; i < BANKNUM; i ++)
		if(bank[i].lefttime > 0)
			if((-- bank[i].lefttime) == 0 && bank[i].stat == REFRESH)
				bank[i].stat = IDLE;
}
uint64 
ClkMem::difftime(uint64 ptime, uint64 ctime)
{
	if(ctime >= ptime)
		return (ctime - ptime);
	else	
		return (CLKMAX - (ptime - ctime));		
}
void 
ClkMem::refresh()
{
	static uint8 refdelay[BANKNUM];
	currentbank = 0;
	currentrow = 0;
	for (int i = 0; i < BANKNUM; i ++)
	{
		if(bank[i].lefttime == 0)
		{
			bank[i].stat = REFRESH;
			bank[i].lefttime = TRFC;
			refdelay[i] = 0;
			lasttime = clock;			
		}
		else		
			if(refdelay[i] >= 8)
			{
		/*There is wrong here, to be modified by xjw later*/
				bank[i].stat = REFRESH;
				bank[i].lefttime = TRFC;
				refdelay[i] = 0;
			}
			else
				refdelay[i] ++;		
	}
}
void
ClkMem::addrparse(uint32 addr,int *bank, int *row)
{
	int gap, col;
	gap = MEMSIZE / BANKNUM;
	col = gap / (8 * 1024);
	*bank = addr / gap;
	*row = (addr % gap ) / col;
}
/*this funciton return the time value before the command can be issued */
int
ClkMem::bankdelay(cmd_t cmd)
{
	int tmptime, delaytime;
	switch(bank[currentbank].stat)
	{		
		case WRITE:
			switch(cmd)
			{
				case READCMD:
					tmptime = (1 + BURSTLEN / 2) + TWTR;
					
					delaytime = tmptime - difftime( lasttime, clock);
					return delaytime > 0 ?:delaytime, 0;
				case WRITECMD:
					tmptime = BURSTLEN /2;

					delaytime = tmptime - difftime( lasttime, clock);
					return delaytime > 0 ?:delaytime, 0;
				/*
				case PRECHARGECMD:
					return 1;
				case ACTIVECMD:
					return 1;
				*/
				default:
					fatal_error("unknown command \n");
			}
		case READ:
			switch(cmd)
			{
				case READCMD:
					tmptime = BURSTLEN / 2;

					delaytime = tmptime - difftime( lasttime, clock);
					return delaytime > 0 ?:delaytime, 0;
				case WRITECMD:
					tmptime =  TCAS + BURSTLEN /2;

					delaytime = tmptime - difftime( lasttime, clock);
					return delaytime > 0 ?:delaytime, 0;
				/*
				case PRECHARGECMD:
					return 1;
				case ACTIVECMD:
					return 1;
				*/
				default :
					fatal_error("unknown command \n");
			}
		default :
			return 0;
	}
}
/*this function return the time value before the command can be issued in the same bank and same row*/
int 
ClkMem::srowdelay(cmd_t cmd)
{
	int tmptime, delaytime;
	switch(bank[currentbank].stat)
	{
		case READ:
			switch(cmd)
			{
				case READCMD:
					tmptime =  BURSTLEN / 2;

					delaytime = tmptime - difftime( lasttime, clock);
					return delaytime > 0 ?:delaytime, 0;
				case WRITECMD:
					tmptime = TCAS + BURSTLEN / 2;

					delaytime = tmptime - difftime( lasttime, clock);
					return delaytime > 0 ?:delaytime, 0;
				default:
					fatal_error("unknown command \n");
			}
		case WRITE:
			switch(cmd)
			{
				case READCMD:
					tmptime = TDQSS + BURSTLEN /2 + TWTR;

					delaytime = tmptime - difftime( lasttime, clock);
					return delaytime > 0 ?:delaytime, 0;	
				case WRITECMD:
					tmptime =  BURSTLEN / 2;

					delaytime = tmptime - difftime( lasttime, clock);
					return delaytime > 0 ?:delaytime, 0;	
				default:
					fatal_error("unknown command \n");
			}
		case IDLE:
			switch(cmd)
			{
				case WRITECMD:
				case READCMD:
					tmptime =  TRCD;

					delaytime = tmptime - difftime( lasttime, clock);
					return delaytime > 0 ?:delaytime, 0;	
				default:
					fatal_error("unknown command \n");				
			}		
		case REFRESH:
			switch(cmd)
			{
				case WRITECMD:
				case READCMD:
					tmptime =  TRFC;

					delaytime = tmptime - difftime( lasttime, clock);
					return delaytime > 0 ?:delaytime, 0;	
				default:
					fatal_error("unknown command \n");			
			}
		default:
			fatal_error("unknown command \n");			
	}	
}
/*this function return the time value before the command can be issued in the same bank and same row*/
int 
ClkMem::drowdelay(cmd_t cmd)
{
	int tmptime, delaytime;
	switch(bank[currentbank].stat)
	{
		case READ:
			switch(cmd)
			{
				case WRITECMD:
				case READCMD:
					tmptime =  TCAS + BURSTLEN/2 + TRP + TRCD;

					delaytime = tmptime - difftime( lasttime, clock);
					return delaytime > 0 ?:delaytime, 0;					
				default:
					fatal_error("unknown command \n");
			}
		case WRITE:
			switch(cmd)
			{
				case WRITECMD:
				case READCMD:
					tmptime = TDQSS + BURSTLEN /2 + TWR + TRCD;

					delaytime = tmptime - difftime( lasttime, clock);
					return delaytime > 0 ?:delaytime, 0;					
				default:
					fatal_error("unknown command \n");
			}
		case IDLE:
			switch(cmd)
			{
				case WRITECMD:
				case READCMD:
					tmptime =  TRCD;

					delaytime = tmptime - difftime( lasttime, clock);
					return delaytime > 0 ?:delaytime, 0;	
				default:
					fatal_error("unknown command \n");				
			}		
		case REFRESH:
			switch(cmd)
			{
				case WRITECMD:
				case READCMD:
					tmptime =  TRFC;

					delaytime = tmptime - difftime( lasttime, clock);
					return delaytime > 0 ?:delaytime, 0;	
				default:
					fatal_error("unknown command \n");			
			}
		default:
			fatal_error("unknown command \n");			
	}
}
int 
ClkMem::operationdelay(cmd_t cmd, bool bst)
{		
	switch(cmd)
	{
		case READCMD:
			if(bst)
				return TCAS + BURSTLEN /2 ;
			else
				return TCAS + 1 ;
		case WRITECMD:
			return 0;
		default:
			fatal_error("unknown command \n");			
	}
}
int 
ClkMem::totaldelay(uint32 addr, cmd_t cmd, bool bst)
{
	int tmpbank, tmprow;	
	int delaytime;
	addrparse(addr, &tmpbank, &tmprow);
	delaytime = 0;
	if(tmpbank != currentbank)		
	{	
		delaytime += bankdelay(cmd);
		currentbank = tmpbank;
	}	
	if(tmprow != bank[currentbank].row)
	{
		delaytime += drowdelay(cmd);
		bank[currentbank].row = tmprow;		
	}
	delaytime += srowdelay(cmd);
	delaytime += operationdelay(cmd, bst);	
	return delaytime;
}
void
ClkMem::fetchword(uint32 addr, uint32* data, uint8 *delay_time)
{
	bank[currentbank].stat = READ;
	bank[currentbank].lefttime += totaldelay(addr, READCMD, false);
	lasttime = clock;
	*delay_time = bank[currentbank].lefttime + BRIDGEDELAY;
	*data = *(uint32*)(address + addr);
}
void
ClkMem::fetchhword(uint32 addr, uint16* data, uint8 *delay_time)
{
	bank[currentbank].stat = READ;
	bank[currentbank].lefttime += totaldelay(addr, READCMD, false);
	lasttime = clock;
	*delay_time = bank[currentbank].lefttime + BRIDGEDELAY;
	*data = *(uint16*)(address + addr);
}
void
ClkMem::fetchbyte(uint32 addr, uint8* data, uint8 *delay_time)
{
	bank[currentbank].stat = READ;
	bank[currentbank].lefttime += totaldelay(addr, READCMD, false);
	lasttime = clock;
	*delay_time = bank[currentbank].lefttime + BRIDGEDELAY;
	*data = *(uint8*)(address + addr);
}
void
ClkMem::storeword(uint32 addr, uint32 data, uint8* delay_time)
{
	bank[currentbank].stat = WRITE;
	bank[currentbank].lefttime += totaldelay(addr, READCMD, false);
	lasttime = clock;
	*delay_time = bank[currentbank].lefttime + BRIDGEDELAY;
	*(uint32*)(address + addr) = data;
}
void
ClkMem::storehword(uint32 addr, uint16 data, uint8 *delay_time)
{
	bank[currentbank].stat = WRITE;
	bank[currentbank].lefttime += totaldelay(addr, READCMD, false);
	lasttime = clock;
	*delay_time = bank[currentbank].lefttime + BRIDGEDELAY;
	*(uint16*)(address + addr) = data;
}
void
ClkMem::storebyte(uint32 addr, uint8 data, uint8* delay_time)
{
	bank[currentbank].stat = WRITE;
	bank[currentbank].lefttime += totaldelay(addr, READCMD, false);
	lasttime = clock;
	*delay_time = bank[currentbank].lefttime + BRIDGEDELAY;
	*(uint8*)(address + addr) = data;
}
void 
ClkMem::readdram(uint32 addr, uint64 *data,  uint8 *delay_time)
{
	bank[currentbank].stat = READ;
	bank[currentbank].lefttime += totaldelay(addr, READCMD, true);
	lasttime = clock;
	*delay_time = bank[currentbank].lefttime + BRIDGEDELAY;
	for (int i = 0; i < BURSTLEN; i ++)
		*(data + i) = *(uint64*)(address + addr + i * 8);
}
void 
ClkMem::writedram(uint32 addr, uint64 *data, uint8 * delay_time)
{
	bank[currentbank].stat = WRITE;
	bank[currentbank].lefttime += totaldelay(addr, READCMD, true);
	lasttime = clock;
	*delay_time = bank[currentbank].lefttime + BRIDGEDELAY;
	for (int i = 0; i < BURSTLEN; i ++)
		*(uint64*)(address + addr + i * 8) = *(data + i);
}


