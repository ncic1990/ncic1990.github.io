/*
  * Added by zwl on Oct 14th, 2003, clkopcodeJumpTable emulation on clock level  
  *--------------------------------------------------------------------
  *
  */

#ifndef _CLKCPU_H_
#define _CLKCPU_H_

#include "sysinclude.h"
#include "cpzero.h"
#include "debug.h"
#include "cpu.h"
#include "clkcpone.h"
//#include "pplstate.h"

class CPOne;
class PPLSTAT;
//	static int aaa;

class CLKCPU : public CPU {
	friend class CPZero;
	friend class PPLSTAT;
	friend class CLKCPONE;
	
private:
	//uint32 pc;
	//uint32 reg[32]; /* general purpose registers */
	int regflag[32];/*identify the state of reg[32]: readable, to be written*/
	int instr_count, cycle_count, stall_count;
	bool pl_state;// true: normal, false: stall 
	bool flaga, flagb;
       uint8 delay_time, if_delay_time;
       int nraw;// the count of raw dependence
       uint16 c_excCode;
       int c_mode;
       int c_coprocno;
       bool exception_if, exception_ex, exception_mem;
       int if_state, ex_state, mem_state;
       uint32 if_epc, ex_epc, mem_epc;
       PPLSTAT *pplstat; //pipeline trace
       bool tlb_state; // to save tlb state when exception occurs
       CLKCPONE *clkcpone; //handle clock level floating point pipeline
       bool sucDocode; // clear up the possible effect brought by fp pipeline for int pipeline
       int ncount; //for compare debug 
       
	//uint32 instr;
	//uint32 hi;
	//uint32 lo;

	
	//vmips *machine;
	//CPU *cpu;
	//CPZero *cpzero;
	//Addr* addr;
	//int delay_state;
	//uint32 delay_pc;
	//uint32 next_epc;
	
//    void cop_unimpl (int coprocno, struct sID_EX id_ex, uint32 pc);	
	uint32 calc_jump_target(uint32 pc);
	/*void branch(uint32 instr, uint32 pc);
	void mult64(uint32 *hi, uint32 *lo, uint32 n, uint32 m);
	void mult64s(uint32 *hi, uint32 *lo, int32 n, int32 m);
	void cop_unimpl (int coprocno, uint32 instr, uint32 pc);*/
	
public:
	bool _if_skip, _id_skip, _ex_skip,  _if_stock, _id_stock, _mem_stock;
	uint32 switch_pc;

	struct sIF_ID{         
		uint32 pc;
		uint32 instr;
		bool stall;
		bool tag;
	}if_id;	
	
	struct sID_EX{
	uint32 pc;
	uint32 instr;
	uint16 op;
	uint16 rs;
	uint16 rt;
	uint16 rd;
	uint32 a;
	uint32 b;
	uint16 shamt;
	uint16 funct;
	uint16 fmt;
	uint32 targ;
	int16 s_imm;//to be affirm
	uint16 imm;
	bool stall;
	bool tag;
	}id_ex;

	struct sEX_MEM{
		uint32 pc;
		uint16 op;
		uint32 b;
		uint16 rs;
		uint16 rt;
		uint16 rd;
		uint16 funct;
		uint16 fmt;
	       int32 ALUoutput;
		bool stall;
		 bool tag;
	}ex_mem;

	struct sMEM_WB{
		uint32 pc;
	       uint32 b;
	       uint16 op;
		uint16 rs;
		uint16 rt;
		uint16 rd;
		uint16 funct;
	       int32 ALUoutput;
		uint32 lmd;//satisfy all data types?
		uint16 fmt;
		bool stall;
	       bool tag;
	}mem_wb;//[[[[

private:
	void funct_clkemulate(uint32 pc);//in fact pc is verbosehere, only to reduce change
	void regimm_clkemulate(uint32 pc);
	void j_clkemulate(uint32 pc);
	void jal_clkemulate(uint32 pc);
	void beq_clkemulate(uint32 pc);
	void bne_clkemulate(uint32 pc);
	void blez_clkemulate(uint32 pc);
	void bgtz_clkemulate(uint32 pc);
	void addi_clkemulate(uint32 pc);
	void addiu_clkemulate(uint32 pc);
	void slti_clkemulate(uint32 pc);
	void sltiu_clkemulate(uint32 pc);
	void andi_clkemulate(uint32 pc);
	void ori_clkemulate( uint32 pc);
	void xori_clkemulate(uint32 pc);
	void lui_clkemulate(uint32 pc);
	void cpzero_clkemulate(uint32 pc);
	void cpone_clkemulate(uint32 pc);
	void cptwo_clkemulate(uint32 pc);
	void cpthree_clkemulate(uint32 pc);
	void lb_clkemulate(uint32 pc);
	void lh_clkemulate(uint32 pc);
	void lwl_clkemulate(uint32 pc);
	void lw_clkemulate(uint32 pc);
	void lbu_clkemulate(uint32 pc);
	void lhu_clkemulate(uint32 pc);
	void lwr_clkemulate(uint32 pc);
	void sb_clkemulate(uint32 pc);
	void sh_clkemulate(uint32 pc);
	void swl_clkemulate(uint32 pc);
	void sw_clkemulate(uint32 pc);
	void swr_clkemulate(uint32 pc);
	void ll_clkemulate(uint32 pc);	//add for atomic operation
	void lwc1_clkemulate(uint32 pc);
	void lwc2_clkemulate(uint32 pc);
	void lwc3_clkemulate(uint32 pc);
	void sc_clkemulate(uint32 pc);	//add for atomic operation
	void swc1_clkemulate(uint32 pc);
	void swc2_clkemulate(uint32 pc);
	void swc3_clkemulate(uint32 pc);

	void sll_clkemulate(uint32 pc);
	void srl_clkemulate(uint32 pc);
	void sra_clkemulate(uint32 pc);
	void sllv_clkemulate(uint32 pc);
	void srlv_clkemulate(uint32 pc);
	void srav_clkemulate(uint32 pc);
	void jr_clkemulate(uint32 pc);
	void jalr_clkemulate(uint32 pc);
	void syscall_clkemulate(uint32 pc);
	void break_clkemulate(uint32 pc);
	void mfhi_clkemulate(uint32 pc);
	void mthi_clkemulate(uint32 pc);
	void mflo_clkemulate(uint32 pc);
	void mtlo_clkemulate(uint32 pc);
	void mult_clkemulate(uint32 pc);
	void multu_clkemulate(uint32 pc);
	void div_clkemulate(uint32 pc);
	void divu_clkemulate(uint32 pc);
	void add_clkemulate(uint32 pc);
	void addu_clkemulate(uint32 pc);
	void sub_clkemulate(uint32 pc);
	void subu_clkemulate(uint32 pc);
	void and_clkemulate(uint32 pc);
	void or_clkemulate(uint32 pc);
	void xor_clkemulate(uint32 pc);
	void nor_clkemulate(uint32 pc);
	void slt_clkemulate(uint32 pc);
	void sltu_clkemulate(uint32 pc);
	void bltz_clkemulate(uint32 pc);
	void bgez_clkemulate(uint32 pc);
	void bltzal_clkemulate(uint32 pc);
	void bgezal_clkemulate(uint32 pc);
	void RI_clkemulate(uint32 pc);

	void cache_clkemulate(uint32 pc);

//	void flush_clkemulate(uint32 instr, uint32 pc);
//	void branch(uint32 pc);//in fact pc is verbose here, only to reduce change

	/*end - Added by zwl on Oct 14th, 2003, clkopcodeJumpTable emulation on clock level  [[[[*/

public:

/*	uint16 opcode(const uint32 instr) const;
	uint16 rs(const uint32 instr) const;
	uint16 rt(const uint32 instr) const;
	uint16 rd(const uint32 instr) const;
	uint16 immed(const uint32 instr) const;
	uint16 shamt(const uint32 instr) const;
	uint16 funct(const uint32 instr) const;
	uint32 jumptarg(const uint32 instr) const;
	int16 s_immed(const uint32 instr) const;
*/
	CLKCPU();//vmips *mch = NULL, Mapper *m = NULL, CPZero *cp0 = NULL
	virtual ~CLKCPU() throw();
	void clkattach(CPOne * cp1, PPLSTAT *ps);
	uint32 debug_get_pc(void); // overide cpu debug_get_pc
	void debug_set_pc(uint32 newpc); // overide cpu debug_get_pc
	void exception(uint16 excCode, int mode = ANY, int coprocno = -1);
	void clkexcphandle(uint16 excCode, int mode = ANY, int coprocno = -1);
	void branch(uint32 pc);
	void clockstep(); 
	
	void ifetch();
	void idecode()	;
	void execute();
	void memaccess();
	void writeback();

};

#endif /* _CLKCPU_H_ */
