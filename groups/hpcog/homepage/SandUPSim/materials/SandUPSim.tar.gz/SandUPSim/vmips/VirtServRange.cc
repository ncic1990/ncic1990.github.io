#include "sysinclude.h"
#include "accesstypes.h"
#include "regnames.h"
#include "excnames.h"

#include "cpu.h"
#include "cpzero.h"
#include "addr.h"
#include "cache.h"
#include "tlb.h"
#include "mapper.h"
#include "range.h"
#include "cpzeroreg.h"

#include "VirtServRange.h"
#include "VirtServUnistd.h"
#include "VirtServType.h"

#define READPARAMETER 0
#define WRITEPARAMETER 1

//#define WALKPATH
//#define PRINTLOCALSERVMSG
//#define PRINTSYSCALLMSG
//#define DEBUGTopsyAssistantServer
//#define DBGREDIRECT
//#define DBGCWD

/* Initialization: create a dummy Range object. */
VirtServRange::VirtServRange(bool inheritflag, const char* tstdin, const char* tstdout, const char* tstderr) throw()
    : Range(VirtualServerSpaceBase, VirtualServerSpace, NULL, DEVICE, MEM_READ_WRITE)
{
	fprintf(stderr,"Mapping VirtServRange to phys address:0x%x    size:0x%x\n",VirtualServerSpaceBase,VirtualServerSpace);
	InitTopsyEnv(inheritflag,tstdin,tstdout,tstderr);
}

VirtServRange::~VirtServRange() throw()
{
	DestroyTopsyEnv();
}

void
VirtServRange::store_byte(uint32 offset, uint8 data, DeviceExc *client)
{
	#ifdef WALKPATH
		fprintf(stderr,"VirtServMsg:store_byte entry->offset: %d,data: %d\n",offset,data);
	#endif
	
	if(offset>=VirtualServerSpace-VirtualServerNum){
		
		#ifdef WALKPATH
			fprintf(stderr,"VirtServMsg:store_byte case...\n");
		#endif

		InstallTopsyEnv();
		switch(offset){
			case LocalVirtualServerOff:
				StartLocalVirtualServer(data,client);
				break;

			case OutputServerOff:
				StartOutputServer(data,client);
				break;

			case LinuxSyscallServerOff:
				StartLinuxSyscallServer(data,client);
				break;

			case TopsyAssistantServerOff:
				StartTopsyAssistantServer(data,client);
				break;
				
			default:
				fprintf(stderr,"VirtServError:In virtual server range by not implemented yet!\n");
				break;
		}
		UnInstallTopsyEnv();
	}
	else{
		#ifdef WALKPATH
			fprintf(stderr,"VirtServMsg:store_byte do store...\n");
		#endif
		((uint8*)VirtServBuffers)[offset]=data;
	}
}

uint8
VirtServRange::fetch_byte(uint32 offset, DeviceExc *client)
{
	if(offset<VirtualServerSpace-VirtualServerNum)
		return ((uint8 *)VirtServBuffers)[offset];
	else{
		fprintf(stderr,"VirtServError:fetch_byte Error:Not in the buffer range!\n");
		return 0;
		}
}

void
VirtServRange::store_halfword(uint32 offset, uint16 data, DeviceExc *client)
{
	if(offset<VirtualServerSpace-VirtualServerNum)
		((uint16 *)VirtServBuffers)[offset/2]=data;
	else{
		fprintf(stderr,"VirtServError:store_halfwork Error:Not in the buffer range!\n");
		}
}

uint16
VirtServRange::fetch_halfword(uint32 offset, DeviceExc *client)
{
	if(offset<VirtualServerSpace-VirtualServerNum)
		return ((uint16 *)VirtServBuffers)[offset/2];
	else{
		fprintf(stderr,"VirtServError:fetch_halfwork Error:Not in the buffer range!\n");
		return 0;
		}
}

void
VirtServRange::store_word(uint32 offset, uint32 data, DeviceExc *client)
{
	#ifdef WALKPATH
		fprintf(stderr,"VirtServMsg:store_word entry->offset: %d,data: %d\n",offset,data);
	#endif
	
	if(offset<VirtualServerSpace-VirtualServerNum)
		((uint32 *)VirtServBuffers)[offset/4]=data;
	else{
		fprintf(stderr,"VirtServError:store_word Error:Not in the buffer range!\n");
		}
}

uint32
VirtServRange::fetch_word(uint32 offset, int mode, DeviceExc *client)
{
	#ifdef WALKPATH
		fprintf(stderr,"VirtServMsg:fetch_word->offset: %d,data: %d\n",offset,((uint32 *)VirtServBuffers)[offset/4]);
	#endif
	
	if(offset<VirtualServerSpace-VirtualServerNum)
		return ((uint32 *)VirtServBuffers)[offset/4];
	else{
		fprintf(stderr,"VirtServError:fetch_word Error:Not in the buffer range!\n");
		return 0;
		}
}

uint32 
VirtServRange::GetReg(uint8 regno)
{
	#ifdef WALKPATH
		fprintf(stderr,"VirtServMsg:GetReg->offset: %d,data: %d\n",(FirstRegInBuf-regno)*4,((uint32*)VirtServBuffers)[FirstRegInBuf-regno]);
	#endif
	return ((uint32*)VirtServBuffers)[FirstRegInBuf-regno];
}

void
VirtServRange::SetReg(uint8 regno,uint32 data)
{
	#ifdef WALKPATH
		fprintf(stderr,"VirtServMsg:SetReg->offset: %d,data: %d\n",(FirstRegInBuf-regno)*4,data);
	#endif
	((uint32*)VirtServBuffers)[FirstRegInBuf-regno]=data;
}

/*slfsmm_maymod>when tlb exception occurs,how to do??????*/
char *
VirtServRange::Range_address_trans(uint32 vaddr,uint32 phys, int mode, DeviceExc *client)
{
	uint32 offset;
	CPU* cpu=(CPU*)client;
	Mapper* map=cpu->GetMapper();
	Range* l;

	l=map->find_mapping_range(phys);
	if (!l) {
		fprintf(stderr,"VirtServError:Range_address_trans:can not find corresponding range!\n");
		if(mode==READPARAMETER)
			client->exception(DBE,DATALOAD);
		else
			client->exception(DBE,DATASTORE);
		return 0;
	}
	offset = phys - l->getBase();
	if ((mode==WRITEPARAMETER)&&(!(l && l->canWrite(offset)))) {
		/* Writes to nonexistent or read-only ranges return ones */
		fprintf(stderr, "Writing bad memory: 0x%08x\n", vaddr);
		return 0;
	}

	return l->getAddress( )+offset;
	
}
uint32 
VirtServRange::cp0_address_trans(uint32 vaddr, int mode, bool *cacheable,DeviceExc *client)
{	
	uint32 phys,vpn;
	CPU* cpu=(CPU*)client;
	CPZero* cp0=cpu->GetCP0();

	if (cp0->kernel_mode()) {
		switch(vaddr & KSEG_SELECT_MASK) {
			case KSEG0:
				*cacheable = true;
				return vaddr - KSEG0_CONST_TRANSLATION;
				break;
			case KSEG1:
				*cacheable = false;
				return vaddr - KSEG1_CONST_TRANSLATION;
				break;
			case KSEG2:
			case KSEG2_top:
				fprintf(stderr,"VirtServError:cp0_address_trans:Invalid segment in Topsy!\n");
				return 0;
				break;
			default: /* KUSEG : go down*/
				break;
		}
	} else /* user mode */ {
		if (vaddr & KERNEL_SPACE_MASK) {
			/* Can't go there. */
			fprintf(stderr,"VirtServError:cp0_address_trans:use kernel segment in user mode!\n");
			return 0;
		} 
	}
	
	/*KUSEG*/
	/*read page table*/
	phys=cp0->reg[Context];
	//fprintf(stderr,"context:%x, vaddr:%x\n",phys,vaddr);
	phys&=Context_PTEBase_MASK;
	vpn=vaddr & EntryLo_PFN_MASK;
	phys|=vpn>>10;
	phys-=0xa0000000;
	//fprintf(stderr,"page table item vaddr:%x\n",phys);
	phys=*(uint32*)Range_address_trans(vaddr,phys,READPARAMETER,client);
	/*analyse the page table item*/
	if(!(phys&EntryLo_G_MASK))
		fprintf(stderr,"VirtServError:cp0_address_trans: Topsy page table error!\n");
	if(!(phys&EntryLo_V_MASK))
		fprintf(stderr,"VirtServError:cp0_address_trans: maybe expanding the stack!\n");
	if((mode==WRITEPARAMETER)&&(!(phys&EntryLo_D_MASK)))
		fprintf(stderr,"VirtServError:cp0_address_trans: write protection!\n");
	if(phys&EntryLo_N_MASK)
		*cacheable=false;
	else
		*cacheable=true;
	return (phys&EntryLo_PFN_MASK)+(vaddr&(~EntryLo_PFN_MASK));
		
}
char *
VirtServRange::AddressTranslation(uint32 vaddr,DeviceExc *client,int mode,uint32* phyaddr,bool *cacheable)
{
	uint32 phys;
	
	phys = cp0_address_trans(vaddr, mode, cacheable, client);
	if(phyaddr!=NULL)
		*(phyaddr)=phys;
	return (char*)Range_address_trans(vaddr,phys,mode,client);
}
/*slfsmm_maymod<*/

void 
VirtServRange::physaddr_fetch_byte(uint32 phys, uint8* data, bool cacheable, DeviceExc *client)
{
	CPU* cpu=(CPU*)client;
	Addr* addr=cpu->GetAddr();
	CACHE* cache=addr->cache;
	Mapper* map=cpu->GetMapper();
	uint8 delay_time;  // added by xjw 2003.11.14

	/* Fetch byte. */
	if(cacheable && cpu ->Get_opt_cacheable())
	{
		uint32 readdata;
		uint8 *byte;
		cache ->read(phys, DATALOAD, &readdata, &delay_time); // modified by xjw 2003.11.14
		byte = (uint8*)(&readdata);
	    *data = *( byte + phys % 4);
		return;
	}
	*data = map->fetch_byte(phys, cacheable, cpu);
}
void
VirtServRange::physaddr_store_byte(uint32 phys, uint8 data, bool cacheable, DeviceExc *client)
{
	CPU* cpu=(CPU*)client;
	Addr* addr=cpu->GetAddr();
	CACHE* cache=addr->cache;
	Mapper* map=cpu->GetMapper();
	uint8 delay_time;  // added by xjw 2003.11.14
	/* Store byte. */
	if(cacheable && cpu ->Get_opt_cacheable())
	{
		uint32 read_data;
		uint8 *byte;
		cache ->read(phys, DATALOAD, &read_data, &delay_time);  // modified by xjw 2003.11.14
		byte = (uint8*)(&read_data);
	    *( byte + phys % 4) =data ;
	    cache ->write( phys, DATASTORE, read_data, &delay_time);  // modified by xjw 2003.11.14
		return;
	}
	map->store_byte(phys, data, cacheable, cpu);
}
//when sync cache to memory, the address should be physical
//when sync memory to cache, the address should be local vitual
long 
VirtServRange::SyncBufLength(uint32 physaddr,caddr_t localvirtaddr,long mode, bool cacheable, DeviceExc *client)
{
	long count=0;
	uint8 onebyte;

	if(mode==SYNCMEMTOCACHE)
		return strlen((char*)localvirtaddr)+1;	//note:the num 1 must be added
	do{
		physaddr_fetch_byte(physaddr,&onebyte,cacheable,client);
		physaddr++;
		count++;
	}
	while(onebyte!='\0');
	return count;
}
void 
VirtServRange::SyncMemAndCache(uint32 virtaddr,uint32 physaddr,char* localvirtaddr,long len,long mode,bool cacheable,DeviceExc *client)
{
	CPU* cpu=(CPU*)client;
	Addr* addr=cpu->GetAddr();
	CACHE* cache=addr->cache;
	long buflength;

	if(!cacheable||!cpu->Get_opt_cacheable()|| len ==0) return;
	
	if(len!=DEFAULTLEN)
		buflength=len;
	else
		buflength=SyncBufLength((uint32)physaddr,localvirtaddr,mode,cacheable,client);
	if(buflength<=0){
		fprintf(stderr,"VirtServError:SyncMemAndCache:buffer length is less than zero!\n");
		return;
	}
	
	/*slfsmm_maymod>may be modified*/
	if(mode==SYNCMEMTOCACHE)
		//flush and invalidate
		cache->invalidate((uint32)physaddr,buflength,0);
	else
		cache->flush((uint32)physaddr,buflength);
	/*slfsmm_maymod<*/

}

/*functions for Topsy env*/
void 
VirtServRange::InitTopsyEnv(bool inheritflag, const char* tstdin, const char* tstdout, const char* tstderr)
{
	InitRedirectStruct(inheritflag,tstdin,tstdout,tstderr);
	InitCWD();
	Inituserinfo(&UserInfo);
}

void 
VirtServRange::DestroyTopsyEnv( )
{
	destroyRedirectStruct();
	DestroyCWD();
}

void 
VirtServRange::InstallTopsyEnv( )
{
	fflush(stdout);
	fflush(stderr);
	RedirectStdIO();
	ChangeCWD();
}

void 
VirtServRange::UnInstallTopsyEnv( )
{
	fflush(stdout);
	fflush(stderr);
	DeRedirectStdIO();
	RecoverCWD();
}

//functions for redirection
void 
VirtServRange::getinputstdio(const char* tstdio, const char* ttyname, const char* str, long which)
{
	long fd;
	
	#ifdef DBGREDIRECT
	fprintf(stderr,"VirtServ msg: InitRedirectStruct: %s\n",str);
	#endif
	if(!strcmp(tstdio,DEFAULTSTDIO)) goto stdiodefault; //default stdio
	if(which==0)
		fd=open(tstdio,0,0);
	else
		fd=open(tstdio,O_WRONLY|O_CREAT|O_TRUNC, 0666);
	if(fd>=0) goto stdiook;
	fprintf(stderr,"VirtServ warning:InitRedirectStruct:Can not open %s->\"%s\"\n",str,tstdio);
	fprintf(stderr,"VirtServ msg:InitRedirectStruct:now open %s by ttyname->\"%s\"\n",str,ttyname);
	stdiodefault:
	fd=getdefaultstdio(ttyname,str,which,0);
	
	stdiook:
	#ifdef DBGREDIRECT
	fprintf(stderr,"VirtServ msg: initRedirectStruct: redirect %s to %d!\n",str,fd);
	#endif
	redirectfds.globalfds[which]=fd;
	redirectfds.currfds[which]=fd;
}
long 
VirtServRange::getdefaultstdio(const char* ttyname, const char* str, long which, long appflag)
{
	long fd;
	
	if(appflag){
	#ifdef DBGREDIRECT
	fprintf(stderr,"VirtServ msg: InitRedirectStruct: %s\n",str);
	#endif
	}
	if(ttyname==NULL) goto stdiovmips;
	if(which==0)
		fd=open(ttyname,0,0);
	else
		fd=open(ttyname,O_WRONLY | O_CREAT | O_TRUNC,0666);
	if(fd>=0) goto stdiook;
	fprintf(stderr,"VirtServ warning: InitRedirectStruct:can not open %s by name. if there is err,please check it !!!\n",str);
	fprintf(stderr,"VirtServ msg:InitRedirectStruct:now duplicate %s from vmips!\n",str);
	stdiovmips:
	fprintf(stderr,"VirtServ msg: InitRedirectStruct: copy vmips %s fd to globalfds.\n",str);
	fd=dup(which);
	if(fd<0){
		fprintf(stderr,"VirtServ err: some trouble while initializing redirect struct!: %s\n",str);
		fprintf(stderr,"please check it!!!\n");
		return NOTDIRECT;
	}
	stdiook:
	if(appflag){
		#ifdef DBGREDIRECT
		fprintf(stderr,"VirtServ msg: initRedirectStruct: redirect %s to %d!\n",str,fd);
		#endif
		redirectfds.appfds[which]=fd;
	}else{
		return fd;
	}
	return fd;
}
void 
VirtServRange::InitRedirectStruct(bool inheritflag, const char* tstdin, const char* tstdout, const char* tstderr)
{
	long count;
	char* ttyname;
	
	tstdio_inheritflag=inheritflag;
	ttyname=getenv("TTYNAME");
	
	#ifdef DBGREDIRECT
	fprintf(stderr,"VirtServ msg: init redirect struct begins...\n");
	fprintf(stderr,"inheritflag->%d\n",tstdio_inheritflag);
	fprintf(stderr,"input tstdin name->\"%s\"\n",tstdin);
	fprintf(stderr,"input tstdout name->\"%s\"\n",tstdout);
	fprintf(stderr,"input tstderr name->\"%s\"\n",tstderr);
	if(ttyname==NULL) fprintf(stderr,"ttyname is NULL!\n");
	else fprintf(stderr,"ttyname->\"%s\"\n",ttyname);
	#endif

	for(count=0;count<STDIONUM;count++){
		redirectfds.globalfds[count]=NOTDIRECT;
		redirectfds.appfds[count]=NOTDIRECT;
		redirectfds.currfds[count]=NOTDIRECT;
		redirectfds.localfds[count]=NOTDIRECT;
	}

	//tstdio
	getinputstdio(tstdin, ttyname, "tstdin", 0); //tstdin
	getinputstdio(tstdout, ttyname, "tstdout", 1); //tstdout
	getinputstdio(tstderr, ttyname, "tstderr", 2); //tstderr

	if(tstdio_inheritflag) goto redirectout;
	//appstdio
	getdefaultstdio(ttyname, "apptstdin", 0, 1); //appstdin
	getdefaultstdio(ttyname, "apptstdout", 1, 1); //appstdout
	getdefaultstdio(ttyname, "apptstderr", 2, 1); //appstderr

	redirectout:
	count=0;
	#ifdef DBGREDIRECT
	fprintf(stderr,"VirtServ msg: init redirect struct ends.\n");
	#endif
}

void 
VirtServRange::destroyRedirectStruct( )
{
	int count;
	int stdionum=STDIONUM;
	for(count=0;count<STDIONUM;count++){
		if(redirectfds.globalfds[count]>=STDIONUM)
			close(redirectfds.globalfds[count]);
		else
			fprintf(stderr,"VirtServ msg:destroyRedirectStruct:warning:globalfds %d is less than %d!\n",count,stdionum);
		if(!tstdio_inheritflag){
			if(redirectfds.appfds[count]>=STDIONUM)
				close(redirectfds.appfds[count]);
			else
				fprintf(stderr,"VirtServ msg:destroyRedirectStruct:warning:appfds %d is less than %d!\n",count,stdionum);

		}
	}
}

void 
VirtServRange::RedirectStdIO( )
{
	int count;
	long fd;

	#ifdef DBGREDIRECT
	fprintf(stderr,"VirtServ msg:RedirectStdIO...\n");
	#endif
	
	for(count=0;count<STDIONUM;count++)
		if(redirectfds.currfds[count]==NOTDIRECT)
			fprintf(stderr,"VirtServ err:RedirectStdIO :detect NOTREDIRECT item in currfds:%d!\n",
				count);

	for(count=0;count<STDIONUM;count++){
		fd=dup(count);
		if(fd<0){
			fprintf(stderr,"VirtServ err: RedirectStdIO: some trouble while redirecting!: %d\n",count);
			fprintf(stderr,"please check it 0!!!\n");
			continue;
		}
		redirectfds.localfds[count]=fd;
		close(count);
		fd=dup2(redirectfds.currfds[count],count);
		if(fd!=count){
			fprintf(stderr,"VirtServ err: RedirectStdIO: some trouble while redirecting!: %d->%d->%d\n",
				(int)redirectfds.currfds[count],count,(int)fd);
			fprintf(stderr,"please check it 1!!!\n");
		}
	}
}

void 
VirtServRange::DeRedirectStdIO( )
{
	int count;
	long fd;
	
	#ifdef DBGREDIRECT
	fprintf(stderr,"VirtServ msg:DeRedirectStdIO...\n");
	#endif

	for(count=0;count<STDIONUM;count++)
		if(redirectfds.localfds[count]==NOTDIRECT)
			fprintf(stderr,"VirtServ err:DeRedirectStdIO :detect NOTREDIRECT item in localfds:%d!\n",
				count);

	for(count=0;count<STDIONUM;count++){
		close(count);
		fd=dup2(redirectfds.localfds[count],count);
		if(fd!=count){
			fprintf(stderr,"VirtServ err: DeRedirectStdIO: some trouble while deredirecting!: %d\n",count);
			fprintf(stderr,"please check it!!!\n");
		}
		close(redirectfds.localfds[count]);
	}
}

//for current working directory
void 
VirtServRange::InitCWD( )
{
	topsycwd.globalCWD[0]='/';
	topsycwd.currCWD[0]='/';
	topsycwd.localCWD[0]='/';
	topsycwd.globalCWD[1]='\0';
	topsycwd.currCWD[1]='\0';
	topsycwd.localCWD[1]='\0';

	char* cp=getcwd(topsycwd.globalCWD, MAXCWDLEN);
	if(cp==NULL){
		fprintf(stderr,"VirtServ err:InitCWD: can not get the cwd,if there is err,please check it !!!\n");
		return;
	}
	strcpy(topsycwd.currCWD,topsycwd.globalCWD);
	#ifdef DBGCWD
	fprintf(stderr,"VirtServ msg:InitCWD:\n");
	fprintf(stderr,"globalCWD:%s\n",topsycwd.globalCWD);
	fprintf(stderr,"currCWD:%s\n",topsycwd.currCWD);
	#endif
}

void 
VirtServRange::DestroyCWD( )
{
}

void 
VirtServRange::ChangeCWD( )
{
	char* cp=getcwd(topsycwd.localCWD, MAXCWDLEN);
	if(cp==NULL){
		fprintf(stderr,"VirtServ err:ChangeCWD:can not get the local cwd, if there is err, please check it !!!\n");
		return;
	}
	#ifdef DBGCWD
	fprintf(stderr,"VirtServ msg:ChangeCWD:\n");
	fprintf(stderr,"globalCWD:%s\n",topsycwd.globalCWD);
	fprintf(stderr,"currCWD:%s\n",topsycwd.currCWD);
	fprintf(stderr,"localCWD:%s\n",topsycwd.localCWD);
	#endif
	if(!strcmp(topsycwd.currCWD, topsycwd.localCWD)) return; //curr==local
	if(chdir(topsycwd.currCWD)<0){
		fprintf(stderr,"VirtServ err:ChangeCWD:can not change cwd, if there is err, please check it !!!\n");
		return;
	}
}

void 
VirtServRange::RecoverCWD( )
{
	if(!strcmp(topsycwd.currCWD, topsycwd.localCWD)) return; //curr==local
	if(chdir(topsycwd.localCWD)<0){
		fprintf(stderr,"VirtServ err:RecoverCWD:can not recover cwd, if there is err, please check it !!!\n");
		return;
	}
}

//vmips can get the mmmapping managed by Topsy through the following
//struct and functions
void 
VirtServRange::Inituserinfo(userinfo* ui)
{
	//user app name
	ui->appname[0]='\0';
	//memory mapping info
	mmmappingitem_t invaliditem={INVALID_MMMAPPING,INVALID_MMMAPPING,INVALID_MMMAPPING};
	ui->usermmmapping.codeseg=invaliditem;
	ui->usermmmapping.dataseg=invaliditem;
	ui->usermmmapping.brk_dynamic=invaliditem;
	ui->usermmmapping.mmmap_dynamic=invaliditem;
	ui->usermmmapping.stackseg=invaliditem;
}

/*Local virtual server*/
void 
VirtServRange::StartLocalVirtualServer( uint8 data, DeviceExc *client)
{
	switch(data){
		case fopenservno:
			FileOpenServer(client);
			break;
		case freadservno:
			FileReadServer(client);
			break;
		case fwriteservno:
			FileWriteServer(client);
			break;
		case fcloseservno:
			FileCloseServer(client);
			break;
		case fseekservno:
			FileSeekServer(client);
			break;
		case ftellservno:
			FileTellServer(client);
			break;
		case rewindservno:
			RewindServer(client);
			break;
		case feofservno:
			FileEofServer(client);
			break;
		case fgetcservno:
			FileGetcServer(client);
			break;
		case fgetsservno:
			FileGetsServer(client);
			break;
		case fputcservno:
			FilePutcServer(client);
			break;
		case fputsservno:
			FilePutsServer(client);
			break;
		case libcgetcwdservno:
			LibcgetcwdServer(client);
			break;
		case libcchdirservno:
			LibcchdirServer(client);
			break;
		default:
			fprintf(stderr,"VirtServError:LocalVirtServError:Server %d not implemented!\n",data);
			break;
		}
}

void 
VirtServRange::HandlingLibcReturn(long ret, long err, DeviceExc *client)
{
	SetReg(0,(uint32)ret);
	SetReg(1,(uint32)err);
}
	
void
VirtServRange::FileOpenServer(DeviceExc *client)
{
  	char* filename;
	char* filemode;
	uint32 physaddr;
	bool cacheable;
	FILE* fp;

	#ifdef PRINTLOCALSERVMSG
		fprintf(stderr,"VirtServMsg:LocalServer:file open ->Para1: %d,Para2: %d\n",GetReg(0),GetReg(1));
	#endif
	
	filename=AddressTranslation(GetReg(0),client,READPARAMETER,&physaddr,&cacheable);
	SyncMemAndCache(GetReg(0),physaddr,filename,DEFAULTLEN,SYNCCACHETOMEM,cacheable,client);
	filemode=AddressTranslation(GetReg(1),client,READPARAMETER,&physaddr,&cacheable);
	SyncMemAndCache(GetReg(1),physaddr,filemode,DEFAULTLEN,SYNCCACHETOMEM,cacheable,client);
	fp=fopen(filename,filemode);
	#ifdef PRINTLOCALSERVMSG
		fprintf(stderr,"VirtServMsg:LocalServer:file open... ->filename:%s, filemode:%s, fp:%d\n",filename,filemode,fp);
	#endif
	HandlingLibcReturn((long)fp,errno,client);
}

void
VirtServRange::FileReadServer(DeviceExc *client)
{
	char* buf;
	uint32 physaddr;
	bool cacheable;
	long ret;

	#ifdef PRINTLOCALSERVMSG
		fprintf(stderr,"file read...\n");
	#endif
	
	buf=AddressTranslation(GetReg(0),client,WRITEPARAMETER,&physaddr,&cacheable);
	SyncMemAndCache(GetReg(0),physaddr,buf,GetReg(1)*GetReg(2),SYNCMEMTOCACHE,cacheable,client);
	ret=fread(buf,GetReg(1),GetReg(2),(FILE*)GetReg(3));
	HandlingLibcReturn(ret,errno,client);
}

void
VirtServRange::FileWriteServer(DeviceExc *client)
{
	char* buf;
	uint32 physaddr;
	bool cacheable;
	long ret;

	#ifdef PRINTLOCALSERVMSG
		fprintf(stderr,"VirServMsg:file write....:buf->0x%x sizeof->%d count->%d fd->%d \n",
			GetReg(0),GetReg(1),GetReg(2),GetReg(3));
	#endif
	
	buf=AddressTranslation(GetReg(0),client,READPARAMETER,&physaddr,&cacheable);
	SyncMemAndCache(GetReg(0),physaddr,buf,GetReg(1)*GetReg(2),SYNCCACHETOMEM,cacheable,client);
	#ifdef PRINTLOCALSERVMSG
		fprintf(stderr,"VirServMsg:file write buffer->");
		for(count=0;count<GetReg(1)*GetReg(2);count++)
			fprintf(stderr,"%c",buf[count]);
		fprintf(stderr,"%\n");
	#endif
	ret=fwrite(buf,GetReg(1),GetReg(2),(FILE*)GetReg(3));
	HandlingLibcReturn(ret,errno,client);
}

void 
VirtServRange::FileCloseServer(DeviceExc *client)
{
	int ret;

	#ifdef PRINTLOCALSERVMSG
		fprintf(stderr,"file close...\n");
	#endif
	
	ret=fclose((FILE*)GetReg(0));
	HandlingLibcReturn(ret,errno,client);
}

void 
VirtServRange::FileSeekServer(DeviceExc *client)
{
	int ret;

	#ifdef PRINTLOCALSERVMSG
		fprintf(stderr,"file seek...\n");
	#endif
	
	ret=fseek((FILE*)GetReg(0),GetReg(1),GetReg(2));
	HandlingLibcReturn(ret,errno,client);
}

void 
VirtServRange::FileTellServer(DeviceExc* client)
{
	long int ret;
	
	#ifdef PRINTLOCALSERVMSG
		fprintf(stderr,"file tell...\n");
	#endif

	ret=ftell((FILE*)GetReg(0));
	HandlingLibcReturn(ret,errno,client);
}

void 
VirtServRange::RewindServer(DeviceExc* client)
{
	#ifdef PRINTLOCALSERVMSG
		fprintf(stderr,"file rewind...\n");
	#endif

	rewind((FILE*)GetReg(0));
}

void 
VirtServRange::FileEofServer(DeviceExc* client)
{
	int ret;
	
	#ifdef PRINTLOCALSERVMSG
		fprintf(stderr,"file eof...\n");
	#endif
	
	ret=feof((FILE*)GetReg(0));
	HandlingLibcReturn(ret,errno,client);
}

void 
VirtServRange::FileGetcServer(DeviceExc* client)
{
	int ret;
	
	#ifdef PRINTLOCALSERVMSG
		fprintf(stderr,"file getc...\n");
	#endif

	ret=fgetc((FILE*)GetReg(0));
	HandlingLibcReturn(ret,errno,client);
}

void 
VirtServRange::FileGetsServer(DeviceExc* client)
{
	char* buf;
	uint32 physaddr;
	bool cacheable;
	char* ret;
	
	#ifdef PRINTLOCALSERVMSG
		fprintf(stderr,"file gets...\n");
	#endif

	buf=AddressTranslation(GetReg(0),client,WRITEPARAMETER,&physaddr,&cacheable);
	SyncMemAndCache(GetReg(0),physaddr,buf,GetReg(1),SYNCMEMTOCACHE,cacheable,client);
	ret=fgets(buf,GetReg(1),(FILE*)GetReg(2));
	HandlingLibcReturn((long)ret,errno,client);
}

void 
VirtServRange::FilePutcServer(DeviceExc* client)
{
	int ret;
	
	#ifdef PRINTLOCALSERVMSG
		fprintf(stderr,"file putc...\n");
	#endif

	ret=fputc(GetReg(0),(FILE*)GetReg(1));
	HandlingLibcReturn(ret,errno,client);
}

void 
VirtServRange::FilePutsServer(DeviceExc* client)
{
	char* buf;
	uint32 physaddr;
	bool cacheable;
	int ret;
	
	#ifdef PRINTLOCALSERVMSG
		fprintf(stderr,"file puts...\n");
	#endif

	buf=AddressTranslation(GetReg(0),client,READPARAMETER,&physaddr,&cacheable);
	SyncMemAndCache(GetReg(0),physaddr,buf,DEFAULTLEN,SYNCCACHETOMEM,cacheable,client);
	ret=fputs(buf,(FILE*)GetReg(1));
	HandlingLibcReturn(ret,errno,client);
}

void 
VirtServRange::LibcgetcwdServer(DeviceExc* client)
{
	char* buf;
	uint32 physaddr;
	bool cacheable;
	char* ret;

	#ifdef PRINTLOCALSERVMSG
		fprintf(stderr,"LibcgetcwdServer...\n");
	#endif

	buf=AddressTranslation(GetReg(0),client,WRITEPARAMETER,&physaddr,&cacheable);
	SyncMemAndCache(GetReg(0),physaddr,buf,GetReg(1),SYNCMEMTOCACHE,cacheable,client);
	ret=getcwd(buf, GetReg(1));
	HandlingLibcReturn((long)ret,errno,client);
}

void 
VirtServRange::LibcchdirServer(DeviceExc* client)
{
  	char* pathname;
	uint32 physaddr;
	bool cacheable;
	long ret;
	char* cp;

	#ifdef PRINTLOCALSERVMSG
		fprintf(stderr,"LibcchdirServer\n");
	#endif
	
	pathname=AddressTranslation(GetReg(0),client,READPARAMETER,&physaddr,&cacheable);
	SyncMemAndCache(GetReg(0),physaddr,pathname,DEFAULTLEN,SYNCCACHETOMEM,cacheable,client);
	if((ret=chdir(pathname))<0) goto out;
	cp=getcwd(topsycwd.currCWD, MAXCWDLEN);
	if(cp==NULL){
		fprintf(stderr,"VirtServ err:LibcchdirServer:can not get the local cwd, if there is err, please check it !!!\n");
		ret=-1;
	}
out:
	HandlingLibcReturn(ret,errno,client);
}

/*OutputServer for such as debugging*/
void 
VirtServRange::StartOutputServer( uint8 data, DeviceExc *client)
{
    switch(data){
		case dumpregservno:
			dumpregserver(client);
			break;
		case errmsgservno:
			ErrMsgServer(client);
			break;
		case tracerservno:
			TracerServer(client);
			break;
		default:
			fprintf(stderr,"VirtServError:OutputServError:Server %d not implemented!\n",data);
			break;
		}
}

char* GenRegNames[32]={
	"Zero", "at", "v0", "v1", "a0", "a1", "a2", "a3", "t0", "t1", "t2", "t3", "t4", "t5", "t6", "t7",
	"s0", "s1", "s2", "s3", "s4", "s5", "s6", "s7", "t8", "t9", "k0", "k1", "gp", "sp", "fp", "ra"};
char * CPZeroRegNames[32]={
    "Index", "Random", "EntryLo0", "EntryLo1", "Context", "PageMask",  "Wired", "Error", 
    "BadVAddr", "Count", "EntryHi", "Compare", "Status",  "Cause", "EPC", "PRId", 
    "Config", "LLAdr", "WatchLo", "WatchHi", "20", "21", "22", "23",
    "24", "25", "ECC", "CacheErr", "TagLo", "TagHi", "ErrorEPC", "31"};
void 
VirtServRange::dumpregserver(DeviceExc *client)
{
	CPU* cpu=(CPU*)client;
	CPZero* cp0=cpu->GetCP0();
    int  regno;
	
	fprintf(stderr,"\nNow dump the registers:\n");

	fprintf(stderr,"General registers:");
	for(regno=0;regno<32;regno++){
		if(regno%4==0)
			fprintf(stderr,"\n");
		fprintf(stderr,"[%-4s]:%-8x",GenRegNames[regno],cpu->GetGenReg(regno));
	}
	
	fprintf(stderr,"\nCPZero registers:");
	for(regno=0;regno<32;regno++){
		if(regno%4==0)
			fprintf(stderr,"\n");
		fprintf(stderr,"[%-8s]:%-8x",CPZeroRegNames[regno],cp0->reg[regno]);
	}

	fprintf(stderr,"\nTLB entries:");
	for(regno=0;regno<(int)(cp0->Random_UPPER_BOUND+1);regno++){
		if(regno%2==0)
			fprintf(stderr,"\n");
		fprintf(stderr,"[%-4d]:%-8x %-8x %-6x",regno,cp0->tlb->tlb_entry[regno].hilo[1],
					cp0->tlb->tlb_entry[regno].hilo[0],cp0->tlb->tlb_entry[regno].entry.vpn);
	}
	
	fprintf(stderr,"\nEnd dump!\n\n");
	
}

char* ErrMsgArr[32]={
	"System call not implemented! Syscall number is : ",
	"Cheating system call. Syscall number is : "
};
/*note:the error message is selected by v0*/
void 
VirtServRange::ErrMsgServer(DeviceExc *client)
{
	fprintf(stderr,"%s%d\n",ErrMsgArr[GetReg(0)],GetReg(1));
}

/* invoke the DBGTracer */
void 
VirtServRange::TracerServer(DeviceExc *client)
{
//	fprintf(stderr,"StartTracing...\n");
	DBGTracer::trigger(GetReg(0));
}

/*LinuxSyscall server*/
void 
VirtServRange::StartLinuxSyscallServer(uint8 data, DeviceExc *client)
{
    switch(data){
		case LinuxSyscallreadservno:
			LinuxSyscallReadServer(client);
			break;
		case LinuxSyscallwriteservno:
			LinuxSyscallWriteServer(client);
			break;
		case LinuxSyscallopenservno:
			LinuxSyscallOpenServer(client);
			break;
		case LinuxSyscallcloseservno:
			LinuxSyscallCloseServer(client);
			break;
		case LinuxSyscallunlinkservno:
			LinuxSyscallunlinkServer(client);
			break;
		case LinuxSyscalltimeservno:
			LinuxSyscalltimeServer(client);
			break;
		case LinuxSyscalllseekservno:
			LinuxSyscalllseekServer(client);
			break;
		case LinuxSyscallgetpidservno:
			LinuxSyscallgetpidServer(client);
			break;
		case LinuxSyscallgetuidservno:
			LinuxSyscallgetuidServer(client);
			break;
		case LinuxSyscallaccessservno:
			LinuxSyscallaccessServer(client);
			break;
		case LinuxSyscallrenameservno:
			LinuxSyscallrenameServer(client);
			break;
		case LinuxSyscalltimesservno:
			LinuxSyscalltimesServer(client);
			break;
		case LinuxSyscallgetgidservno:
			LinuxSyscallgetgidServer(client);
			break;
		case LinuxSyscallgeteuidservno:
			LinuxSyscallgeteuidServer(client);
			break;
		case LinuxSyscallgetegidservno:
			LinuxSyscallgetegidServer(client);
			break;
		case LinuxSyscallioctlservno:
			LinuxSyscallioctlServer(client);
			break;
		case LinuxSyscallfcntlservno:
			LinuxSyscallfcntlServer(client,data);
			break;
		case LinuxSyscallgetrlimitservno:
			LinuxSyscallgetrlimitServer(client);
			break;
		case LinuxSyscallgetrusageservno:
			LinuxSyscallgetrusageServer(client);
			break;
		case LinuxSyscallftruncateservno:
			LinuxSyscallftruncateServer(client);
			break;
		case LinuxSyscallstatservno:
		case LinuxSyscalllstatservno:
		case LinuxSyscallfstatservno:
			LinuxSyscallfstatServer(client,data);
			break;
		case LinuxSyscallnewunameservno:
			LinuxSyscallnewunameServer(client);
			break;
		case LinuxSyscallllseekservno:
			LinuxSyscallllseekServer(client);
			break;
		case LinuxSyscallnewselectservno:
			LinuxSyscallnewselectServer(client);
			break;
		case LinuxSyscallftruncate64servno:
			LinuxSyscallftruncate64Server(client);
			break;
		case LinuxSyscallstat64servno:
		case LinuxSyscalllstat64servno:
		case LinuxSyscallfstat64servno:
			LinuxSyscallfstat64Server(client,data);
			break;
		case LinuxSyscallfcntl64servno:
			LinuxSyscallfcntlServer(client,data);
			break;
		default:
			fprintf(stderr,"VirtServError:SyscallServError:Server %d not implemented!\n",data);
			break;
		}
}

void 
VirtServRange::HandlingSysCallReturn(long ret, DeviceExc *client)
{
	if(ret>=0){
		SetReg(0,(uint32)ret);
		SetReg(1,0);
	}
	else
		if(ret==-1){
			SetReg(0,errno);
			SetReg(1,1);
		}
		else
			fprintf(stderr,"VirtServError:SyscallServError:Not such return value when running the Linux syscall server!\n");
}

_syscall3(int,tlread,unsigned int,fd,char *,buf,long,count)
void 
VirtServRange::LinuxSyscallReadServer(DeviceExc* client)
{
	char* buf;
	uint32 physaddr;
	bool cacheable;
	long ret;

	#ifdef PRINTSYSCALLMSG
		fprintf(stderr,"VirServMsg:%d:Linux Syscall read...:fd->%d buf->%d count->%d\n",
			4000+LinuxSyscallreadservno,GetReg(0),GetReg(1),GetReg(2));
	#endif
	
	buf=AddressTranslation(GetReg(1),client,WRITEPARAMETER,&physaddr,&cacheable);
	SyncMemAndCache(GetReg(1),physaddr,buf,GetReg(2),SYNCMEMTOCACHE,cacheable,client);
	ret=tlread(GetReg(0),buf,GetReg(2));
	if(ret>0){
		/*#ifdef PRINTSYSCALLMSG
			fprintf(stderr,"VirServMsg:Linux Syscall read retval:ret->%d, buf->%s\n",ret,buf);
		#endif*/
	}
	#ifdef PRINTSYSCALLMSG
	fprintf(stderr,"ret->%d\n",ret);
	#endif
	HandlingSysCallReturn(ret,client);
	
}

_syscall3(int,tlwrite,unsigned int,fd,const char *,buf,long,count)
void 
VirtServRange::LinuxSyscallWriteServer(DeviceExc* client)
{
	char* buf;
	uint32 physaddr;
	bool cacheable;
	long ret;

	#ifdef PRINTSYSCALLMSG
		fprintf(stderr,"VirServMsg:%d:Linux Syscall write...:fd->%d buf->%d count->%d\n",
			4000+LinuxSyscallwriteservno,GetReg(0),GetReg(1),GetReg(2));
	#endif
	
	buf=AddressTranslation(GetReg(1),client,READPARAMETER,&physaddr,&cacheable);
	SyncMemAndCache(GetReg(1),physaddr,buf,GetReg(2),SYNCCACHETOMEM,cacheable,client);
	/*#ifdef PRINTSYSCALLMSG
	      uint32 buffer=(uint32)physaddr;
		fprintf(stderr,"VirServMsg:Linux Syscall write buffer->");
		for(count=0;count<GetReg(2);count++)
			fprintf(stderr,"%c",buf[count]);
		fprintf(stderr,"%\n");
	#endif*/
	ret=tlwrite(GetReg(0),buf,GetReg(2));
	HandlingSysCallReturn(ret,client);

}

fileflagconvert_t fflagcnvttable[]={
{O_WRONLY_MIPS,O_WRONLY},{O_RDWR_MIPS,O_RDWR},{O_APPEND_MIPS,O_APPEND},
{O_SYNC_MIPS,O_SYNC},{O_NONBLOCK_MIPS,O_NONBLOCK},{O_CREAT_MIPS,O_CREAT},
{O_TRUNC_MIPS,O_TRUNC},{O_EXCL_MIPS,O_EXCL},{O_NOCTTY_MIPS,O_NOCTTY},
{FASYNC_MIPS,FASYNC},{O_LARGEFILE_MIPS,O_LARGEFILE},{O_DIRECT_MIPS,O_DIRECT},
{O_DIRECTORY_MIPS,O_DIRECTORY},{O_NOFOLLOW_MIPS,O_NOFOLLOW},
//{O_ATOMICLOOKUP_MIPS,O_ATOMICLOOKUP},
{-1,0}
};
int fileflagconvert(int mipsflag)
{
	int count=0;
	int x86flag=0;

	while((int)fflagcnvttable[count].mipsflag!=(int)-1){
		if(mipsflag&fflagcnvttable[count].mipsflag){
			x86flag|=fflagcnvttable[count].x86flag;
			mipsflag&=~fflagcnvttable[count].mipsflag;
		}
		count++;
	}
	if(mipsflag!=0)
		fprintf(stderr,"VirtServ Warning:fileflagconvert:can not convert completely!\n");
	return x86flag;
}
_syscall3(long,tlopen,const char*,filename,int,flag,int,mode)
void 
VirtServRange::LinuxSyscallOpenServer(DeviceExc* client)
{
  	char* filename;
	uint32 physaddr;
	bool cacheable;
	long fd;
	int flag;

	#ifdef PRINTSYSCALLMSG
		fprintf(stderr,"VirServMsg:%d:Linux Syscall open...:filename->%d flag->%d mode->%d\n",
			4000+LinuxSyscallopenservno,GetReg(0),GetReg(1),GetReg(2));
	#endif
	
	filename=AddressTranslation(GetReg(0),client,READPARAMETER,&physaddr,&cacheable);
	SyncMemAndCache(GetReg(0),physaddr,filename,DEFAULTLEN,SYNCCACHETOMEM,cacheable,client);
	flag=fileflagconvert(GetReg(1));
	fd=tlopen(filename,flag,GetReg(2));
	#ifdef PRINTSYSCALLMSG
		fprintf(stderr,"filename:%s fd:0x%x\n",filename,fd);
	#endif
	HandlingSysCallReturn(fd,client);
	
}

_syscall1(long,tlclose,unsigned int,fd)
void 
VirtServRange::LinuxSyscallCloseServer(DeviceExc* client)
{
	long ret;
	
	#ifdef PRINTSYSCALLMSG
		fprintf(stderr,"VirServMsg:%d:Linux Syscall close...:fd->%d\n",
			4000+LinuxSyscallcloseservno,GetReg(0));
	#endif

	ret=tlclose(GetReg(0));
	HandlingSysCallReturn(ret,client);
	
}

_syscall1(long, tlunlink, const char *, pathname)
void 
VirtServRange::LinuxSyscallunlinkServer(DeviceExc* client)
{
  	char* pathname;
	uint32 physaddr;
	bool cacheable;
	long retval;

	#ifdef PRINTSYSCALLMSG
		fprintf(stderr,"VirServMsg:%d:Linux Syscall unlink...\n",4000+LinuxSyscallunlinkservno);
	#endif
	
	pathname=AddressTranslation(GetReg(0),client,READPARAMETER,&physaddr,&cacheable);
	SyncMemAndCache(GetReg(0),physaddr,pathname,DEFAULTLEN,SYNCCACHETOMEM,cacheable,client);
	retval=tlunlink(pathname);
	#ifdef PRINTSYSCALLMSG
		fprintf(stderr,"filename:%s, retval:0x%x\n",pathname,retval);
	#endif
	HandlingSysCallReturn(retval,client);
}

_syscall1(long, tltime, int *, tloc)
void 
VirtServRange::LinuxSyscalltimeServer(DeviceExc* client)
{
	int* tloc=NULL;
	uint32 physaddr;
	bool cacheable;
	long ret;

	#ifdef PRINTSYSCALLMSG
		fprintf(stderr,"VirServMsg:%d:Linux Syscall time...:tloc->0x%x\n",
			4000+LinuxSyscalltimeservno,GetReg(0));
	#endif

	if((int*)GetReg(0)!=NULL){
		tloc=(int*)AddressTranslation(GetReg(0),client,WRITEPARAMETER,&physaddr,&cacheable);
		SyncMemAndCache(GetReg(0),physaddr,(char*)tloc,sizeof(int),SYNCMEMTOCACHE,cacheable,client);
	}
	ret=tltime(tloc);
	
	#ifdef PRINTSYSCALLMSG
		fprintf(stderr,"VirServMsg:Linux Syscall time:ret->0x%x,*tloc->0x%x\n",ret,*tloc);
	#endif
	HandlingSysCallReturn(ret,client);
}

_syscall3(long,tllseek,unsigned int,fd,long,offset,unsigned int,origin)
void
VirtServRange::LinuxSyscalllseekServer(DeviceExc* client)
{
	long ret;
	
	#ifdef PRINTSYSCALLMSG
		fprintf(stderr,"VirServMsg:%d:Linux Syscall lseek...:fd->%d offset->%d origin->%d\n",
			4000+LinuxSyscalllseekservno,GetReg(0),GetReg(1),GetReg(2));
	#endif

	ret=tllseek(GetReg(0),GetReg(1),GetReg(2));
	HandlingSysCallReturn(ret,client);

}

_syscall0(long, tlgetpid)
void 
VirtServRange::LinuxSyscallgetpidServer(DeviceExc* client)
{
	long ret=tlgetpid();
	#ifdef PRINTSYSCALLMSG
		fprintf(stderr,"VirServMsg:%d:Linux Syscall getpid...:ret->0x%x\n",
			4000+LinuxSyscallgetpidservno,ret);
	#endif
	HandlingSysCallReturn(ret,client);
}

_syscall0(long,tlgetuid32)
void 
VirtServRange::LinuxSyscallgetuidServer(DeviceExc* client)
{
	long ret;
	
	#ifdef PRINTSYSCALLMSG
		fprintf(stderr,"VirServMsg:%d:Linux Syscall getuid...\n",4000+LinuxSyscallgetuidservno);
	#endif

	ret=tlgetuid32( );
	#ifdef PRINTSYSCALLMSG
		fprintf(stderr,"retval->%d\n",ret);
	#endif
	HandlingSysCallReturn(ret,client);
	#ifdef PRINTSYSCALLMSG
		fprintf(stderr,"VirServMsg:Linux Syscall getuid ends........\n\n");
	#endif
}

_syscall2(long,tlaccess,const char *, filename, int, mode)
void 
VirtServRange::LinuxSyscallaccessServer(DeviceExc* client)
{
  	char* filename;
	uint32 physaddr;
	bool cacheable;
	long retval;

	filename=AddressTranslation(GetReg(0),client,READPARAMETER,&physaddr,&cacheable);
	SyncMemAndCache(GetReg(0),physaddr,filename,DEFAULTLEN,SYNCCACHETOMEM,cacheable,client);
	retval=tlaccess(filename,GetReg(1));
	#ifdef PRINTSYSCALLMSG
	fprintf(stderr,"VirServMsg:%d:Linux Syscall access...:filename->%s mode->0x%x\n",
		4000+LinuxSyscallaccessservno,filename,GetReg(1));
	fprintf(stderr,"ret->0x%x\n",retval);
	#endif
	
	HandlingSysCallReturn(retval,client);
}

_syscall2(long, tlrename, const char *, oldname, const char *, newname)
void 
VirtServRange::LinuxSyscallrenameServer(DeviceExc* client)
{
  	char* oldfilename;
	char* newfilename;
	uint32 physaddr;
	bool cacheable;
	long retval;

	#ifdef PRINTSYSCALLMSG
		fprintf(stderr,"VirServMsg:%d:Linux Syscall rename...\n",4000+LinuxSyscallrenameservno);
	#endif
	
	oldfilename=AddressTranslation(GetReg(0),client,READPARAMETER,&physaddr,&cacheable);
	SyncMemAndCache(GetReg(0),physaddr,oldfilename,DEFAULTLEN,SYNCCACHETOMEM,cacheable,client);
	newfilename=AddressTranslation(GetReg(1),client,READPARAMETER,&physaddr,&cacheable);
	SyncMemAndCache(GetReg(1),physaddr,newfilename,DEFAULTLEN,SYNCCACHETOMEM,cacheable,client);
	retval=tlrename(oldfilename,newfilename);
	#ifdef PRINTSYSCALLMSG
		fprintf(stderr,"oldfilename:%s, newfilename:%s, retval:0x%x\n",oldfilename,newfilename,retval);
	#endif
	HandlingSysCallReturn(retval,client);
}

_syscall1(long, tltimes, struct tms *, tbuf)
void 
VirtServRange::LinuxSyscalltimesServer(DeviceExc* client)
{
	struct tms* tbuf;
	uint32 physaddr;
	bool cacheable;
	long ret;

	#ifdef PRINTSYSCALLMSG
		fprintf(stderr,"VirServMsg:%d:Linux Syscall times...:tbuf->0x%x,sizeof(struct tms)->0x%x\n",
			4000+LinuxSyscalltimesservno,GetReg(0),sizeof(struct tms));
	#endif
	
	tbuf=(struct tms*)AddressTranslation(GetReg(0),client,WRITEPARAMETER,&physaddr,&cacheable);
	SyncMemAndCache(GetReg(0),physaddr,(char*)tbuf,sizeof(struct tms),SYNCMEMTOCACHE,cacheable,client);
	ret=tltimes(tbuf);
	
	#ifdef PRINTSYSCALLMSG
		fprintf(stderr,"VirServMsg:Linux Syscall times:\n");
		fprintf(stderr,"ret->0x%x\n",ret);
		fprintf(stderr,"tms_utime->0x%x\n",tbuf->tms_utime);
		fprintf(stderr,"tms_stime->0x%x\n",tbuf->tms_stime);
		fprintf(stderr,"tms_cutime->0x%x\n",tbuf->tms_cutime);
		fprintf(stderr,"tms_cstime->0x%x\n",tbuf->tms_cstime);
		fprintf(stderr,"VirServMsg:Linux Syscall times ends...\n");
	#endif
	HandlingSysCallReturn(ret,client);
}

_syscall0(long,tlgetgid32)
void 
VirtServRange::LinuxSyscallgetgidServer(DeviceExc* client)
{
	long ret;
	
	#ifdef PRINTSYSCALLMSG
		fprintf(stderr,"VirServMsg:%d:Linux Syscall getgid...\n",4000+LinuxSyscallgetgidservno);
	#endif

	ret=tlgetgid32( );
	#ifdef PRINTSYSCALLMSG
		fprintf(stderr,"retval->%d\n",ret);
	#endif
	HandlingSysCallReturn(ret,client);
	#ifdef PRINTSYSCALLMSG
		fprintf(stderr,"VirServMsg:Linux Syscall getgid ends........\n\n");
	#endif
}

_syscall0(long,tlgeteuid32)
void 
VirtServRange::LinuxSyscallgeteuidServer(DeviceExc* client)
{
	long ret;
	
	#ifdef PRINTSYSCALLMSG
		fprintf(stderr,"VirServMsg:%d:Linux Syscall geteuid...\n",4000+LinuxSyscallgeteuidservno);
	#endif

	ret=tlgeteuid32( );
	#ifdef PRINTSYSCALLMSG
		fprintf(stderr,"retval->%d\n",ret);
	#endif
	HandlingSysCallReturn(ret,client);
	#ifdef PRINTSYSCALLMSG
		fprintf(stderr,"VirServMsg:Linux Syscall geteuid ends........\n\n");
	#endif
}

_syscall0(long,tlgetegid32)
void 
VirtServRange::LinuxSyscallgetegidServer(DeviceExc* client)
{
	long ret;
	
	#ifdef PRINTSYSCALLMSG
		fprintf(stderr,"VirServMsg:%d:Linux Syscall getegid...\n",4000+LinuxSyscallgetegidservno);
	#endif

	ret=tlgetegid32( );
	#ifdef PRINTSYSCALLMSG
		fprintf(stderr,"retval->%d\n",ret);
	#endif
	HandlingSysCallReturn(ret,client);
	#ifdef PRINTSYSCALLMSG
		fprintf(stderr,"VirServMsg:Linux Syscall getegid ends........\n\n");
	#endif
}

_syscall3(long,tlioctl,unsigned int,fd, unsigned int,cmd, unsigned long,arg)
void 
VirtServRange::LinuxSyscallioctlServer(DeviceExc* client)
{
	long retval;
	
	#ifdef PRINTSYSCALLMSG
		fprintf(stderr,"VirServMsg:%d:Linux Syscall ioctl...:fd->%d cmd->%d arg->0x%x\n",
			4000+LinuxSyscallioctlservno,GetReg(0),GetReg(1),GetReg(2));
	#endif

	retval=-1; errno=ENOTTY; goto out;
	
	//arg should be preprocess first!!!
	retval=tlioctl(GetReg(0),GetReg(1),GetReg(2));
	
	#ifdef PRINTSYSCALLMSG
		fprintf(stderr,"retval->%d\n",retval);
	#endif
out:
	HandlingSysCallReturn(retval,client);
}

_syscall3(long,tlfcntl,unsigned int,fd, unsigned int,cmd, unsigned long,arg)
_syscall3(long,tlfcntl64,unsigned int,fd, unsigned int,cmd, unsigned long,arg)
void 
VirtServRange::LinuxSyscallfcntlServer(DeviceExc* client, long syscallnum)
{
	long ret;
	
	#ifdef PRINTSYSCALLMSG
	if(syscallnum==LinuxSyscallfcntlservno)
		fprintf(stderr,"VirServMsg:%d:Linux Syscall fcntl...:fd->%d cmd->%d arg->%d\n",
			4000+syscallnum,GetReg(0),GetReg(1),GetReg(2));
	else
		fprintf(stderr,"VirServMsg:%d:Linux Syscall fcntl64...:fd->%d cmd->%d arg->%d\n",
			4000+syscallnum,GetReg(0),GetReg(1),GetReg(2));
	#endif

	if((GetReg(1)!=F_GETFD)&&(GetReg(1)!=F_SETFD))
		fprintf(stderr,"VirtServWarning:LinuxSyscallfcntlServer: server not implemented completely!\n");
	if(syscallnum==LinuxSyscallfcntlservno)
		ret=tlfcntl(GetReg(0),GetReg(1),GetReg(2));
	else
		ret=tlfcntl64(GetReg(0),GetReg(1),GetReg(2));
	
	#ifdef PRINTSYSCALLMSG
	fprintf(stderr,"retval->%d\n",ret);
	#endif
	HandlingSysCallReturn(ret,client);
	#ifdef PRINTSYSCALLMSG
	fprintf(stderr,"VirServMsg:Linux Syscall fcntl ends........\n\n");
	#endif
}

_syscall2(long, tlugetrlimit, unsigned int, resource, struct rlimit *, rlim)
void 
VirtServRange::LinuxSyscallgetrlimitServer(DeviceExc* client)
{
	struct rlimit* rlim;
	uint32 physaddr;
	bool cacheable;
	long ret;

	#ifdef PRINTSYSCALLMSG
		fprintf(stderr,"VirServMsg:%d:Linux Syscall getrlimit...:res->%d rlimit->0x%x\n",
			4000+LinuxSyscallgetrlimitservno,GetReg(0),GetReg(1));
	#endif
	
	rlim=(struct rlimit*)AddressTranslation(GetReg(1),client,WRITEPARAMETER,&physaddr,&cacheable);
	SyncMemAndCache(GetReg(1),physaddr,(char*)rlim,sizeof(struct rlimit),SYNCMEMTOCACHE,cacheable,client);
	ret=tlugetrlimit(GetReg(0), rlim);

	#ifdef PRINTSYSCALLMSG
	if(ret>=0){
		fprintf(stderr,"getrlimit success! ret->0x%x\n",ret);
		fprintf(stderr,"rlim_cur->0x%x, rlim_max->0x%x .\n",rlim->rlim_cur,rlim->rlim_max);
	}else
		fprintf(stderr,"getrlimit failed!\n");
	fprintf(stderr,"VirServMsg: getrlimit ends.\n");
	#endif
	
	HandlingSysCallReturn(ret,client);
}

_syscall2(long, tlgetrusage, int, who, struct rusage *, ru)
void 
VirtServRange::LinuxSyscallgetrusageServer(DeviceExc* client)
{
	struct rusage * ru;
	uint32 physaddr;
	bool cacheable;
	long ret;

	#ifdef PRINTSYSCALLMSG
		fprintf(stderr,"VirServMsg:%d:Linux Syscall getrusage...:who->%d rusage->0x%x\n",
			4000+LinuxSyscallgetrusageservno,GetReg(0),GetReg(1));
	#endif
	
	ru=(struct rusage*)AddressTranslation(GetReg(1),client,WRITEPARAMETER,&physaddr,&cacheable);
	SyncMemAndCache(GetReg(1),physaddr,(char*)ru,sizeof(struct rusage),SYNCMEMTOCACHE,cacheable,client);
	ret=tlgetrusage(GetReg(0), ru);

	#ifdef PRINTSYSCALLMSG
	if(ret>=0){
		fprintf(stderr,"getrusage success! ret->0x%x, sizeof(struct rusage)->0x%x\n",ret,sizeof(struct rusage));
		fprintf(stderr,"ru_utime: tv_sec->0x%x, tv_usec->0x%x\n",
			ru->ru_utime.tv_sec,ru->ru_utime.tv_usec);
		fprintf(stderr,"ru_stime: tv_sec->0x%x, tv_usec->0x%x\n",
			ru->ru_stime.tv_sec,ru->ru_stime.tv_usec);
		fprintf(stderr,"ru_maxrss->0x%x, ru_ixrss->0x%x\n",ru->ru_maxrss,ru->ru_ixrss);
		fprintf(stderr,"ru_idrss->0x%x, ru_isrss->0x%x\n",ru->ru_idrss,ru->ru_isrss);
		fprintf(stderr,"ru_minflt->0x%x, ru_majflt->0x%x\n",ru->ru_minflt,ru->ru_majflt);
		fprintf(stderr,"ru_nswap->0x%x, ru_inblock->0x%x\n",ru->ru_nswap,ru->ru_inblock);
		fprintf(stderr,"ru_oublock->0x%x, ru_msgsnd->0x%x\n",ru->ru_oublock,ru->ru_msgsnd);
		fprintf(stderr,"ru_msgrcv->0x%x, ru_nsignals->0x%x\n",ru->ru_msgrcv,ru->ru_nsignals);
		fprintf(stderr,"ru_nvcsw->0x%x, ru_nivcsw->0x%x\n",ru->ru_nvcsw,ru->ru_nivcsw);
	}else
		fprintf(stderr,"getrusage failed!\n");
	fprintf(stderr,"VirServMsg: getrusage ends.\n");
	#endif
	
	HandlingSysCallReturn(ret,client);
}

_syscall2(long,tlftruncate,unsigned int, fd, unsigned long, length)
void 
VirtServRange::LinuxSyscallftruncateServer(DeviceExc* client)
{
	long ret;
	
	ret=tlftruncate(GetReg(0),GetReg(1));
	#ifdef PRINTSYSCALLMSG
	fprintf(stderr,"VirServMsg:%d:Linux Syscall ftruncate...:fd->0x%x,len->0x%x,ret->0x%x\n",
	4000+LinuxSyscallftruncateservno,GetReg(0),GetReg(1),ret);
	#endif
	HandlingSysCallReturn(ret,client);
}

void CopyStat(struct stat* statlocalptr, struct statformips* statbuf)
{
	if(statlocalptr==NULL||statbuf==NULL){
		fprintf(stderr,"VirtServError:SyscallError:when copying local fstat to mips!\n");
		return;
	}
	
	statbuf->st_dev=(unsigned int)statlocalptr->st_dev;
	statbuf->st_ino=(unsigned long)statlocalptr->st_ino;
	statbuf->st_mode=(unsigned int)statlocalptr->st_mode;
	statbuf->st_nlink=(int)statlocalptr->st_nlink;
	statbuf->st_uid=(int)statlocalptr->st_uid;
	statbuf->st_gid=(int)statlocalptr->st_gid;
	statbuf->st_rdev=(unsigned int)statlocalptr->st_rdev;
	statbuf->st_size=(long)statlocalptr->st_size;
	statbuf->st_accesstime=(long)statlocalptr->st_atime;
	statbuf->st_modifytime=(long)statlocalptr->st_mtime;
	statbuf->st_createtime=(long)statlocalptr->st_ctime;
	statbuf->st_blksize=(long)statlocalptr->st_blksize;
	statbuf->st_blocks=(long)statlocalptr->st_blocks;
		
	#ifdef PRINTSYSCALLMSG
	fprintf(stderr,"VirtServ stat...\n");
	fprintf(stderr,"st_dev->0x%x\n",(long int)statlocalptr->st_dev);
	fprintf(stderr,"st_ino->0x%x\n",(long int)statlocalptr->st_ino);
	fprintf(stderr,"st_mode->0x%x\n",(long int)statlocalptr->st_mode);
	fprintf(stderr,"st_nlink->0x%x\n",(long int)statlocalptr->st_nlink);
	fprintf(stderr,"st_uid->0x%x\n",(long int)statlocalptr->st_uid);
	fprintf(stderr,"st_gid->0x%x\n",(long int)statlocalptr->st_gid);
	fprintf(stderr,"st_rdev->0x%x\n",(long int)statlocalptr->st_rdev);
	fprintf(stderr,"st_size->0x%x\n",(long int)statlocalptr->st_size);
	fprintf(stderr,"st_accesstime->0x%x\n",(long int)statlocalptr->st_atime);
	fprintf(stderr,"st_modifytime->0x%x\n",(long int)statlocalptr->st_mtime);
	fprintf(stderr,"st_createtime->0x%x\n",(long int)statlocalptr->st_ctime);
	fprintf(stderr,"st_blksize->0x%x\n",(long int)statlocalptr->st_blksize);
	fprintf(stderr,"st_blocks->0x%x\n",(long int)statlocalptr->st_blocks);
	#endif
} 
_syscall2(long, tlstat,char *, filename, struct stat *, statbuf)
_syscall2(long, tllstat,char *, filename, struct stat *, statbuf)
_syscall2(long, tlfstat,unsigned int, fd, struct stat *, statbuf)
void 
VirtServRange::LinuxSyscallfstatServer(DeviceExc* client, long syscallnum)
{
	struct stat statlocal;
	struct statformips* statmips;
	char* filename=NULL;
	uint32 physaddr;
	bool cacheable;
	long ret=0;

	if(syscallnum!=LinuxSyscallfstatservno){
		filename=AddressTranslation(GetReg(0),client,READPARAMETER,&physaddr,&cacheable);
		SyncMemAndCache(GetReg(0),physaddr,filename,DEFAULTLEN,SYNCCACHETOMEM,cacheable,client);
	}
	
	#ifdef PRINTSYSCALLMSG
	if(syscallnum==LinuxSyscallstatservno)
		fprintf(stderr,"VirServMsg:%d:Linux Syscall stat...:filename->%s statbuf->0x%x\n",
			4000+LinuxSyscallstatservno,filename,GetReg(1));
	else if(syscallnum==LinuxSyscalllstatservno)
		fprintf(stderr,"VirServMsg:%d:Linux Syscall lstat64...:filename->%s statbuf->0x%x\n",
			4000+LinuxSyscalllstatservno,filename,GetReg(1));
	else if(syscallnum==LinuxSyscallfstatservno)
		fprintf(stderr,"VirServMsg:%d:Linux Syscall fstat64...:fd->%d statbuf->0x%x\n",
			4000+LinuxSyscallfstatservno,GetReg(0),GetReg(1));
	#endif

	statmips=(struct statformips*)AddressTranslation(GetReg(1),client,WRITEPARAMETER,&physaddr,&cacheable);
	SyncMemAndCache(GetReg(1),physaddr,(char*)statmips,sizeof(struct statformips),SYNCMEMTOCACHE,cacheable,client);

	if(syscallnum==LinuxSyscallstatservno)
		ret=tlstat(filename, &statlocal);
	else if(syscallnum==LinuxSyscalllstatservno)
		ret=tllstat(filename, &statlocal);
	else if(syscallnum==LinuxSyscallfstatservno)
		ret=tlfstat(GetReg(0), &statlocal);
	
	if(ret>=0)
		CopyStat(&statlocal, statmips);
	fprintf(stderr,"\n");
	HandlingSysCallReturn(ret,client); 
}

_syscall1(long,tluname,struct new_utsname_fori386 *,name)
void 
VirtServRange::LinuxSyscallnewunameServer(DeviceExc* client)
{
	long ret;
	uint32 physaddr;
	bool cacheable;
	struct new_utsname_fori386* name;
	
	#ifdef PRINTSYSCALLMSG
		fprintf(stderr,"VirServMsg:%d:Linux Syscall newuname...:name->0x%x\n",
			4000+LinuxSyscallnewunameservno,GetReg(0));
	#endif

	name=(new_utsname_fori386*)AddressTranslation(GetReg(0),client,WRITEPARAMETER,&physaddr,&cacheable);
	SyncMemAndCache(GetReg(0),physaddr,(char*)name,sizeof(struct new_utsname_fori386),SYNCMEMTOCACHE,cacheable,client);
	ret=tluname(name);
	#ifdef PRINTSYSCALLMSG
		fprintf(stderr,"retval->%d\n",ret);
	#endif
	if(ret>=0){
		#ifdef PRINTSYSCALLMSG
			fprintf(stderr,"sysname->%s\nnodename->%s\nrelease->%s\nversion->%s\nmachine->%s\ndomainname->%s\n",
				name->sysname,name->nodename,name->release,name->version,name->machine,name->domainname);
		#endif
	}
	HandlingSysCallReturn(ret,client);
	#ifdef PRINTSYSCALLMSG
		fprintf(stderr,"VirServMsg:Linux Syscall newuname ends........\n\n");
	#endif
}

_syscall5(long, tl_llseek, unsigned int, fd, unsigned long, offset_high,
	unsigned long, offset_low, long long *, result, unsigned int, origin)
void 
VirtServRange::LinuxSyscallllseekServer(DeviceExc* client)
{
	long long* result;
	uint32 physaddr;
	bool cacheable;
	long ret;

	#ifdef PRINTSYSCALLMSG
		fprintf(stderr,"VirServMsg:%d:Linux Syscall llseek...:fd->%d, off_high->0x%x, off_low->0x%x, result->0x%x, origin->%d\n",
			4000+LinuxSyscallllseekservno,GetReg(0),GetReg(1),GetReg(2),GetReg(3),GetReg(4));
	#endif
	
	result=(long long*)AddressTranslation(GetReg(3),client,WRITEPARAMETER,&physaddr,&cacheable);
	SyncMemAndCache(GetReg(3),physaddr,(char*)result,sizeof(long long),SYNCMEMTOCACHE,cacheable,client);
	ret=tl_llseek(GetReg(0),GetReg(1),GetReg(2),result,GetReg(4));
	
	#ifdef PRINTSYSCALLMSG
		fprintf(stderr,"VirServMsg:Linux Syscall llseek:ret->0x%x, result_high->0x%x,result_low->0x%x\n",
			ret, ((long*)result)[1],((long*)result)[0]);
	#endif
	HandlingSysCallReturn(ret,client);
}

_syscall5(long, tl_newselect, int, n, fd_set *, inp, fd_set *, outp,
	fd_set *, exp, struct timeval *, tvp)
void 
VirtServRange::LinuxSyscallnewselectServer(DeviceExc* client)
{
	fd_set* inp;
	fd_set* outp;
	fd_set* exp;
	struct timeval* tvp;
	uint32 physaddr;
	bool cacheable;
	long ret;

	#ifdef PRINTSYSCALLMSG
		fprintf(stderr,"VirServMsg:%d:Linux Syscall newselect...0x%x,0x%x,0x%x,0x%x,0x%x\n",
		4000+LinuxSyscallnewselectservno,GetReg(0),GetReg(1),GetReg(2),
		GetReg(3),GetReg(4));
	#endif
	
	inp=(fd_set*)AddressTranslation(GetReg(1),client,WRITEPARAMETER,&physaddr,&cacheable);
	SyncMemAndCache(GetReg(1),physaddr,(char*)inp,sizeof(fd_set),SYNCMEMTOCACHE,cacheable,client);
	outp=(fd_set*)AddressTranslation(GetReg(2),client,WRITEPARAMETER,&physaddr,&cacheable);
	SyncMemAndCache(GetReg(2),physaddr,(char*)outp,sizeof(fd_set),SYNCMEMTOCACHE,cacheable,client);
	exp=(fd_set*)AddressTranslation(GetReg(3),client,WRITEPARAMETER,&physaddr,&cacheable);
	SyncMemAndCache(GetReg(3),physaddr,(char*)exp,sizeof(fd_set),SYNCMEMTOCACHE,cacheable,client);
	tvp=(struct timeval*)AddressTranslation(GetReg(4),client,WRITEPARAMETER,&physaddr,&cacheable);
	SyncMemAndCache(GetReg(4),physaddr,(char*)tvp,sizeof(fd_set),SYNCMEMTOCACHE,cacheable,client);
	ret=tl_newselect(GetReg(0),inp,outp,exp,tvp);

	#ifdef PRINTSYSCALLMSG
	fprintf(stderr,"retval->%d\n",ret);
	#endif
	HandlingSysCallReturn(ret,client);
}

_syscall3(long,tlftruncate64,unsigned int, fd, long, lenlow,long, lenhigh)
void
VirtServRange::LinuxSyscallftruncate64Server(DeviceExc* client)
{
	long ret;

	ret=tlftruncate64(GetReg(0),GetReg(2),GetReg(3));
	#ifdef PRINTSYSCALLMSG
	fprintf(stderr,"VirServMsg:%d:Linux Syscall ftruncate64...:reg0->0x%x,reg1->0x%x,
	reg2->0x%x,reg3->0x%x,fd->0x%x,len_low->0x%x,len_high->0x%x,ret->0x%x\n",
	4000+LinuxSyscallftruncate64servno,GetReg(0),GetReg(1),GetReg(2),GetReg(3),
	GetReg(0),GetReg(2),GetReg(3),ret);
	#endif
	HandlingSysCallReturn(ret,client);
}

void CopyStat64(struct stat64for386* statlocalptr, struct stat64formips* statbuf, long long* buf)
{
	if(statlocalptr==NULL||statbuf==NULL){
		fprintf(stderr,"VirtServError:SyscallError:when copying local fstat64 to mips!\n");
		return;
	}
	
	(*(unsigned long*)(buf++))=(unsigned long)statlocalptr->st_dev;
	(*(unsigned long*)(buf++))=(unsigned long)statlocalptr->st_ino;
	(*(unsigned int*)(buf++))=(unsigned int)statlocalptr->st_mode;
	(*(int*)(buf++))=(int)statlocalptr->st_nlink;
	(*(int*)(buf++))=(int)statlocalptr->st_uid;
	(*(int*)(buf++))=(int)statlocalptr->st_gid;
	(*(unsigned long*)(buf++))=(unsigned long)statlocalptr->st_rdev;
	(*(long long*)(buf++))=(long long)statlocalptr->st_size;
	(*(long*)(buf++))=(long)statlocalptr->st_accesstime;
	(*(long*)(buf++))=(long)statlocalptr->st_modifytime;
	(*(long*)(buf++))=(long)statlocalptr->st_createtime;
	(*(unsigned long*)(buf++))=(unsigned long)statlocalptr->st_blksize;
	(*(long long*)(buf++))=(long long)statlocalptr->st_blocks;
	
	#ifdef PRINTSYSCALLMSG
	fprintf(stderr,"VirtServ stat64...\n");
	fprintf(stderr,"st_dev->0x%x\n",(long)statlocalptr->st_dev);
	fprintf(stderr,"st_ino->0x%x\n",(long)statlocalptr->st_ino);
	fprintf(stderr,"st_mode->0x%x\n",(long)statlocalptr->st_mode);
	fprintf(stderr,"st_nlink->0x%x\n",(long)statlocalptr->st_nlink);
	fprintf(stderr,"st_uid->0x%x\n",(long)statlocalptr->st_uid);
	fprintf(stderr,"st_gid->0x%x\n",(long)statlocalptr->st_gid);
	fprintf(stderr,"st_rdev->0x%x\n",(long)statlocalptr->st_rdev);
	fprintf(stderr,"st_size->0x%x\n",(long)statlocalptr->st_size);
	fprintf(stderr,"st_accesstime->0x%x\n",(long)statlocalptr->st_accesstime);
	fprintf(stderr,"st_modifytime->0x%x\n",(long)statlocalptr->st_modifytime);
	fprintf(stderr,"st_createtime->0x%x\n",(long)statlocalptr->st_createtime);
	fprintf(stderr,"st_blksize->0x%x\n",(long)statlocalptr->st_blksize);
	fprintf(stderr,"st_blocks->0x%x\n",(long)statlocalptr->st_blocks);
	#endif
} 
_syscall3(long,tlstat64,char *, filename,struct stat64for386*,statbuf,long,flags)
_syscall3(long,tllstat64,char *, filename,struct stat64for386*,statbuf,long,flags)
_syscall3(long,tlfstat64,unsigned long, fd,struct stat64for386*,statbuf,long,flags)
void 
VirtServRange::LinuxSyscallfstat64Server(DeviceExc* client, long syscallnum)
{	 
	struct stat64for386 statlocal;
	struct stat64for386* statlocalptr;
	char* filename=NULL;
	uint32 physaddr;
	bool cacheable;
	long ret=0;

	#ifdef PRINTSYSCALLMSG
	if(syscallnum==LinuxSyscallstat64servno)
		fprintf(stderr,"VirServMsg:%d:Linux Syscall stat64...:filename->0x%x statbuf->0x%x flags->0x%x\n",
			4000+LinuxSyscallstat64servno,GetReg(0),GetReg(1),GetReg(2));
	else if(syscallnum==LinuxSyscalllstat64servno)
		fprintf(stderr,"VirServMsg:%d:Linux Syscall lstat64...:filename->0x%x statbuf->0x%x flags->0x%x\n",
			4000+LinuxSyscalllstat64servno,GetReg(0),GetReg(1),GetReg(2));
	else if(syscallnum==LinuxSyscallfstat64servno)
		fprintf(stderr,"VirServMsg:%d:Linux Syscall fstat64...:fd->%d statbuf->0x%x flags->0x%x\n",
			4000+LinuxSyscallfstat64servno,GetReg(0),GetReg(1),GetReg(2));
	#endif

	if(syscallnum!=LinuxSyscallfstat64servno){
		filename=AddressTranslation(GetReg(0),client,READPARAMETER,&physaddr,&cacheable);
		SyncMemAndCache(GetReg(0),physaddr,filename,DEFAULTLEN,SYNCCACHETOMEM,cacheable,client);
	}
	if((struct stat64formips*)(GetReg(1))==NULL)
		statlocalptr=NULL;
	else 
		statlocalptr=&statlocal;
	if(syscallnum==LinuxSyscallstat64servno)
		ret=tlstat64(filename, statlocalptr, GetReg(2));
	else if(syscallnum==LinuxSyscalllstat64servno)
		ret=tllstat64(filename, statlocalptr, GetReg(2));
	else if(syscallnum==LinuxSyscallfstat64servno)
		ret=tlfstat64(GetReg(0), statlocalptr, GetReg(2));
	
	if(ret>=0)
		CopyStat64(statlocalptr, (struct stat64formips*)GetReg(1), VirtServBuffers);
	fprintf(stderr,"\n");
	HandlingSysCallReturn(ret,client); 

}

/*TopsyAssistantServer:some assistant functions used in Topsy*/
void 
VirtServRange::StartTopsyAssistantServer(uint8 data, DeviceExc *client)
{
	switch(data){
		case ioConsolePutStringservno:
			ioConsolePutStringServer(client);
			break;
		case ioConsolePutHexIntservno:
			ioConsolePutHexIntServer(client);
			break;
		case stringoutservno:
			stringoutServer(client);
			break;
		case stringinservno:
			stringinServer(client);
			break;
		case redirectstdioservno:
			redirectstdioServer(client);
			break;
		case deredirectstdioservno:
			deredirectstdioServer(client);
			break;
		case changecwdservno:
			ChangeCWDServer(client);
			break;
		case recovercwdservno:
			RecoverCWDServer(client);
			break;
		case printfnullservno:
			printfnullServer(client);
			break;
		case printfstrservno:
			printfstrServer(client);
			break;
		case printfnumservno:
			printfnumServer(client);
			break;
		case memsetservno:
			memsetServer(client);
			break;
		case TAgetcwdservno:
			TAgetcwdServer(client);
			break;
		case TAlssimulationservno:
			TAlssimulationServer(client);
			break;
		case TAgetenvservno:
			TAgetenvServer(client);
			break;
		case TAmmmappinginfoservno:
			TAmmmappinginforServer(client);
			break;
		case TAappnameservno:
			TAappnameServer(client);
			break;
		case TAinvalidcacheservno:
			TAinvalidcacheServer(client);
			break;
		case TAgetallenvservno:
			TAgetallenvServer(client);
			break;
		default:
			fprintf(stderr,"VirtServError:TopsyAssistantServError:Server %d not implemented!\n",data);
			break;
	}
}

//simulation of Topsy function ioConsolePutString(char* buf) ; to stderr
void
VirtServRange::ioConsolePutStringServer(DeviceExc* client)
{
	char* buf;
	uint32 physaddr;
	bool cacheable;
	
	buf=AddressTranslation(GetReg(0),client,READPARAMETER,&physaddr,&cacheable);
	SyncMemAndCache(GetReg(0),physaddr,buf,DEFAULTLEN,SYNCCACHETOMEM,cacheable,client);
	#ifdef DEBUGTopsyAssistantServer
	fprintf(stderr,"VirtServMsg:ioConsolePutStringServer");
	if(buf)
		fprintf(stderr,":buf->%s",buf);
	fprintf(stderr,"\n");
	#endif
	fprintf(stderr,"%s",buf);
	fflush(stderr);
}

//simulation of Topsy function ioConsolePutHexInt(long data); to stderr
void 
VirtServRange::ioConsolePutHexIntServer(DeviceExc* client)
{
	#ifdef DEBUGTopsyAssistantServer
	fprintf(stderr,"VirtServMsg:ioConsolePutHexIntServer...\n");
	#endif
	fprintf(stderr,"%x\n",GetReg(0));
	fflush(stderr);
}

//simulation of Topsy function stringout(char* buf); to stderr
void 
VirtServRange::stringoutServer(DeviceExc* client)
{
	char* buf;
	uint32 physaddr;
	bool cacheable;
	
	buf=AddressTranslation(GetReg(0),client,READPARAMETER,&physaddr,&cacheable);
	SyncMemAndCache(GetReg(0),physaddr,buf,DEFAULTLEN,SYNCCACHETOMEM,cacheable,client);
	#ifdef DEBUGTopsyAssistantServer
	fprintf(stderr,"VirtServMsg:stringoutServer");
	if(buf)
		fprintf(stderr,":buf->%s",buf);
	fprintf(stderr,"\n");
	#endif
	fprintf(stderr,"%s",buf);
	fflush(stderr);
}

//simulation of Topsy function stringin(char* buf)
char* getstring(char* buf,long len,long fd)
{
	long count;
	long ret;
	
	for(count=0;count<len-1;count++){
		ret=read(fd,&buf[count],1);
		if(ret<0) {
			buf[count]='\0';
			return NULL;
		}
		if((ret==0)||(buf[count]=='\n'))
			break;
	}
	buf[count+1]='\0';
	return buf;
}
void 
VirtServRange::stringinServer(DeviceExc* client)
{
	char* buf;
	uint32 physaddr;
	bool cacheable;
	char* ret;

	buf=AddressTranslation(GetReg(0),client,WRITEPARAMETER,&physaddr,&cacheable);
	SyncMemAndCache(GetReg(0),physaddr,buf,GetReg(1),SYNCMEMTOCACHE,cacheable,client);
	//ret=fgets(buf,GetReg(1),stdin);
	ret=getstring(buf,GetReg(1),redirectfds.currfds[0]);
	#ifdef DEBUGTopsyAssistantServer
	fprintf(stderr,"VirtServMsg:stringinServer");
	if(ret!=NULL)
		fprintf(stderr,":buf->%s",buf);
	fprintf(stderr,"\n");
	fflush(stderr);
	#endif
	HandlingLibcReturn((long)ret,errno,client);
}

//two functions for redirection of stdio
void 
VirtServRange::redirectstdioServer(DeviceExc* client)
{
	long count;
	long fd;
	
	for(count=0;count<STDIONUM;count++){
		fd=GetReg(count);
		if((fd<0)&&(fd!=NOTDIRECT)){
			fprintf(stderr,"VirtServ err:redirectstdioServer!\n");
			HandlingLibcReturn(REDIRECTFAILED,errno,client);
			return;
		}
		if(fd==NOTDIRECT){
			if(tstdio_inheritflag)
				redirectfds.currfds[count]=redirectfds.globalfds[count];
			else
				redirectfds.currfds[count]=redirectfds.appfds[count];
		}
		else
			redirectfds.currfds[count]=fd;
	}
	HandlingLibcReturn(REDIRECTOK,errno,client);
}

void 
VirtServRange::deredirectstdioServer(DeviceExc* client)
{
	long count;

	for(count=0;count<STDIONUM;count++){
		if(redirectfds.currfds[count]==NOTDIRECT)
			fprintf(stderr,"VirtServ err:deredirectstdioServer:catch NOTDIRECT currfds!\n");
		if(redirectfds.globalfds[count]==NOTDIRECT)
			fprintf(stderr,"VirtServ err:deredirectstdioServer:catch NOTDIRECT globalfds!\n");
		redirectfds.currfds[count]=redirectfds.globalfds[count];
	}
}

//two functions for changing or recovering cwd
//when returning 0:failed  1:ok
void 
VirtServRange::ChangeCWDServer(DeviceExc* client)
{
  	char* pathname;
	char* fullpath;
	uint32 physaddr;
	bool cacheable;
	long pathlen;
	long retval=CWDFAILED;

	pathname=AddressTranslation(GetReg(0),client,READPARAMETER,&physaddr,&cacheable);
	SyncMemAndCache(GetReg(0),physaddr,pathname,DEFAULTLEN,SYNCCACHETOMEM,cacheable,client);
	strcpy(topsycwd.globalCWD,topsycwd.currCWD); //save old cwd for shell
	while(*pathname==' ') pathname++;
	fullpath=pathname;
	if(pathname[0]!='/'){
		pathlen=strlen(topsycwd.currCWD);
		fullpath=(char*)malloc(pathlen+strlen(pathname)+2);
		if(!fullpath){
			fprintf(stderr,"VirtServ err:ChangeCWDServer:can not malloc for path!\n");
			goto out;
		}
		strcpy(fullpath,topsycwd.currCWD);
		fullpath[pathlen]='/';
		strcpy(fullpath+pathlen+1,pathname);
	}
	#ifdef DBGCWD
	fprintf(stderr,"VirtServ msg:ChangeCWDServer:fullpath->%s\n",fullpath);
	#endif
	if(strlen(fullpath)>=MAXCWDLEN){
		fprintf(stderr,"VirtServ msg:ChangeCWDServer:path is too long!\n");
		goto out;
	}
	if(chdir(fullpath)<0){
		fprintf(stderr,"VirtServ msg:ChangeCWDServer:can not change cwd!!!\n");
		goto out;
	}
	strcpy(topsycwd.currCWD,fullpath);
	retval=CWDOK;
	#ifdef DBGCWD
	fprintf(stderr,"VirtServ msg:ChangeCWDServer:\n");
	fprintf(stderr,"globalCWD:%s\n",topsycwd.globalCWD);
	fprintf(stderr,"currCWD:%s\n",topsycwd.currCWD);
	fprintf(stderr,"localCWD:%s\n",topsycwd.localCWD);
	#endif
out:
	HandlingLibcReturn(retval,errno,client);
}

void 
VirtServRange::RecoverCWDServer(DeviceExc* client)
{
	if(chdir(topsycwd.globalCWD)<0){
		fprintf(stderr,"VirtServ err:RecoverCWDServer:can not recover cwd, if there is err, please check it !!!\n");
		return;
	}
	strcpy(topsycwd.currCWD, topsycwd.globalCWD);
	#ifdef DBGCWD
	fprintf(stderr,"VirtServ msg:RecoverCWDServer:\n");
	fprintf(stderr,"globalCWD:%s\n",topsycwd.globalCWD);
	fprintf(stderr,"currCWD:%s\n",topsycwd.currCWD);
	fprintf(stderr,"localCWD:%s\n",topsycwd.localCWD);
	#endif
}

//print str for Topsy; to stdout
void 
VirtServRange::printfnullServer(DeviceExc* client)
{
	char* str;
	uint32 physaddr;
	bool cacheable;
	
	#ifdef DEBUGTopsyAssistantServer
	fprintf(stderr,"VirtServMsg:printfnullServer...\n");
	#endif
	
	str=AddressTranslation(GetReg(0),client,READPARAMETER,&physaddr,&cacheable);
	SyncMemAndCache(GetReg(0),physaddr,str,DEFAULTLEN,SYNCCACHETOMEM,cacheable,client);
	printf(str);
	fflush(stdout);
}

//print string for Topsy; to stdout
void 
VirtServRange::printfstrServer(DeviceExc* client)
{
	char* mode;
	char* outputstr;
	uint32 physaddr;
	bool cacheable;
	
	#ifdef DEBUGTopsyAssistantServer
	fprintf(stderr,"VirtServMsg:printfstrServer...\n");
	#endif
	
	mode=AddressTranslation(GetReg(0),client,READPARAMETER,&physaddr,&cacheable);
	SyncMemAndCache(GetReg(0),physaddr,mode,DEFAULTLEN,SYNCCACHETOMEM,cacheable,client);
	outputstr=AddressTranslation(GetReg(1),client,READPARAMETER,&physaddr,&cacheable);
	SyncMemAndCache(GetReg(1),physaddr,outputstr,DEFAULTLEN,SYNCCACHETOMEM,cacheable,client);
	#ifdef DEBUGTopsyAssistantServer
	fprintf(stderr,"VirtServMsg:printfstrServer:mode->%s, str->%s\n",mode,outputstr);
	#endif
	printf(mode,outputstr);
	fflush(stdout);
}

//print number for Topsy; to stdout
void 
VirtServRange::printfnumServer(DeviceExc* client)
{
	char* mode;
	uint32 physaddr;
	bool cacheable;
	
	#ifdef DEBUGTopsyAssistantServer
	fprintf(stderr,"VirtServMsg:printfnumServer...\n");
	#endif
	
	mode=AddressTranslation(GetReg(0),client,READPARAMETER,&physaddr,&cacheable);
	SyncMemAndCache(GetReg(0),physaddr,mode,DEFAULTLEN,SYNCCACHETOMEM,cacheable,client);
	#ifdef DEBUGTopsyAssistantServer
	fprintf(stderr,"VirtServMsg:printfnumServer:mode->%s, num->%d\n",mode,GetReg(1));
	#endif
	printf(mode,GetReg(1));
	fflush(stdout);
}

//simulation of void* memset(void* base, int c, int count) for os
void 
VirtServRange::memsetServer(DeviceExc* client)
{
	char* base;
	uint32 physaddr;
	bool cacheable;
	char* ret;

	base=AddressTranslation(GetReg(0),client,WRITEPARAMETER,&physaddr,&cacheable);
	SyncMemAndCache(GetReg(0),physaddr,base,GetReg(2),SYNCMEMTOCACHE,cacheable,client);
	ret=(char*)memset(base, GetReg(1), GetReg(2));
	HandlingLibcReturn((long)ret,errno,client);
}

//long TAgetcwd(char* buf, long size, long mode)
void 
VirtServRange::TAgetcwdServer(DeviceExc* client)
{
	char* buf;
	uint32 physaddr;
	bool cacheable;
	char* tmpbuf;
	long count;
	long start;

	buf=AddressTranslation(GetReg(0),client,WRITEPARAMETER,&physaddr,&cacheable);
	SyncMemAndCache(GetReg(0),physaddr,buf,GetReg(1),SYNCMEMTOCACHE,cacheable,client);
	if((tmpbuf=(char*)malloc(MAXCWDLEN))==NULL){
		fprintf(stderr,"VirtServ err:TAgetcwdServer: can not get space for cwd!\n");
		HandlingLibcReturn(TAGETCWDFAILED,errno,client);
		return;
	}
	if(getcwd(tmpbuf, MAXCWDLEN)==NULL){
		fprintf(stderr,"VirtServ err:TAgetcwdServer: can not get cwd!\n");
		HandlingLibcReturn(TAGETCWDFAILED,errno,client);
		goto outfree;
	}
	count=strlen(tmpbuf);
	if(GetReg(2)==TAGETCWDABSOLUTE){
		if(count>=(long)GetReg(1)){
			HandlingLibcReturn(TAGETCWDFAILED,errno,client);
			goto outfree;
		}
		strcpy(buf, tmpbuf);
		HandlingLibcReturn(TAGETCWDOK,errno,client);
		goto outfree;
	}
	start=count-1;
	while((start>=0)&&(tmpbuf[start]!='/')) start--;
	if(start<0) { start=0; goto out;}
	if(count==1) {start=0; goto out;}
	start++;
	count=strlen(tmpbuf+start);
	
out:
	if(count>=(long)GetReg(1)){
		HandlingLibcReturn(TAGETCWDFAILED,errno,client);
		goto outfree;
	}
	strcpy(buf,(char*)(tmpbuf+start));
	HandlingLibcReturn(TAGETCWDOK,errno,client);
outfree:
	free(tmpbuf);
}

//simulation of ls, char* format is options of ls,now is not used
#define S_ISEXE(mode) (mode&S_IXUSR)
bool outputfilenamebytype(char* filename)
{
	//c function stat64() and type struct stat64:
	//When the sources are compiled with _FILE_OFFSET_BITS == 64 
	//the function and the type are available
	//#define LS_USESTAT

	#ifdef LS_USESTAT
	struct stat statbuf; 
	#else
	struct stat64 statbuf;
	#endif
	char dircolor[]= { 27,'[','3','3','m',0}; //yellow
	char execolor[]= { 27,'[','3','2','m',0}; //green
	char normalcolor[]= { 27,'[','0','m',0}; //reset
	
	#ifdef LS_USESTAT
	if(stat(filename,&statbuf)==-1) { 
	#else
	if(stat64(filename,&statbuf)==-1) { 
	#endif
		fprintf(stderr,"VirtServ err:outputfilenamebytype: can not stat file:%s!\n",filename);
		return false;
	} 
	if(S_ISDIR(statbuf.st_mode)){//is dir
		printf("%s%-25s%s",dircolor,filename,normalcolor);
	}else if(S_ISREG(statbuf.st_mode)) {//normal file
		if(S_ISEXE(statbuf.st_mode))//exe
			printf("%s%-25s%s",execolor,filename,normalcolor);
		else
			printf("%-25s",filename);//other normal file
	}else{
		printf("%-25s",filename);//other file types
	}

	return true;
}
void 
VirtServRange::TAlssimulationServer(DeviceExc* client)
{
	char* format;
	uint32 physaddr;
	bool cacheable;
	char* buf;
	DIR *dirp; 
	struct dirent *direntp; 
	long countforline;
	#define FILENAMENUMONELINE 3
	#define MAXFILENAMELEN 25
	
	format=AddressTranslation(GetReg(0),client,READPARAMETER,&physaddr,&cacheable);
	SyncMemAndCache(GetReg(0),physaddr,format,DEFAULTLEN,SYNCCACHETOMEM,cacheable,client);

	if((buf=(char*)malloc(MAXCWDLEN))==NULL){
		fprintf(stderr,"VirtServ err:TAlssimulationServer: malloc failed!\n");
		return;
	}
	if(getcwd(buf, MAXCWDLEN)==NULL){
		fprintf(stderr,"VirtServ err:TAlssimulationServer: can not get cwd!\n");
		goto out1;
	}

	if((dirp=opendir(buf))==NULL) { 
		fprintf(stderr,"VirtServ err:TAlssimulationServer: can not open cwd!\n");
		goto out1;
	} 
	countforline=0;
	while((direntp=readdir(dirp))!=NULL) {
		if(!strcmp(direntp->d_name,".")) continue;
		if(!strcmp(direntp->d_name,"..")) continue;
		if(!outputfilenamebytype(direntp->d_name)) goto out2;
		countforline++;
		if(countforline==FILENAMENUMONELINE){
			printf("\n");
			countforline=0;
		}
	}
	if(countforline!=0) printf("\n");

out2:
	closedir(dirp);
out1:
	free(buf);
}

//topsy assistant function to get env; char* TAgetenv(char* envname,char* buf,long maxlen)
//if not exist, return NULL
void 
VirtServRange::TAgetenvServer(DeviceExc* client)
{
	char* envname;
	char* buf;
	uint32 physaddr;
	bool cacheable;
	char* env;
	long len;
	long count;

	envname=AddressTranslation(GetReg(0),client,READPARAMETER,&physaddr,&cacheable);
	SyncMemAndCache(GetReg(0),physaddr,envname,DEFAULTLEN,SYNCCACHETOMEM,cacheable,client);
	buf=AddressTranslation(GetReg(1),client,WRITEPARAMETER,&physaddr,&cacheable);
	SyncMemAndCache(GetReg(1),physaddr,buf,GetReg(2),SYNCMEMTOCACHE,cacheable,client);

	env=getenv(envname);
	if(env){
		len=strlen(env);
		len=(len>(long)(GetReg(2)-1))? (long)(GetReg(2)-1) : len;
		for(count=0;count<len;count++)
			buf[count]=env[count];
		buf[count]=0;
	}
	
	HandlingLibcReturn((long)env,errno,client);
}

//by this function, Topsy tell vmips the memory mapping
//simulation of Topsy function void mmmappinginfotovmips(mmmapping_t* mappingptr)
void 
VirtServRange::TAmmmappinginforServer(DeviceExc* client)
{
	mmmapping_t* mappingptr;
	uint32 physaddr;
	bool cacheable;

	mappingptr=(mmmapping_t*)AddressTranslation(GetReg(0),client,READPARAMETER,&physaddr,&cacheable);
	SyncMemAndCache(GetReg(0),physaddr,(char*)mappingptr,sizeof(mmmapping_t),SYNCCACHETOMEM,cacheable,client);
	UserInfo.usermmmapping=*mappingptr;
	#ifdef DEBUGTopsyAssistantServer
	fprintf(stderr,"VirtServ msg:TAmmmappinginforServer:begins...\n");
	fprintf(stderr,"usermmmapping struct:\n");
	fprintf(stderr,"codeseg: physbase->0x%x, virtbase->0x%x, size->0x%x\n",
		UserInfo.usermmmapping.codeseg.physbase,
		UserInfo.usermmmapping.codeseg.virtbase,
		UserInfo.usermmmapping.codeseg.size);
	fprintf(stderr,"dataseg: physbase->0x%x, virtbase->0x%x, size->0x%x\n",
		UserInfo.usermmmapping.dataseg.physbase,
		UserInfo.usermmmapping.dataseg.virtbase,
		UserInfo.usermmmapping.dataseg.size);
	fprintf(stderr,"brk_dynamic: physbase->0x%x, virtbase->0x%x, size->0x%x\n",
		UserInfo.usermmmapping.brk_dynamic.physbase,
		UserInfo.usermmmapping.brk_dynamic.virtbase,
		UserInfo.usermmmapping.brk_dynamic.size);
	fprintf(stderr,"mmmap_dynamic: physbase->0x%x, virtbase->0x%x, size->0x%x\n",
		UserInfo.usermmmapping.mmmap_dynamic.physbase,
		UserInfo.usermmmapping.mmmap_dynamic.virtbase,
		UserInfo.usermmmapping.mmmap_dynamic.size);
	fprintf(stderr,"stackseg: physbase->0x%x, virtbase->0x%x, size->0x%x\n",
		UserInfo.usermmmapping.stackseg.physbase,
		UserInfo.usermmmapping.stackseg.virtbase,
		UserInfo.usermmmapping.stackseg.size);
	fprintf(stderr,"VirtSer msg:TAmmmappinginforServer:ends.\n");
	#endif
}

//simulation of void TAappnametovmips(char* appname)
//tell vmips the appname
void 
VirtServRange::TAappnameServer(DeviceExc* client)
{
	char* appname;
	uint32 physaddr;
	bool cacheable;
	long len,count;

	appname=AddressTranslation(GetReg(0),client,READPARAMETER,&physaddr,&cacheable);
	SyncMemAndCache(GetReg(0),physaddr,appname,DEFAULTLEN,SYNCCACHETOMEM,cacheable,client);
	len=strlen(appname)+1;
	len=len>MAXFILENAME? MAXFILENAME: len;
	for(count=0;count<len;count++)
		UserInfo.appname[count]=appname[count];
	UserInfo.appname[count]='\0';
	#ifdef DEBUGTopsyAssistantServer
	fprintf(stderr,"VirtServ msg:TAappnameServer:appname->%s\n",UserInfo.appname);
	#endif
}

//a Topsy assistant function to invalidate all the cache
void 
VirtServRange::TAinvalidcacheServer(DeviceExc* client)
{
	CPU* cpu=(CPU*)client;
	Addr* addr=cpu->GetAddr();
	CACHE* cache=addr->cache;

	if(cpu ->Get_opt_cacheable())
		cache->invalidate( );
}

//get all the environment variables
//simulation of long TAgetallenv(char* buf,long maxlen)
//the return value is the envc
//when failed, the return value is 0
extern char**environ;
void 
VirtServRange::TAgetallenvServer(DeviceExc* client)
{
	char* buf;
	uint32 physaddr;
	bool cacheable;
	char** env;
	long len;
	long count=0;
	long maxlen=GetReg(1);
	long envc=0;

	buf=AddressTranslation(GetReg(0),client,WRITEPARAMETER,&physaddr,&cacheable);
	SyncMemAndCache(GetReg(0),physaddr,buf,GetReg(1),SYNCMEMTOCACHE,cacheable,client);

	for (env =environ;*env !=NULL;++env){
		len=strlen(*env)+1;
		if(count+len>maxlen){
			fprintf(stderr,"VirtServ warning:TAgetallenvServer:buf is not enough!\n");
			goto out;
		}
		strcpy(buf+count,*env);
		count+=len;
		envc++;
	}

out:	
	HandlingLibcReturn(envc,errno,client);
}

/*other server*/

