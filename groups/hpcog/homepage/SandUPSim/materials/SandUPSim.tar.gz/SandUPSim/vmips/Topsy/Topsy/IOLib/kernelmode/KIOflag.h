#ifndef KIOFLAG_H
#define KIOFLAG_H

#include "KVirtServ.h"
#include "SoftIOConsoleOpt.h"

#ifndef IOALWAYSVIRT
extern long VIRTSERVFLAG;
#define IOCOMMONVIRTSERVFLAG VIRTSERVFLAG
#else
#define IOCOMMONVIRTSERVFLAG 1
#endif

#endif

