/*
	Copyright (c) 1996-1997 Swiss Federal Institute of Technology, 
	Computer Engineering and Networks Laboratory. All rights reserved.

	TOPSY - A Teachable Operating System. 
		Implementation of a tiny and simple micro kernel for
		teaching purposes.

	Permission to use, copy, modify, and distribute this software and its
	documentation for any purpose, without fee, and without written 
	agreement is hereby granted, provided that the above copyright notice 
	and the following two paragraphs appear in all copies of this software.


	
	File:                  $Source: /work/cvs/cvsroot/Topsy/Threads/TMThread.c,v $
 	Author(s):             Christian Conrad
 	Affiliation:           ETH Zuerich, TIK
 	Version:               $Revision: 1.26 $
 	Creation Date:         
 	Last Date of Change:   $Date: 2004/03/07 15:11:04 $      by: $Author: slfsmm $
	
	
*/

#include "TMThread.h"
#include "TMScheduler.h"
#include "TMHal.h"
#include "TMIPC.h"
#include "TMMain.h"
#include "HashList.h"
#include "List.h"
#include "Lock.h"
#include "Syscall.h"
#include "Support.h"
#include "limits.h"
#include "MMMapping.h"
#include "MMVirtualMemory.h"
#include "loadelf.h"
#include "SoftIOConsole.h"
#include "loadelf.h"
#include "elf.h"
#define noRunningThreadString "(in init)"
#define MAXUSERTHREADID    LONG_MAX
#define MAXKERNELTHREADID  LONG_MIN

/*added by xjw 2003.12.16*/
#ifdef OPEN_TRACE
#include "VirtServEntry.h"
#endif
/*added by xjw ends*/
//which process calls threaddestroy?
#define THREADDESTROY_EXIT 0
#define THREADDESTROY_KILL 1

//used in thread creating
//#define TRACETHREADSTART
extern unsigned long userstackbase;
extern long PAGETABLEPHYSBASE;
//command line
extern commandlineformat_t cmdlineformat;
//environment variables
extern envvar_t envvar_format;
//Auxillary Vectors
extern auxvec_t aux_vec;

HashList threadHashList=NULL;            /* Hash list of all threads */
extern List threadList;             /* Contains all threads (user & kernel) */

LockDesc threadLockDesc;            /* lock to protect global thread lists */
Lock threadLock = &threadLockDesc;

extern ThreadId nextUserThreadId;   /* from TMMain */
extern ThreadId nextKernelThreadId;
int exceptionContextFlag = 0;       /* Set to 1 for exception context */

/*
 * Get a new thread id
 */
ThreadId getThreadId(AddressSpace space)
{
    Thread* threadPtr;
    int wraps = 0;
    Error ret;
    
    if (space == KERNEL) {
    	while (TRUE) {
	    if (nextKernelThreadId > 0) { /* negative kernel id underflow */
		wraps++;
		if (wraps == 2) PANIC("out of kernel thread id's");
		nextKernelThreadId = FIRST_KERNELTHREAD;
	    }
	    ret = hashListGet(threadHashList, (void**)(&threadPtr), 
			      nextKernelThreadId); 
	    if (ret == HASHNOTFOUND) return nextKernelThreadId--;
	    nextKernelThreadId--;
	}
    }
    else {
    	while (TRUE) {
	    if (nextUserThreadId < 0) { /* positive user id overflow */
		wraps++;
		if (wraps == 2) PANIC("out of user thread id's");
		nextUserThreadId = FIRST_USERTHREAD;
	    }
	    ret = hashListGet(threadHashList, (void**)(&threadPtr), 
			      nextUserThreadId); 
	    if (ret == HASHNOTFOUND) return nextUserThreadId++;
	    nextUserThreadId++;
	}
    }
    return 0;
}

/* This procedure initializes a thread structure. resources are passed as
 * arguments so threadBuild doesn't need to know about memory allocation.
 */
 //#define DBGARGENVAUX
 Register arrange_arg_env_aux(Register sp)
{
	long argc=cmdlineformat.argc;
	long envc=envvar_format.envc;
	long* arg_env_arr;
	long cmdlinelen=cmdlineformat.cmdlinelen;
	char* cmdlinebase;
	long envlen=envvar_format.envlen;
	char* envbase;

	#define DLINFO_ITEMS 13
	long auxc=DLINFO_ITEMS;
	long* aux_arr;
	
	#define GAP 4
	#define STACKALIGN 16
	#define STACKALIGNMASK 0xfffffff0
	long count;
	char* ptr;

	sp=(sp-GAP)&STACKALIGNMASK; //GAP
	zeroOut((Address)sp,GAP);
	#ifdef DBGARGENVAUX
	ioConsolePutString("arrange_arg_env_aux begins...\n");
	ioConsolePutString("GAP base:0x");
	ioConsolePutHexInt(sp);
	#endif

	sp=(sp-envlen)&STACKALIGNMASK; //env string
	envbase=(char*)sp;
	//copy env
	byteCopy(envbase,envvar_format.env_vars,envlen);
	#ifdef DBGARGENVAUX
	ioConsolePutString("env string base:0x");
	ioConsolePutHexInt(sp);
	#endif

	sp=(sp-cmdlinelen)&STACKALIGNMASK; //command line string
	cmdlinebase=(char*)sp;
	byteCopy(cmdlinebase,cmdlineformat.cmdlinebase,cmdlinelen);
	#ifdef DBGARGENVAUX
	ioConsolePutString("cmdline string base:0x");
	ioConsolePutHexInt(sp);
	#endif

	//align
	count=(1+envc+1+argc+1)*4+(1+auxc)*2*4;
	sp=((sp-count)&STACKALIGNMASK)+count;

	sp=(sp-(auxc+1)*2*4); //aux arr
	aux_arr=(long*)sp;
	//arrange aux arr
#define NEW_AUX_ENT(nr, id, val) \
	aux_arr[nr*2]=(long)id;\
	aux_arr[nr*2+1]=(long)val;\
	
	NEW_AUX_ENT( 0, AT_HWCAP, 0);
	NEW_AUX_ENT( 1, AT_PAGESZ, PAGESIZE);
	NEW_AUX_ENT( 2, AT_CLKTCK, 0); //may be modified
	NEW_AUX_ENT( 3, AT_PHDR, aux_vec.a_phdr);
	NEW_AUX_ENT( 4, AT_PHENT, aux_vec.a_phent);
	NEW_AUX_ENT( 5, AT_PHNUM, aux_vec.a_phnum);
	NEW_AUX_ENT( 6, AT_BASE, aux_vec.a_base);
	NEW_AUX_ENT( 7, AT_FLAGS, 0);
	NEW_AUX_ENT( 8, AT_ENTRY, aux_vec.a_entry);
	NEW_AUX_ENT( 9, AT_UID, 0);
	NEW_AUX_ENT(10, AT_EUID, 0);
	NEW_AUX_ENT(11, AT_GID, 0);
	NEW_AUX_ENT(12, AT_EGID, 0);
	NEW_AUX_ENT(13, AT_NULL, 0);
	
#undef NEW_AUX_ENT
	#ifdef DBGARGENVAUX
	ioConsolePutString("aux arr base:0x");
	ioConsolePutHexInt(sp);
	#endif

	sp=(sp-(envc+1)*4); //env arr
	arg_env_arr=(long*)sp;
	//arrange env arr
	ptr=envbase;
	for(count=0;count<envc;count++){
		arg_env_arr[count]=(long)ptr;
		if(count!=envc-1)
			ptr+=stringlen(ptr)+1;
	}
	arg_env_arr[count]=0;
	#ifdef DBGARGENVAUX
	ioConsolePutString("env arr base:0x");
	ioConsolePutHexInt(sp);
	ioConsolePutString("envc:0x");
	ioConsolePutHexInt(envc);
	ioConsolePutString("env var:\n");
	for(count=0;count<envc;count++){
		ioConsolePutString((char*)arg_env_arr[count]);
		ioConsolePutString("\n");
	}
	#endif

	sp=(sp-(argc+1)*4); //argv
	arg_env_arr=(long*)sp;
	for(count=0;count<argc;count++)
		arg_env_arr[count]=(long)(cmdlinebase+cmdlineformat.argv[count]);
	arg_env_arr[count]=0;
	#ifdef DBGARGENVAUX
	ioConsolePutString("arg arr base:0x");
	ioConsolePutHexInt(sp);
	ioConsolePutString("argc:0x");
	ioConsolePutHexInt(argc);
	ioConsolePutString("arg:\n");
	for(count=0;count<argc;count++){
		ioConsolePutString((char*)arg_env_arr[count]);
		ioConsolePutString("\n");
	}
	#endif

	sp-=4;	//argc
	*((long*)sp)=argc;
	#ifdef DBGARGENVAUX
	ioConsolePutString("argc base:0x");
	ioConsolePutHexInt(sp);
	ioConsolePutString("arrange_arg_env_aux ends...\n");
	#endif

	return sp;
}

void threadBuild( ThreadId id,
		  ThreadId parentId,
		  char* name,
		  ProcContext* contextPtr,
		  Address stackBaseAddress, /* static address or 
					     * as obtained via vmAlloc */
		  unsigned int stackSize,
		  ThreadMainFunction mainFunction,
		  ThreadArg parameter,
		  AddressSpace space,
		  Boolean lightWeight,
		  Thread* threadPtr)
{
    Message threadExitMsg = {TMTHREADID, TM_EXIT, {{NULL, NULL, NULL}}};
    int exitCodeLength = endAutomaticThreadExit - automaticThreadExit;
	int messageLength=(sizeof(Message)%4)==0? 
		sizeof(Message): (sizeof(Message)&0xfffffffc)+4;
    Register mode;
    Register sp;
	/*slfsmm1>*/
	unsigned long * pagetableentry=(unsigned long *)(K1SEG_BASE+PAGETABLEPHYSBASE);
	unsigned long off;
	char *	phys;
	/*slfsmm1<*/

	/*slfsmm031121_add>Thread and ProcContext are now in kenel stack!*/
	zeroOut(contextPtr,sizeof(ProcContext));
	/*slfsmm031121_add<*/
	
    threadPtr->id = id;
    threadPtr->parentId = parentId;

    if (name != NULL) {
	stringNCopy(threadPtr->name, name, sizeof(threadPtr->name));
    }
    else {
	stringNCopy(threadPtr->name, "no name", sizeof(threadPtr->name));    
    }

    initMsgQueue( &(threadPtr->msgQueue));
    /* prepare the value of the status register of the new threads context
     * it is adjusted that the new thread runs either in user or kernel
     * mode with interrupts enabled.
     */
    if (space == USER) {
	schedulerInsert(threadPtr, USER_PRIORITY);
	mode = STATUS_INT_ENABLE_USER_PREV;
    } else {
	if (!lightWeight) {
	    schedulerInsert(threadPtr, KERNEL_PRIORITY);
	} else {
	    schedulerInsert(threadPtr, IDLE_PRIORITY);
	}
	mode = STATUS_INT_ENABLE_KERNEL_PREV; 
    }
    //if (!lightWeight) {
	threadPtr->stackStart = (char*)(stackBaseAddress) + stackSize - 4;
	threadPtr->stackEnd = stackBaseAddress;
    //} else {
	//threadPtr->stackStart = stackBaseAddress;
	//threadPtr->stackEnd = stackBaseAddress; /* should never be destroyed */
    //}	
    threadPtr->contextPtr = contextPtr;
    
    /* here we setup the context. register access is machine dependent, 
     * so this is done in TMHal
     */
    //if (!lightWeight) {
	/*slfsmm031121_mod>Thread and ProcContext are now in kenel stack!*/
    if(space==USER)
		sp = (Register)((char*)(threadPtr->stackStart) - messageLength - exitCodeLength);
	else
		sp=(Register)((char*)threadPtr->stackStart);
    //} else {
	//sp = (Register)(threadPtr->stackStart);
    //}

	*((long*)((char*)contextPtr-4))=(long)((char*)threadPtr+TM_DEFAULTTHREADSTACKSIZE);
	/*slfsmm031121_mod<*/
	
    tmSetStackPointer(threadPtr->contextPtr, sp);

    /* the code at sp+4 does an automatic exit() and will be executed
     * after the main procedure of the thread does a return without an exit()
     * see also the byteCopies a few lines below...
     */
    if(id<=0)
    	threadPtr->contextPtr->globalPointer=0xa00c0000;

    tmSetReturnAddress(threadPtr->contextPtr, sp + 4);
    tmSetProgramCounter(threadPtr->contextPtr, (Register)mainFunction);
    tmSetFramePointer(threadPtr->contextPtr, 0);
    tmSetArgument0(threadPtr->contextPtr, (Register)parameter);
    tmSetStatusRegister(threadPtr->contextPtr, mode);
    enableAllInterruptsInContext(threadPtr->contextPtr);

	#ifdef TRACETHREADSTART
	ioConsolePutString("msg:");
	ioConsolePutHexInt((char*)(threadPtr->stackStart) - messageLength + 4);
	#endif

	if(space!=USER) goto out;
	
    byteCopy((char*)(threadPtr->stackStart) - messageLength+ 4,
	      &threadExitMsg,
	      sizeof(Message));

	/*slfsmm1>*/
    if(space == USER){
	    pagetableentry+=((unsigned long)(threadPtr->stackStart) 
			- messageLength - exitCodeLength + 4)/PAGESIZE;
	    off=(unsigned long)(*pagetableentry);
	    off=off&0xfffff000;
	    off+=(unsigned long)((char*)(threadPtr->stackStart) - messageLength - exitCodeLength + 4)%PAGESIZE;
	    phys=(char*)off;
	    phys+=0xa0000000;
	}
    else
	    phys=(char*)(threadPtr->stackStart) - messageLength - exitCodeLength + 4;

	#ifdef TRACETHREADSTART
	ioConsolePutString("code:");
	ioConsolePutHexInt(phys);
	#endif
	byteCopy(phys, automaticThreadExit, exitCodeLength);
	//byteCopy((char*)(threadPtr->stackStart) - sizeof(Message) - 
    //							exitCodeLength + 4,
	//      automaticThreadExit,
	//      exitCodeLength);
    /*slfsmm1<*/
	
    byteCopy((char*)(threadPtr->stackStart) - messageLength - exitCodeLength ,
	      &exitCodeLength, 4);

    if (space == USER){
		//put arg and env to user stack
		sp=arrange_arg_env_aux(sp);
		tmSetStackPointer(threadPtr->contextPtr, sp);
		//redirect stdio
		ioConsolePutString("user thread build OK!\n\n");
		if(!RedirectStdIO(cmdlineformat.redirect[0],
			cmdlineformat.redirect[1],cmdlineformat.redirect[2]))
			ioConsolePutString("threadBuild:stdio redirection failed!\n");
		//tell vmips the appname
		TAappnametovmips(cmdlineformat.cmdlinebase);
		/*added by xjw 2003.12.16*/
		#ifdef OPEN_TRACE
		if(!lightWeight)
			tracerserver(DBG_TRACE_ON);
		#endif
		/*added by xjw ends*/
    }

out:
    if (space!= USER){
	#ifdef TRACETHREADSTART
	ioConsolePutString("thread build OK!\n\n");
	#endif
	}
    //ioConsolePutHexInt((unsigned long)mainFunction);
    
}


/* This procedure initializes a thread structure. resources are passed as
 * arguments so threadBuild doesn't need to know about memory allocation.
 */
Error threadDestroy( ThreadId id, int flag, int exitcode)
{
    Thread* threadPtr;
	long count;

    /* Lookup in hash table to find pointer onto destination thread */
    if (hashListGet( threadHashList, (void**)(&threadPtr),
		     id) != HASHOK) {
	/* inexistent threads can't call exit! */
	WARNING("threadExit(): could not find threadId");
	return -1;
    }
    
    /* Clean up hash table, global thread list and scheduler list */
    
    lock(threadLock); {
	hashListRemove(threadHashList, id);
	listRemove(threadList, threadPtr, NULL);
    }
    unlock(threadLock);    

    schedulerRemove(threadPtr);

    /* Deallocate stack and thread descriptor.
     * stackEnd is the basis address ! 
     */
 	//if(id<0)//user thread stack is static. sgz 2003-10-16
    //    vmFree((Address)(threadPtr->stackEnd));  
    /*slfsmm031122_mod>Thread and ProcContext are now all in kernel stack!*/
    //hmFree((Address)threadPtr);
    vmFree((Address)threadPtr);
	/*slfsmm031122_mod<*/
    vmCleanup(threadPtr->id);
	/*slfsmm031201_add>deredirection*/
	DeRedirectStdIO();
	for(count=0;count<STDIONUM;count++){
		if(cmdlineformat.redirect[count]!=NOTREDIRECT){
			TLclose(cmdlineformat.redirect[count]);
			cmdlineformat.redirect[count]=NOTREDIRECT;
		}
	}
	/*slfsmm031201_add<*/
	/*slfsmm031203_add>cwd*/
	doRecoverCWD( );
	/*slfsmm031203_add<*/

    /* Wake all threads that were blocked waiting for 
     * a message from exited thread 
     */
    if(THREAD_MODE(id)==USER)
    	ClearUpUserAddressSpace();
    ipcFreeBlockedThreads( id);

	//printf exit code
	switch(flag){
		case THREADDESTROY_EXIT:
			ioConsolePutString("\n\nTM_EXIT........\n");
			break;
		case THREADDESTROY_KILL:
			ioConsolePutString("\n\nTM_KILL........\n");
			break;
	}
	ioConsolePutString("exitcode:0x");
	ioConsolePutHexInt(exitcode);
	ioConsolePutString("\n\n");
	/*added by xjw 2003.12.16*/
	#ifdef OPEN_TRACE
	tracerserver(DBG_TRACE_OFF);
	#endif
	/*added by xjw ends*/
    return TM_OK;
}

/*
 *
 */
ThreadId threadStart( ThreadMainFunction fctnAddr, 
		      ThreadArg parameter,
		      AddressSpace space,
		      char* name,
		      ThreadId parentId,
		      Boolean lightWeight)
{
    Thread* threadPtr;
    Address spaceFrom;
    unsigned long spaceSize;
    Address stackBaseAddress;
	unsigned long stacksize;

	#ifdef TRACETHREADSTART
	ioConsolePutString("threadStart begins...");
	#endif
	
	
    /* users may pass illegal pointers to name. this has to be checked here. 
     * we check if the user buffer is inside the user address space and
     * watch for overflow!
     */
    if (THREAD_MODE(parentId) == USER) {
        mmAddressSpaceRange(USER, &spaceFrom, &spaceSize);
	if ((Address)name < spaceFrom || (unsigned long)name + MAXNAMESIZE > 
	    (unsigned long)spaceFrom + spaceSize 
	    || UNSIGNED_LONG_MAX - (unsigned long)name < MAXNAMESIZE)
	  {
	      name = NULL;
	  }
    }    
    /* Preparation of a new Thread entry, memory allocation for both Thread
     * and ProcContext structure. For simplicity, these structures are made
     * contiguous in a single call to hmAlloc(). 
     */
    /*slfsmm031121_del>Thread and ProcContext are now in kenel stack!*/
	/*
    if (hmAlloc( (Address*)&threadPtr,
		 sizeof(Thread)+sizeof(ProcContext)) == HM_ALLOCFAILED) {
		ERROR("couldn't create thread structure");
		return TM_THREADSTARTFAILED;
    }
    */
	/*slfsmm031121_del<*/

	/*slfsmm031031_add_bug_note>all the registers should be initialized!!!*/
    /*slfsmm031121_del>Thread and ProcContext are now in kenel stack!*/
	//zeroOut(threadPtr,sizeof(Thread)+sizeof(ProcContext));
	/*slfsmm031121_del<*/
	/*slfsmm031031_add_bug_note<*/
	
    /* Requesting an execution stack for new thread, only for
     * non-lightweight threads */
    //if (!lightWeight) {
    	//ioConsolePutHexInt(&stackBaseAddress);
    	
    /*slfsmm1>*/
    /*slfsmm031121_del>Thread and ProcContext are now in kenel stack!*/
	//if(space != USER){//kernel thread stack alloc begin
	/*slfsmm031121_del<*/
   	if (vmAlloc( &stackBaseAddress,
   		     TM_DEFAULTTHREADSTACKSIZE) == VM_ALLOCFAILED) {
   	    ERROR("couldn't create stack for new thread.\n");
   	    /* Deallocate of threadPtr */
		/*slfsmm031121_del>Thread and ProcContext are now in kenel stack!*/
   	    //hmFree((Address)threadPtr);
   	    /*slfsmm031121_del<*/
   	    return TM_THREADSTARTFAILED;
   	}
	stacksize=TM_DEFAULTTHREADSTACKSIZE;
	/*slfsmm031211_add>init the kernel stack*/
	TAmemset(stackBaseAddress,0,stacksize);
	/*slfsmm031211_add<*/
	/*slfsmm031121_add>Thread and ProcContext are now in kenel stack!*/
	threadPtr=(Thread*)stackBaseAddress;
	zeroOut(threadPtr,sizeof(Thread));
	threadPtr->contextPtr=(ProcContext*)(stackBaseAddress+stacksize-sizeof(ProcContext));
	//zeroOut(threadPtr->contextPtr,sizeof(ProcContext));
	/*slfsmm031121_add<*/
	/*slfsmm031121_mod>*/
	//}//kernel thread stack alloc end
	//else{
	if(space==USER){
	/*slfsmm031121_mod<*/
		stackBaseAddress=(Address)userstackbase;
		stacksize=INITSTACKSIZE;
	}
	#ifdef TRACETHREADSTART
	ioConsolePutString("stack base:");
	ioConsolePutHexInt(stackBaseAddress);
	ioConsolePutString("stack size:");
	ioConsolePutHexInt(stacksize);
	#endif
	/*slfsmm1<*/
	
    //} 
	//else {
	//stackBaseAddress = (Address)BOOTSTACKTOP;
	//stacksize=TM_DEFAULTTHREADSTACKSIZE;
    //}
    //ioConsolePutString(name);
    
    /* Three things may fail: we're out of thread id's or we can't insert
     * the thread into either the hash list or the global thread list:
     * in all cases we release the already allocated resources and return
     * a syscall failure.
     */
    threadPtr->id = getThreadId(space); 
    
    lock(threadLock); {
	if ((threadPtr->id == 0) ||
	  (hashListAdd( threadHashList, threadPtr, threadPtr->id) != HASHOK) ||
	  (listAddInFront( threadList, threadPtr, NULL) != LIST_OK)) {
	    unlock(threadLock);
	    /* Deallocate stack and thread descriptor */
	    //if (!lightWeight) {
		vmFree(stackBaseAddress);
	    //}
		/*slfsmm031121_del>Thread and ProcContext are now in kenel stack!*/
	    //hmFree((Address)threadPtr);
	    /*slfsmm031121_del<*/
	    ERROR("got invalid thread id or list operations failed");	
	    return TM_THREADSTARTFAILED;
	}
    }
    unlock(threadLock);
    //ioConsolePutHexInt(space);
    /* If a user thread is required, stack has to be moved to user space */

	/*slfsmm1>*/
	/*
    if (space == USER) {
    	//ioConsolePutString("stackBaseAddress:");
    	//ioConsolePutHexInt(&stackBaseAddress);
	if (vmMove(&stackBaseAddress, threadPtr->id) == VM_MOVEFAILED) {
	    ioConsolePutString("user stack could not be moved from kernel space");
	    vmFree(stackBaseAddress);

	    hmFree((Address)threadPtr);
	    return TM_THREADSTARTFAILED;
	}
    }
    */
    /*slfsmm1<*/
	
    /* Building of the thread structure */
	/*slfsmm1>*/
	/*
    threadBuild( threadPtr->id, parentId, name,
		 (ProcContextPtr)((char*)threadPtr+sizeof(Thread)),
 		 stackBaseAddress, TM_DEFAULTTHREADSTACKSIZE,
		 fctnAddr, parameter, space, lightWeight, threadPtr);
	*/
	/*slfsmm031121_mod>Thread and ProcContext are now in kenel stack!*/
	/*
    threadBuild( threadPtr->id, parentId, name,
		 (ProcContextPtr)((char*)threadPtr+sizeof(Thread)),
 		 stackBaseAddress, stacksize,
		 fctnAddr, parameter, space, lightWeight, threadPtr);
	*/
	
	threadBuild( threadPtr->id, parentId, name,
		 threadPtr->contextPtr, stackBaseAddress, stacksize,
		 fctnAddr, parameter, space, lightWeight, threadPtr);
	/*slfsmm031121_mod<*/
	/*slfsmm1<*/
    
    /* Last page of stack is protected to catch most overflows */
    /* vmProtect(...); */
	
    /* New thread is put in ready status */
    schedulerSetReady(threadPtr);

    /* at this point the new thread is born and may be scheduled (i.e. even
     * before the parent receives the child id as a reply message
     */
    //ioConsolePutHexInt(threadPtr->id);
	#ifdef TRACETHREADSTART
	ioConsolePutString("threadStart ends.");
	#endif
    return threadPtr->id;
}


/*
 * Handle tmExit() syscall
 */
void threadExit(ThreadId threadId, int exitcode)
{
    threadDestroy( threadId, THREADDESTROY_EXIT, exitcode);
}


/*
 * This procedure is EXCLUSIVELY invoked in an exception context.
 * Thus it is possible to invoke the restoreContext() function.
 */
void threadYield()
{
    /* The next runnable thread is computed */
    schedule();
    
    /* Restoring context of new runnable thread */
    restoreContext(schedulerRunning()->contextPtr);
}


Error threadKill( ThreadId killedId, ThreadId killerId)
{
    /*Thread* threadPtr;
    int exitCodeLength = endAutomaticThreadExit - automaticThreadExit;*/

    ioConsolePutString("Entering threadKill");
    
    /* Not allowed for a user thread to kill a kernel thread */
    if (THREAD_MODE(killerId) == USER && THREAD_MODE(killedId) == KERNEL) {
	/* The faulting user thread is killed (recursively) without 
	 * remorse. the new killer id is TMTHREADID so this will hopefully
	 * happen...
	 */
	if (threadKill(killerId, TMTHREADID) == TM_KILLFAILED) {
	    return TM_THREADKILLFAILED;
	} 
	return TM_OK;
    }
    threadDestroy(killedId, THREADDESTROY_KILL, -1);
    return TM_OK;
}


/* answers questions about a thread's identity, nice, huh? 
 */
Error threadInfo( ThreadId id, ThreadId aboutId,
		  ThreadInfo info, long int values[])
{
    Thread* threadPtr;

    if (aboutId == SELF) {
	aboutId = id;
    }
    /* Lookup in hash table to find pointer onto aboutId thread */
    if (hashListGet( threadHashList, (void**)(&threadPtr),
		     aboutId) != HASHOK) {
	return TM_FAILED;
    }
    switch (info) {	
    case INFO_ID:
      values[0] = aboutId;                 /* own thread id */
      values[1] = threadPtr->parentId;     /* parent thread id */
      break;
    default:
      WARNING("invalid info requested");
      break;
    }
    return TM_OK;
}


/*
 * Returns name of current running thread. Could be replace by a direct
 * reference to (schedulerRunning())->name, however, such a function
 * provides more transparency (the global scheduler variable would have
 * to be declared everywhere where PANIC or WARNING is used !
 */
char* getCurrentThreadName()
{
    if (schedulerRunning() == NULL) {
	return noRunningThreadString;
    } else {
	return schedulerRunning()->name;
    }
}
