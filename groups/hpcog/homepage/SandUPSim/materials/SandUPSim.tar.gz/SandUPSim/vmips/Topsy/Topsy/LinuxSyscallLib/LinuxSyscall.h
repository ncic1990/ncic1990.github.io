#ifndef LINUXSYSCALL_H
#define LINUXSYSCALL_H

#include "LibcLinuxTypes.h"
#include "LinuxSyscallOpt.h"

#ifndef SYSCALLINLINE
long sys_errno;
#endif

void sys_exit(int exitcode);//v0==4001
int sys_read(unsigned int fd, char * buf, long count);//v0==4003
int sys_write(unsigned int fd, const char * buf, long count);//v0==4004
long sys_open(const char * filename, int flags, int mode);//v0==4005
long sys_close(unsigned int fd);//v0==4006
long sys_unlink(const char* pathname);//v0==4010
long sys_time(int* tloc);//v0==4013
long sys_lseek(unsigned int fd, long offset, unsigned int origin);//v0==4019
long sys_getpid(void);//v0==4020
long sys_getuid(void);//v0==4024
long sys_access(const char * filename, int mode);//v0==4033
long sys_rename(const char * oldname, const char * newname);//v0==4038
long sys_times(struct tms* tbuf);//v0==4043
unsigned long sys_brk(unsigned long brk);//v0==4045
long sys_getgid(void);//v0==4047
long sys_geteuid(void);//v0==4049
long sys_getegid(void);//v0==4050
long sys_ioctl(unsigned int fd, unsigned int cmd, unsigned long arg);//v0==4054
long sys_fcntl(unsigned int fd, unsigned int cmd, unsigned long arg);//v0==4055
long sys_setrlimit(unsigned int resource, struct rlimitformips*rlim);//v0==4075
long sys_getrlimit(unsigned int resource, struct rlimitformips *rlim);//v0==4076
long sys_getrusage(int who, struct rusageformips*ru);//v0==4077
unsigned long sys_mmap(unsigned long addr, unsigned long len, unsigned long prot,
         unsigned long flags, unsigned long fd, unsigned long offset);//v0==4090
long sys_munmap(unsigned long addr, unsigned long len);//v0==4091
long sys_ftruncate(unsigned int fd, unsigned long length);//v0==4093
long sys_stat(char * filename, struct statformips* statbuf);//v0==4106
long sys_lstat(char * filename, struct statformips* statbuf);//v0==4107
long sys_fstat(unsigned int fd, struct statformips* statbuf);//v0==4108
long sys_newuname(new_utsname_formips * name);//v0==4122
long sys_mprotect(unsigned long start, size_t len, unsigned long prot);//v0==4125
long sys_llseek(unsigned int fd, unsigned long offset_high, 
	unsigned long offset_low, loff_t * result, unsigned int origin);//v0==4140
long sys_newselect(int n, fd_set *inp, fd_set *outp, fd_set *exp, struct timeval *tvp);//v0==4142
long sys_nanosleep(struct timespecformips *rqtp, struct timespecformips *rmtp);//v0==4166
long sys_rt_sigaction(int sig, const struct sigactioninvalid *act, 
	struct sigactioninvalid *oact, long sigsetsize);//v0==4194
long sys_rt_sigprocmask(int how, sigsetinvalid_t *set, sigsetinvalid_t *oset, 
	size_t sigsetsize);//v0==4195
long sys_mmap2(unsigned long addr, unsigned long len, unsigned long prot,
          unsigned long flags, unsigned long fd, unsigned long pgoff);//v0==4210
long sys_ftruncate64(unsigned int fd, loff_t length);//v0==4212
long sys_stat64(char * filename, struct stat64formips * statbuf, long flags);//v0==4213
long sys_lstat64(char * filename, struct stat64formips * statbuf, long flags);//v0==4214
long sys_fstat64(unsigned long fd, struct stat64formips * statbuf, long flags);//v0==4215
long sys_fcntl64(unsigned int fd, unsigned int cmd, unsigned long arg);//v0==4220

#endif/*LINUXSYSCALL_H*/
