#ifndef __TMTHREAD_H
#define __TMTHREAD_H
/*
	Copyright (c) 1996-1997 Swiss Federal Institute of Technology, 
	Computer Engineering and Networks Laboratory. All rights reserved.

	TOPSY - A Teachable Operating System. 
		Implementation of a tiny and simple micro kernel for
		teaching purposes.

	Permission to use, copy, modify, and distribute this software and its
	documentation for any purpose, without fee, and without written 
	agreement is hereby granted, provided that the above copyright notice 
	and the following two paragraphs appear in all copies of this software.


	
	File:                  $Source: /work/cvs/cvsroot/Topsy/Threads/TMThread.h,v $
 	Author(s):             Christian Conrad
 	Affiliation:           ETH Zuerich, TIK
 	Version:               $Revision: 1.5 $
 	Creation Date:         
 	Last Date of Change:   $Date: 2003/12/09 02:03:33 $      by: $Author: slfsmm $
	
	
*/

#include "tm-include.h"
#include "Lock.h"

extern Lock threadLock;

/*slfsmm1>*/
/*move from file "TMThread.c"*/
/*slfsmm003_mov>move back to "TMThread.c"*/
//HashList threadHashList;            /* Hash list of all threads */
/*slfsmm003_mov<*/
/*slfsmm1<*/

/*
 * Thread interface functions
 */
ThreadId threadStart( ThreadMainFunction fctnAddr, 
		      ThreadArg parameter,
		      AddressSpace mode,
		      char *name,
		      ThreadId parentId,
		      Boolean lightWeight);
void threadExit( ThreadId threadId, int exitcode);
void threadYield();
Error threadKill( ThreadId id, ThreadId killerId);
Error threadInfo( ThreadId id, ThreadId about,
		  ThreadInfo info, long int values[]);

void threadBuild( ThreadId id,
		  ThreadId parentId,
		  char* name,
		  ProcContextPtr contextPtr,
		  Address stackBaseAddress,
		  unsigned int stackSize,
		  ThreadMainFunction mainFunction,
		  ThreadArg parameter,
		  AddressSpace space,
		  Boolean lightWeightThread,
		  Thread* threadPtr);

ThreadId startMinimalIdleThread();

#endif /*__TMTHREAD_H*/

