/*
	Copyright (c) 1996-1997 Swiss Federal Institute of Technology, 
	Computer Engineering and Networks Laboratory. All rights reserved.

	TOPSY - A Teachable Operating System. 
		Implementation of a tiny and simple micro kernel for
		teaching purposes.

	Permission to use, copy, modify, and distribute this software and its
	documentation for any purpose, without fee, and without written 
	agreement is hereby granted, provided that the above copyright notice 
	and the following two paragraphs appear in all copies of this software.


	
	File:                  $Source: /work/cvs/cvsroot/Topsy/Memory/mips/MMDirectMapping.c,v $
 	Author(s):             George Fankhauser
 	Affiliation:           ETH Zuerich, TIK
 	Version:               $Revision: 1.22 $
 	Creation Date:         
 	Last Date of Change:   $Date: 2004/03/07 15:00:48 $      by: $Author: slfsmm $
	
	
*/

#include "MMMapping.h"
#include "Threads.h"
#include "Support.h"
#include "tlb.h"
#include "cpu.h"
#include "hwconfig.h"
#include "KSupportInlineAsm.h"
#include "globalopt.h"
#include "LibcLinuxTypes.h"

//#define MAPPINGTRACE

extern long PHYSMEM;
extern long USERMEM;
extern long PAGETABLEPHYSBASE;
extern long TLB_SIZE;
mmmapping_t usermmmapping;

Error   mmInitMemoryMapping(Address codeAddr, unsigned long int codeSize,
			    Address dataAddr, unsigned long int dataSize,
			    Address userLoadedInKernelAt, unsigned long int* codePhysAddr,
			    unsigned long int* dataPhysAddr)
{
	unsigned long * pagetableentry;
	unsigned long * pagetablebase;
	unsigned long addr;
	unsigned int count;
    unsigned int i;
	
	ioConsolePutString("user mmmapping begin........\n");
#ifndef SIMOS

    /* to simulate a directmapped memory on a paged machine we fill
     * the TLB to provide the user with 64*4k memory from 4k to (256+4)k - 1.
     * Pages from [PHYSMEM-256k, PHYSMEM] are mapped to [4, 260k].
     * Page Table Entries are set to valid and global.
     * (setting up a *real* virtual memory system is lot harder) 
     */

	#ifdef MAPPINGTRACE
	ioConsolePutString("codeAddr:0x");
	ioConsolePutHexInt(codeAddr);
	ioConsolePutString("codeSize:0x");
	ioConsolePutHexInt(codeSize);
	ioConsolePutString("dataAddr:0x");
	ioConsolePutHexInt(dataAddr);
	ioConsolePutString("dataSize:0x");
	ioConsolePutHexInt(dataSize);
	ioConsolePutString("stackSize:0x");
	ioConsolePutHexInt(INITSTACKSIZE);
	ioConsolePutString("user memory:0x");
	ioConsolePutHexInt(USERMEM);
	#endif

	/*.................................virtual space checking...................................*/

	#ifdef MAPPINGTRACE
	ioConsolePutString("mmInitMemoryMapping:user virtual space checking begins...\n");
	#endif
    /*slfsmm031022_addr>check segment page align*/
    if(PAGEREMAINDER(codeAddr)!=0 || PAGEREMAINDER(dataAddr)!=0){
		ioConsolePutString("VMError:mmInitMemoryMapping: code or data segment not page aligned!\n");
		ioConsolePutString("codeAddr:0x");
		ioConsolePutHexInt(codeAddr);
		ioConsolePutString("dataAddr:0x");
		ioConsolePutHexInt(dataAddr);
		return MM_INITMEMORYMAPPINGFAILED;
    }
	codeSize=NotLogical_RoundUp(codeSize);
	dataSize=NotLogical_RoundUp(dataSize);
	/*slfsmm031022_add<*/
	/*slfsmm031210_add>checking the memory size*/
	if(codeSize+dataSize+INITSTACKSIZE>USERMEM){//memory is too small
		ioConsolePutString("mmInitMemoryMapping: memory is too small, please check it !\n");
		ioConsolePutString("codeSize:0x");
		ioConsolePutHexInt(codeSize);
		ioConsolePutString("dataSize:0x");
		ioConsolePutHexInt(dataSize);
		ioConsolePutString("init stack size:0x");
		ioConsolePutHexInt(INITSTACKSIZE);
		ioConsolePutString("totally needed memory size:0x");
		ioConsolePutHexInt(codeSize+dataSize+INITSTACKSIZE);
		ioConsolePutString("but there is only:0x");
		ioConsolePutHexInt(USERMEM);
		ioConsolePutString("user mmmapping failed!!!\n");
		return MM_INITMEMORYMAPPINGFAILED;
	}
	/*slfsmm031210_add<*/
	/*slfsmm031212_add>checking the layout of virtual memory*/
	if((unsigned long int)codeAddr+codeSize>(unsigned long int)dataAddr){
		ioConsolePutString("mmInitMemoryMapping: memory layout invalid, please check it !\n");
		ioConsolePutString("codeBase:0x");
		ioConsolePutHexInt(codeAddr);
		ioConsolePutString("codeSize:0x");
		ioConsolePutHexInt(codeSize);
		ioConsolePutHexInt("dataBase:0x");
		ioConsolePutHexInt(dataAddr);
		return MM_INITMEMORYMAPPINGFAILED;
	}
	if((unsigned long int)dataAddr+USERMEM-codeSize-INITSTACKSIZE>USERSTACKBASE){
		ioConsolePutString("mmInitMemoryMapping: memory layout invalid, please check it !\n");
		ioConsolePutString("dataBase:0x");
		ioConsolePutHexInt(dataAddr);
		ioConsolePutString("dataSize:0x");
		ioConsolePutHexInt(dataSize);
		ioConsolePutHexInt("stackBase:0x");
		ioConsolePutHexInt(USERSTACKBASE);
		return MM_INITMEMORYMAPPINGFAILED;
	}
	/*slfsmm031212_add<*/
	if(!codePhysAddr||!dataPhysAddr){
		ioConsolePutString("mmInitMemoryMapping: codePhysAddr or dataPhysAddr invalid !\n");
		return MM_INITMEMORYMAPPINGFAILED;
	}
	#ifdef MAPPINGTRACE
	ioConsolePutString("mmInitMemoryMapping:user virtual space checking OK.\n");
	#endif

	/*.................................init user physical space..................................*/

	#ifdef MAPPINGTRACE
	ioConsolePutString("mmInitMemoryMapping:init user physical space(by k1seg) begins...\n");
	#endif
	/*slfsmm031211_add>init the user memory*/
	TAmemset(PAGETABLEPHYSBASE+PAGETABLEMEM+K1SEG_BASE,0,USERMEM);
	/*slfsmm031211_add<*/
	#ifdef MAPPINGTRACE
	ioConsolePutString("mmInitMemoryMapping:init user physical space OK.\n");
	#endif

	/*...........................................init tlb..................................................*/

	#ifdef MAPPINGTRACE
	ioConsolePutString("mmInitMemoryMapping:init tlb begins...\n");
	#endif
	/*init tlb*/
    Register lo = ((PHYS_BASE+KERNELMEM+PAGETABLEMEM) & TLB_LO_PFN_MASK) | 
					    TLB_VALID | TLB_GLOBAL | TLB_DIRTY;
	/*slfsmm031022_mod>make all tlb item invalid except item 0 for io and virtserv*/
    Register hi =K1SEG_BASE;
	/*slfsmm031022_mod<*/
	
    for (i = 3; i < TLB_SIZE; i++) {
	setTLBEntry(lo, hi, i); 
	hi += PAGESIZE; lo += PAGESIZE;  
    }

	/*mapping spimconsole and virtserv*/
	lo=( SpimConsolePhysBase & TLB_LO_PFN_MASK) 
					|TLB_VALID | TLB_GLOBAL | TLB_DIRTY | TLB_NOCACHE;
	hi=USERVIRTSERVBASE;
	setTLBEntry(lo,hi,0);

	//NetWorkCard mapping
	lo=( (RemoteServerSpacePhysBase+PAGESIZE) & TLB_LO_PFN_MASK) 
					|TLB_VALID | TLB_GLOBAL | TLB_DIRTY | TLB_NOCACHE;
	hi=NETCARDHIGHUSERBASE;
	setTLBEntry(lo,hi,1);
	lo=( RemoteServerSpacePhysBase & TLB_LO_PFN_MASK) 
					|TLB_VALID | TLB_GLOBAL | TLB_DIRTY | TLB_NOCACHE;
	hi=NETCARDLOWUSERBASE;
	setTLBEntry(lo,hi,2);
	#ifdef MAPPINGTRACE
	kerneldumpregs();
	ioConsolePutString("mmInitMemoryMapping:init tlb OK.\n");
	#endif

	/*........................................invalidate cache........................................*/
	#ifdef MAPPINGTRACE
	ioConsolePutString("mmInitMemoryMapping:invalidate cache begins...\n");
	#endif
	TAinvalidatecache( );
	#ifdef MAPPINGTRACE
	ioConsolePutString("mmInitMemoryMapping:invalidate cache ends.\n");
	#endif

	/*........................................init page table...........................................*/

	#ifdef MAPPINGTRACE
	ioConsolePutString("mmInitMemoryMapping:init pagetable(by k1seg) begins...\n");
	#endif
	//init page table
    pagetablebase=pagetableentry=(unsigned long*)(K1SEG_BASE+PAGETABLEPHYSBASE);
	count=PAGETABLEMEM/sizeof(unsigned long*);
	#ifdef MAPPINGTRACE
	ioConsolePutString("page table base:0x");
	ioConsolePutHexInt(pagetablebase);
	ioConsolePutString("page table size:0x");
	ioConsolePutHexInt(PAGETABLEMEM);
	ioConsolePutString("page table items:0x");
	ioConsolePutHexInt(count);
	#endif
	#ifdef TASSISTMEMSET
	/*slfsmm031212_mod>note*/
	//TAmemset(pagetableentry, 0, PAGETABLEMEM);
	TAmemset(pagetableentry, TLB_GLOBAL, PAGETABLEMEM);
	/*slfsmm031212_mod<*/
	#else
	/*slfsmm01023_note>count==0*/
	//for(i=0;i<count;i++){
	for(i=0;i<0;i++){
	/*slfsmm031023_note<*/
		*(pagetableentry)=TLB_GLOBAL;
		pagetableentry++;
	}
	#endif
	addr=USERPHYSMEMPHYSBASE;
	
	//user code
	pagetableentry=pagetablebase+(unsigned long)codeAddr/PAGESIZE;
	count=codeSize/PAGESIZE;
	*codePhysAddr=addr;
	usermmmapping.codeseg.physbase=(long)addr;
	usermmmapping.codeseg.virtbase=(long)codeAddr;
	usermmmapping.codeseg.size=(long)codeSize;
	#ifdef MAPPINGTRACE
	ioConsolePutString("page table: user code base:0x");
	ioConsolePutHexInt(pagetableentry);
	ioConsolePutString("page table: user code pages:0x");
	ioConsolePutHexInt(count);
	ioConsolePutString("page table: user code mapping to physical addr:0x");
	ioConsolePutHexInt(addr);
	#endif
	for(i=0;i<count;i++){
		/*slfsmm031212_mod>user code should be read only*/
		//*(pagetableentry)=( addr & TLB_LO_PFN_MASK)|TLB_VALID|TLB_GLOBAL|TLB_DIRTY;
		*(pagetableentry)=( addr & TLB_LO_PFN_MASK)|TLB_VALID|TLB_GLOBAL;
		/*slfsmm031212_mod<*/
		pagetableentry++;
		addr+=PAGESIZE;
	}

	//user data;heap
	pagetableentry=pagetablebase+(unsigned long)dataAddr/PAGESIZE;
	count=(USERMEM-INITSTACKSIZE-codeSize)/PAGESIZE;
	*dataPhysAddr=addr;
	usermmmapping.dataseg.physbase=(long)addr;
	usermmmapping.dataseg.virtbase=(long)dataAddr;
	usermmmapping.dataseg.size=(long)dataSize;
	usermmmapping.brk_dynamic.physbase=usermmmapping.dataseg.physbase+usermmmapping.dataseg.size;
	usermmmapping.brk_dynamic.virtbase=usermmmapping.dataseg.virtbase+usermmmapping.dataseg.size;
	usermmmapping.brk_dynamic.size=NotLogical_RoundUp((USERMEM-INITSTACKSIZE-codeSize-dataSize)/DYNAMICCONST);
	usermmmapping.mmmap_dynamic.physbase=usermmmapping.brk_dynamic.physbase+usermmmapping.brk_dynamic.size;
	usermmmapping.mmmap_dynamic.virtbase=usermmmapping.brk_dynamic.virtbase+usermmmapping.brk_dynamic.size;
	usermmmapping.mmmap_dynamic.size=USERMEM-INITSTACKSIZE-codeSize-dataSize-usermmmapping.brk_dynamic.size;
	#ifdef MAPPINGTRACE
	ioConsolePutString("page table: user data base:0x");
	ioConsolePutHexInt(pagetableentry);
	ioConsolePutString("page table: user data pages:0x");
	ioConsolePutHexInt(count);
	ioConsolePutString("page table: user data mapping to physical addr:0x");
	ioConsolePutHexInt(addr);
	#endif
	for(i=0;i<count;i++){
		*(pagetableentry)=( addr & TLB_LO_PFN_MASK) 
			|TLB_VALID | TLB_GLOBAL | TLB_DIRTY;
		pagetableentry++;
		addr+=PAGESIZE;
	}

	//initial user stack
	pagetableentry=pagetablebase+USERSTACKBASE/PAGESIZE;
	count=INITSTACKSIZE/PAGESIZE;
	usermmmapping.stackseg.physbase=(long)addr+(long)INITSTACKSIZE;
	usermmmapping.stackseg.virtbase=(long)USERSTACKBASE+(long)INITSTACKSIZE;
	usermmmapping.stackseg.size=(long)INITSTACKSIZE;
	#ifdef MAPPINGTRACE
	ioConsolePutString("page table: user stack base:0x");
	ioConsolePutHexInt(pagetableentry);
	ioConsolePutString("page table: user stack pages:0x");
	ioConsolePutHexInt(count);
	ioConsolePutString("page table: user stack mapping to physical addr:0x");
	ioConsolePutHexInt(addr);
	#endif
	for(i=0;i<count;i++){
		*(pagetableentry)=( addr & TLB_LO_PFN_MASK) 
			|TLB_VALID | TLB_GLOBAL | TLB_DIRTY;
		pagetableentry++;
		addr+=PAGESIZE;
	}

	/*mapping device*/
	//for terminal and virtual service:map to the user space:nocached
	pagetableentry=pagetablebase+USERVIRTSERVBASE/PAGESIZE;
	*(pagetableentry)=( SpimConsolePhysBase & TLB_LO_PFN_MASK) 
					|TLB_VALID | TLB_GLOBAL | TLB_DIRTY | TLB_NOCACHE;

	//NetWorkCard mapping
	pagetableentry=pagetablebase+NETCARDHIGHUSERBASE/PAGESIZE;
	*(pagetableentry)=( (RemoteServerSpacePhysBase+PAGESIZE) & TLB_LO_PFN_MASK) 
					|TLB_VALID | TLB_GLOBAL | TLB_DIRTY | TLB_NOCACHE;
	pagetableentry=pagetablebase+NETCARDLOWUSERBASE/PAGESIZE;
	*(pagetableentry)=( RemoteServerSpacePhysBase & TLB_LO_PFN_MASK) 
					|TLB_VALID | TLB_GLOBAL | TLB_DIRTY | TLB_NOCACHE;

	//tell vmips the memory mapping of app
	TAmmmappinginfotovmips(&usermmmapping);
	
	#ifdef MAPPINGTRACE
	ioConsolePutString("mmInitMemoryMapping:init page table OK.\n");
	#endif

#else

    /* SimOS emulates R4K, which is significantly different in the
     * TLB department. I hard-wire these values, as they are not used
     * anywhere else, and I adopt the policy of minimal modification to
     * the Topsy source tree. Soon, I hope to create a <r4k.h> and
     * put all relevant information in there. */

    /* Expression for the ammount of memory that may be mapped
     * with the 48 TLB entries mapping two pages each. */
    int i;

    /* Initial values for the page_mask and hi CP0 registers. */
    Register hi =
	(0 << 0) | /* ASID is unused, hence fixed at 0 */
	(KUSEG_BASE & 0xffffe000); /* VPN/2 (also 0) */
    Register lo =
	(1 << 0) | /* Global bit set */
	(1 << 1) | /* Valid bit set */
	(1 << 2) | /* Dirty bit set */
	(6 << 3) | /* Cache algorithm set to "coherent update on write" */
	((PHYSMEM-USERMEM+PHYS_BASE) >> PAGEBITS << 6); /* PFN */

    /* First entry is special. lo0 must be invalid (0) to get the same 
     * effect as leaving the first page unmapped. */
    setTLBEntry(0, lo + (1 << 6), hi, 0);

    for (i = 1; i < 48; ++i) {
	lo += (2 << 6); 	/* increment the PFN (twice) */
	hi += (1 << 13); 	/* increment the VPN/2 (once) */
	setTLBEntry(lo, lo + (1 << 6), hi, i);
    }

#endif

    /* once the mapping is done, copy user code and data */ 
	/*slfsmm031023_del>user thread is not created in the loading process*/
    //byteCopy((Address)0xa0200000, (Address)0xa01c1000, codeSize+dataSize);
	/*slfsmm031023_del<*/

	ioConsolePutString("user mmmapping OK.\n");

    return MM_INITMEMORYMAPPINGOK;
}

Error mmMapPages(Page startPage, Page nOfPages, PageStatus pstat)
{
    return MM_MAPPAGESOK;
}


Error mmUnmapPages(Page startPage, Page nOfPages)
{
    return MM_UNMAPPAGESOK;
}


Error mmMovePage(Page from, Page to)
{
    /* direct mapped memory systems can only copy the page */
    byteCopy((Address)(to*LOGICALPAGESIZE), (Address)(from*LOGICALPAGESIZE), 
							    LOGICALPAGESIZE);
    //ioConsolePutString("bytecopy ok in mmMovePage.\n");
    zeroOut((Address)(from*LOGICALPAGESIZE), LOGICALPAGESIZE);
    return MM_MOVEPAGEOK;
} 


Error mmProtectPage(Page page, ProtectionMode pmode)
{
    /* direct mapped memory does nothing */
    return MM_PROTECTPAGEFAILED;
}


Error  mmAddressSpaceRange(AddressSpace space, Address* addressPtr,
					unsigned long int* sizePtr)
{
    if (space == KERNEL) {
    	*addressPtr = (Address)K1SEG_BASE;//K1SEG_BASE
		*sizePtr = KERNELMEM; 
    }
    else if (space == USER) {
		/*slfsmm031023_maymod>*/
        *addressPtr = (Address)KUSEG_BASE; 
		*sizePtr=(unsigned long int)USERSPACESIZE;
		/*slfsmm031023_maymod<*/
    }
    else return MM_ADDRESSSPACERANGEFAILED;
    return MM_ADDRESSSPACERANGEOK;
}
