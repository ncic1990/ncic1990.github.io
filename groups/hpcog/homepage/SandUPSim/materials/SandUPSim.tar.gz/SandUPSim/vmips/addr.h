/*This is the Addr module of sand simulator, which is developed by
ASL group of NCIC;
Copyright 2003 by ASL NCIC */
#ifndef _ADDR_H
#define _ADDR_H

#include "sysinclude.h"
#include "memstat.h"
#include "clkmem.h"
class CPU;
class CACHE;
class Mapper;

/*slfsmm031207_add>for tlb short cut*/
#include "globalopt.h"
#ifdef TLBSHORTCUT
typedef union
{
	struct
	{
		uint8      z0   ;
		unsigned g    : 1 ;   //global
		unsigned v    : 1 ;   //dirty
		unsigned d    : 1 ;   //validate
		unsigned n    : 1 ;    //cacheable
		unsigned pfn  : 20;
	}entrylo;
	uint32 tlblo;
}TLB_ENTRY_LO;       
#endif
/*slfsmm031107_add<*/

class  Addr
{
friend class ClkMem;
private:		
	CPU* cpu;	
	Mapper *mem;
	uint32 phys;	
	bool cacheable;
	Memstat * memstat;	
	ClkMem* clkmem;
	uint32 memsize;
	
	/*slfsmm031207_add>for tlb short cut*/
	#ifdef TLBSHORTCUT
	#define TLBSHORTCUTFAILED 0xffffffff
	inline uint32 AddrTlbTransShortCut(uint32 vaddr, int mode, bool *cacheable);
	bool opt_tlbshortcut;
	#endif
	/*slfsmm031207_add<*/

public:

	CACHE *cache;
       Addr();
	inline  bool inmem(uint32 addr)	
	{
		if(addr >= 0 && addr <= memsize)
			return true;
		return false;
	}
	
       void attach(CPU* p = NULL, Mapper* m = NULL,CACHE *c = NULL, Memstat * ms = NULL,ClkMem *cm = NULL);
       virtual ~Addr();       
       void fetch_instr(uint32 vaddr, uint32* data, uint8 * delay_time);
	void fetch_word(uint32 vaddr, uint32* data, uint8* delay_time);
	void fetch_wordl(uint32 vaddr, uint32 regdata,  uint32* data, uint8* delay_time);
	void fetch_wordr(uint32 vaddr, uint32 regdata, uint32* data, uint8* delay_time);
	void fetch_half_word(uint32 vaddr, uint16* data, uint8* delay_time);
	void fetch_byte(uint32 vaddr, uint8* data, uint8* delay_time);
	void store_word(uint32 vaddr, uint32 data, uint8* delay_time);
	void store_wordl(uint32 vaddr, uint32 regdata,  uint8* delay_time);
	void store_wordr(uint32 vaddr, uint32 regdata,  uint8* delay_time);
	void store_half_word(uint32 vaddr, uint16 data, uint8* delay_time);
	void store_byte(uint32 vaddr, uint8 data, uint8* delay_time);        
	
};
#endif   //_ADDR_H
