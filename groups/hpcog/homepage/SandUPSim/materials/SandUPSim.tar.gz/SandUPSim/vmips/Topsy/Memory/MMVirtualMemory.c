/*
	Copyright (c) 1996-1997 Swiss Federal Institute of Technology, 
	Computer Engineering and Networks Laboratory. All rights reserved.

	TOPSY - A Teachable Operating System. 
		Implementation of a tiny and simple micro kernel for
		teaching purposes.

	Permission to use, copy, modify, and distribute this software and its
	documentation for any purpose, without fee, and without written 
	agreement is hereby granted, provided that the above copyright notice 
	and the following two paragraphs appear in all copies of this software.


	
	File:                  $Source: /work/cvs/cvsroot/Topsy/Memory/MMVirtualMemory.c,v $
 	Author(s):             George Fankhauser
 	Affiliation:           ETH Zuerich, TIK
 	Version:               $Revision: 1.23.4.1 $
 	Creation Date:         
 	Last Date of Change:   $Date: 2004/10/15 12:19:46 $      by: $Author: slfsmm $
	
	
*/


#include "Topsy.h"
#include "Configuration.h"

#include "Memory.h"
#include "MMMapping.h"
#include "MemoryLayout.h"
#include "MMVirtualMemory.h"
#include "List.h"
#include "HashList.h"
#include "TMHal.h"
#include "LinuxSyscallErrno.h"
#include "LinuxSyscallmman.h"
#include "globalopt.h"

extern HashList threadHashList;
unsigned long userheapstart;
unsigned long userbrk;
unsigned long TASK_UNMAPPED_BASE;
unsigned long userstackbase;

#define STACKSIZE TM_DEFAULTTHREADSTACKSIZE

/*slfsmm031031_add>*/
extern long USERMEM;
//#define DEBUGVMM
/*slfsmm031031_add<*/

static void vmInitRegion(List list, Address startAddr, unsigned long int size,
		RegionStatus status, ProtectionMode pmode, ThreadId owner);
static Boolean vmFreeRegion(List list, List freeList, 
		Region region, Address address, ThreadId owner);
static Boolean vmAllocRegion(Region region, Page pages, List list, 
			     List freeList, ThreadId sender, Address* addr);
static Boolean isPageInRegion(Region region, Page page, int mode);
static Region getRegion(Address address, int mode, ThreadId hint);

static unsigned long int roundToPageUp(unsigned long int x);
static unsigned long int roundUp(unsigned long int x);

/*slfsmm003_mov>move  to file "MMVirtualMemory.h"*/
//static AddressSpaceDesc addressSpaces[ADDRESSSPACES];
/*slfsmm003_mov<*/

/* the heap follows always kernel code and data. this function returns
 * the start address in order to allow early initialization of the heap
 */
Address mmVmGetHeapAddress( Address kernelDataStart, 
			    unsigned long int kernelDataSize)
{
    return (Address)0xa000a000;//roundUp((unsigned long)kernelDataStart + kernelDataSize);
}


/* this is topsy's initial vm region setup. note the two stacks that are
 * made in advance for tmInit to startup properly.
 */
Error  mmVmInit(Address kernelCodeStart, unsigned long int kernelCodeSize,
		Address kernelDataStart, unsigned long int kernelDataSize,
		Address userCodeStart, unsigned long int userCodeSize,
		Address userDataStart, unsigned long int userDataSize,
		Address* mmStackPtr, Address* tmStackPtr)
{
    AddressSpacePtr space;
    Address addr;
    unsigned long int size, loc;
	
	ioConsolePutString("vminit begin........\n");

    /*** setup kernel memory regions (a total of 7 initial regions) */
    mmAddressSpaceRange(KERNEL, &addr, &size);
    space = &(addressSpaces[KERNEL]);
    space->regionList = listNew();
    space->freeList = listNew();
    space->startPage = LOGICALPAGENUMBER((unsigned long int)addr);
    space->endPage = roundToPageUp((unsigned long int)addr + size);
          
    /** boot/exception stack */
    vmInitRegion (space->regionList, (Address)BOOTSTACKBOTTOM, BOOTSTACKSIZE, 
    		VM_ALLOCATED, READ_WRITE_REGION, 0);
		
    /** kernel code */
    vmInitRegion (space->regionList, kernelCodeStart, kernelCodeSize, 
		VM_ALLOCATED, READ_ONLY_REGION, 0);
		
    /** kernel data */
    vmInitRegion (space->regionList, kernelDataStart, kernelDataSize, 
		VM_ALLOCATED, READ_WRITE_REGION, 0);

    /** page table region */
    vmInitRegion (space->regionList, (Address)0xa0400000, 2*1024*1024, 
    		VM_ALLOCATED, READ_ONLY_REGION, 0);

		
    /** heap region */
    loc = (unsigned long)mmVmGetHeapAddress(kernelDataStart, kernelDataSize);
    vmInitRegion (space->regionList, (Address)loc, KERNELHEAPSIZE, 
    		VM_ALLOCATED, READ_WRITE_REGION, 0);
    
    /** mmStack */
    //loc=0xa000a000;
    loc += KERNELHEAPSIZE;
    vmInitRegion (space->regionList, (Address)loc, STACKSIZE, 
    		VM_ALLOCATED, READ_WRITE_REGION, 0);
    *mmStackPtr = (Address)loc;

    /** tmStack */
    loc += STACKSIZE;
    vmInitRegion (space->regionList, (Address)loc, STACKSIZE, 
    		VM_ALLOCATED, READ_WRITE_REGION, 0);
    *tmStackPtr = (Address)loc;

    /** free region for kernel memory */
    loc += STACKSIZE;
    /*vmInitRegion (space->freeList, 
    		(Address)loc, size - (loc - (unsigned long int)addr), 
		VM_FREED, READ_WRITE_REGION, 0);*/
    vmInitRegion (space->freeList, 
    		(Address)0xa0020800, 0x7f000, 
		VM_FREED, READ_WRITE_REGION, 0);
        
	ioConsolePutString("vminit OK.\n");
	
    return MM_VMINITOK;
} 

//#define USERVMINITTRACE
/* copy from mmVmInit, for initing user app regions of virtual address. by sgz 2003-10-20*/
//should be called after mmInitMemoryMapping( );
Error  mmUserVmInit(Address userCodeStart, unsigned long int userCodeSize,
		Address userDataStart, unsigned long int userDataSize)
{
    AddressSpacePtr space;
    Address addr;
    unsigned long int size, loc;
	
	ioConsolePutString("user vminit begin........\n");

	userCodeSize=NotLogical_RoundUp(userCodeSize);
	userDataSize=NotLogical_RoundUp(userDataSize);
	#ifdef USERVMINITTRACE
	ioConsolePutString("codeAddr:0x");
	ioConsolePutHexInt(userCodeStart);
	ioConsolePutString("codeSize:0x");
	ioConsolePutHexInt(userCodeSize);
	ioConsolePutString("dataAddr:0x");
	ioConsolePutHexInt(userDataStart);
	ioConsolePutString("dataSize:0x");
	ioConsolePutHexInt(userDataSize);
	#endif

	//init user space manage structure
	mmAddressSpaceRange(USER, &addr, &size);
	space = &(addressSpaces[USER]);
	space->regionList = listNew();
	space->freeList = listNew();
	space->startPage = LOGICALPAGENUMBER((unsigned long int)addr);
	space->endPage = roundToPageUp((unsigned long int)addr + size);
	#ifdef USERVMINITTRACE
	ioConsolePutString("user address space info:\n");
	ioConsolePutString("user space base:0x");
	ioConsolePutHexInt(addr);
	ioConsolePutString("user space size:0x");
	ioConsolePutHexInt(size);
	ioConsolePutString("start logical page:0x");
	ioConsolePutHexInt(space->startPage);
	ioConsolePutString("end logical page:0x");
	ioConsolePutHexInt(space->endPage);
	#endif
	 
	 /*** insert some regions for users address space */
	 /** user code */
	 /** user data */
	 vmInitRegion (space->regionList, userCodeStart, userCodeSize, 
			 VM_ALLOCATED, READ_ONLY_REGION, 0);
	 vmInitRegion (space->regionList, userDataStart, userDataSize, 
			 VM_ALLOCATED, READ_WRITE_REGION, 0);
	
	 /* free region for user memory */
	 /*slfsmm003_mod_add_maymod>*/
	 size=USERMEM-userDataSize-userCodeSize-INITSTACKSIZE;
 	 #ifdef USERVMINITTRACE
	 ioConsolePutString("total memory size:0x");
	 ioConsolePutHexInt(USERMEM);
	 ioConsolePutString("dynamic space size:0x");
	 ioConsolePutHexInt(size);
     ioConsolePutString("brk vs mmap: 1 vs ");
	 ioConsolePutHexInt(DYNAMICCONST-1);
	 #endif
	 loc=(unsigned long int)userDataStart+userDataSize;
	 userheapstart=userbrk=loc;
	 TASK_UNMAPPED_BASE=NotLogical_RoundUp(size/DYNAMICCONST);
	 size-=TASK_UNMAPPED_BASE;
	 TASK_UNMAPPED_BASE+=loc;
	 //now TASK_UNMAPPED_BASE is mmap base and size is mmap size
	 #ifdef USERVMINITTRACE
	 ioConsolePutString("user heap base:0x");
	 ioConsolePutHexInt(userheapstart);
	 ioConsolePutString("user heap size:0x");
	 ioConsolePutHexInt(roundUp(size/DYNAMICCONST));
	 ioConsolePutString("user map base:0x");
	 ioConsolePutHexInt(TASK_UNMAPPED_BASE);
	 ioConsolePutString("user map size:0x");
	 ioConsolePutHexInt(size);
	 #endif
	 /*heap alloc*/
	 if(loc>roundUp(TASK_UNMAPPED_BASE)){
		 ioConsolePutString("MMError:vminit:TASK_UNMAPPED_BASE is too small!\n");
		 return MM_VMINITFAILED;
	 }
	 vmInitRegion (space->regionList, (Address)loc,TASK_UNMAPPED_BASE -loc,
		  VM_HEAP, READ_WRITE_REGION, 0);
	 /*free*/
	 vmInitRegion (space->freeList, (Address)TASK_UNMAPPED_BASE, size ,
		  VM_FREED, READ_WRITE_REGION, 0);
	 /*slfsmm003_mod_add_maymod<*/

	 //user stack region
	 loc=USERSTACKBASE;
	 userstackbase=loc;
	 #ifdef USERVMINITTRACE
	 ioConsolePutString("user statck base:0x");
	 ioConsolePutHexInt(loc);
	 ioConsolePutString("user stack size:0x");
	 ioConsolePutHexInt(INITSTACKSIZE);
	 #endif
	 vmInitRegion (space->regionList, (Address)loc, INITSTACKSIZE, 
			 VM_STACK, READ_WRITE_REGION, 0);
	
	ioConsolePutString("user vminit OK.\n");
	
    return MM_VMINITOK;
} 

Error mmVmAlloc(Address* addressPtr, unsigned long int size, ThreadId owner)
{
    Region region;
    Boolean success;
    List list = addressSpaces[THREAD_MODE(owner)].regionList;
    List freeList = addressSpaces[THREAD_MODE(owner)].freeList;
    Page pages = roundToPageUp(size);
    listGetFirst(freeList, (void**)&region);
    success = vmAllocRegion(region, pages, list, freeList, owner, addressPtr); 
    if (success) return VM_ALLOCOK;
    
    while (region != NULL) {
	listGetNext(freeList, (void**)&region);
	success = vmAllocRegion(region, pages, list, freeList, 
				owner, addressPtr); 
	if (success) {
	    return VM_ALLOCOK;
	}
    }
    return VM_ALLOCFAILED;
}


Error mmVmFree(Address address, ThreadId sender)
{
    List list, freeList;
    Region region;
    Boolean success;
    
    /* test aligned existence of region for given address */
    region = getRegion(address, MM_VMEXACT, MMTHREADID);
    if (region == NULL) {
	WARNING("vmFree failed (no such region)");    
	return VM_FREEFAILED;
    }
    /* kernel threads are allowed to free kernel and user vm regions */
    /* users may only remove their own regions */
    if (THREAD_MODE(region->owner) == KERNEL) {
	if (THREAD_MODE(sender) == USER) {
	    WARNING("vmFree: user tried to free kernel region");
	    return VM_FREEFAILED;
	} 
	list = addressSpaces[KERNEL].regionList;
	freeList = addressSpaces[KERNEL].freeList;
    }
    else {
	list = addressSpaces[USER].regionList;
	freeList = addressSpaces[USER].freeList;
    }
    success = vmFreeRegion(list, freeList, region, address, sender);
    if (success) return VM_FREEOK;

    WARNING("vmFree failed (freeRegion failed)");
    return VM_FREEFAILED;
}


Error mmVmMove(Address* addressPtr, ThreadId newOwner)
{
    Address oldAddress = *addressPtr;
    Region region;
    Page from, to, i;
    Error ret;
    
    if (THREAD_MODE(newOwner) == KERNEL) {
	/* kernel does not want to move regions from kernel to kernel */
	return VM_MOVEFAILED;
    }
    /* moving of pages for virtual memory or copying for direct mapping */
    region = getRegion(oldAddress, MM_VMEXACT, MMTHREADID);
    if (region == NULL) {
	return VM_MOVEFAILED;
    }    
    ret = mmVmAlloc(addressPtr, region->numOfPages * LOGICALPAGESIZE,newOwner);
    if (ret != VM_ALLOCOK) {
	return VM_MOVEFAILED;
    }
    //ioConsolePutString("mmVmAlloc in mmVmMove ok.\n");
 	//ioConsolePutHexInt(oldAddress);
 	//ioConsolePutHexInt(*addressPtr);

    from = LOGICALPAGENUMBER(oldAddress);
    to = LOGICALPAGENUMBER(*addressPtr);
 	//ioConsolePutHexInt(from);
 	//ioConsolePutHexInt(to);
 	//ioConsolePutHexInt(region->numOfPages);
    for (i = 0; i < region->numOfPages; i++) {
	if (mmMovePage(from, to) != MM_MOVEPAGEOK) {
	    mmVmFree(addressPtr, MMTHREADID);
	    WARNING("vmMove: page moving failed");
	    return VM_MOVEFAILED;
	}
	//ioConsolePutHexInt(i);
	from++; to++;
    }
    //ioConsolePutString("mmMovePage in mmVmMove ok.\n");
    mmVmFree(oldAddress, MMTHREADID);
    return VM_MOVEOK;
}


Error mmVmProtect(Address startAddr, unsigned long int size,
		   ProtectionMode pmode, ThreadId owner)
{
    Page page, end;
    Region region;
    
    if (LOGICALPAGEREMAINDER(size) != 0) return VM_PROTECTFAILED;

    /* pages must be in a region to protect */
    region = getRegion(startAddr, MM_VMINSIDE, owner);
    if (region == NULL) return VM_PROTECTFAILED;

    /* users must own the regions */
    if (THREAD_MODE(owner) == USER) {
	if (region->owner != owner) return VM_PROTECTFAILED;
    }
    end = LOGICALPAGENUMBER(size) + LOGICALPAGENUMBER(startAddr);
    for (page = LOGICALPAGENUMBER(startAddr); page < end; page++) {
	if (mmProtectPage(page, pmode) == MM_PROTECTPAGEFAILED)
	    return VM_PROTECTFAILED;
    }
    return VM_PROTECTOK;
}


/* this kernel internal message is used to reclaim all vm resource
 * owned by a thread. just in case it forgets to call vmFree or it
 * crashes before doing it.
 * we assume that kernel threads do not allocate and own vmRegions
 * in user space.
 */
 /*slfsmm031214_bug_mod>bug of VmCleanup: operation of listGetFirst and listGetNext*/
/*
 Error mmVmCleanup(ThreadId id)
 {
	 List list;
	 Region region;
 
	 list = addressSpaces[THREAD_MODE(id)].regionList;
	 listGetFirst(list, (void**)&region);
	 while (region != NULL) {
		 if (region->owner == id)
			 mmVmFree((Address)(region->startPage * LOGICALPAGESIZE), id);
		 listGetNext(list, (void**)&region);
	 }
	 return VM_CLEANUPOK;
 }
 */
 //#define DBGVMCLEARUP
Error mmVmCleanup(ThreadId id)
{
    List list;
    Region region;
	ListElement current;
	Region nextregion;

	#ifdef DBGVMCLEARUP
	ioConsolePutString("................mmVmCleanup.................\n");
	#endif
    list = addressSpaces[THREAD_MODE(id)].regionList;
    listGetFirst(list, (void**)&region);
	listGetNext(list,(void**)&nextregion);
	current=list->current;
    while (region != NULL) {
	if (region->owner == id) {
		#ifdef DBGVMCLEARUP
		ioConsolePutHexInt(count);
		ioConsolePutHexInt(region->startPage * LOGICALPAGESIZE);
		ioConsolePutHexInt(region->numOfPages);
		ioConsolePutHexInt(region->pmode);
		#endif
		mmVmFree((Address)(region->startPage * LOGICALPAGESIZE), id);
	}
	list->current=current;
	region=nextregion;
	listGetNext(list, (void**)&nextregion);
	current=list->current;
    }	
    return VM_CLEANUPOK;
}
/*slfsmm031214_bug_mod<*/


static Boolean isPageInRegion(Region region, Page page, int mode)
{
    if (mode == MM_VMEXACT) {
	if (region->startPage == page) return TRUE;
	else return FALSE;
    }
    else if (mode == MM_VMINSIDE) {
	if (page >= region->startPage && 
	    page < region->startPage + region->numOfPages) return TRUE;
	else return FALSE;
    }
    return FALSE;
}


static Region getRegion(Address address, int mode, ThreadId hint)
{    
    List list;
    AddressSpace first, then;
    Region region;
    Page page = LOGICALPAGENUMBER(address);

    if (mode == MM_VMEXACT) {
    	if (LOGICALPAGEREMAINDER(address) != 0) {
	    WARNING("getRegion: got unaligned address");
	    return NULL;
	}
    }	
    if (THREAD_MODE(hint) == USER) { first = USER; then = KERNEL; }
    else { first = KERNEL; then = USER; }

    list = addressSpaces[first].regionList;
    listGetFirst(list, (void**)&region);
    while (region != NULL) {
	if (isPageInRegion(region, page, mode)) return region;
	listGetNext(list, (void**)&region);
    }	
    list = addressSpaces[then].regionList;
    listGetFirst(list, (void**)&region);
    while (region != NULL) {
	if (isPageInRegion(region, page, mode)) return region;
	listGetNext(list, (void**)&region);
    }
    return NULL;
}


static Boolean vmFreeRegion(List list, List freeList, 
			    Region region, Address address, ThreadId sender)
{
    unsigned long int page = LOGICALPAGENUMBER(address);
    
    if (region == NULL) return FALSE;
    
    if (region->startPage == page) {
	if ((region->owner == sender) || (THREAD_MODE(sender) == KERNEL)) {
		listRemove(list, (void*)region, NULL);
		mmUnmapPages(region->startPage, region->numOfPages);
#ifndef CONFIG_MM_MERGE
		listAddInFront(freeList, (void*)region, NULL);
#else
		Region currregion;
		Region oldregion=NULL;
		int mergeflag=0;
		for_each_item(freeList,currregion){
			if(currregion->startPage>region->startPage)
				break;
			oldregion=currregion;
		}
		if(oldregion!=NULL && oldregion->startPage+oldregion->numOfPages==region->startPage&&
			oldregion->pmode==region->pmode){
			mergeflag+=1;
		}
		if(currregion!=NULL && currregion->startPage==region->startPage+region->numOfPages&&
			currregion->pmode==region->pmode){
			mergeflag+=2;
		}
		switch(mergeflag){
			case 1: oldregion->numOfPages+=region->numOfPages; break;
			case 2: currregion->startPage=region->startPage;
				currregion->numOfPages+=region->numOfPages;
				break;
			case 3: oldregion->numOfPages+=region->numOfPages+currregion->numOfPages;
				if(listRemove(freeList, (void*)currregion, NULL)==LIST_OK){
					hmFree(currregion);
					goto merged;
				}
			default:
				if(listAddCurr(freeList, (void*)region, NULL)==LIST_ERROR)
					return FALSE;
				else return TRUE;
		}
	merged:
		hmFree(region);
#endif/*end of CONFIG_MM_MERGE*/
		return TRUE;
	}
    }
    return FALSE;
}


/* allocates a region without mapping pages. pages are mapped either
 * on demand (when a paged memory model is used) or they don't need
 * to be mapped at all for a direct mapped memory model.
 */
 /*split the free region and alloc the first part*/
static Boolean vmAllocRegion(Region region, Page pages, List list, 
			     List freeList, ThreadId sender, Address* addr)
{
    Region newRegion;
    
    if (region == NULL) return FALSE;

    if (region->numOfPages > pages) {
	/* make new region, split free into an allocated and a free one */
	if (hmAlloc((Address*)&newRegion, sizeof(RegionDesc)) != HM_ALLOCOK)
	    return FALSE;
	newRegion->owner = sender;
	newRegion->startPage = region->startPage;
	newRegion->numOfPages = pages;

	*addr = (Address)((newRegion->startPage) * LOGICALPAGESIZE);
	listAddInFront(list, newRegion, NULL);   /* add new region to list */
	
	/* adjust free region, subtract used space */
	region->owner = ANY;
	region->startPage += pages;
	region->numOfPages -= pages;
//	zeroOut(*addr, pages*LOGICALPAGESIZE);
	return TRUE;
    }
    else if (region->numOfPages == pages) {
	region->owner = sender;
	*addr = (Address)((region->startPage) * LOGICALPAGESIZE);
	listRemove(freeList, region, NULL);  /* changing places */
	listAddInFront(list, region, NULL);
//	zeroOut(*addr, pages*LOGICALPAGESIZE);
	return TRUE;
    }
    return FALSE;
}


static void vmInitRegion(List list, Address startAddr, unsigned long int size,
		RegionStatus status, ProtectionMode pmode, ThreadId owner)
{
    Region region;
    
    hmAlloc((Address*)&region, sizeof(RegionDesc));
    region->startPage = LOGICALPAGENUMBER((unsigned long int)startAddr);
    region->numOfPages = roundToPageUp(size);
    region->pmode = pmode;
    region->owner = owner;
    listAddInFront(list, region, NULL);
}


/* round address up to logical page size and return page number 
 */
static unsigned long int roundToPageUp(unsigned long int x)
{
    if (LOGICALPAGEREMAINDER(x) > 0)
    	return LOGICALPAGENUMBER(x) + 1;
    else
    	return LOGICALPAGENUMBER(x);
}

/* round address up to logical page size and return rounded address 
 */
static unsigned long int roundUp(unsigned long int x)
{
    return roundToPageUp(x) * LOGICALPAGESIZE;
}

/*slfsmm031022_add>handling the page(not logical page)*/
unsigned long NotLogical_RoundToPageUp(unsigned long addr)
{
	if(PAGEREMAINDER(addr)!=0)
		return PAGENUMBER(addr)+1;
	else
		return PAGENUMBER(addr);
}
unsigned long NotLogical_RoundUp(unsigned long addr)
{
	return NotLogical_RoundToPageUp(addr)*PAGESIZE;
}
unsigned long NotLogical_Round(unsigned long addr)
{
	return PAGENUMBER(addr)*PAGESIZE;
}
unsigned long NotLogical_RoundToPage(unsigned long addr)
{
	return PAGENUMBER(addr);
}
/*slfsmm031022_add<*/

/*the following two functions are used to clear up the user address space 
  while user thread exits.*/
void ClearUpUserList(List* listptr)
{
	List list=*listptr;
    Region region;
    ListElement element;
	
	if(list!=NULL)
	{	
	     while((element=list->first)!=NULL)
	     {
	     	
	     	region=(Region)element->item;
	    	listRemove(list, (void*)region, NULL);
	     	if(region==NULL)
	     		ioConsolePutString("VMError:ClearUpUserAddressSpace:supprising error!\n");
	     	else
	     		hmFree(region);
	     }
	     hmFree(list);
	     *listptr=NULL;
	}

}
void ClearUpUserAddressSpace( )
{
    ClearUpUserList(&addressSpaces[USER].regionList);
	ClearUpUserList(&addressSpaces[USER].freeList);
}

/*slfsmm1>*/
/*if the address in the region*/
//#define DBGGETUSERREGIONBYADDR
Region getUserRegionByAddr(Address address,int mode)
{    
    List list;
    Region region;
    Page page = LOGICALPAGENUMBER(address);

	switch(mode){
		case USERALLOCREGION:
		    list = addressSpaces[USER].regionList;
			break;
		case USERFREEREGION:
		    list = addressSpaces[USER].freeList;
			break;
		default:
			ioConsolePutString("Invalid mode when calling getUserRegionByAddr( )!\n");
			return;
	}
	
	listGetFirst(list, (void**)&region);
	while (region != NULL) {
		#ifdef DBGGETUSERREGIONBYADDR
		ioConsolePutString("one of the regions.................................\n");
		ioConsolePutString("region start virt addr:0x");
		ioConsolePutHexInt((int)region->startPage*LOGICALPAGESIZE);
		ioConsolePutString("region size:0x");
		ioConsolePutHexInt((int)region->numOfPages*LOGICALPAGESIZE);
		#endif
		if (isPageInRegion(region, page, MM_VMINSIDE)) return region;
		listGetNext(list, (void**)&region);
	}
	return NULL;
	
}
/*slfsmm1<*/

/*slfsmm040309_add>for allocating space starting at a fix address*/
/*addressPtr must be aligned to page*/
//#define DBGMMUSERVMFIXALLOC
Error mmUserVmFixAlloc(Address addressPtr, unsigned long int size, ThreadId owner)
{
    Region region;
	Region leftregion;
    Boolean success;
    List list = addressSpaces[THREAD_MODE(owner)].regionList;
    List freeList = addressSpaces[THREAD_MODE(owner)].freeList;
	Page startlogicpage=LOGICALPAGENUMBER((Page)addressPtr);
    Page pages = roundToPageUp(size);
	Page leftlogicpage;
	Address addr;

	#ifdef DBGMMUSERVMFIXALLOC
	ioConsolePutString("VMmsg:mmUserVmFixAlloc begins...\n");
	ioConsolePutString("address:0x");
	ioConsolePutHexInt((int)addressPtr);
	ioConsolePutString("size:0x");
	ioConsolePutHexInt((int)size);
	ioConsolePutString("startlogicpage:0x");
	ioConsolePutHexInt((int)startlogicpage);
	ioConsolePutString("pages:0x");
	ioConsolePutHexInt((int)pages);
	#endif
	region=getUserRegionByAddr(addressPtr,USERFREEREGION);
	//is the region exists and large enough??
	if(region==NULL){
		ioConsolePutString("VMErr:mmUserVmFixAlloc:The fix region is not free!\n");
		return VM_ALLOCFAILED;
	}
	#ifdef DBGMMUSERVMFIXALLOC
	ioConsolePutString("msg:The fix region is free!\n");
	ioConsolePutString("region startlogicpage:0x");
	ioConsolePutHexInt((int)region->startPage);
	ioConsolePutString("region numOfPages:0x");
	ioConsolePutHexInt((int)region->numOfPages);
	#endif
	if(region->numOfPages<(pages+(startlogicpage-region->startPage))){
		ioConsolePutString("VMErr:mmUserVmFixAlloc:The fix region is not enough!\n");
		return VM_ALLOCFAILED;
	}
	//ok
	//split the region
	leftlogicpage=startlogicpage-region->startPage;
	if(leftlogicpage>0){
		if (hmAlloc((Address*)&leftregion, sizeof(RegionDesc)) != HM_ALLOCOK){
			ioConsolePutString("VMErr:mmUserVmFixAlloc:alloc RegionDesc failed!\n");
			return VM_ALLOCFAILED;
		}
		leftregion->owner = region->owner;
		leftregion->startPage = region->startPage;
		leftregion->numOfPages = leftlogicpage;
		listAddInFront(freeList, leftregion, NULL);
		
		/* adjust free region, subtract used space */
		region->startPage += leftlogicpage;
		region->numOfPages -= leftlogicpage;
	}

	//alloc the needed space
    success = vmAllocRegion(region, pages, list, freeList, owner, &addr); 
    if (success&&(addr==addressPtr)) return VM_ALLOCOK;
    return VM_ALLOCFAILED;
}
/*slfsmm040309_add<*/

/*slfsmm002>*/
/*slfsmm003_mod>*/
long brk(unsigned long brk,ThreadId sender)
{
	long ret;
    Error errorCode = TM_OK;
    Thread* fromThreadPtr;
	
    /* Lookup in hash table to find pointer onto threadId */
	if(THREAD_MODE(sender)!=USER){
		ioConsolePutString("MMError:brk:Kernel calls brk!\n");
		ret= -EPERM;
		goto outfailed;
	}
    if ((errorCode = hashListGet( threadHashList, (void**)(&fromThreadPtr),
				  sender)) != HASHOK) {
		ioConsolePutString("MMError:brk:required thread id does not exist!\n");
		ret= -EPERM;
		goto outfailed;
    }
	#ifdef DEBUGVMM
	ioConsolePutString("sys_brk( )...\n");
	ioConsolePutString("parameters:\n");
	ioConsolePutString("brk--0x");
	ioConsolePutHexInt(brk);
	#endif

	ret=do_brk(brk);
	#ifdef DEBUGVMM
	ioConsolePutString("retval:0x");
	ioConsolePutHexInt(ret);
	ioConsolePutString("\n");
	#endif
	HandlingTLSyscallReturn(fromThreadPtr,ret);
outfailed:
	return ret;
}

long mmap(unsigned long addr, unsigned long len, unsigned long prot,
         unsigned long flags, unsigned long fd, unsigned long offset,ThreadId sender)
{
	long ret;
    Error errorCode = TM_OK;
    Thread* fromThreadPtr;
	
    /* Lookup in hash table to find pointer onto threadId */
	if(THREAD_MODE(sender)!=USER){
		ioConsolePutString("MMError:mmap:Kernel calls mmap!\n");
		ret= -EPERM;
		goto outfailed;
	}
    if ((errorCode = hashListGet( threadHashList, (void**)(&fromThreadPtr),
				  sender)) != HASHOK) {
		ioConsolePutString("MMError:map:required thread id does not exist!\n");
		ret= -EPERM;
		goto outfailed;
    }
	#ifdef DEBUGVMM
	ioConsolePutString("sys_mmap( )...\n");
	ioConsolePutString("parameters:\n");
	ioConsolePutString("addr--0x");	
	ioConsolePutHexInt(addr);
	ioConsolePutString("len--0x");	
	ioConsolePutHexInt(len);
	ioConsolePutString("prot--0x");	
	ioConsolePutHexInt(prot);
	ioConsolePutString("flags--0x");	
	ioConsolePutHexInt(flags);
	ioConsolePutString("fd--0x");	
	ioConsolePutHexInt(fd);
	ioConsolePutString("offset--0x");	
	ioConsolePutHexInt(offset);
	#endif

	//do file offset checking 
	ret=-EINVAL;
	if(offset&(PAGESIZE-1))
		goto outfailed;
	ret=do_mmap(addr,len,prot,flags,fd,offset>> PAGEBITS,sender);
	#ifdef DEBUGVMM
	ioConsolePutString("retval:0x");
	ioConsolePutHexInt(ret);
	ioConsolePutString("\n");
	#endif
	HandlingTLSyscallReturn(fromThreadPtr,ret);
outfailed:
	return ret;
}

long munmap(unsigned long addr, unsigned long len,ThreadId sender)
{
	long ret;
    Error errorCode = TM_OK;
    Thread* fromThreadPtr;
	
    /* Lookup in hash table to find pointer onto threadId */
	if(THREAD_MODE(sender)!=USER){
		ioConsolePutString("MMError:munmap:Kernel calls munmap!\n");
		ret= -EPERM;
		goto outfailed;
	}
    if ((errorCode = hashListGet( threadHashList, (void**)(&fromThreadPtr),
				  sender)) != HASHOK) {
		ioConsolePutString("MMError:munmap:required thread id does not exist!\n");
		ret= -EPERM;
		goto outfailed;
    }
	#ifdef DEBUGVMM
	ioConsolePutString("sys_munmap( )...\n");
	ioConsolePutString("parameters:\n");
	ioConsolePutString("addr--0x");
	ioConsolePutHexInt(addr);
	ioConsolePutString("len--0x");
	ioConsolePutHexInt(len);
	#endif

	ret=do_unmap(addr,len,sender);
	#ifdef DEBUGVMM
	ioConsolePutString("retval:0x");
	ioConsolePutHexInt(ret);
	ioConsolePutString("\n");
	#endif
	HandlingTLSyscallReturn(fromThreadPtr,ret);
outfailed:
	return ret;
}

long mmap2(unsigned long addr, unsigned long len, unsigned long prot,
          unsigned long flags, unsigned long fd, unsigned long pgoff,ThreadId sender)
{
	long ret;
    Error errorCode = TM_OK;
    Thread* fromThreadPtr;
	
    /* Lookup in hash table to find pointer onto threadId */
	if(THREAD_MODE(sender)!=USER){
		ioConsolePutString("MMError:mmap2:Kernel calls mmap2!\n");
		ret= -EPERM;
		goto outfailed;
	}
    if ((errorCode = hashListGet( threadHashList, (void**)(&fromThreadPtr),
				  sender)) != HASHOK) {
		ioConsolePutString("MMError:mmap2:required thread id does not exist!\n");
		ret= -EPERM;
		goto outfailed;
    }
	#ifdef DEBUGVMM
	ioConsolePutString("sys_mmap2( )...\n");
	ioConsolePutString("parameters:\n");
	ioConsolePutString("addr--0x");	
	ioConsolePutHexInt(addr);
	ioConsolePutString("len--0x");	
	ioConsolePutHexInt(len);
	ioConsolePutString("prot--0x");	
	ioConsolePutHexInt(prot);
	ioConsolePutString("flags--0x");	
	ioConsolePutHexInt(flags);
	ioConsolePutString("fd--0x");	
	ioConsolePutHexInt(fd);
	ioConsolePutString("pgoff--0x");	
	ioConsolePutHexInt(pgoff);
	#endif
	
	ret=do_mmap(addr,len,prot,flags,fd,pgoff,sender);
	#ifdef DEBUGVMM
	ioConsolePutString("retval:0x");
	ioConsolePutHexInt(ret);
	ioConsolePutString("\n");
	#endif
	HandlingTLSyscallReturn(fromThreadPtr,ret);
outfailed:
	return ret;
}
/*slfsmm003_mod<*/
/*slfsmm003_add>*/
long do_brk(unsigned long brk)
{
	long retval;

	if (brk < userheapstart)
		goto out;
	if(brk>TASK_UNMAPPED_BASE){
		ioConsolePutString("VMError:do_brk:heap overflow! userheapend:0x");
		ioConsolePutHexInt(TASK_UNMAPPED_BASE);
		goto out;
	}
	if(getUserRegionByAddr((Address)userheapstart,USERALLOCREGION)==NULL){
		ioConsolePutString("VMError:do_brk:heap region does not exist!\n");
		goto out;
	}
	/*slfsmm041014_bug_add>the new space should be zeroout*/
	if(brk>userbrk) 
		TAmemset(userbrk, 0, brk-userbrk);
	/*slfsmm041014_bug_add<*/
	userbrk = brk;
out:
	retval = userbrk;
	return retval;

}
//#define DBGDOMMAP
long do_mmap(unsigned long addr, unsigned long len,unsigned long prot,
	unsigned long flags, unsigned long fd, unsigned long pgoff,ThreadId sender)
{
	long retval=-EBADF;
	unsigned long fd_now=(unsigned long)-1;

	flags &= ~(MAP_EXECUTABLE | MAP_DENYWRITE);
	if(!(flags & MAP_ANONYMOUS)){
#define ValidFd(fd) (TLlseek(fd,0,1)>=0)
		if(!ValidFd(fd)){
			#ifdef DBGDOMMAP
			ioConsolePutString("VMError:do_mmap:invalid fd!\n");
			ioConsolePutString("fd:0x");
			ioConsolePutHexInt(fd);
			ioConsolePutString("checking value:0x");
			ioConsolePutHexInt(ValidFd(fd));
			#endif
			goto out;
		}
#undef ValidFd
	fd_now=fd;
	}
	
	retval= do_mmap_pgoff(fd_now, addr, len, prot, flags, pgoff,sender);
out:
	return retval;
}
//#define DBGDOMMAPPGOFF
long do_mmap_pgoff(unsigned long fd, unsigned long addr, unsigned long len,
	unsigned long prot, unsigned long flags, unsigned long pgoff,ThreadId sender)
{
	long retval=-EPERM;
	Address addralloced;
	unsigned long count;
	char* base;

	//len align
	if ((len = PAGE_ALIGN(len)) == 0)
		return addr;
	//len checking
	if (len > TASK_SIZE){
		#ifdef DBGDOMMAPPGOFF
		ioConsolePutString("VMErr:do_mmap_pgoff:len checking 1!\n");
		#endif
		return -EINVAL;
	}
	if ((pgoff + (len >> PAGE_SHIFT)) < pgoff){
		#ifdef DBGDOMMAPPGOFF
		ioConsolePutString("VMErr:do_mmap_pgoff:len checking 2!\n");
		#endif
		return -EINVAL;
	}

	//may be modified
	retval=-ENOMEM;
	if (flags & MAP_FIXED) {
		if (addr > TASK_SIZE - len)
			return -ENOMEM;
		if (addr & (PAGESIZE-1))
			return -EINVAL;
		/*should be push back --040309------------------------------------>*/
		if(sender==0)
		/*<--------------------------------------------------------------*/
		if(mmUserVmFixAlloc((Address)addr,len,sender)!=VM_ALLOCOK){
			ioConsolePutString("VMError:do_mmap_pgoff: Can not alloc the fix space!\n");
			goto out;
		}
		addralloced=(Address)addr;
	}else{
		if(mmVmAlloc(&addralloced,len,sender)!=VM_ALLOCOK){
			ioConsolePutString("VMError:do_mmap_pgoff: Not enough memory!\n");
			goto out;
		}
		if((unsigned long)addralloced<addr)
			ioConsolePutString("VMWarning:do_mmap_pgoff: parameter addr is ignored!\n");
	}

	/*set the space to zero*/
	base=(char*)addralloced;
	count=len;
	if(count>0){
		#ifdef TASSISTMEMSET
		TAmemset(base, 0, count);
		#else
		int i;
		for(i=0;i<count;i++,base++)
			*base=(char)0;
		#endif
	}
	//is it file mapping??
	if((long)fd<0) goto outok;
	
	//mapping a file into the user space
	retval=-EBADF;
	if(TLlseek(fd,pgoff<<PAGE_SHIFT,0)<0)
		goto out_free_mm;
	count=TLread(fd, (char*)addralloced, len);
	if(count<0||count>len)
		goto out_free_mm;
	
outok:
	return (long)addralloced;
out_free_mm:
	if(mmVmFree((Address)addralloced,sender)!=VM_FREEOK)
		ioConsolePutString("VMError:do_unmap:surprising error!\n");
out:
	return retval;
}
long do_unmap(unsigned long addr, unsigned long len,ThreadId sender)
{
	long retval=-EINVAL;
	Region region;

    if((region = getRegion((Address)addr, MM_VMEXACT, MMTHREADID))==NULL){
		ioConsolePutString("VMError:do_unmap:free failed (no such region)!\n");
		goto out;
    }
	if(region->numOfPages*LOGICALPAGESIZE!=len){
		ioConsolePutString("VMError:do_unmap:free failed (len not equal to that in region)!\n");
		goto out;
	}

	if(mmVmFree((Address)addr,sender)!=VM_FREEOK){
		ioConsolePutString("VMError:do_unmap:surprising error!\n");
		goto out;
	}

	return 0;
out:
	return retval;
}
void HandlingTLSyscallReturn(Thread* sender,long ret)
{
	if(ret>=0){
		sender->contextPtr->argument[3]=0;
		sender->contextPtr->returnValue[0]=ret;
	}else{
		sender->contextPtr->argument[3]=1;
		sender->contextPtr->returnValue[0]=-ret;
	}
}
/*slfsmm003_add<*/
/*slfsmm031027_add>*/
long mprotect(unsigned long start, unsigned int len, unsigned long prot,ThreadId sender)
{
	long ret;
    Error errorCode = TM_OK;
    Thread* fromThreadPtr;
	
    /* Lookup in hash table to find pointer onto threadId */
	if(THREAD_MODE(sender)!=USER){
		ioConsolePutString("MMError:mmap2:Kernel calls mmap2!\n");
		return;
	}
    if ((errorCode = hashListGet( threadHashList, (void**)(&fromThreadPtr),
				  sender)) != HASHOK) {
		ioConsolePutString("MMError:mmap2:required thread id does not exist!\n");
		return;
    }
	#ifdef DEBUGVMM
	ioConsolePutString("sys_mprotect( )...\n");
	ioConsolePutString("parameters:\n");
	ioConsolePutString("start->0x");	
	ioConsolePutHexInt(start);
	ioConsolePutString("len->0x");	
	ioConsolePutHexInt(len);
	ioConsolePutString("prot->0x");	
	ioConsolePutHexInt(prot);
	#endif

	ret=do_mprotect(start,len,prot,sender);
	#ifdef DEBUGVMM
	ioConsolePutString("retval:0x");
	ioConsolePutHexInt(ret);
	ioConsolePutString("\n");
	#endif
	HandlingTLSyscallReturn(fromThreadPtr,ret);

}
long do_mprotect(unsigned long start, unsigned int len, unsigned long prot,ThreadId sender)
{
	unsigned long end;
	
	if (start & PAGEMASK)
		return -EINVAL;
	len = NotLogical_RoundUp(len);
	end = start + len;
	if (end < start)
		return -EINVAL;
	if (prot & ~(PROT_READ | PROT_WRITE | PROT_EXEC))
		return -EINVAL;
	if (end == start)
		return 0;

	ioConsolePutString("VMMsg:do_mprotect: the protection is ignored!\n");
	return 0;
}
/*slfsmm031027_add<*/
/*slfsmm002<*/
