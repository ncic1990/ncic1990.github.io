#ifndef __SUPPORT_H
#define __SUPPORT_H
/*
	Copyright (c) 1996-1997 Swiss Federal Institute of Technology, 
	Computer Engineering and Networks Laboratory. All rights reserved.

	TOPSY - A Teachable Operating System. 
		Implementation of a tiny and simple micro kernel for
		teaching purposes.

	Permission to use, copy, modify, and distribute this software and its
	documentation for any purpose, without fee, and without written 
	agreement is hereby granted, provided that the above copyright notice 
	and the following two paragraphs appear in all copies of this software.


	
	File:                  $Source: /work/cvs/cvsroot/Topsy/Topsy/Support.h,v $
 	Author(s):             Christian Conrad
 	Affiliation:           ETH Zuerich, TIK
 	Version:               $Revision: 1.9 $
 	Creation Date:         
 	Last Date of Change:   $Date: 2003/12/09 07:57:24 $      by: $Author: slfsmm $
	
	
*/

#include "Topsy.h"
//#include "LibcLinuxTypes.h"

/*
 * Copy nbBytes from address srcAddress to address targetAddress.
 * (equivalent to UNIX memcpy(), new name to avoid confusion).
 */
void byteCopy( Address targetAddress, Address sourceAddress, unsigned long int nbBytes);

/* fill memory with zeros */
void zeroOut(Address target, unsigned long int size);

/*
 * Copy a NULL-terminated string from source to target.
 * (equivalent to UNIX strcpy(), new name to avoid confusion).
 */
void stringCopy( char* target, char* source );

/* copies a string or at most the first size-1 bytes 
 * and terminates it with 0 
 */
void stringNCopy( char* target, char* source, unsigned long int size);

/* support function (in assembler) to test and set memory
 * in one atomic step
 */
Boolean testAndSet(Boolean* lockvar);

long stringlen(char* buf);

int stringcmp(char *a, char *b);

char* findstringblock(char* start, long* blocklen);

//when find,return offset in block; when failed ,return -1
int findcharinblock(char* start,long len,char c);
//clear the bland char at the header of string
void clearHeaderSpaceInString(char* src, char* des);
void clearEndingSpaceInString(char* str);
//when meeting the first '\n', change it to '\0' in a string
void ReturnToNullInString(char* src);
//only copy n chars from source to dest
void StringOnlyNCopy(char* dest, char* src, long size);

#endif /*__SUPPORT_H*/

