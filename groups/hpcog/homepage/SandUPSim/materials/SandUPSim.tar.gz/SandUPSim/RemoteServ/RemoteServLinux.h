#ifndef REMOTESERVLINUX_H
#define REMOTESERVLINUX_H
#include "RemoteServ.h"

bool LinuxSyscallDispatcher(ReqDBH* reqbodyheader);

#endif /*REMOTESERVLINUX_H*/

