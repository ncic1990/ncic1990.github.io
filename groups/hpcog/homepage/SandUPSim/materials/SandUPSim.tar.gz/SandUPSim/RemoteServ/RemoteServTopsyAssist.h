#ifndef REMOTESERVTOPSYASSIST_H
#define REMOTESERVTOPSYASSIST_H
#include "RemoteServ.h"

bool InitTopsyEnv( );
void DestroyTopsyEnv( );
void InstallTopsyEnv( );
void UnInstallTopsyEnv( );
bool TopsyAssistDispatcher(ReqDBH* reqbodyheader);

#endif /*REMOTESERVTOPSYASSIST_H*/
