#include "RemoteServCommon.h"
#include "RemoteServ.h"
#include "DBGRemoteServ.h"

//global data structures
char* RequestBuf=NULL;
char* OriginReqBufBase=NULL;
uint32 OriginReqBufLen;
char* ReplyBuf=NULL;
char* OriginReplyBufBase=NULL;
uint32 OriginReplyBufLen;

//assistant functions
uint32 up2exp(uint32 input)
{
	int i;
	uint32 count=1;
	for(i=0;i<32;i++){
		if(count>=input)
			return count;
		count=count<<1;
	}
	#ifndef REMOTESERVQUIET
	fprintf(stderr,"RemoteServ err: up2exp:There must be something wrong!\n");
	#endif
}
#define ALIGN(input) up2exp(input)
#define DATASETALIGN ALIGN(ORIGINDATASETALIGN)

void initbuffer(char** buf, char** origin, uint32* len)
{
	*origin=NULL;
	*buf=NULL;
	*len=0;
}
bool newbuffer(char** buf,char** originbase,uint32* originlen,uint32 newlen)
{
	*originlen=newlen+(DATASETALIGN-1);
	*originbase=malloc(*originlen);
	if(originbase==NULL){
		#ifndef REMOTESERVQUIET
		fprintf(stderr,"RemoteServ err: malloc does not succeed!\n");
		#endif
		return false;
	}
	*buf=(char*)(((uint32)(*originbase)+(DATASETALIGN-1))&(~(DATASETALIGN-1)));
	return true;
}
void destroybuffer(char** buf,char** origin,uint32* len)
{
	if(buf) free(*origin);
	*len=0;
	*origin=NULL;
	*buf=NULL;
}
bool HALBufferLenChecking( )
{
	if(NetWorkCardBufSize>=sizeof(package_header_t)+sizeof(RDH)+sizeof(RDBH)) return true;
	#ifndef REMOTESERVQUIET
	fprintf(stderr,"RemoteServ err: HALBufferLenChecking:buffer length is too small!\n");
	#endif
	return false;
}
RDH* getbuffer_RDH(char* buf)
{
	if(!buf) {
		#ifndef REMOTESERVQUIET
		fprintf(stderr,"RemoteServ err: getbuffer_RDH:buffer is NULL!\n");
		#endif
		return NULL;
	}
	return (RDH*)buf;
}
bool setbuffer_RDH(char* buf,ServInfoDesc_t* servinfoptr, uint32 datasetlen)
{
	if(!buf) {
		#ifndef REMOTESERVQUIET
		fprintf(stderr,"RemoteServ err: setbuffer_RDH:buffer is NULL!\n");
		#endif
		return false;
	}
	RDH* rdheader=(RDH*)buf;
	rdheader->destaddr=servinfoptr->destaddr;
	rdheader->srcaddr=servinfoptr->srcaddr;
	UNITVAL(rdheader->datasetlen)=datasetlen;
	return true;
}
RDBH* getbuffer_RDBH(char* buf)
{
	if(!buf) {
		#ifndef REMOTESERVQUIET
		fprintf(stderr,"RemoteServ err: getbuffer_RDBH:buffer is NULL!\n");
		#endif
		return NULL;
	}
	return (RDBH*)(buf+sizeof(RDH));
}
bool setbuffer_RDBH(char* buf,ServInfoDesc_t* servinfoptr)
{
	if(!buf) {
		#ifndef REMOTESERVQUIET
		fprintf(stderr,"RemoteServ err: setbuffer_RDBH:buffer is NULL!\n");
		#endif
		return false;
	}
	RDBH* rdbheader=(RDBH*)(buf+sizeof(RDH));
	UNITVAL(rdbheader->servtype)=servinfoptr->type;
	UNITVAL(rdbheader->service)=servinfoptr->service;
	return true;
}
RDBP* getbuffer_Params(char* buf)
{
	if(!buf) {
		#ifndef REMOTESERVQUIET
		fprintf(stderr,"RemoteServ err: getbuffer_Params:buffer is NULL!\n");
		#endif
		return NULL;
	}
	return (RDBP*)(buf+sizeof(RDH)+sizeof(RDBH));
}
bool setbuffer_Params(char* buf,ParamsDesc_t* paramsdesc)
{
	uint32 count;
	
	if(!buf) {
		#ifndef REMOTESERVQUIET
		fprintf(stderr,"RemoteServ err: setbuffer_Params:buffer is NULL!\n");
		#endif
		return false;
	}
	if(!paramsdesc) {
		#ifndef REMOTESERVQUIET
		fprintf(stderr,"RemoteServ err: setbuffer_Params:paramsdesc is NULL!\n");
		#endif
		return false;
	}
	RDBP* rdbparams=(RDBP*)(buf+sizeof(RDH)+sizeof(RDBH));
	UNITVAL(rdbparams->parameternum)=paramsdesc->paramnum;
	if(paramsdesc->paramnum==DEFCANNOTSERV) return true;
	for(count=0;count<paramsdesc->paramnum;count++){
		if(paramsdesc->parameters[count].notpointer){
			UNITVAL(rdbparams->parameters[count].paramval)=paramsdesc->parameters[count].paramval;
			UNITVAL(rdbparams->parameters[count].structlen)=PARAM_NOTPOINTER;
			continue;
		}
		UNITVAL(rdbparams->parameters[count].structlen)=paramsdesc->parameters[count].len;
		if((long)UNITVAL(rdbparams->parameters[count].structlen)==(long)PARAM_POINTERNULL){
			UNITVAL(rdbparams->parameters[count].paramval)=paramsdesc->parameters[count].paramval;
			continue;
		}
		UNITVAL(rdbparams->parameters[count].paramval)=paramsdesc->parameters[count].offset;
		memcpy((char*)rdbparams+paramsdesc->parameters[count].offset,
			(char*)paramsdesc->parameters[count].paramval,paramsdesc->parameters[count].len);
	}
	return true;
}
void outputdataset(char*s, char* buf)
{
	RDH* rdheader=(RDH*)buf;
	RDBH* rdbheader=(RDBH*)(rdheader+1);
	RDBP* rdbparams=(RDBP*)(rdbheader+1);
	long paramnum,count;
	long buflen,charcount;
	long offset;
	char* base=(char*)rdbparams;

	fprintf(stderr,"RemoteServ msg:%s:\n",s);
	fprintf(stderr,"RDH: len->%d\n",UNITVAL(rdheader->datasetlen));
	fprintf(stderr,"RDBH: type->%d service->%d\n",
		UNITVAL(rdbheader->servtype),UNITVAL(rdbheader->service));

	//params
	paramnum=UNITVAL(rdbparams->parameternum);
	fprintf(stderr,"RDBP begins: paramnum->%d\n",paramnum);
	for(count=0;count<paramnum;count++){
		offset=UNITVAL(rdbparams->parameters[count].paramval);
		buflen=UNITVAL(rdbparams->parameters[count].structlen);
		fprintf(stderr,"param %d:val->%d, len->%d",count,offset,buflen);
		if(buflen<=0){ fprintf(stderr,"\n"); continue;}
		fprintf(stderr,", buf->");
		for(charcount=0;charcount<buflen;charcount++)
			fprintf(stderr,"%c",((char*)base+offset)[charcount]);
		fprintf(stderr,"\n");
	}
	fprintf(stderr,"RDBP ends!\n");
}
//get not pointer parameter. 0,1,2...
bool GetParameter(RDBP* rdbparams,int which,uint32* retval)
{
	if(!rdbparams){
		#ifndef REMOTESERVQUIET
		fprintf(stderr,"RemoteServ err:GetParameter:rdbparams is NULL!\n");
		#endif
		return false;
	}
	if((which<0)||(which>=MAXPARAMETERS)){
		#ifndef REMOTESERVQUIET
		fprintf(stderr,"RemoteServ err:GetParameter:param num is too large!\n"); 
		#endif
		return false;
	}
	if((long)UNITVAL(rdbparams->parameters[which].structlen)!=(long)PARAM_NOTPOINTER){
		#ifndef REMOTESERVQUIET
		fprintf(stderr,"RemoteServ err:GetParameter: param No.%d is not a notpointer value!\n",which);
		#endif 
		return false;
	}
	*retval=UNITVAL(rdbparams->parameters[which].paramval);
	return true;
}
char* GetPointerParameter(RDBP* rdbparams,int which,uint32 checkinglen)
{
	if(!rdbparams){
		#ifndef REMOTESERVQUIET
		fprintf(stderr,"RemoteServ err:GetPointerParameter:buf is NULL!\n");
		#endif
		return NULL;
	}
	if((which<0)||(which>=MAXPARAMETERS)){
		#ifndef REMOTESERVQUIET
		fprintf(stderr,"RemoteServ err:GetPointerParameter:param num is too large!\n"); 
		#endif
		return NULL;
	}
	if((long)UNITVAL(rdbparams->parameters[which].structlen)==(long)PARAM_NOTPOINTER){
		#ifndef REMOTESERVQUIET
		fprintf(stderr,"RemoteServ err:GetPointerParameter: param No.%d is not a pointer!\n",which);
		#endif 
		return NULL;
	}
	if((long)UNITVAL(rdbparams->parameters[which].structlen)==(long)PARAM_POINTERNULL){
		return NULL;
	}
	if(((long)checkinglen!=PARAMCHECKING_DEFAULTLEN)&&
		(long)UNITVAL(rdbparams->parameters[which].structlen)!=(long)checkinglen){
		#ifndef REMOTESERVQUIET
		fprintf(stderr,"RemoteServ err:GetPointerParameter: the len of param No.%d is not correct!\n",which);
		#endif 
		return NULL;
	}
	#ifdef DEBUGGLOBAL
	fprintf(stderr,"RemoteServ msg:GetPointerParameter:which->%d, offset->%d\n",
		which,UNITVAL(rdbparams->parameters[which].paramval));
	#endif
	char* buffer=(char*)((char*)rdbparams-sizeof(RDH)-sizeof(RDBH));
	uint32 datasetlen=UNITVAL(((RDH*)buffer)->datasetlen);
	char* buf=(char*)rdbparams+UNITVAL(rdbparams->parameters[which].paramval);
	uint32 len=UNITVAL(rdbparams->parameters[which].structlen);
	if((buf<buffer)||(buf>=buffer+datasetlen)){
		#ifndef REMOTESERVQUIET
		fprintf(stderr,"RemoteServ err:GetPointParameter:buffer is not in data set!\n");
		#endif
		return NULL;
	}
	if(len>(buffer+datasetlen-buf)){
		#ifndef REMOTESERVQUIET
		fprintf(stderr,"RemoteServ err:GetPointParameter:buffer is not all in data set!\n");
		#endif
		return NULL;
	}
	#ifdef DEBUGGLOBAL
	fprintf(stderr,"RemoteServ msg:GetPointerParameter:buf->%s\n",buf);
	#endif
	return buf;
}

