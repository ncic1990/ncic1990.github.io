#ifndef APPLAYER_H
#define APPLAYER_H
#include "RemoteServ.h"

bool MakeDataSet(ServInfoDesc_t* servinfoptr,
	char** buf, char** originbuf, uint32* len);
bool ServerMakeReplyDataSet(ServInfoDesc_t* servinfoptr);
bool SetParamDescNum(ParamsDesc_t* paramsdesc,uint32 num);
bool SetParamDescParameter(ParamsDesc_t* paramsdesc,uint32 which,
	uint32 paramval,uint32 notpointer,uint32 align,uint32 len);
bool CheckParamNum(char* s,ReqDBP* reqparams,uint32 params);

#endif /*end of APPLAYER_H*/

