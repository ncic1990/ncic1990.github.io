#include "RemoteServTopsyAssist.h"
#include "DBGRemoteServ.h"
#include "RemoteServCommon.h"
#include "AppLayer.h"

#define TACOMMONDEC\
	uint32 ret;\
	ServInfoDesc_t servinfo;\
	ParamsDesc_t* paramsdescptr=&servinfo.paramdesc;

#define TACOMMONRET(ret)\
do{\
	SetParamDescNum(paramsdescptr, 2);\
	SetParamDescParameter(paramsdescptr,0,(uint32)ret,true,0,0);\
	SetParamDescParameter(paramsdescptr,1,(uint32)errno,true,0,0);\
	ServerMakeReplyDataSet(&servinfo);\
	return true;\
}while(0)

#define TA_BUFNOTFREE 0
#define TA_BUFFREE 1
#define TACOMMONRET_1BUF(ret,success,buf,align,successlen,buffreeflag)\
do{\
	SetParamDescNum(paramsdescptr,3);\
	SetParamDescParameter(paramsdescptr,0,(uint32)ret,true,0,0);\
	SetParamDescParameter(paramsdescptr,1,(uint32)errno,true,0,0);\
	if(success)\
		SetParamDescParameter(paramsdescptr,2,(uint32)buf,false,align,successlen);\
	else\
		SetParamDescParameter(paramsdescptr,2,(uint32)buf,false,align,PARAM_POINTERNULL);\
	ServerMakeReplyDataSet(&servinfo);\
	if(buffreeflag)\
		if(buf) free(buf);\
	return true;\
}while(0)

//os state: in shell or app
#define OSST_OS 0
#define OSST_APP 1

//for stdio redirection of Topsy and App
#define STDIONUM 3
#define NOTDIRECT -1
#define DEFAULTSTDIO ":::"
typedef struct RedirectStruct{
	long globalfds[STDIONUM];
	long appfds[STDIONUM];
}RedirectStruct_t;

//for the current working directory of Topsy
#define MAXCWDLEN 1024
typedef struct CWDStruct{
	char globalCWD[MAXCWDLEN];
}CWDStruct_t;

//os state variable
long os_state=OSST_OS;
//struct for redirection
RedirectStruct_t redirectfds;
bool tstdio_inheritflag;
//two functions for redirection of stdio
bool InitRedirectStruct()
{
	long count;
	long fd;

	//default os state
	os_state=OSST_OS;
	//default mode:inherit
	tstdio_inheritflag=true;
	//invalid redirection struct
	for(count=0;count<STDIONUM;count++){
		redirectfds.globalfds[count]=NOTDIRECT;
		redirectfds.appfds[count]=NOTDIRECT;
	}

	//get the stdio for os
	for(count=0;count<STDIONUM;count++){
		fd=dup(count);
		if(fd<0) goto failed;
		redirectfds.globalfds[count]=fd;
	}
	//get the stdio for app
	for(count=0;count<STDIONUM;count++){
		fd=dup(count);
		if(fd<0) goto failed;
		redirectfds.appfds[count]=fd;
	}
	return true;
failed:
	#ifndef REMOTESERVQUIET
	fprintf(stderr,"RemoteServ err: some trouble while initializing redirect struct!: %d\n",count);
	fprintf(stderr,"please check it!!!\n");
	#endif
	return false;
}
void destroyRedirectStruct( )
{
	int count;
	int stdionum=STDIONUM;
	for(count=0;count<STDIONUM;count++){
		if(redirectfds.globalfds[count]>=STDIONUM)
			close(redirectfds.globalfds[count]);
		else{
			#ifndef REMOTESERVQUIET
			fprintf(stderr,"RemoteServ msg:destroyRedirectStruct:warning:globalfds %d is less than %d!\n",count,stdionum);
			#endif
		}
		if(redirectfds.appfds[count]>=STDIONUM)
			close(redirectfds.appfds[count]);
		else{
			#ifndef REMOTESERVQUIET
			fprintf(stderr,"RemoteServ msg:destroyRedirectStruct:warning:appfds %d is less than %d!\n",count,stdionum);
			#endif
		}
	}//for
}
//for current working directory
CWDStruct_t topsycwd;
void InitCWD( )
{
	topsycwd.globalCWD[0]='/';
	topsycwd.globalCWD[1]='\0';

	char* cp=getcwd(topsycwd.globalCWD, MAXCWDLEN);
	if(cp==NULL){
		#ifndef REMOTESERVQUIET
		fprintf(stderr,"RemoteServ err:InitCWD: can not get the cwd,if there is err,please check it !!!\n");
		#endif
	}
}
void DestroyCWD( )
{
}
//four control functions
bool InitTopsyEnv( )
{
	if(!InitRedirectStruct()) return false;
	InitCWD( );
	return true;
}
void DestroyTopsyEnv( )
{
	destroyRedirectStruct( );
	DestroyCWD( );
}
void InstallTopsyEnv( )
{
	fflush(stdout);
	fflush(stderr);
}
void UnInstallTopsyEnv( )
{
	fflush(stdout);
	fflush(stderr);
}

bool TAioConsolePutString(ReqDBP* reqparams)
{
	char* buf;
	
	#ifdef DEBUGTA
	fprintf(stderr,"RemoteServ msg:TopsyAssist: ioConsolePutString...\n");
	#endif

	if(!CheckParamNum("TopsyAssist: ioConsolePutString",reqparams,ioConsolePutStringparams)) return false;
	
	buf=GetPointerParameter(reqparams,0,PARAMCHECKING_DEFAULTLEN);
	fprintf(stderr,"%s",buf);
	fflush(stderr);
	
	return true;	
}
bool TAioConsolePutHexInt(ReqDBP* reqparams)
{
	uint32 num;
	
	#ifdef DEBUGTA
	fprintf(stderr,"RemoteServ msg:TopsyAssist: ioConsolePutHexInt...\n");
	#endif

	if(!CheckParamNum("TopsyAssist: ioConsolePutHexInt",reqparams,ioConsolePutHexIntparams)) return false;
	
	if(!GetParameter(reqparams,0,&num)) return false;
	fprintf(stderr,"%x\n",num);
	fflush(stderr);
	
	return true;	
}
bool TAstringout(ReqDBP* reqparams)
{
	char* buf;
	
	#ifdef DEBUGTA
	fprintf(stderr,"RemoteServ msg:TopsyAssist: stringout...\n");
	#endif

	if(!CheckParamNum("TopsyAssist: stringout",reqparams,stringoutparams)) return false;
	
	buf=GetPointerParameter(reqparams,0,PARAMCHECKING_DEFAULTLEN);
	fprintf(stderr,"%s",buf);
	fflush(stderr);
	
	return true;	
}
char* getstring(char* buf,long len,long fd)
{
	long count;
	long ret;
	
	for(count=0;count<len-1;count++){
		ret=read(fd,&buf[count],1);
		if(ret<0) {
			buf[count]='\0';
			return NULL;
		}
		if((ret==0)||(buf[count]=='\n'))
			break;
	}
	buf[count+1]='\0';
	return buf;
}
bool TAstringin(ReqDBP* reqparams)
{
	uint32 maxcount;
	char* buf;
	TACOMMONDEC
	
	#ifdef DEBUGTA
	fprintf(stderr,"RemoteServ msg:TopsyAssist: stringin...\n");
	#endif

	if(!CheckParamNum("TopsyAssist: stringin",reqparams,stringinparams)) return false;
	
	if(!GetParameter(reqparams,0,&maxcount)) return false;
	if(!(buf=malloc(maxcount))) return false;
//	ret=(uint32)fgets(buf,maxcount,stdin);
	ret=(uint32)getstring(buf,maxcount,0);
	#ifdef DEBUGTA
	fprintf(stderr,"RemoteServ msg:TAstringin");
	if(ret)
		fprintf(stderr,":buf->%s",buf);
	fprintf(stderr,"\n");
	fflush(stderr);
	#endif
	
	TACOMMONRET_1BUF(ret,ret,buf,CHARALIGN,strlen(buf)+1,TA_BUFFREE);
}
//simulation of: long TARedirectStdIO(long stdinto, long stdoutto, long stderrto)
//when returning 0:failed  1:ok
#define REDIRECTOK 1
#define REDIRECTFAILED 0
bool TARedirectStdIO(ReqDBP* reqparams)
{
	long count;
	long fd;
	TACOMMONDEC
	
	#ifdef DEBUGTA
	fprintf(stderr,"RemoteServ msg:TopsyAssist: TARedirectStdIO...\n");
	#endif
	
	if(!CheckParamNum("TopsyAssist: TARedirectStdIO",reqparams,redirectstdioparams)) return false;

	ret=REDIRECTFAILED;
	for(count=0;count<STDIONUM;count++){
		if(!GetParameter(reqparams,count,&fd)) return false;
		if((fd<0)&&(fd!=NOTDIRECT)){
			#ifndef REMOTESERVQUIET
			fprintf(stderr,"RemoteServ err:TARedirectStdIO: invalid parameter!\n");
			#endif
			goto out;
		}
		if(fd==NOTDIRECT)
			fd=redirectfds.appfds[count];
		close(count);
		fd=dup2(fd,count);
		if(fd!=count){
			#ifndef REMOTESERVQUIET
			fprintf(stderr,"RemoteServ err:TARedirectStdIO: err in dup2!\n");
			#endif
			goto out;
		}
	}
	ret=REDIRECTOK;
	//change os state
	os_state=OSST_APP;
out:
	TACOMMONRET(ret);
}
//simulation of: void TADeRedirectStdIO( )
bool TADeRedirectStdIO(ReqDBP* reqparams)
{
	long count;
	long fd;
	
	#ifdef DEBUGTA
	fprintf(stderr,"RemoteServ msg:TopsyAssist: TADeRedirectStdIO...\n");
	#endif
	
	if(!CheckParamNum("TopsyAssist: TADeRedirectStdIO",reqparams,deredirectstdioparams)) return false;

	for(count=0;count<STDIONUM;count++){
		close(count);
		fd=dup2(redirectfds.globalfds[count],count);
		if(fd!=count){
			#ifndef REMOTESERVQUIET
			fprintf(stderr,"RemoteServ err:TADeRedirectStdIO: err in dup2!\n");
			#endif
			goto out;
		}
	}
out:
	//change os state:note:in spite of success or failed,
	//os_state should be change to OSST_OS
	os_state=OSST_OS;
	return true;
}
//simulation of: long TAChangeCWD(const char* pathname)
//when returning 0:failed  1:ok
#define CWDOK 1
#define CWDFAILED 0
bool TAChangeCWD(ReqDBP* reqparams)
{
	char* pathname;
	char* cp;
	TACOMMONDEC
	
	#ifdef DEBUGTA
	fprintf(stderr,"RemoteServ msg:TopsyAssist: TAChangeCWD...\n");
	#endif
	
	if(!CheckParamNum("TopsyAssist: TAChangeCWD",reqparams,changecwdparams)) return false;

	ret=CWDFAILED;
	cp=getcwd(topsycwd.globalCWD, MAXCWDLEN);
	if(cp==NULL){
		#ifndef REMOTESERVQUIET
		fprintf(stderr,"RemoteServ err:TopsyAssist:TAChangeCWD:can not get the local cwd\n");
		#endif
		goto out;
	}
	pathname=GetPointerParameter(reqparams,0,PARAMCHECKING_DEFAULTLEN);
	if(pathname==NULL) goto out;
	if((ret=chdir(pathname))<0){
		#ifndef REMOTESERVQUIET
		fprintf(stderr,"RemoteServ err:TopsyAssist:TAChangeCWD:can not change cwd\n");
		#endif
		goto out;
	}
	ret=CWDOK;
out:
	TACOMMONRET(ret);
}
//simulation of: void TARecoverCWD( )
bool TARecoverCWD(ReqDBP* reqparams)
{
	#ifdef DEBUGTA
	fprintf(stderr,"RemoteServ msg:TopsyAssist: TARecoverCWD...\n");
	#endif
	
	if(!CheckParamNum("TopsyAssist: TARecoverCWD",reqparams,recovercwdparams)) return false;

	if(chdir(topsycwd.globalCWD)<0){
		#ifndef REMOTESERVQUIET
		fprintf(stderr,"RemoteServ err:TopsyAssist:TARecoverCWD:can not change cwd\n");
		#endif
	}
	return true;
}
//simulation of: void TAprintfnull(const char* str) //to stdout
bool TAprintfnull(ReqDBP* reqparams)
{
	char* buf;
	
	#ifdef DEBUGTA
	fprintf(stderr,"RemoteServ msg:TopsyAssist: TAprintfnull...\n");
	#endif

	if(!CheckParamNum("TopsyAssist: TAprintfnull",reqparams,printfnullparams)) return false;
	
	buf=GetPointerParameter(reqparams,0,PARAMCHECKING_DEFAULTLEN);
	printf("%s",buf);
	fflush(stdout);
	
	return true;	
}
//simulation of: void TAprintfstr(const char* mode, const char* str) //to stdout
bool TAprintfstr(ReqDBP* reqparams)
{
	char* mode;
	char* str;
	
	#ifdef DEBUGTA
	fprintf(stderr,"RemoteServ msg:TopsyAssist: TAprintfstr...\n");
	#endif

	if(!CheckParamNum("TopsyAssist: TAprintfstr",reqparams,printfstrparams)) return false;
	
	mode=GetPointerParameter(reqparams,0,PARAMCHECKING_DEFAULTLEN);
	str=GetPointerParameter(reqparams,1,PARAMCHECKING_DEFAULTLEN);
	printf(mode,str);
	fflush(stdout);
	
	return true;	

}
//simulation of: void TAprintfnum(const char* mode, long num) //to stdout
bool TAprintfnum(ReqDBP* reqparams)
{
	char* mode;
	long num;
	
	#ifdef DEBUGTA
	fprintf(stderr,"RemoteServ msg:TopsyAssist: TAprintfnum...\n");
	#endif

	if(!CheckParamNum("TopsyAssist: TAprintfnum",reqparams,printfnumparams)) return false;
	
	mode=GetPointerParameter(reqparams,0,PARAMCHECKING_DEFAULTLEN);
	if(!GetParameter(reqparams,1,&num)) return false;
	printf(mode,num);
	fflush(stdout);
	
	return true;	
}
//simualtion of: long TAgetcwd(char* buf, long size, long mode)
//get cwd const
#define TAGETCWDOK 0
#define TAGETCWDFAILED -1
#define TAGETCWDABSOLUTE 1
#define TAGETCWDDIRNAME 0
bool TAgetcwd(ReqDBP* reqparams)
{
	char* buf=NULL;
	char* tmpbuf=NULL;
	long size;
	long mode;
	long count;
	long start;
	long ret=TAGETCWDFAILED;
	ServInfoDesc_t servinfo;
	ParamsDesc_t* paramsdescptr=&servinfo.paramdesc;

	if(!CheckParamNum("TopsyAssist: TAgetcwd",reqparams,TAgetcwdparams)) return false;

	if(!GetParameter(reqparams,0,&size)) return false;
	if(!GetParameter(reqparams,1,&mode)) return false;
	#ifdef DEBUGTA
	fprintf(stderr,"RemoteServ msg:TopsyAssist: TAgetcwd:size->%d, mode->%d...\n",
		size,mode);
	#endif
	if((buf=(char*)malloc(size))==NULL){
		#ifndef REMOTESERVQUIET
		fprintf(stderr,"RemoteServ err:TAgetcwd: can not get space for cwd!\n");
		#endif
		goto out;
	}
	tmpbuf=buf;
	if(getcwd(buf, size)==NULL){
		#ifndef REMOTESERVQUIET
		fprintf(stderr,"RemoteServ err:TAgetcwd: can not get cwd!\n");
		#endif
		goto out;
	}
	ret=TAGETCWDOK;
	
 	if(mode==TAGETCWDABSOLUTE)
		goto out;
	
	count=strlen(buf);
	start=count-1;
	while((start>=0)&&(buf[start]!='/')) start--;
	if(start<0) { start=0; goto out;}
	if(count==1) {start=0; goto out;}
	start++;
	tmpbuf=buf+start;
	
out:
	//make reply data set
	SetParamDescNum(paramsdescptr, 3);
	SetParamDescParameter(paramsdescptr,0,(uint32)ret,true,0,0);
	SetParamDescParameter(paramsdescptr,1,(uint32)errno,true,0,0);
	if(ret==TAGETCWDOK)
		SetParamDescParameter(paramsdescptr,2,(uint32)tmpbuf,false,CHARALIGN,strlen(tmpbuf)+1);
	else
		SetParamDescParameter(paramsdescptr,2,(uint32)tmpbuf,false,CHARALIGN,PARAM_POINTERNULL);
	ServerMakeReplyDataSet(&servinfo);
	if(buf)
		free(buf);
	return true;
}
//simulation of : void rsTAlssimulation(char* format); 
//char* format is options of ls,now is not used
#define S_ISEXE(mode) (mode&S_IXUSR)
bool outputfilenamebytype(char* filename)
{
	//c function stat64() and type struct stat64:
	//When the sources are compiled with _FILE_OFFSET_BITS == 64 
	//the function and the type are available
	//#define LS_USESTAT

	#ifdef LS_USESTAT
	struct stat statbuf; 
	#else
	struct stat64 statbuf;
	#endif
	char dircolor[]= { 27,'[','3','3','m',0}; //yellow
	char execolor[]= { 27,'[','3','2','m',0}; //green
	char normalcolor[]= { 27,'[','0','m',0}; //reset
	
	#ifdef LS_USESTAT
	if(stat(filename,&statbuf)==-1) { 
	#else
	if(stat64(filename,&statbuf)==-1) { 
	#endif
		#ifndef REMOTESERVQUIET
		fprintf(stderr,"RemoteServ err:outputfilenamebytype(): can not stat file:%s!\n",filename);
		#endif
		return false;
	} 
	if(S_ISDIR(statbuf.st_mode)){//is dir
		printf("%s%-25s%s",dircolor,filename,normalcolor);
	}else if(S_ISREG(statbuf.st_mode)) {//normal file
		if(S_ISEXE(statbuf.st_mode))//exe
			printf("%s%-25s%s",execolor,filename,normalcolor);
		else
			printf("%-25s",filename);//other normal file
	}else{
		printf("%-25s",filename);//other file types
	}

	return true;
}
bool TAlssimulation(ReqDBP* reqparams)
{
	char* format;
	char* buf;
	DIR *dirp; 
	struct dirent *direntp; 
	long countforline;
	#define FILENAMENUMONELINE 3
	#define MAXFILENAMELEN 25
	#define MAXCWDLEN 1024
	
	if(!CheckParamNum("TopsyAssist: TAlssimulation",reqparams,TAlssimulationparams)) return false;

	//get parameters
	format=GetPointerParameter(reqparams,0,PARAMCHECKING_DEFAULTLEN);
	#ifdef DEBUGTA
	fprintf(stderr,"RemoteServ msg:TopsyAssist: TAlssimulation:format->%s...\n",format);
	#endif

	if((buf=(char*)malloc(MAXCWDLEN))==NULL){
		#ifndef REMOTESERVQUIET
		fprintf(stderr,"RemoteServ err:TAlssimulation: malloc failed!\n");
		#endif
		goto out0;
	}
	if(getcwd(buf, MAXCWDLEN)==NULL){
		#ifndef REMOTESERVQUIET
		fprintf(stderr,"RemoteServ err:TAlssimulation: can not get cwd!\n");
		#endif
		goto out1;
	}

	if((dirp=opendir(buf))==NULL) { 
		#ifndef REMOTESERVQUIET
		fprintf(stderr,"RemoteServ err:TAlssimulation: can not open cwd!\n");
		#endif
		goto out1;
	} 
	countforline=0;
	while((direntp=readdir(dirp))!=NULL) {
		if(!strcmp(direntp->d_name,".")) continue;
		if(!strcmp(direntp->d_name,"..")) continue;
		if(!outputfilenamebytype(direntp->d_name)) goto out2;
		countforline++;
		if(countforline==FILENAMENUMONELINE){
			printf("\n");
			countforline=0;
		}
	}
	if(countforline!=0) printf("\n");

out2:
	closedir(dirp);
out1:
	free(buf);
out0:
	return true;
}
//simulation of: char* TAgetenv(char* envname,char* buf,long maxlen)
bool TAgetenv(ReqDBP* reqparams)
{
	char* envname;
	char* buf=NULL;
	long maxlen;
	char* env=NULL;
	long len;
	long count;
	TACOMMONDEC

	if(!CheckParamNum("TopsyAssist: TAgetenv",reqparams,TAgetenvparams)) return false;

	//get parameters
	envname=GetPointerParameter(reqparams,0,PARAMCHECKING_DEFAULTLEN);
	if(!GetParameter(reqparams,1,&maxlen)) return false;
	#ifdef DEBUGTA
	fprintf(stderr,"RemoteServ msg:TopsyAssist: TAgetenv:envname->%s, maxcount->%d...\n",
		envname,maxlen);
	#endif
	if((buf=(char*)malloc(maxlen))==NULL){
		#ifndef REMOTESERVQUIET
		fprintf(stderr,"RemoteServ err:TAgetenv: malloc failed!\n");
		#endif
		goto out;
	}

	//get env variables
	env=getenv(envname);
	if(env){
		len=strlen(env);
		len=(len>maxlen-1)? maxlen-1: len;
		for(count=0;count<len;count++)
			buf[count]=env[count];
		buf[count]=0;
	}

out:
	ret=(uint32)env;
	TACOMMONRET_1BUF(ret,ret,buf,CHARALIGN,strlen(buf)+1,TA_BUFFREE);
}
//simulation of: long TAchstdiobyname(char* stdinname,char* stdoutname,
//char* stderrname,bool inheritflag)
#define DUPLICATEFDFAILED -1
long duplicatefd(long src, long maybedest)
{
	long fd;
	
	fd=dup2(src,maybedest);
	if(fd==maybedest) return maybedest;
	fd=dup(src);
	if(fd>=0) return fd;
	#ifndef REMOTESERVQUIET
	fprintf(stderr,"RemoteServ err:TopsyAssist: duplicatefd:there must be something error, please check it!\n");
	#endif
	return DUPLICATEFDFAILED;
}
#define TACHSTDIOBYNAMEOK 1
#define TACHSTDIOBYNAMEFAILED 0
bool TAchstdiobyname(ReqDBP* reqparams)
{
	char* stdinname;
	char* stdoutname;
	char* stderrname;
	long inheritflag;
	long fd;
	long stdiofd[STDIONUM];
	long count;
	TACOMMONDEC

	if(!CheckParamNum("TopsyAssist: TAchstdiobyname",reqparams,TAchstdiobynameparams)) return false;

	stdinname=GetPointerParameter(reqparams,0,PARAMCHECKING_DEFAULTLEN);
	stdoutname=GetPointerParameter(reqparams,1,PARAMCHECKING_DEFAULTLEN);
	stderrname=GetPointerParameter(reqparams,2,PARAMCHECKING_DEFAULTLEN);
	if(!GetParameter(reqparams,3,(uint32*)&inheritflag)) return false;
	#ifdef DEBUGTA
	fprintf(stderr,"RemoteServ msg:TopsyAssist: TAchstdiobyname:stdinname->%s, stdoutname->%s, stderrname->%s, inheritflag->%d...\n",
		stdinname,stdoutname,stderrname,inheritflag);
	#endif

	ret=TACHSTDIOBYNAMEFAILED;
	//opening stdio file by name 
	if(!strcmp(stdinname,DEFAULTSTDIO))//not direct
		stdiofd[0]=NOTDIRECT;
	else{
		fd=open(stdinname,0,0);//stdin
		if(fd<0) goto out;
		stdiofd[0]=fd;
	}
	if(!strcmp(stdoutname,DEFAULTSTDIO))//not direct
		stdiofd[1]=NOTDIRECT;
	else{
		fd=open(stdoutname,O_WRONLY|O_CREAT|O_TRUNC, 0666);//stdout
		if(fd<0) goto out;
		stdiofd[1]=fd;
	}
	if(!strcmp(stderrname,DEFAULTSTDIO))//not direct
		stdiofd[2]=NOTDIRECT;
	else{
		fd=open(stderrname,O_WRONLY|O_CREAT|O_TRUNC, 0666);//stderr
		if(fd<0) goto out;
		stdiofd[2]=fd;
	}

	//do changes
	//for stdio in 0,1,2
	for(count=0;count<STDIONUM;count++){
		if((stdiofd[count]==NOTDIRECT)&&(os_state!=OSST_OS)) continue;
		if((stdiofd[count]==NOTDIRECT)&&(os_state==OSST_OS)) goto heritentry;
		close(count);
		fd=dup2(stdiofd[count],count);
		if(fd!=count){
			#ifndef REMOTESERVQUIET
			fprintf(stderr,"RemoteServ err:TopsyAssist: TAchstdiobyname:while dup2, please check it!%d.\n",count);
			#endif
			goto out;
		}
		if(os_state!=OSST_OS) continue;
		close(redirectfds.globalfds[count]);
		fd=duplicatefd(stdiofd[count],redirectfds.globalfds[count]);
		if(fd==DUPLICATEFDFAILED) goto out;
		redirectfds.globalfds[count]=fd;
		heritentry:
		if(!inheritflag) continue;
		close(redirectfds.appfds[count]);
		fd=duplicatefd(redirectfds.globalfds[count],redirectfds.appfds[count]);
		if(fd==DUPLICATEFDFAILED) goto out;
		redirectfds.appfds[count]=fd;
	}
	if(os_state==OSST_OS) {
		if(inheritflag) tstdio_inheritflag=true;
		else tstdio_inheritflag=false;
	}

	//final part
	if(stdiofd[0]!=NOTDIRECT) close(stdiofd[0]);
	if(stdiofd[1]!=NOTDIRECT) close(stdiofd[1]);
	if(stdiofd[2]!=NOTDIRECT) close(stdiofd[2]);
	ret=TACHSTDIOBYNAMEOK;
out:
	TACOMMONRET(ret);
}
//simulation of: long TAgetallenv(char* buf,long maxlen)
//get all the environment variables
//the return value is the envc
//when failed, the return value is 0
extern char**environ;
bool TAgetallenv(ReqDBP* reqparams)
{
	char* buf=NULL;
	long maxlen;
	char** env=NULL;
	long len;
	long count=0;
	long envc=0;
	TACOMMONDEC

	if(!CheckParamNum("TopsyAssist: TAgetallenv",reqparams,TAgetallenvparams)) return false;

	//get parameters
	if(!GetParameter(reqparams,0,&maxlen)) return false;
	#ifdef DEBUGTA
	fprintf(stderr,"RemoteServ msg:TopsyAssist: TAgetallenv:maxcount->%d...\n",maxlen);
	#endif
	if((buf=(char*)malloc(maxlen))==NULL){
		#ifndef REMOTESERVQUIET
		fprintf(stderr,"RemoteServ err:TAgetallenv: malloc failed!\n");
		#endif
		goto out;
	}

	//get env variables
	for (env =environ;*env !=NULL;++env){
		len=strlen(*env)+1;
		if(count+len>maxlen){
			fprintf(stderr,"RemoteServ warning:TAgetallenv:buf is not enough!\n");
			goto out;
		}
		strcpy(buf+count,*env);
		count+=len;
		envc++;
	}

out:
	ret=(uint32)envc;
	TACOMMONRET_1BUF(ret,ret,buf,CHARALIGN,count,TA_BUFFREE);
}

bool TopsyAssistDispatcher(ReqDBH* reqbodyheader)
{
	ReqDataSetBodyParameters_t* reqparams=(ReqDBP*)(reqbodyheader+1);
	
	switch(UNITVAL(reqbodyheader->service)){
		case ioConsolePutStringservno:
			return TAioConsolePutString(reqparams);
		case ioConsolePutHexIntservno:
			return TAioConsolePutHexInt(reqparams);
		case stringoutservno:
			return TAstringout(reqparams);
		case stringinservno:
			return TAstringin(reqparams);
		case redirectstdioservno:
			return TARedirectStdIO(reqparams);
		case deredirectstdioservno:
			return TADeRedirectStdIO(reqparams);
		case changecwdservno:
			return TAChangeCWD(reqparams);
		case recovercwdservno:
			return TARecoverCWD(reqparams);
		case printfnullservno:
			return TAprintfnull(reqparams);
		case printfstrservno:
			return TAprintfstr(reqparams);
		case printfnumservno:
			return TAprintfnum(reqparams);
		case TAgetcwdservno:
			return TAgetcwd(reqparams);
		case TAlssimulationservno:
			return TAlssimulation(reqparams);
		case TAgetenvservno:
			return TAgetenv(reqparams);
		case TAchstdiobynameservno:
			return TAchstdiobyname(reqparams);
		case TAgetallenvservno:
			return TAgetallenv(reqparams);
		default:
			#ifndef REMOTESERVQUIET
			fprintf(stderr,"RemoteServ err:TopsyAssistDispatcher:invalid TA service:%d\n",UNITVAL(reqbodyheader->service));
			#endif
			return false;
	}
	return true;
}

