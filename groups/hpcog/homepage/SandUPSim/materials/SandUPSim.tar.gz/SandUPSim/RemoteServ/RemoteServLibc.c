#include "RemoteServLibc.h"
#include "DBGRemoteServ.h"
#include "RemoteServCommon.h"
#include "AppLayer.h"

#define LIBCCOMMONDEC\
	uint32 ret;\
	ServInfoDesc_t servinfo;\
	ParamsDesc_t* paramsdescptr=&servinfo.paramdesc;

#define LIBCCOMMONRET(ret)\
do{\
	SetParamDescNum(paramsdescptr, 2);\
	SetParamDescParameter(paramsdescptr,0,(uint32)ret,true,0,0);\
	SetParamDescParameter(paramsdescptr,1,(uint32)errno,true,0,0);\
	ServerMakeReplyDataSet(&servinfo);\
	return true;\
}while(0)

#define LIBC_BUFNOTFREE 0
#define LIBC_BUFFREE 1
#define LIBCCOMMONRET_1BUF(ret,success,buf,align,successlen,buffreeflag)\
do{\
	SetParamDescNum(paramsdescptr,3);\
	SetParamDescParameter(paramsdescptr,0,(uint32)ret,true,0,0);\
	SetParamDescParameter(paramsdescptr,1,(uint32)errno,true,0,0);\
	if(success)\
		SetParamDescParameter(paramsdescptr,2,(uint32)buf,false,align,successlen);\
	else\
		SetParamDescParameter(paramsdescptr,2,(uint32)buf,false,align,PARAM_POINTERNULL);\
	ServerMakeReplyDataSet(&servinfo);\
	if(buffreeflag)\
		if(buf) free(buf);\
	return true;\
}while(0)

bool Libcfopen(ReqDBP* reqparams)
{
	FILE* fp;
	char* filename;
	char* filemode;
	LIBCCOMMONDEC
	
	#ifdef WALKPATH
	fprintf(stderr,"Remoteserv msg:libc fopen...\n");
	#endif

	if(!CheckParamNum("libc fopen",reqparams,fopenparams)) return false;
	
	filename=GetPointerParameter(reqparams,0,PARAMCHECKING_DEFAULTLEN);
	filemode=GetPointerParameter(reqparams,1,PARAMCHECKING_DEFAULTLEN);
	fp=fopen(filename,filemode);

	#ifdef DEBUGLIBC
	if(fp!=NULL)
		fprintf(stderr,"Remoteserv msg:libc fopen: filename->%s, filemode->%s, fp->0x%x\n",
			filename,filemode,fp);
	else
		fprintf(stderr,"Remoteserv err:libc fopen\n");
	#endif

	ret=(uint32)fp;
	LIBCCOMMONRET(ret);
}
bool Libcfread(ReqDBP* reqparams)
{
	char* buf;
	uint32 size;
	uint32 num;
	FILE* fp;
	LIBCCOMMONDEC
	
	#ifdef WALKPATH
	fprintf(stderr,"Remoteserv msg:libc fread...\n");
	#endif

	if(!CheckParamNum("libc fread",reqparams,freadparams)) return false;

	if(!GetParameter(reqparams,0,&size)) return false;
	if(!GetParameter(reqparams,1,&num)) return false;
	if(!GetParameter(reqparams,2,(uint32*)&fp)) return false;
	if(!(buf=malloc(size*num+1))) return false;
	ret=fread(buf,size,num,fp);
	
	#ifdef DEBUGLIBC
	buf[ret]='\0';
	fprintf(stderr,"Remoteserv msg:libc fread:fp->0x%x, size->%d, num->%d, ret->%d, buf->%s\n",fp,size,num,ret,buf);
	#endif
	
	LIBCCOMMONRET_1BUF(ret,ret>0,buf,CHARALIGN,ret*size,LIBC_BUFFREE);
}
bool Libcfwrite(ReqDBP* reqparams)
{
	char* buf;
	uint32 size;
	uint32 num;
	FILE* fp;
	LIBCCOMMONDEC
	
	#ifdef WALKPATH
	fprintf(stderr,"Remoteserv msg:libc fwrite...\n");
	#endif

	if(!CheckParamNum("libc fwrite",reqparams,fwriteparams)) return false;
	
	if(!GetParameter(reqparams,1,&size)) return false;
	if(!GetParameter(reqparams,2,&num)) return false;
	if((buf=GetPointerParameter(reqparams,0,size*num))==NULL) return false;
	if(!GetParameter(reqparams,3,(uint32*)&fp)) return false;
	ret=fwrite(buf,size,num,fp);
	
	#ifdef DEBUGLIBC
	uint32 count;
	fprintf(stderr,"Remoteserv msg:libc fwrite:ret->%d, buf->",ret);
	if(buf)
		for(count=0;count<size*num;count++)
			printf("%c",buf[count]);
	fprintf(stderr,"\n");
	#endif
	
	LIBCCOMMONRET(ret);
}
bool Libcfclose(ReqDBP* reqparams)
{
	FILE* fp;
	LIBCCOMMONDEC
	
	#ifdef WALKPATH
	fprintf(stderr,"Remoteserv msg:libc fclose...\n");
	#endif

	if(!CheckParamNum("libc fclose",reqparams,fcloseparams)) return false;

	if(!GetParameter(reqparams,0,(uint32*)&fp)) return false;
	ret=fclose(fp);

	LIBCCOMMONRET(ret);
}
bool Libcfseek(ReqDBP* reqparams)
{
	FILE* fp;
	uint32 offset;
	uint32 whence;
	LIBCCOMMONDEC

	#ifdef WALKPATH
	fprintf(stderr,"Remoteserv msg:libc fseek...\n");
	#endif

	if(!CheckParamNum("libc fseek",reqparams,fseekparams)) return false;

	if(!GetParameter(reqparams,0,(uint32*)&fp)) return false;
	if(!GetParameter(reqparams,1,&offset)) return false;
	if(!GetParameter(reqparams,2,&whence)) return false;
	ret=fseek(fp,offset,whence);

	LIBCCOMMONRET(ret);
}
bool Libcftell(ReqDBP* reqparams)
{
	FILE* fp;
	LIBCCOMMONDEC

	#ifdef WALKPATH
	fprintf(stderr,"Remoteserv msg:libc ftell...\n");
	#endif

	if(!CheckParamNum("libc ftell",reqparams,ftellparams)) return false;

	if(!GetParameter(reqparams,0,(uint32*)&fp)) return false;
	ret=ftell(fp);

	LIBCCOMMONRET(ret);
}
//This function does not need to return reply data set to client,so...
bool Libcrewind(ReqDBP* reqparams)
{
	FILE* fp;

	#ifdef WALKPATH
	fprintf(stderr,"Remoteserv msg:libc rewind...\n");
	#endif

	if(!CheckParamNum("libc rewind",reqparams,rewindparams)) return false;

	if(!GetParameter(reqparams,0,(uint32*)&fp)) return false;
	rewind(fp);

	return true;
}
bool Libcfeof(ReqDBP* reqparams)
{
	FILE* fp;
	LIBCCOMMONDEC

	#ifdef WALKPATH
	fprintf(stderr,"Remoteserv msg:libc feof...\n");
	#endif

	if(!CheckParamNum("libc feof",reqparams,feofparams)) return false;

	if(!GetParameter(reqparams,0,(uint32*)&fp)) return false;
	ret=feof(fp);

	LIBCCOMMONRET(ret);
}
bool Libcfgetc(ReqDBP* reqparams)
{
	FILE* fp;
	LIBCCOMMONDEC

	#ifdef WALKPATH
	fprintf(stderr,"Remoteserv msg:libc fgetc...\n");
	#endif

	if(!CheckParamNum("libc fgetc",reqparams,fgetcparams)) return false;

	if(!GetParameter(reqparams,0,(uint32*)&fp)) return false;
	ret=fgetc(fp);

	LIBCCOMMONRET(ret);
}
bool Libcfgets(ReqDBP* reqparams)
{
	char* buf;
	uint32 n;
	FILE* fp;
	LIBCCOMMONDEC
	
	#ifdef WALKPATH
	fprintf(stderr,"Remoteserv msg:libc fgets...\n");
	#endif

	if(!CheckParamNum("libc fgets",reqparams,fgetsparams)) return false;

	if(!GetParameter(reqparams,0,&n)) return false;
	if(!GetParameter(reqparams,1,(uint32*)&fp)) return false;
	if(!(buf=malloc(n))) return false;
	ret=(uint32)fgets(buf,n,fp);
	
	#ifdef DEBUGLIBC
	fprintf(stderr,"Remoteserv msg:libc fgets:fp->0x%x, ret->%d, buf->%s\n",fp,ret,buf);
	#endif
	
	LIBCCOMMONRET_1BUF(ret,ret,buf,CHARALIGN,strlen(buf)+1,LIBC_BUFFREE);
}
bool Libcfputc(ReqDBP* reqparams)
{
	uint32 input;
	FILE* fp;
	LIBCCOMMONDEC

	#ifdef WALKPATH
	fprintf(stderr,"Remoteserv msg:libc fputc...\n");
	#endif

	if(!CheckParamNum("libc fputc",reqparams,fputcparams)) return false;

	if(!GetParameter(reqparams,0,&input)) return false;
	if(!GetParameter(reqparams,1,(uint32*)&fp)) return false;
	ret=fputc(input,fp);

	LIBCCOMMONRET(ret);
}
bool Libcfputs(ReqDBP* reqparams)
{
	char* buf;
	FILE* fp;
	LIBCCOMMONDEC
	
	#ifdef WALKPATH
	fprintf(stderr,"Remoteserv msg:libc fputs...\n");
	#endif

	if(!CheckParamNum("libc fputs",reqparams,fputsparams)) return false;
	
	buf=GetPointerParameter(reqparams,0,PARAMCHECKING_DEFAULTLEN);
	if(!GetParameter(reqparams,1,(uint32*)&fp)) return false;
	ret=fputs(buf,fp);
	
	#ifdef DEBUGLIBC
	fprintf(stderr,"Remoteserv msg:libc fputs:ret->%d, buf->%s\n",ret,buf);
	#endif
	
	LIBCCOMMONRET(ret);
}
//simulation of: char* Libcgetcwd(char* buf, long size)
bool Libcgetcwd(ReqDBP* reqparams)
{
	char* buf=NULL;
	uint32 size;
	char* retchar=NULL;
	LIBCCOMMONDEC

	#ifdef DEBUGTA
	fprintf(stderr,"RemoteServ msg:libc: Libcgetcwd...\n");
	#endif
	
	if(!CheckParamNum("libc getcwd",reqparams,libcgetcwdparams)) return false;
	
	if(!GetParameter(reqparams,0,&size)) return false;
	#ifdef DEBUGLIBC
	fprintf(stderr,"Remoteserv msg:libc getcwd: size->%d...\n",size);
	#endif
	if(!(buf=malloc(size))) {
		#ifndef REMOTESERVQUIET
		fprintf(stderr,"RemoteServ err:Libcgetcwd: malloc failed!\n");
		#endif
		goto out;
	}
	retchar=getcwd(buf, size);
	#ifdef DEBUGLIBC
	fprintf(stderr,"Remoteserv msg:libc getcwd:buf->%s,ret->%d\n",buf,ret);
	#endif
out:
	ret=(uint32)retchar;
	LIBCCOMMONRET_1BUF(ret,ret,buf,CHARALIGN,strlen(buf)+1,LIBC_BUFFREE);
}
//simulation of: int Libcchdir(const char* path)
bool Libcchdir(ReqDBP* reqparams)
{
	char* path;
	LIBCCOMMONDEC

	#ifdef DEBUGTA
	fprintf(stderr,"RemoteServ msg:libc: Libcchdir...\n");
	#endif
	
	if(!CheckParamNum("libc chdir",reqparams,libcchdirparams)) return false;

	ret=-1;
	path=GetPointerParameter(reqparams,0,PARAMCHECKING_DEFAULTLEN);
	if(path==NULL) goto out;
	if((ret=chdir(path))<0){
		#ifndef REMOTESERVQUIET
		fprintf(stderr,"RemoteServ err:libc:Libcchdir:can not change cwd\n");
		#endif
	}
out:
	LIBCCOMMONRET(ret);
}

bool LibcServDispatcher(ReqDBH* reqbodyheader)
{
	ReqDataSetBodyParameters_t* reqparams=(ReqDBP*)(reqbodyheader+1);
	
	switch(UNITVAL(reqbodyheader->service)){
		case fopenservno:
			return Libcfopen(reqparams);
		case freadservno:
			return Libcfread(reqparams);
		case fwriteservno:
			return Libcfwrite(reqparams);
		case fcloseservno:
			return Libcfclose(reqparams);
		case fseekservno:
			return Libcfseek(reqparams);
		case ftellservno:
			return Libcftell(reqparams);
		case rewindservno:
			return Libcrewind(reqparams);
		case feofservno:
			return Libcfeof(reqparams);
		case fgetcservno:
			return Libcfgetc(reqparams);
		case fgetsservno:
			return Libcfgets(reqparams);
		case fputcservno:
			return Libcfputc(reqparams);
		case fputsservno:
			return Libcfputs(reqparams);
		case libcgetcwdservno:
			return Libcgetcwd(reqparams);
		case libcchdirservno:
			return Libcchdir(reqparams);
		default:
			#ifndef REMOTESERVQUIET
			fprintf(stderr,"Remoteserv err:LibcServDispatcher:invalid libc service:%d\n",UNITVAL(reqbodyheader->service));
			#endif
			return false;
	}
	return true;
}

