#ifndef REMOTESERVTYPE_H
#define REMOTESERVTYPE_H

/*for syscall fstat64( )>*/
#ifndef _I386_STAT_H
#define _I386_STAT_H

/* This matches struct stat64 in glibc2.1, hence the absolutely
 * insane amounts of padding around dev_t's.
 */
 #define STATDOMAINNUMNEED 13
struct stat64for386{
	unsigned short	st_dev;
	unsigned char	__pad0[10];

#define STAT64_HAS_BROKEN_ST_INO	1
	unsigned long	__st_ino;

	unsigned int	st_mode;
	unsigned int	st_nlink;

	unsigned long	st_uid;
	unsigned long	st_gid;

	unsigned short	st_rdev;
	unsigned char	__pad3[10];

	long long		st_size;
	unsigned long	st_blksize;

	unsigned long	st_blocks;	//Number 512-byte blocks allocated. 
	unsigned long	__pad4;		// future possible st_blocks high bits 

	unsigned long	st_accesstime;
	unsigned long	__pad5;

	unsigned long	st_modifytime;
	unsigned long	__pad6;

	unsigned long	st_createtime;
	unsigned long	__pad7;		// will be high 32 bits of ctime someday 

	unsigned long long	st_ino;
};

struct stat64formips {
	unsigned long	st_dev;
	unsigned long	st_pad0[3];	//Reserved for st_dev expansion 
	unsigned long long st_ino;	//ino_t
	unsigned int	st_mode;	//mode_t
	int     		st_nlink;	//nlink_t
	int     		st_uid;		//uid_t
	int				st_gid;		//gid_t
	unsigned long	st_rdev;
	unsigned long	st_pad1[3];	//Reserved for st_rdev expansion
	long long		st_size;
	 // Actually this should be timestruc_t st_atime, st_mtime and st_ctime
	 // but we don't have it under Linux.
	long			st_accesstime;	//time_t
	unsigned long	reserved0;	// Reserved for st_atime expansion
	long			st_modifytime;	//time_t
	unsigned long	reserved1;	//Reserved for st_atime expansion 
	long			st_createtime;	//time_t
	unsigned long	reserved2;	// Reserved for st_atime expansion  
	unsigned long	st_blksize;
	long long		st_blocks;
};

#endif
/*for syscall fstat64( )<*/

//for syscall stat
struct statformips {
	unsigned int		st_dev;
	long				st_pad1[3];		/* Reserved for network id */
	unsigned long		st_ino;
	unsigned int		st_mode;
	int					st_nlink;
	int					st_uid;
	int					st_gid;
	unsigned int		st_rdev;
	long				st_pad2[2];
	long				st_size;
	long				st_pad3;
	/*
	 * Actually this should be timestruc_t st_atime, st_mtime and st_ctime
	 * but we don't have it under Linux.
	 */
	long				st_accesstime;
	long				reserved0;
	long				st_modifytime;
	long				reserved1;
	long				st_createtime;
	long				reserved2;
	long				st_blksize;
	long				st_blocks;
	long				st_pad4[14];
};

/*for syscall newuname( )>*/
#ifndef _LINUX_UTSNAME_H
#define _LINUX_UTSNAME_H
struct new_utsname_fori386{
	char sysname[65];
	char nodename[65];
	char release[65];
	char version[65];
	char machine[65];
	char domainname[65];
};
#endif
/*for syscall newuname( )<*/

/*open flags for mips*/
#define O_ACCMODE_MIPS			0x0003
#define O_RDONLY_MIPS			0x0000
#define O_WRONLY_MIPS			0x0001
#define O_RDWR_MIPS				0x0002
#define O_APPEND_MIPS			0x0008
#define O_SYNC_MIPS				0x0010
#define O_NONBLOCK_MIPS			0x0080
#define O_CREAT_MIPS         	0x0100	/* not fcntl */
#define O_TRUNC_MIPS			0x0200	/* not fcntl */
#define O_EXCL_MIPS				0x0400	/* not fcntl */
#define O_NOCTTY_MIPS			0x0800	/* not fcntl */
#define FASYNC_MIPS				0x1000	/* fcntl, for BSD compatibility */
#define O_LARGEFILE_MIPS		0x2000	/* allow large file opens */
#define O_DIRECT_MIPS			0x8000	/* direct disk access hint */
#define O_DIRECTORY_MIPS		0x10000	/* must be a directory */
#define O_NOFOLLOW_MIPS			0x20000	/* don't follow links */
#define O_ATOMICLOOKUP_MIPS		0x40000
/*convert bit flag mipsflag to x86flag*/
typedef struct fileflagconvertitem{
	int mipsflag;
	int x86flag;
}fileflagconvert_t;

#endif /*end of REMOTESERVTYPE_H*/
