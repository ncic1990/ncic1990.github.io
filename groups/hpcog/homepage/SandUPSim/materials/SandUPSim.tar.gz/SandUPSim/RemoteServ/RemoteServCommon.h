#ifndef REMOTESERVCOMMON_H
#define REMOTESERVCOMMON_H
#include "RemoteServ.h"

uint32 up2exp(uint32 input);
void initbuffer(char** buf, char** origin, uint32* len);
bool newbuffer(char** buf,char** originbase,uint32* originlen,uint32 newlen);
void destroybuffer(char** buf,char** origin,uint32* len);
bool HALBufferLenChecking( );
RDH* getbuffer_RDH(char* buf);
bool setbuffer_RDH(char* buf,ServInfoDesc_t* servinfoptr, uint32 datasetlen);
RDBH* getbuffer_RDBH(char* buf);
bool setbuffer_RDBH(char* buf,ServInfoDesc_t* servinfoptr);
RDBP* getbuffer_Params(char* buf);
bool setbuffer_Params(char* buf,ParamsDesc_t* paramsdesc);
void outputdataset(char*s, char* buf);
bool GetParameter(RDBP* rdbparams,int which,uint32* retval);
char* GetPointerParameter(RDBP* rdbparams,int which,uint32 len);

#endif /*end of REMOTESERVCOMMON_H*/

