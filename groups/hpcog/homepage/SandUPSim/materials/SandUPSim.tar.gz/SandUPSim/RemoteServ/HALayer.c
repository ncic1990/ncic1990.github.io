#include "HALayer.h"
#include "DBGRemoteServ.h"

//global data structures
//HALayer data buffers
uint64 NetWorkCardMem[NetWorkCardBufSize/sizeof(uint64)];
char* NetWorkCardBuf=(char*)NetWorkCardMem;
int globalconnectfd;


//some assistant functions
long readn(int fd, void* vptr, long n)
{
	long nleft=n;
	long nread;
	char* ptr=(char*)vptr;

	while(nleft>0){
		if((nread=read(fd,ptr,nleft))<0){
			if(errno==EINTR)
				nread=0;
			else
				return -1;
		}else if(nread==0)
			break;
		nleft-=nread;
		ptr+=nread;
	}
	return (n-nleft);
}
long writen(int fd, const void* vptr, long n)
{
	long nleft=n;
	long nwrite;
	const char* ptr=(char*)vptr;

	while(nleft>0){
		if((nwrite=write(fd,ptr,nleft))<0){
			if(errno==EINTR)
				nwrite=0;
			else 
				return -1;
		}
		nleft-=nwrite;
		ptr+=nwrite;
	}
	return (n-nleft);
}
bool PackageLengthChecking(package_header_t* pheader)
{
	if(UNITVAL(pheader->packagelen)<=NetWorkCardBufSize) return true;
	#ifndef REMOTESERVQUIET
	fprintf(stderr,"RemoteServ err: HALayer: PackageLengthChecking: packagelen is greater than NetWorkCardBufSize!\n");
	#endif
	return false;
}

//send the data package to destination
bool SendPackage()
{
	int rc = 0;
	package_header_t* pheader=(package_header_t*)NetWorkCardBuf;

	if(!PackageLengthChecking(pheader)) return false;
	rc=writen(globalconnectfd,NetWorkCardBuf,UNITVAL(pheader->packagelen));
	if(rc!=UNITVAL(pheader->packagelen)){
		#ifndef REMOTESERVQUIET
		fprintf(stderr,"RemoteServ err: HALayer: SendPackage:The package can not be sent all!\n");
		#endif
		return false;
	}

	return true;
}

bool RecvPackage()
{
	int rc;
	uint32 left;
	package_header_t* pheader=(package_header_t*)NetWorkCardBuf;
	
	rc=readn(globalconnectfd,pheader,sizeof(package_header_t));
	if(rc!=sizeof(package_header_t)){
		#ifndef REMOTESERVQUIET
		fprintf(stderr,"RemoteServ err: HALayer: RecvPackage:can not get the package header!\n");
		#endif
		return false;
	}
	if(!PackageLengthChecking(pheader)) return false;
	left=UNITVAL(pheader->packagelen)-sizeof(package_header_t);
	if(left<0){
		#ifndef REMOTESERVQUIET
		fprintf(stderr,"RemoteServ err: HALayer: RecvPackage:package length is less than the header!\n");
		#endif
		return false;
	}
	rc=readn(globalconnectfd,NetWorkCardBuf+sizeof(package_header_t),left);
	if(rc!=left){
		#ifndef REMOTESERVQUIET
		fprintf(stderr,"RemoteServ err: HALayer: RecvPackage:The package can not be received all!\n");
		#endif
		return false;
	}

	return true;
}

