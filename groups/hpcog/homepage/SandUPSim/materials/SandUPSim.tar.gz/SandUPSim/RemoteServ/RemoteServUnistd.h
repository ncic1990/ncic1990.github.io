#ifndef REMOTESERVUNISTD_H
#define REMOTESERVUNISTD_H

/*
 * This file contains the system call numbers.
 */
//remote serv:rs
#define __NR_rsexit		  1
#define __NR_rsfork		  2
#define __NR_rsread		  3
#define __NR_rswrite		  4
#define __NR_rsopen		  5
#define __NR_rsclose		  6
#define __NR_rswaitpid		  7
#define __NR_rscreat		  8
#define __NR_rslink		  9
#define __NR_rsunlink		 10
#define __NR_rsexecve		 11
#define __NR_rschdir		 12
#define __NR_rstime		 13
#define __NR_rsmknod		 14
#define __NR_rschmod		 15
#define __NR_rslchown		 16
#define __NR_rsbreak		 17
#define __NR_rsoldstat		 18
#define __NR_rslseek		 19
#define __NR_rsgetpid		 20
#define __NR_rsmount		 21
#define __NR_rsumount		 22
#define __NR_rssetuid		 23
#define __NR_rsgetuid		 24
#define __NR_rsstime		 25
#define __NR_rsptrace		 26
#define __NR_rsalarm		 27
#define __NR_rsoldfstat		 28
#define __NR_rspause		 29
#define __NR_rsutime		 30
#define __NR_rsstty		 31
#define __NR_rsgtty		 32
#define __NR_rsaccess		 33
#define __NR_rsnice		 34
#define __NR_rsftime		 35
#define __NR_rssync		 36
#define __NR_rskill		 37
#define __NR_rsrename		 38
#define __NR_rsmkdir		 39
#define __NR_rsrmdir		 40
#define __NR_rsdup		 41
#define __NR_rspipe		 42
#define __NR_rstimes		 43
#define __NR_rsprof		 44
#define __NR_rsbrk		 45
#define __NR_rssetgid		 46
#define __NR_rsgetgid		 47
#define __NR_rssignal		 48
#define __NR_rsgeteuid		 49
#define __NR_rsgetegid		 50
#define __NR_rsacct		 51
#define __NR_rsumount2		 52
#define __NR_rslock		 53
#define __NR_rsioctl		 54
#define __NR_rsfcntl		 55
#define __NR_rsmpx		 56
#define __NR_rssetpgid		 57
#define __NR_rsulimit		 58
#define __NR_rsoldolduname	 59
#define __NR_rsumask		 60
#define __NR_rschroot		 61
#define __NR_rsustat		 62
#define __NR_rsdup2		 63
#define __NR_rsgetppid		 64
#define __NR_rsgetpgrp		 65
#define __NR_rssetsid		 66
#define __NR_rssigaction		 67
#define __NR_rssgetmask		 68
#define __NR_rsssetmask		 69
#define __NR_rssetreuid		 70
#define __NR_rssetregid		 71
#define __NR_rssigsuspend		 72
#define __NR_rssigpending		 73
#define __NR_rssethostname	 74
#define __NR_rssetrlimit		 75
#define __NR_rsgetrlimit		 76	/* Back compatible 2Gig limited rlimit */
#define __NR_rsgetrusage		 77
#define __NR_rsgettimeofday	 78
#define __NR_rssettimeofday	 79
#define __NR_rsgetgroups		 80
#define __NR_rssetgroups		 81
#define __NR_rsselect		 82
#define __NR_rssymlink		 83
#define __NR_rsoldlstat		 84
#define __NR_rsreadlink		 85
#define __NR_rsuselib		 86
#define __NR_rsswapon		 87
#define __NR_rsreboot		 88
#define __NR_rsreaddir		 89
#define __NR_rsmmap		 90
#define __NR_rsmunmap		 91
#define __NR_rstruncate		 92
#define __NR_rsftruncate		 93
#define __NR_rsfchmod		 94
#define __NR_rsfchown		 95
#define __NR_rsgetpriority	 96
#define __NR_rssetpriority	 97
#define __NR_rsprofil		 98
#define __NR_rsstatfs		 99
#define __NR_rsfstatfs		100
#define __NR_rsioperm		101
#define __NR_rssocketcall		102
#define __NR_rssyslog		103
#define __NR_rssetitimer		104
#define __NR_rsgetitimer		105
#define __NR_rsstat		106
#define __NR_rslstat		107
#define __NR_rsfstat		108
#define __NR_rsolduname		109
#define __NR_rsiopl		110
#define __NR_rsvhangup		111
#define __NR_rsidle		112
#define __NR_rsvm86old		113
#define __NR_rswait4		114
#define __NR_rsswapoff		115
#define __NR_rssysinfo		116
#define __NR_rsipc		117
#define __NR_rsfsync		118
#define __NR_rssigreturn		119
#define __NR_rsclone		120
#define __NR_rssetdomainname	121
#define __NR_rsuname		122
#define __NR_rsmodify_ldt		123
#define __NR_rsadjtimex		124
#define __NR_rsmprotect		125
#define __NR_rssigprocmask	126
#define __NR_rscreate_module	127
#define __NR_rsinit_module	128
#define __NR_rsdelete_module	129
#define __NR_rsget_kernel_syms	130
#define __NR_rsquotactl		131
#define __NR_rsgetpgid		132
#define __NR_rsfchdir		133
#define __NR_rsbdflush		134
#define __NR_rssysfs		135
#define __NR_rspersonality	136
#define __NR_rsafs_syscall	137 /* Syscall for Andrew File System */
#define __NR_rssetfsuid		138
#define __NR_rssetfsgid		139
#define __NR_rs_llseek		140
#define __NR_rsgetdents		141
#define __NR_rs_newselect		142
#define __NR_rsflock		143
#define __NR_rsmsync		144
#define __NR_rsreadv		145
#define __NR_rswritev		146
#define __NR_rsgetsid		147
#define __NR_rsfdatasync		148
#define __NR_rs_sysctl		149
#define __NR_rsmlock		150
#define __NR_rsmunlock		151
#define __NR_rsmlockall		152
#define __NR_rsmunlockall		153
#define __NR_rssched_setparam		154
#define __NR_rssched_getparam		155
#define __NR_rssched_setscheduler		156
#define __NR_rssched_getscheduler		157
#define __NR_rssched_yield		158
#define __NR_rssched_get_priority_max	159
#define __NR_rssched_get_priority_min	160
#define __NR_rssched_rr_get_interval	161
#define __NR_rsnanosleep		162
#define __NR_rsmremap		163
#define __NR_rssetresuid		164
#define __NR_rsgetresuid		165
#define __NR_rsvm86		166
#define __NR_rsquery_module	167
#define __NR_rspoll		168
#define __NR_rsnfsservctl		169
#define __NR_rssetresgid		170
#define __NR_rsgetresgid		171
#define __NR_rsprctl              172
#define __NR_rsrt_sigreturn	173
#define __NR_rsrt_sigaction	174
#define __NR_rsrt_sigprocmask	175
#define __NR_rsrt_sigpending	176
#define __NR_rsrt_sigtimedwait	177
#define __NR_rsrt_sigqueueinfo	178
#define __NR_rsrt_sigsuspend	179
#define __NR_rspread		180
#define __NR_rspwrite		181
#define __NR_rschown		182
#define __NR_rsgetcwd		183
#define __NR_rscapget		184
#define __NR_rscapset		185
#define __NR_rssigaltstack	186
#define __NR_rssendfile		187
#define __NR_rsgetpmsg		188	/* some people actually want streams */
#define __NR_rsputpmsg		189	/* some people actually want streams */
#define __NR_rsvfork		190
#define __NR_rsugetrlimit		191	/* SuS compliant getrlimit */
#define __NR_rsmmap2		192
#define __NR_rstruncate64		193
#define __NR_rsftruncate64	194
#define __NR_rsstat64		195
#define __NR_rslstat64		196
#define __NR_rsfstat64		197
#define __NR_rslchown32		198
#define __NR_rsgetuid32		199
#define __NR_rsgetgid32		200
#define __NR_rsgeteuid32		201
#define __NR_rsgetegid32		202
#define __NR_rssetreuid32		203
#define __NR_rssetregid32		204
#define __NR_rsgetgroups32	205
#define __NR_rssetgroups32	206
#define __NR_rsfchown32		207
#define __NR_rssetresuid32	208
#define __NR_rsgetresuid32	209
#define __NR_rssetresgid32	210
#define __NR_rsgetresgid32	211
#define __NR_rschown32		212
#define __NR_rssetuid32		213
#define __NR_rssetgid32		214
#define __NR_rssetfsuid32		215
#define __NR_rssetfsgid32		216
#define __NR_rspivot_root		217
#define __NR_rsmincore		218
#define __NR_rsmadvise		219
#define __NR_rsmadvise1		219	/* delete when C lib stub is removed */
#define __NR_rsgetdents64		220
#define __NR_rsfcntl64		221
#define __NR_rssecurity		223	/* syscall for security modules */
#define __NR_rsgettid		224
#define __NR_rsreadahead		225
#define __NR_rssetxattr		226
#define __NR_rslsetxattr		227
#define __NR_rsfsetxattr		228
#define __NR_rsgetxattr		229
#define __NR_rslgetxattr		230
#define __NR_rsfgetxattr		231
#define __NR_rslistxattr		232
#define __NR_rsllistxattr		233
#define __NR_rsflistxattr		234
#define __NR_rsremovexattr	235
#define __NR_rslremovexattr	236
#define __NR_rsfremovexattr	237
#define __NR_rstkill		238
#define __NR_rssendfile64		239
#define __NR_rsfutex		240
#define __NR_rssched_setaffinity	241
#define __NR_rssched_getaffinity	242
#define __NR_rsset_thread_area	243
#define __NR_rsget_thread_area	244
#define __NR_rsio_setup		245
#define __NR_rsio_destroy		246
#define __NR_rsio_getevents	247
#define __NR_rsio_submit		248
#define __NR_rsio_cancel		249
#define __NR_rsalloc_hugepages	250
#define __NR_rsfree_hugepages	251
#define __NR_rsexit_group		252
#define __NR_rslookup_dcookie	253
#define __NR_rsset_tid_address	258

/* user-visible error numbers are in the range -1 - -124: see <asm-i386/errno.h> */

#define __syscall_return(type, res) \
do { \
	if ((unsigned long)(res) >= (unsigned long)(-125)) { \
		errno = -(res); \
		res = -1; \
	} \
	return (type) (res); \
} while (0)

/* XXX - _foo needs to be __foo, while __NR_bar could be _NR_bar. */
#define _syscall0(type,name) \
type name(void) \
{ \
long __res; \
__asm__ volatile ("int $0x80" \
	: "=a" (__res) \
	: "0" (__NR_##name)); \
__syscall_return(type,__res); \
}

#define _syscall1(type,name,type1,arg1) \
type name(type1 arg1) \
{ \
long __res; \
__asm__ volatile ("int $0x80" \
	: "=a" (__res) \
	: "0" (__NR_##name),"b" ((long)(arg1))); \
__syscall_return(type,__res); \
}

#define _syscall2(type,name,type1,arg1,type2,arg2) \
type name(type1 arg1,type2 arg2) \
{ \
long __res; \
__asm__ volatile ("int $0x80" \
	: "=a" (__res) \
	: "0" (__NR_##name),"b" ((long)(arg1)),"c" ((long)(arg2))); \
__syscall_return(type,__res); \
}

#define _syscall3(type,name,type1,arg1,type2,arg2,type3,arg3) \
type name(type1 arg1,type2 arg2,type3 arg3) \
{ \
long __res; \
__asm__ volatile ("int $0x80" \
	: "=a" (__res) \
	: "0" (__NR_##name),"b" ((long)(arg1)),"c" ((long)(arg2)), \
		  "d" ((long)(arg3))); \
__syscall_return(type,__res); \
}

#define _syscall4(type,name,type1,arg1,type2,arg2,type3,arg3,type4,arg4) \
type name (type1 arg1, type2 arg2, type3 arg3, type4 arg4) \
{ \
long __res; \
__asm__ volatile ("int $0x80" \
	: "=a" (__res) \
	: "0" (__NR_##name),"b" ((long)(arg1)),"c" ((long)(arg2)), \
	  "d" ((long)(arg3)),"S" ((long)(arg4))); \
__syscall_return(type,__res); \
} 

#define _syscall5(type,name,type1,arg1,type2,arg2,type3,arg3,type4,arg4, \
	  type5,arg5) \
type name (type1 arg1,type2 arg2,type3 arg3,type4 arg4,type5 arg5) \
{ \
long __res; \
__asm__ volatile ("int $0x80" \
	: "=a" (__res) \
	: "0" (__NR_##name),"b" ((long)(arg1)),"c" ((long)(arg2)), \
	  "d" ((long)(arg3)),"S" ((long)(arg4)),"D" ((long)(arg5))); \
__syscall_return(type,__res); \
}

#define _syscall6(type,name,type1,arg1,type2,arg2,type3,arg3,type4,arg4, \
	  type5,arg5,type6,arg6) \
type name (type1 arg1,type2 arg2,type3 arg3,type4 arg4,type5 arg5,type6 arg6) \
{ \
long __res; \
__asm__ volatile ("push %%ebp ; movl %%eax,%%ebp ; movl %1,%%eax ; int $0x80 ; pop %%ebp" \
	: "=a" (__res) \
	: "i" (__NR_##name),"b" ((long)(arg1)),"c" ((long)(arg2)), \
	  "d" ((long)(arg3)),"S" ((long)(arg4)),"D" ((long)(arg5)), \
	  "0" ((long)(arg6))); \
__syscall_return(type,__res); \
}

#ifdef __KERNEL_SYSCALLS__

/*
 * we need this inline - forking from kernel space will result
 * in NO COPY ON WRITE (!!!), until an execve is executed. This
 * is no problem, but for the stack. This is handled by not letting
 * main() use the stack at all after fork(). Thus, no function
 * calls - which means inline code for fork too, as otherwise we
 * would use the stack upon exit from 'fork()'.
 *
 * Actually only pause and fork are needed inline, so that there
 * won't be any messing with the stack from main(), but we define
 * some others too.
 */
#define __NR__exit __NR_exit
static inline _syscall0(int,pause)
static inline _syscall0(int,sync)
static inline _syscall0(pid_t,setsid)
static inline _syscall3(int,write,int,fd,const char *,buf,off_t,count)
static inline _syscall3(int,read,int,fd,char *,buf,off_t,count)
static inline _syscall3(off_t,lseek,int,fd,off_t,offset,int,count)
static inline _syscall1(int,dup,int,fd)
static inline _syscall3(int,execve,const char *,file,char **,argv,char **,envp)
static inline _syscall3(int,open,const char *,file,int,flag,int,mode)
static inline _syscall1(int,close,int,fd)
static inline _syscall1(int,_exit,int,exitcode)
static inline _syscall3(pid_t,waitpid,pid_t,pid,int *,wait_stat,int,options)
static inline _syscall1(int,delete_module,const char *,name)

static inline pid_t wait(int * wait_stat)
{
	return waitpid(-1,wait_stat,0);
}

#endif

/*
 * "Conditional" syscalls
 *
 * What we want is __attribute__((weak,alias("sys_ni_syscall"))),
 * but it doesn't work on all toolchains, so we just do it by hand
 */
#define cond_syscall(x) asm(".weak\t" #x "\n\t.set\t" #x ",sys_ni_syscall");

#endif /* REMOTESERVUNISTD_H */

