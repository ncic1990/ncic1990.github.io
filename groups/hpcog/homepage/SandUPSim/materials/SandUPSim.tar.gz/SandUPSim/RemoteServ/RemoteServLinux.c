#include "RemoteServLinux.h"
#include "DBGRemoteServ.h"
#include "RemoteServUnistd.h"
#include "RemoteServType.h"
#include "RemoteServCommon.h"
#include "AppLayer.h"

uint32 ConvertSysCallReturn(uint32 inputret,uint32* outputret)
{
	if(inputret>=0){
		*outputret=inputret;
		return 0;
	}
	else if(inputret==-1){
			*outputret=errno;
			return 1;
		}
		else{
			#ifndef REMOTESERVQUIET
			fprintf(stderr,"RemoteServ err:SyscallServError:Not such return value when running the Linux syscall server!\n");
			#endif
		}
}

#define LINUXCOMMONDECLARE\
	uint32 retval;\
	uint32 v0;\
	uint32 a3;\
	ServInfoDesc_t servinfo;\
	ParamsDesc_t* paramsdescptr=&servinfo.paramdesc;

#define X86SYSCALLOK(retval)\
	(retval>=0)
#define X86SYSCALLFAILED(retval)\
	(retval<0)
	
#define LINUXCOMMONRET(retval)\
do{\
	a3=ConvertSysCallReturn(retval,&v0);\
	SetParamDescNum(paramsdescptr,2);\
	SetParamDescParameter(paramsdescptr,0,v0,true,0,0);\
	SetParamDescParameter(paramsdescptr,1,a3,true,0,0);\
	ServerMakeReplyDataSet(&servinfo);\
	return true;\
}while(0)

#define LINUX_BUFNOTFREE 0
#define LINUX_BUFFREE 1
#define LINUXCOMMONRET_1BUF(retval,buf,align,successlen,buffreeflag)\
do{\
	a3=ConvertSysCallReturn(retval,&v0);\
	SetParamDescNum(paramsdescptr,3);\
	SetParamDescParameter(paramsdescptr,0,v0,true,0,0);\
	SetParamDescParameter(paramsdescptr,1,a3,true,0,0);\
	if(!a3)\
		SetParamDescParameter(paramsdescptr,2,(uint32)buf,false,align,successlen);\
	else\
		SetParamDescParameter(paramsdescptr,2,(uint32)buf,false,align,PARAM_POINTERNULL);\
	ServerMakeReplyDataSet(&servinfo);\
	if(buffreeflag)\
		if(buf) free(buf);\
	return true;\
}while(0)

_syscall3(int,rsread,unsigned int,fd,char *,buf,long,count)
bool LinuxSyscallread(ReqDBP* reqparams)
{
	uint32 fd;
	char* buf;
	uint32 count;
	LINUXCOMMONDECLARE
	
	if(!CheckParamNum("Linux syscall read",reqparams,LinuxSyscallreadparams)) return false;

	if(!GetParameter(reqparams,0, &fd)) return false;
	if(!GetParameter(reqparams,1, &count)) return false;
	if(!(buf=malloc(count+1))) return false;

	retval=rsread(fd,buf,count);

	#ifdef DEBUGLINUX
	fprintf(stderr,"RemoteServ msg:%d:Linux Syscall read...:fd->%d, count->%d; retval->%d\n",
		4000+LinuxSyscallreadservno,fd,count,retval<0?retval*errno:retval);
	if(X86SYSCALLOK(retval)){
		buf[retval]='\0';
		fprintf(stderr,"buf->%s\n",buf);
	}
	#endif
	LINUXCOMMONRET_1BUF(retval,buf,CHARALIGN,retval,LINUX_BUFFREE);
}

_syscall3(int,rswrite,unsigned int,fd,const char *,buf,long,count)
bool LinuxSyscallwrite(ReqDBP* reqparams)
{
	uint32 fd;
	char* buf;
	uint32 count;
	LINUXCOMMONDECLARE

	if(!CheckParamNum("Linux syscall write",reqparams,LinuxSyscallwriteparams)) return false;

	if(!GetParameter(reqparams,0, &fd)) return false;
	if(!GetParameter(reqparams,2, &count)) return false;
	buf=GetPointerParameter(reqparams,1,count);

	retval=rswrite(fd,buf,count);

	#ifdef DEBUGLINUX
	fprintf(stderr,"RemoteServ msg:%d:Linux Syscall write...:fd->%d, buf->%s, count->%d; retval->%d\n",
		4000+LinuxSyscallwriteservno,fd,buf,count,retval<0?retval*errno:retval);
	#endif
	LINUXCOMMONRET(retval);
}

fileflagconvert_t fflagcnvttable[]={
{O_WRONLY_MIPS,O_WRONLY},{O_RDWR_MIPS,O_RDWR},{O_APPEND_MIPS,O_APPEND},
{O_SYNC_MIPS,O_SYNC},{O_NONBLOCK_MIPS,O_NONBLOCK},{O_CREAT_MIPS,O_CREAT},
{O_TRUNC_MIPS,O_TRUNC},{O_EXCL_MIPS,O_EXCL},{O_NOCTTY_MIPS,O_NOCTTY},
{FASYNC_MIPS,FASYNC},{O_LARGEFILE_MIPS,O_LARGEFILE},{O_DIRECT_MIPS,O_DIRECT},
{O_DIRECTORY_MIPS,O_DIRECTORY},{O_NOFOLLOW_MIPS,O_NOFOLLOW},
//{O_ATOMICLOOKUP_MIPS,O_ATOMICLOOKUP},
{-1,0}
};
int fileflagconvert(int mipsflag)
{
	int count=0;
	int x86flag=0;

	while((int)fflagcnvttable[count].mipsflag!=(int)-1){
		if(mipsflag&fflagcnvttable[count].mipsflag){
			x86flag|=fflagcnvttable[count].x86flag;
			mipsflag&=~fflagcnvttable[count].mipsflag;
		}
		count++;
	}
	if(mipsflag!=0){
		#ifndef REMOTESERVQUIET
		fprintf(stderr,"RemoteServ Warning:fileflagconvert:can not convert completely!\n");
		#endif
	}
	return x86flag;
}
_syscall3(long,rsopen,const char*,filename,int,flag,int,mode)
bool LinuxSyscallopen(ReqDBP* reqparams)
{
	char* filename;
	uint32 flag;
	uint32 mode;
	LINUXCOMMONDECLARE

	if(!CheckParamNum("Linux syscall open",reqparams,LinuxSyscallopenparams)) return false;

	filename=GetPointerParameter(reqparams,0,PARAMCHECKING_DEFAULTLEN);
	if(!GetParameter(reqparams,1, &flag)) return false;
	flag=fileflagconvert(flag);
	if(!GetParameter(reqparams,2, &mode)) return false;

	retval=rsopen(filename,flag,mode);
	
	#ifdef DEBUGLINUX
	fprintf(stderr,"RemoteServ msg:%d:Linux Syscall open...:filename->%s, flag->0x%x, mode->0x%x; fd->%d\n",
		4000+LinuxSyscallopenservno,filename,flag,mode,retval<0?retval*errno:retval);
	#endif
	LINUXCOMMONRET(retval);
}

_syscall1(long,rsclose,unsigned int,fd)
bool LinuxSyscallclose(ReqDBP* reqparams)
{
	uint32 fd;
	LINUXCOMMONDECLARE
	
	if(!CheckParamNum("Linux syscall close",reqparams,LinuxSyscallcloseparams)) return false;

	if(!GetParameter(reqparams,0, &fd)) return false;
	
	retval=rsclose(fd);
	
	#ifdef DEBUGLINUX
	fprintf(stderr,"RemoteServ msg:%d:Linux Syscall close...:fd->%d; retval->%d\n",
		4000+LinuxSyscallcloseservno,fd,retval<0?retval*errno:retval);
	#endif
	LINUXCOMMONRET(retval);
}

//simulation of: long unlink(const char* pathname)
_syscall1(long, rsunlink, const char *, pathname)
bool LinuxSyscallunlink(ReqDBP* reqparams)
{
	char* pathname;
	LINUXCOMMONDECLARE

	if(!CheckParamNum("Linux syscall unlink",reqparams,LinuxSyscallunlinkparams)) return false;

	pathname=GetPointerParameter(reqparams,0,PARAMCHECKING_DEFAULTLEN);

	retval=rsunlink(pathname);

	#ifdef DEBUGLINUX
	fprintf(stderr,"RemoteServ msg:%d:Linux Syscall unlink...:pathname->%s; retval->%d\n",
		4000+LinuxSyscallunlinkservno,pathname,retval<0?retval*errno:retval);
	#endif
	LINUXCOMMONRET(retval);
}

//simulation of: long time(int* tloc)
_syscall1(long, rstime, int *, tloc)
bool LinuxSyscalltime(ReqDBP* reqparams)
{
	LINUXCOMMONDECLARE

	if(!CheckParamNum("Linux syscall time",reqparams,LinuxSyscalltimeparams)) return false;

	retval=rstime(NULL);

	#ifdef DEBUGLINUX
	fprintf(stderr,"RemoteServ msg:%d:Linux Syscall time...:retval->%d\n",
		4000+LinuxSyscalltimeservno,retval<0?retval*errno:retval);
	#endif
	LINUXCOMMONRET(retval);
}

_syscall3(long,rslseek,unsigned int,fd,long,offset,unsigned int,origin)
bool LinuxSyscalllseek(ReqDBP* reqparams)
{
	uint32 fd;
	uint32 offset;
	uint32 origin;
	LINUXCOMMONDECLARE
	
	if(!CheckParamNum("Linux syscall lseek",reqparams,LinuxSyscalllseekparams)) return false;

	if(!GetParameter(reqparams,0, &fd)) return false;
	if(!GetParameter(reqparams,1, &offset)) return false;
	if(!GetParameter(reqparams,2, &origin)) return false;
	
	retval=rslseek(fd,offset,origin);
	
	#ifdef DEBUGLINUX
	fprintf(stderr,"RemoteServ msg:%d:Linux Syscall lseek...:fd->%d, offset->%d, origin->%d; retval->%d\n",
		4000+LinuxSyscalllseekservno,fd,offset,origin,retval<0?retval*errno:retval);
	#endif
	LINUXCOMMONRET(retval);
}

//simulation of: long getpid(void)
_syscall0(long, rsgetpid)
bool LinuxSyscallgetpid(ReqDBP* reqparams)
{
	LINUXCOMMONDECLARE

	if(!CheckParamNum("Linux syscall getpid",reqparams,LinuxSyscallgetpidparams)) return false;

	retval=rsgetpid();

	#ifdef DEBUGLINUX
	fprintf(stderr,"RemoteServ msg:%d:Linux Syscall getpid...:retval->%d\n",
		4000+LinuxSyscallgetpidservno,retval<0?retval*errno:retval);
	#endif
	LINUXCOMMONRET(retval);
}

_syscall0(long,rsgetuid32)
bool LinuxSyscallgetuid(ReqDBP* reqparams)
{
	LINUXCOMMONDECLARE
	
	if(!CheckParamNum("Linux syscall getuid",reqparams,LinuxSyscallgetuidparams)) return false;

	retval=rsgetuid32();

	#ifdef DEBUGLINUX
	fprintf(stderr,"RemoteServ msg:%d:Linux Syscall getuid...:retval->%d\n",
		4000+LinuxSyscallgetuidservno,retval<0?retval*errno:retval);
	#endif
	LINUXCOMMONRET(retval);
}

//simulation of: long access(const char * filename, int mode)
_syscall2(long, rsaccess,const char *, filename, int, mode)
bool LinuxSyscallaccess(ReqDBP* reqparams)
{
	char* filename;
	int mode;
	LINUXCOMMONDECLARE

	if(!CheckParamNum("Linux syscall access",reqparams,LinuxSyscallaccessparams)) return false;

	filename=GetPointerParameter(reqparams,0,PARAMCHECKING_DEFAULTLEN);
	if(!GetParameter(reqparams,1, (uint32*)&mode)) return false;
	
	retval=rsaccess(filename,mode);

	#ifdef DEBUGLINUX
	fprintf(stderr,"RemoteServ msg:%d:Linux Syscall access...:filename->%s, mode->0x%x; retval->%d\n",
		4000+LinuxSyscallaccessservno,filename,mode,retval<0?retval*errno:retval);
	#endif
	LINUXCOMMONRET(retval);
}

//simulation of: long rename(const char * oldname, const char * newname)
_syscall2(long, rsrename, const char *, oldname, const char *, newname)
bool LinuxSyscallrename(ReqDBP* reqparams)
{
	char* oldname;
	char* newname;
	LINUXCOMMONDECLARE

	if(!CheckParamNum("Linux syscall rename",reqparams,LinuxSyscallrenameparams)) return false;

	oldname=GetPointerParameter(reqparams,0,PARAMCHECKING_DEFAULTLEN);
	newname=GetPointerParameter(reqparams,1,PARAMCHECKING_DEFAULTLEN);
	
	retval=rsrename(oldname,newname);

	#ifdef DEBUGLINUX
	fprintf(stderr,"RemoteServ msg:%d:Linux Syscall rename...:oldname->%s, newname->%s; retval->%d\n",
		4000+LinuxSyscallrenameservno,oldname,newname,retval<0?retval*errno:retval);
	#endif
	LINUXCOMMONRET(retval);
}

//simulation of: long times(struct tms* tbuf)
_syscall1(long, rstimes, struct tms*, tbuf)
bool LinuxSyscalltimes(ReqDBP* reqparams)
{
	struct tms tstruct;
	LINUXCOMMONDECLARE

	if(!CheckParamNum("Linux syscall times",reqparams,LinuxSyscalltimesparams)) return false;

	retval=rstimes(&tstruct);

	#ifdef DEBUGLINUX
	fprintf(stderr,"RemoteServ msg:%d:Linux Syscall times...:retval->%d\n",
		4000+LinuxSyscalltimesservno,retval<0?retval*errno:retval);
	#endif
	LINUXCOMMONRET_1BUF(retval,&tstruct,DWORDALIGN,sizeof(struct tms),LINUX_BUFNOTFREE);
}

_syscall0(long,rsgetgid32)
bool LinuxSyscallgetgid(ReqDBP* reqparams)
{
	LINUXCOMMONDECLARE
	
	if(!CheckParamNum("Linux syscall getgid",reqparams,LinuxSyscallgetgidparams)) return false;

	retval=rsgetgid32();
	
	#ifdef DEBUGLINUX
	fprintf(stderr,"RemoteServ msg:%d:Linux Syscall getgid...:retval->%d\n",
		4000+LinuxSyscallgetgidservno,retval<0?retval*errno:retval);
	#endif
	LINUXCOMMONRET(retval);
}

_syscall0(long,rsgeteuid32)
bool LinuxSyscallgeteuid(ReqDBP* reqparams)
{
	LINUXCOMMONDECLARE
	
	if(!CheckParamNum("Linux syscall geteuid",reqparams,LinuxSyscallgeteuidparams)) return false;

	retval=rsgeteuid32();

	#ifdef DEBUGLINUX
	fprintf(stderr,"RemoteServ msg:%d:Linux Syscall geteuid...:retval->%d\n",
		4000+LinuxSyscallgeteuidservno,retval<0?retval*errno:retval);
	#endif
	LINUXCOMMONRET(retval);
}

_syscall0(long,rsgetegid32)
bool LinuxSyscallgetegid(ReqDBP* reqparams)
{
	LINUXCOMMONDECLARE
	
	if(!CheckParamNum("Linux syscall getegid",reqparams,LinuxSyscallgetegidparams)) return false;

	retval=rsgetegid32();

	#ifdef DEBUGLINUX
	fprintf(stderr,"RemoteServ msg:%d:Linux Syscall getegid...:retval->%d\n",
		4000+LinuxSyscallgetegidservno,retval<0?retval*errno:retval);
	#endif
	LINUXCOMMONRET(retval);
}

//simulation of: long ioctl(unsigned int fd, unsigned int cmd, unsigned long arg)
//note: not implemented completely!!!
_syscall3(long, rsioctl,unsigned int,fd, unsigned int,cmd, unsigned long,arg)
bool LinuxSyscallioctl(ReqDBP* reqparams)
{
	uint32 fd;
	uint32 cmd;
	uint32 arg;
	LINUXCOMMONDECLARE

	if(!CheckParamNum("Linux syscall ioctl",reqparams,LinuxSyscallioctlparams)) return false;

	if(!GetParameter(reqparams,0, &fd)) return false;
	if(!GetParameter(reqparams,1, &cmd)) return false;
	if(!GetParameter(reqparams,2, &arg)) return false;

	retval=-1; errno=ENOTTY; //special

	#ifdef DEBUGLINUX
	fprintf(stderr,"RemoteServ msg:%d:Linux Syscall ioctl...:fd->%d, cmd->0x%x, arg->0x%x; retval->%d\n",
		4000+LinuxSyscallioctlparams,fd,cmd,arg,retval<0?retval*errno:retval);
	#endif
	LINUXCOMMONRET(retval);
}

_syscall3(long,rsfcntl,unsigned int,fd, unsigned int,cmd, unsigned long,arg)
_syscall3(long,rsfcntl64,unsigned int,fd, unsigned int,cmd, unsigned long,arg)
bool LinuxSyscallfcntl(ReqDBP* reqparams, uint32 syscallno)
{
	uint32 fd;
	uint32 cmd;
	uint32 arg;
	LINUXCOMMONDECLARE

	if(syscallno==LinuxSyscallfcntlservno){
		if(!CheckParamNum("Linux syscall fcntl",reqparams,LinuxSyscallfcntlparams))
			return false;
	}else{
		if(!CheckParamNum("Linux syscall fcntl64",reqparams,LinuxSyscallfcntl64params)) 
			return false;
	}
	
	if(!GetParameter(reqparams,0, &fd)) return false;
	if(!GetParameter(reqparams,1, &cmd)) return false;
	if(!GetParameter(reqparams,2, &arg)) return false;
	#ifdef DEBUGLINUX
	if(syscallno==LinuxSyscallfcntlservno)
		fprintf(stderr,"RemoteServ msg:%d:Linux Syscall fcntl...:fd->%d, cmd->0x%x, arg->0x%x",
			4000+syscallno,fd,cmd,arg);
	else
		fprintf(stderr,"RemoteServ msg:%d:Linux Syscall fcntl64...:fd->%d, cmd->0x%x, arg->0x%x",
			4000+syscallno,fd,cmd,arg);
	#endif

	if((cmd!=F_GETFD)&&(cmd!=F_SETFD))
		fprintf(stderr,"RemoteServ Warning:LinuxSyscallfcntl: server not implemented completely!\n");
	if(syscallno==LinuxSyscallfcntlservno)
		retval=rsfcntl(fd,cmd,arg);
	else
		retval=rsfcntl64(fd,cmd,arg);
	#ifdef DEBUGLINUX
	fprintf(stderr,"; retval->%d\n",retval<0?retval*errno:retval);
	#endif

	LINUXCOMMONRET(retval);
}

//simulation of: long getrlimit(unsigned int resource, struct rlimit* rlim)
_syscall2(long, rsgetrlimit, unsigned int, resource, struct rlimit *, rlim)
bool LinuxSyscallgetrlimit(ReqDBP* reqparams)
{
	unsigned int resource;
	struct rlimit rlimitstruct;
	LINUXCOMMONDECLARE

	if(!CheckParamNum("Linux syscall getrlimit",reqparams,LinuxSyscallgetrlimitparams)) return false;

	if(!GetParameter(reqparams,0,(uint32*)&resource)) return false;
	
	retval=rsgetrlimit(resource,&rlimitstruct);

	#ifdef DEBUGLINUX
	fprintf(stderr,"RemoteServ msg:%d:Linux Syscall getrlimit...: resource->%d; retval->%d\n",
		4000+LinuxSyscallgetrlimitservno,resource,retval<0?retval*errno:retval);
	#endif
	LINUXCOMMONRET_1BUF(retval,&rlimitstruct,DWORDALIGN,sizeof(struct rlimit),LINUX_BUFNOTFREE);
}

//simulation of: long getrusage(int who, struct rusage* ru)
_syscall2(long, rsgetrusage, int, who, struct rusage *, ru)
bool LinuxSyscallgetrusage(ReqDBP* reqparams)
{
	int who;
	struct rusage rusagestruct;
	LINUXCOMMONDECLARE

	if(!CheckParamNum("Linux syscall getrusage",reqparams,LinuxSyscallgetrusageparams)) return false;

	if(!GetParameter(reqparams,0,(uint32*)&who)) return false;
	
	retval=rsgetrusage(who,&rusagestruct);

	#ifdef DEBUGLINUX
	fprintf(stderr,"RemoteServ msg:%d:Linux Syscall getrusage...: who->%d; retval->%d\n",
		4000+LinuxSyscallgetrusageservno,who,retval<0?retval*errno:retval);
	#endif
	LINUXCOMMONRET_1BUF(retval,&rusagestruct,DWORDALIGN,sizeof(struct rusage),LINUX_BUFNOTFREE);
}

//simulation of: long ftruncate(unsigned int fd, unsigned long length)
_syscall2(long, rsftruncate,unsigned int, fd, unsigned long, length)
bool LinuxSyscallftruncate(ReqDBP* reqparams)
{
	unsigned int fd;
	unsigned long length;
	LINUXCOMMONDECLARE

	if(!CheckParamNum("Linux syscall ftruncate",reqparams,LinuxSyscallftruncateparams)) return false;

	if(!GetParameter(reqparams,0,(uint32*)&fd)) return false;
	if(!GetParameter(reqparams,1,(uint32*)&length)) return false;
	
	retval=rsftruncate(fd,length);

	#ifdef DEBUGLINUX
	fprintf(stderr,"RemoteServ msg:%d:Linux Syscall ftruncate...: fd->%d, length->%d; retval->%d\n",
		4000+LinuxSyscallftruncateservno,fd,length,retval<0?retval*errno:retval);
	#endif
	LINUXCOMMONRET(retval);
}

//simulation of: long stat(char * filename, struct stat* statbuf)
//simulation of: long lstat(char * filename, struct stat* statbuf)
//simulation of: long fstat(unsigned int fd, struct stat* statbuf)
void CopyStat(struct stat* statlocalptr, struct statformips* statbuf)
{
	if(statlocalptr==NULL||statbuf==NULL){
		#ifndef REMOTESERVQUIET
		fprintf(stderr,"RemoteServ err:Linux:when copying local fstat to mips!\n");
		#endif
		return;
	}
	
	statbuf->st_dev=(unsigned int)statlocalptr->st_dev;
	statbuf->st_ino=(unsigned long)statlocalptr->st_ino;
	statbuf->st_mode=(unsigned int)statlocalptr->st_mode;
	statbuf->st_nlink=(int)statlocalptr->st_nlink;
	statbuf->st_uid=(int)statlocalptr->st_uid;
	statbuf->st_gid=(int)statlocalptr->st_gid;
	statbuf->st_rdev=(unsigned int)statlocalptr->st_rdev;
	statbuf->st_size=(long)statlocalptr->st_size;
	statbuf->st_accesstime=(long)statlocalptr->st_atime;
	statbuf->st_modifytime=(long)statlocalptr->st_mtime;
	statbuf->st_createtime=(long)statlocalptr->st_ctime;
	statbuf->st_blksize=(long)statlocalptr->st_blksize;
	statbuf->st_blocks=(long)statlocalptr->st_blocks;
		
	#ifdef DEBUGLINUX
	fprintf(stderr,"RemoteServ stat...\n");
	fprintf(stderr,"st_dev->0x%x\n",(long int)statlocalptr->st_dev);
	fprintf(stderr,"st_ino->0x%x\n",(long int)statlocalptr->st_ino);
	fprintf(stderr,"st_mode->0x%x\n",(long int)statlocalptr->st_mode);
	fprintf(stderr,"st_nlink->0x%x\n",(long int)statlocalptr->st_nlink);
	fprintf(stderr,"st_uid->0x%x\n",(long int)statlocalptr->st_uid);
	fprintf(stderr,"st_gid->0x%x\n",(long int)statlocalptr->st_gid);
	fprintf(stderr,"st_rdev->0x%x\n",(long int)statlocalptr->st_rdev);
	fprintf(stderr,"st_size->0x%x\n",(long int)statlocalptr->st_size);
	fprintf(stderr,"st_accesstime->0x%x\n",(long int)statlocalptr->st_atime);
	fprintf(stderr,"st_modifytime->0x%x\n",(long int)statlocalptr->st_mtime);
	fprintf(stderr,"st_createtime->0x%x\n",(long int)statlocalptr->st_ctime);
	fprintf(stderr,"st_blksize->0x%x\n",(long int)statlocalptr->st_blksize);
	fprintf(stderr,"st_blocks->0x%x\n",(long int)statlocalptr->st_blocks);
	#endif
} 
_syscall2(long, rsstat,char *, filename, struct stat *, statbuf)
_syscall2(long, rslstat,char *, filename, struct stat *, statbuf)
_syscall2(long, rsfstat,unsigned int, fd, struct stat *, statbuf)
bool LinuxSyscallfstat(ReqDBP* reqparams, uint32 syscallno)
{
	char* filename;
	unsigned int fd;
	struct stat x86stat;
	struct statformips statmips;
	LINUXCOMMONDECLARE

	switch(syscallno){
		case LinuxSyscallstatservno:
			if(!CheckParamNum("Linux syscall stat",reqparams,LinuxSyscallstatparams)) return false;
			filename=GetPointerParameter(reqparams,0,PARAMCHECKING_DEFAULTLEN);
			#ifdef DEBUGLINUX
			fprintf(stderr,"RemoteServ msg:%d:Linux Syscall stat...:filename->%s",4000+LinuxSyscallstatservno,filename);
			#endif
			retval=rsstat(filename,&x86stat);
			break;
		case LinuxSyscalllstatservno:
			if(!CheckParamNum("Linux syscall lstat",reqparams,LinuxSyscalllstatparams)) return false;
			filename=GetPointerParameter(reqparams,0,PARAMCHECKING_DEFAULTLEN);
			#ifdef DEBUGLINUX
			fprintf(stderr,"RemoteServ msg:%d:Linux Syscall lstat...:filename->%s",4000+LinuxSyscalllstatservno,filename);
			#endif
			retval=rslstat(filename,&x86stat);
			break;
		case LinuxSyscallfstatservno:
			if(!CheckParamNum("Linux syscall fstat",reqparams,LinuxSyscallfstatparams)) return false;
			if(!GetParameter(reqparams,0,(uint32*)&fd)) return false;
			#ifdef DEBUGLINUX
			fprintf(stderr,"RemoteServ msg:%d:Linux Syscall fstat...:fd->%d",4000+LinuxSyscallfstatservno,fd);
			#endif
			retval=rsfstat(fd,&x86stat);
			break;
		default:
			#ifndef REMOTESERVQUIET
			fprintf(stderr,"RemoteServer err:Linux:LinuxSyscallfstat:invalid syscallno!\n");
			#endif
			return false;
	}

	#ifdef DEBUGLINUX
	fprintf(stderr,"; retval->%d\n",retval<0?retval*errno:retval);
	#endif
	if(X86SYSCALLOK(retval)) CopyStat(&x86stat, &statmips);
	LINUXCOMMONRET_1BUF(retval,&statmips,DWORDALIGN,
		sizeof(struct statformips),LINUX_BUFNOTFREE);
}

_syscall1(long,rsuname,struct new_utsname_fori386 *,name)
bool LinuxSyscallnewuname(ReqDBP* reqparams)
{
	struct new_utsname_fori386 name;
	LINUXCOMMONDECLARE

	if(!CheckParamNum("Linux syscall newuname",reqparams,LinuxSyscallnewunameparams)) return false;

	retval=rsuname(&name);
	
	#ifdef DEBUGLINUX
	fprintf(stderr,"RemoteServ msg:%d:Linux Syscall newuname...:retval->%d\n",
		4000+LinuxSyscallnewunameservno,retval<0?retval*errno:retval);
	if(X86SYSCALLOK(retval)){
		fprintf(stderr,"sysname->%s\nnodename->%s\nrelease->%s\nversion->%s\nmachine->%s\ndomainname->%s\n",
			name.sysname,name.nodename,name.release,name.version,name.machine,name.domainname);
	}
	#endif
	LINUXCOMMONRET_1BUF(retval,&name,CHARALIGN,
		sizeof(struct new_utsname_fori386),LINUX_BUFNOTFREE);
}

//simulation of: long llseek(unsigned int fd, unsigned long offset_high,
//	unsigned long offset_low, loff_t * result, unsigned int origin)
_syscall5(long, rs_llseek, unsigned int, fd, unsigned long, offset_high,
	unsigned long, offset_low, loff_t *, result, unsigned int, origin)
bool LinuxSyscallllseek(ReqDBP* reqparams)
{
	unsigned int fd;
	unsigned long offset_high;
	unsigned long offset_low;
	loff_t resultval;
	unsigned int origin;
	LINUXCOMMONDECLARE

	if(!CheckParamNum("Linux syscall llseek",reqparams,LinuxSyscallllseekparams)) return false;

	if(!GetParameter(reqparams,0,(uint32*)&fd)) return false;
	if(!GetParameter(reqparams,1,(uint32*)&offset_high)) return false;
	if(!GetParameter(reqparams,2,(uint32*)&offset_low)) return false;
	if(!GetParameter(reqparams,3,(uint32*)&origin)) return false;
	
	retval=rs_llseek(fd,offset_high,offset_low,&resultval,origin);

	#ifdef DEBUGLINUX
	fprintf(stderr,"RemoteServ msg:%d:Linux Syscall llseek...: fd->%d, offset_high->0x%x, offset_low->0x%x, origin->%d; retval->%d, result->0x%llx\n",
		4000+LinuxSyscallllseekservno,fd,offset_high,offset_low,origin,retval<0?retval*errno:retval,resultval);
	#endif
	LINUXCOMMONRET_1BUF(retval,&resultval,DWORDALIGN,sizeof(loff_t),LINUX_BUFNOTFREE);
}

//simulation of: long select(int n, fd_set *inp, fd_set *outp, fd_set *exp, struct timeval *tvp)
_syscall5(long, rs_newselect, int, n, fd_set *, inp, fd_set *, outp,
	fd_set *, exp, struct timeval *, tvp)
bool LinuxSyscallselect(ReqDBP* reqparams)
{
	int n;
	fd_set* inp;
	fd_set* outp;
	fd_set* exp;
	struct timeval* tvp;
	uint32 retval;
	uint32 v0;
	uint32 a3;
	ServInfoDesc_t servinfo;
	ParamsDesc_t* paramsdescptr=&servinfo.paramdesc;
	
	if(!CheckParamNum("Linux syscall newselect",reqparams,LinuxSyscallnewselectparams)) return false;

	if(!GetParameter(reqparams,0,(uint32*)&n)) return false;
	inp=(fd_set*)GetPointerParameter(reqparams,1,sizeof(fd_set));
	outp=(fd_set*)GetPointerParameter(reqparams,2,sizeof(fd_set));
	exp=(fd_set*)GetPointerParameter(reqparams,3,sizeof(fd_set));
	tvp=(struct timeval*)GetPointerParameter(reqparams,4,sizeof(struct timeval));
	
	retval=rs_newselect(n,inp,outp,exp,tvp);

	#ifdef DEBUGLINUX
	fprintf(stderr,"RemoteServ msg:%d:Linux Syscall newselect...:n->%d; retval->%d\n",
		4000+LinuxSyscallnewselectservno,n,retval<0?retval*errno:retval);
	#endif
	a3=ConvertSysCallReturn(retval,&v0);
	SetParamDescNum(paramsdescptr,6);
	SetParamDescParameter(paramsdescptr,0,v0,true,0,0);
	SetParamDescParameter(paramsdescptr,1,a3,true,0,0);
	SetParamDescParameter(paramsdescptr,2,(uint32)inp,false,DWORDALIGN,sizeof(fd_set));
	SetParamDescParameter(paramsdescptr,3,(uint32)outp,false,DWORDALIGN,sizeof(fd_set));
	SetParamDescParameter(paramsdescptr,4,(uint32)exp,false,DWORDALIGN,sizeof(fd_set));
	SetParamDescParameter(paramsdescptr,5,(uint32)tvp,false,DWORDALIGN,sizeof(struct timeval));
	ServerMakeReplyDataSet(&servinfo);
	return true;
}

//simulation of: long ftruncate64(unsigned int fd, loff_t length)
_syscall3(long,rsftruncate64,unsigned int, fd, long, lenlow,long, lenhigh)
bool LinuxSyscallftruncate64(ReqDBP* reqparams)
{
	unsigned int fd;
	long lenlow;
	long lenhigh;
	LINUXCOMMONDECLARE	

	if(!CheckParamNum("Linux syscall ftruncate64",reqparams,LinuxSyscallftruncate64params)) return false;

	if(!GetParameter(reqparams,0,(uint32*)&fd)) return false;
	if(!GetParameter(reqparams,1,(uint32*)&lenlow)) return false;
	if(!GetParameter(reqparams,2,(uint32*)&lenhigh)) return false;
	
	retval=rsftruncate64(fd,lenlow,lenhigh);

	#ifdef DEBUGLINUX
	fprintf(stderr,"RemoteServ msg:%d:Linux Syscall ftruncate64...: fd->%d, lenlow->0x%x, lenhigh->0x%x; retval->%d\n",
		4000+LinuxSyscallftruncate64servno,fd,lenlow,lenhigh,retval<0?retval*errno:retval);
	#endif
	LINUXCOMMONRET(retval);
}

//simulation of: long stat64(char * filename, struct stat64for386* statbuf, long flags)
//simulation of: long lstat64(char * filename, struct stat64for386* statbuf, long flags)
//simulation of: long fstat64(unsigned long fd, struct stat64for386* statbuf, long flags)
void CopyStat64(struct stat64for386* statlocalptr,RServDataUnit_t * buf)
{
	if((statlocalptr==NULL)||(buf==NULL)){
		#ifndef REMOTESERVQUIET
		fprintf(stderr,"RemoteServ err:SyscallError:when copying fstat64!\n");
		#endif
		return;
	}
	
	(*(unsigned long*)(buf++))=(unsigned long)statlocalptr->st_dev;
	(*(unsigned long*)(buf++))=(unsigned long)statlocalptr->st_ino;
	(*(unsigned int*)(buf++))=(unsigned int)statlocalptr->st_mode;
	(*(int*)(buf++))=(int)statlocalptr->st_nlink;
	(*(int*)(buf++))=(int)statlocalptr->st_uid;
	(*(int*)(buf++))=(int)statlocalptr->st_gid;
	(*(unsigned long*)(buf++))=(unsigned long)statlocalptr->st_rdev;
	(*(long long*)(buf++))=(long long)statlocalptr->st_size;
	(*(long*)(buf++))=(long)statlocalptr->st_accesstime;
	(*(long*)(buf++))=(long)statlocalptr->st_modifytime;
	(*(long*)(buf++))=(long)statlocalptr->st_createtime;
	(*(unsigned long*)(buf++))=(unsigned long)statlocalptr->st_blksize;
	(*(long long*)(buf++))=(long long)statlocalptr->st_blocks;
	
	#ifdef DEBUGLINUX
	fprintf(stderr,"remote fstat64...\n");
	fprintf(stderr,"st_dev->0x%x\n",statlocalptr->st_dev);
	fprintf(stderr,"st_ino->0x%x\n",statlocalptr->st_ino);
	fprintf(stderr,"st_mode->0x%x\n",statlocalptr->st_mode);
	fprintf(stderr,"st_nlink->0x%x\n",statlocalptr->st_nlink);
	fprintf(stderr,"st_uid->0x%x\n",statlocalptr->st_uid);
	fprintf(stderr,"st_gid->0x%x\n",statlocalptr->st_gid);
	fprintf(stderr,"st_rdev->0x%x\n",statlocalptr->st_rdev);
	fprintf(stderr,"st_size->0x%llx\n",statlocalptr->st_size);
	fprintf(stderr,"st_accesstime->0x%x\n",statlocalptr->st_accesstime);
	fprintf(stderr,"st_modifytime->0x%x\n",statlocalptr->st_modifytime);
	fprintf(stderr,"st_createtime->0x%x\n",statlocalptr->st_createtime);
	fprintf(stderr,"st_blksize->0x%x\n",statlocalptr->st_blksize);
	fprintf(stderr,"st_blocks->0x%llx\n",statlocalptr->st_blocks);
	#endif
} 
_syscall3(long,rsfstat64,unsigned long, fd,struct stat64for386*,statbuf,long,flags)
_syscall3(long,rsstat64,char *, filename,struct stat64for386*,statbuf,long,flags)
_syscall3(long,rslstat64,char *, filename,struct stat64for386*,statbuf,long,flags)
bool LinuxSyscallfstat64(ReqDBP* reqparams, uint32 syscallno)
{	
	char* filename;
	uint32 fd;
	struct stat64for386 stat;
	uint32 flags;
	RServDataUnit_t statreply[STATDOMAINNUMNEED];
	LINUXCOMMONDECLARE	

	switch(syscallno){
		case LinuxSyscallstat64servno:
			if(!CheckParamNum("Linux syscall stat64",reqparams,LinuxSyscallstat64params)) return false;
			filename=GetPointerParameter(reqparams,0,PARAMCHECKING_DEFAULTLEN);
			if(!GetParameter(reqparams,1, &flags)) return false;
			#ifdef DEBUGLINUX
			fprintf(stderr,"RemoteServ msg:%d:Linux Syscall stat64...: filename->%s, flags->0x%x",
				4000+LinuxSyscallstat64servno,filename,flags);
			#endif
			retval=rsstat64(filename,&stat,flags);
			break;
		case LinuxSyscalllstat64servno:
			if(!CheckParamNum("Linux syscall lstat64",reqparams,LinuxSyscalllstat64params)) return false;
			filename=GetPointerParameter(reqparams,0,PARAMCHECKING_DEFAULTLEN);
			if(!GetParameter(reqparams,1, &flags)) return false;
			#ifdef DEBUGLINUX
			fprintf(stderr,"RemoteServ msg:%d:Linux Syscall lstat64...: filename->%s, flags->0x%x",
				4000+LinuxSyscalllstat64servno,filename,flags);
			#endif
			retval=rslstat64(filename,&stat,flags);
			break;
		case LinuxSyscallfstat64servno:
			if(!CheckParamNum("Linux syscall fstat64",reqparams,LinuxSyscallfstat64params)) return false;
			if(!GetParameter(reqparams,0, &fd)) return false;
			if(!GetParameter(reqparams,1, &flags)) return false;
			#ifdef DEBUGLINUX
			fprintf(stderr,"RemoteServ msg:%d:Linux Syscall fstat64...: fd->%d, flags->0x%x",
				4000+LinuxSyscallfstat64servno,fd,flags);
			#endif
			retval=rsfstat64(fd,&stat,flags);
			break;
		default:
			#ifndef REMOTESERVQUIET
			fprintf(stderr,"RemoteServer err:Linux:LinuxSyscallfstat64:invalid syscallno!\n");
			#endif
			return false;
	}

	#ifdef DEBUGLINUX
	fprintf(stderr,"; retval->%d\n",retval<0?retval*errno:retval);
	#endif
	bzero(statreply,sizeof(statreply));
	if(X86SYSCALLOK(retval)) CopyStat64(&stat, statreply);
	LINUXCOMMONRET_1BUF(retval,statreply,DWORDALIGN,
		sizeof(RServDataUnit_t)*STATDOMAINNUMNEED,LINUX_BUFNOTFREE);
}

bool LinuxSyscallDispatcher(ReqDBH* reqbodyheader)
{
	ReqDataSetBodyParameters_t* reqparams=(ReqDBP*)(reqbodyheader+1);

	switch(UNITVAL(reqbodyheader->service)){
		case LinuxSyscallreadservno:
			return LinuxSyscallread(reqparams);
		case LinuxSyscallwriteservno:
			return LinuxSyscallwrite(reqparams);
		case LinuxSyscallopenservno:
			return LinuxSyscallopen(reqparams);
		case LinuxSyscallcloseservno:
			return LinuxSyscallclose(reqparams);
		case LinuxSyscallunlinkservno:
			return LinuxSyscallunlink(reqparams);
		case LinuxSyscalltimeservno:
			return LinuxSyscalltime(reqparams);
		case LinuxSyscalllseekservno:
			return LinuxSyscalllseek(reqparams);
		case LinuxSyscallgetpidservno:
			return LinuxSyscallgetpid(reqparams);
		case LinuxSyscallgetuidservno:
			return LinuxSyscallgetuid(reqparams);
		case LinuxSyscallaccessservno:
			return LinuxSyscallaccess(reqparams);
		case LinuxSyscallrenameservno:
			return LinuxSyscallrename(reqparams);
		case LinuxSyscalltimesservno:
			return LinuxSyscalltimes(reqparams);
		case LinuxSyscallgetgidservno:
			return LinuxSyscallgetgid(reqparams);
		case LinuxSyscallgeteuidservno:
			return LinuxSyscallgeteuid(reqparams);
		case LinuxSyscallgetegidservno:
			return LinuxSyscallgetegid(reqparams);
		case LinuxSyscallioctlservno:
			return LinuxSyscallioctl(reqparams);
		case LinuxSyscallfcntlservno:
			return LinuxSyscallfcntl(reqparams,LinuxSyscallfcntlservno);
		case LinuxSyscallgetrlimitservno:
			return LinuxSyscallgetrlimit(reqparams);
		case LinuxSyscallgetrusageservno:
			return LinuxSyscallgetrusage(reqparams);
		case LinuxSyscallftruncateservno:
			return LinuxSyscallftruncate(reqparams);
		case LinuxSyscallstatservno:
			return LinuxSyscallfstat(reqparams,LinuxSyscallstatservno);
		case LinuxSyscalllstatservno:
			return LinuxSyscallfstat(reqparams,LinuxSyscalllstatservno);
		case LinuxSyscallfstatservno:
			return LinuxSyscallfstat(reqparams,LinuxSyscallfstatservno);
		case LinuxSyscallnewunameservno:
			return LinuxSyscallnewuname(reqparams);
		case LinuxSyscallllseekservno:
			return LinuxSyscallllseek(reqparams);
		case LinuxSyscallnewselectservno:
			return LinuxSyscallselect(reqparams);
		case LinuxSyscallftruncate64servno:
			return LinuxSyscallftruncate64(reqparams);
		case LinuxSyscallstat64servno:
			return LinuxSyscallfstat64(reqparams,LinuxSyscallstat64servno);
		case LinuxSyscalllstat64servno:
			return LinuxSyscallfstat64(reqparams,LinuxSyscalllstat64servno);
		case LinuxSyscallfstat64servno:
			return LinuxSyscallfstat64(reqparams,LinuxSyscallfstat64servno);
		case LinuxSyscallfcntl64servno:
			return LinuxSyscallfcntl(reqparams,LinuxSyscallfcntl64servno);
		default:
			#ifndef REMOTESERVQUIET
			fprintf(stderr,"RemoteServ err:LinuxSyscallDispatcher:invalid linux syscall service:%d\n",UNITVAL(reqbodyheader->service));
			#endif
			return false;
	}
	return true;
}

