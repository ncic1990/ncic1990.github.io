#include "RemoteServ.h"
#include "RemoteServCommon.h"
#include "SRLayer.h"
#include "AppLayer.h"
#include "RemoteServLibc.h"
#include "RemoteServLinux.h"
#include "RemoteServTopsyAssist.h"
#include "DBGRemoteServ.h"

extern char* RequestBuf;
extern char* OriginReqBufBase;
extern uint32 OriginReqBufLen;
extern char* ReplyBuf;
extern char* OriginReplyBufBase;
extern uint32 OriginReplyBufLen;
extern int globalconnectfd;

bool ReqTypeDispatcher(char* reqbuf)
{
	bool retval;
	
	ReqDataSetBodyHeader_t* reqbodyheader=
		(ReqDataSetBodyHeader_t*)(reqbuf+sizeof(ReqDataSetHeader_t));
	if(reqbuf==NULL){
		#ifndef REMOTESERVQUIET
		fprintf(stderr,"RemoteServ err:ReqTypeDispatcher:request buffer is NULL!\n");
		#endif
		return false;
	}

	retval=true;
	InstallTopsyEnv();
	switch(UNITVAL(reqbodyheader->servtype)){
		case LIBCREQ:
			retval=LibcServDispatcher(reqbodyheader);
			break;
		case LINUXSYSCALL:
			retval=LinuxSyscallDispatcher(reqbodyheader);
			break;
		case TOPSYASSISTREQ:
			retval=TopsyAssistDispatcher(reqbodyheader);
			break;
		default:
			#ifndef REMOTESERVQUIET
			printf("server err:ReqTypeDispatcher:server err:invalid request type!\n");
			#endif
			retval=false;
			break;
	}
	UnInstallTopsyEnv();
	return retval;
}

//handling process of service request
void HandlingServRequest()
{
	initbuffer(&RequestBuf,&OriginReqBufBase,&OriginReqBufLen);
	initbuffer(&ReplyBuf,&OriginReplyBufBase,&OriginReplyBufLen);
	if(!RecvDataSet(&RequestBuf,&OriginReqBufBase,&OriginReqBufLen)) 
		goto outfailed;
	if(!ReqTypeDispatcher(RequestBuf)) goto outfailed;

outfailed:
	SendDataSet(ReplyBuf);
outnotreply:
	destroybuffer(&RequestBuf,&OriginReqBufBase,&OriginReqBufLen);
	destroybuffer(&ReplyBuf,&OriginReplyBufBase,&OriginReplyBufLen);
}

int
main(int argc, char **argv)
{
	uint32 serverport;
    int listenfd, connfd;
    socklen_t clilen;
    struct sockaddr_in cliaddr, servaddr;
    int rc = 0;

	//some checkings and initializations
	if(!HALBufferLenChecking( )) return -1;
	if(!InitTopsyEnv()) return -1;

	//get serverport
	serverport=argc==1? SERVERPORT: atoi(argv[1]);
	#ifdef DEBUGMAIN
	fprintf(stderr,"server port: %d.\n",serverport);
	#endif

    if((listenfd = socket(AF_INET, SOCK_STREAM, 0))<0){
		#ifndef REMOTESERVQUIET
		fprintf(stderr,"RemoteServ err: main: can not create socket!\n");
		#endif
		return 0;
    }

    bzero(&servaddr, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
    servaddr.sin_port = htons(serverport);
    rc = bind(listenfd, (struct sockaddr*) &servaddr, sizeof(servaddr));
    if(rc < -1) perror("bind");

    listen(listenfd, 5);

	#ifdef DEBUGMAIN
	fprintf(stderr,"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n");
	fprintf(stderr,"!!!!!!!!!!!!!!!!!!start remote server!!!!!!!!!!!!!!!!!!\n");
	fprintf(stderr,"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n");
	#endif
    for ( ; ; ) {
			#ifdef WALKPATH
			fprintf(stderr,"\n...................server msg:waiting for connection...................\n");
			#endif
            clilen = sizeof(cliaddr);
            connfd = accept(listenfd, (struct sockaddr*)&cliaddr, &clilen);
			globalconnectfd=connfd;
            HandlingServRequest();
            close(connfd); 
			#ifdef WALKPATH
			fprintf(stderr,"...................server msg:connection closed...................\n\n");
			#endif
    }

	//some destroy processes
	DestroyTopsyEnv( );
}

