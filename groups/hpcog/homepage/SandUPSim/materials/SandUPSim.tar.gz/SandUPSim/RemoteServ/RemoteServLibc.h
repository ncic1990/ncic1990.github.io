#ifndef REMOTESERVLIBC_H
#define REMOTESERVLIBC_H
#include "RemoteServ.h"

bool LibcServDispatcher(ReqDBH* reqbodyheader);

#endif /*REMOTESERVLIBC_H*/
