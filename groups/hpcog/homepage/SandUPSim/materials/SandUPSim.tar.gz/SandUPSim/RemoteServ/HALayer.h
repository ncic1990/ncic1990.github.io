#ifndef HALAYER_H
#define HALAYER_H
#include "RemoteServ.h"

bool SendPackage();
bool RecvPackage();

#endif /*end of HALAYER_H*/

