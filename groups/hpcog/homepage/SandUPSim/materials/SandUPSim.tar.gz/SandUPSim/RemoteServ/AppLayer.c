#include "AppLayer.h"
#include "DBGRemoteServ.h"
#include "RemoteServCommon.h"

extern char* RequestBuf;
extern char* OriginReqBufBase;
extern uint32 OriginReqBufLen;
extern char* ReplyBuf;
extern char* OriginReplyBufBase;
extern uint32 OriginReplyBufLen;

uint32 calsizeofRDBP(ParamsDesc_t* paramsdesc)
{
	uint32 count;
	uint32 size=0;
	uint32 align;
	
	if(!paramsdesc) return 0;
	if(paramsdesc->paramnum==DEFCANNOTSERV) return sizeof(RServDataUnit_t);
	size=paramsdesc->paramnum*sizeof(DSParamDesc_t)+sizeof(RServDataUnit_t);
	for(count=0;count<paramsdesc->paramnum;count++){
		if(paramsdesc->parameters[count].notpointer) continue;
		if((long)paramsdesc->parameters[count].len==(long)PARAM_POINTERNULL) continue;
		align=paramsdesc->parameters[count].align;
		align=up2exp(align);
		size=(size+align-1)&(~(align-1));
		paramsdesc->parameters[count].offset=size;
		size+=paramsdesc->parameters[count].len;
	}
	return size;
}

bool MakeDataSet(ServInfoDesc_t* servinfoptr,
	char** buf, char** originbuf, uint32* len)
{	
	ParamsDesc_t* paramsdescptr=&servinfoptr->paramdesc;
	if(!paramsdescptr){
		paramsdescptr=malloc(sizeof(ParamsDesc_t));
		if(!paramsdescptr) return false;
		paramsdescptr->paramnum=DEFCANNOTSERV;
	}

	if(*buf) destroybuffer(buf,originbuf,len);
	uint32 size=sizeof(RDH)+sizeof(RDBH)+calsizeofRDBP(paramsdescptr);
	if(!newbuffer(buf,originbuf,len,size)) return false;
	if(!setbuffer_RDH(*buf,servinfoptr,size)) goto outfailed;
	if(!setbuffer_RDBH(*buf,servinfoptr)) goto outfailed;
	if(!setbuffer_Params(*buf,paramsdescptr)) goto outfailed;
	return true;

outfailed:
	destroybuffer(buf,originbuf,len);
	return false;
}
bool ServerMakeReplyDataSet(ServInfoDesc_t* servinfoptr)
{
	if(!RequestBuf||!servinfoptr){
		#ifndef REMOTESERVQUIET
		fprintf(stderr,"RemoteServ err: ServerMakeReplyDataSet:RequestBuf or servinfoptr is NULL!\n");
		#endif
		return false;
	}
	RDH* rdataheader=(RDH*)RequestBuf;
	RDBH* rdatabodyheader=(RDBH*)(RequestBuf+sizeof(RDH));
	servinfoptr->destaddr=rdataheader->srcaddr;
	servinfoptr->srcaddr=rdataheader->destaddr;
	servinfoptr->type=UNITVAL(rdatabodyheader->servtype);
	servinfoptr->service=UNITVAL(rdatabodyheader->service);
	return MakeDataSet(servinfoptr,&ReplyBuf,&OriginReplyBufBase,&OriginReplyBufLen);
}
bool SetParamDescNum(ParamsDesc_t* paramsdesc,uint32 num)
{
	if(!paramsdesc) {
		#ifndef REMOTESERVQUIET
		fprintf(stderr,"RemoteServ err: SetParamnum:paramsdesc is NULL!\n");
		#endif
		return false;
	}
	paramsdesc->paramnum=num;
	return true;
}
bool SetParamDescParameter(ParamsDesc_t* paramsdesc,uint32 which,
	uint32 paramval,uint32 notpointer,uint32 align,uint32 len)
{
	if(!paramsdesc) {
		#ifndef REMOTESERVQUIET
		fprintf(stderr,"RemoteServ err: SetParameter:paramsdesc is NULL!\n"); 
		#endif
		return false;
	}
	if((which<0)||(which>=MAXPARAMETERS)) {
		#ifndef REMOTESERVQUIET
		fprintf(stderr,"RemoteServ err: SetParameter:which is invalid!\n");
		#endif
		return false;
	}
	paramsdesc->parameters[which].paramval=paramval;
	paramsdesc->parameters[which].notpointer=notpointer;
	paramsdesc->parameters[which].align=align;
	paramsdesc->parameters[which].len=len;
	return true;
}
bool CheckParamNum(char* s,ReqDBP* reqparams,uint32 params)
{
	if(reqparams==NULL){
		#ifndef REMOTESERVQUIET
		fprintf(stderr,"RemoteServ err: CheckParamNum:reqparams is NULL!\n");
		#endif
		return false;
	}
	if(UNITVAL(reqparams->parameternum)==params) return true;
	#ifndef REMOTESERVQUIET
	fprintf(stderr,"RemoteServ err: %s:invalid parameter number->%d!\n",s,UNITVAL(reqparams->parameternum));
	#endif
	return false;
}

