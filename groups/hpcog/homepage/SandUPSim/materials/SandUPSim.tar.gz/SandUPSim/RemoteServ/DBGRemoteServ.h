#ifndef DBGREMOTESERV_H
#define DBGREMOTESERV_H

/*debug switches*/
//#define WALKPATH
//#define DEBUGGLOBAL
//#define DEBUGHAL
//#define DEBUGSR
//#define DEBUGAPP
//#define DEBUGLIBC
//#define DEBUGLINUX
//#define DEBUGTA
#define DEBUGMAIN
//#define REMOTESERVQUIET
#define STRICTCHECKING

#endif /*end of DBGREMOTESERV_H*/

