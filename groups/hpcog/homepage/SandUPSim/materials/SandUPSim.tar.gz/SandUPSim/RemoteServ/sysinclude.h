#ifndef SYSINCLUDE_H
#define SYSINCLUDE_H

#include <sys/types.h>
#include <sys/mman.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <limits.h>
#include <string.h>
#include <ctype.h>
#include <pwd.h>
#include <time.h>
#include <errno.h>
#ifndef __USE_GNU
#define __USE_GNU
#endif
#ifndef __USE_LARGEFILE64
#define __USE_LARGEFILE64
#endif
#include <fcntl.h>
#include <termios.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/stat.h> 
#include <dirent.h> 
#include <sys/times.h>


//note:architecture dependding
typedef unsigned long long uint64;
typedef unsigned long uint32;
typedef unsigned short uint16;
typedef unsigned char uint8;
typedef uint8 bool;
#define true 1
#define false 0

#endif /*end of SYSINCLUDE_H*/
