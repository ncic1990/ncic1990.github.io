#ifndef SRLAYER_H
#define SRLAYER_H
#include "RemoteServ.h"

bool SendDataSet(char* buf);
bool RecvDataSet(char** buf,char** originbuf,uint32* len);


#endif /*end of SRLAYER_H*/

