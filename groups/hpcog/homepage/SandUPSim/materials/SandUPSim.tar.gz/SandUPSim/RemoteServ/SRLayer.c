#include "SRLayer.h"
#include "DBGRemoteServ.h"
#include "HALayer.h"
#include "RemoteServCommon.h"

extern char* NetWorkCardBuf;

//send and receive layer
bool SendDataSet(char* buf)
{
	if(!buf){
		#ifdef DEBUGSR
		fprintf(stderr,"RemoteServ msg: SRLayer: SendDataSet:reply buffer is empty and is not sent!\n");
		#endif
		return false;
	}
	
	RDH* rdheader=(RDH*)buf;
	uint32 bufcount=UNITVAL(rdheader->datasetlen);
	char* sendbuf=(char*)buf;
	uint32 count;
	uint32 packagecount;
	package_header_t* packageheader=(package_header_t*)NetWorkCardBuf;
	uint32 sendlen;
	
	if(bufcount<sizeof(RDH)+sizeof(RDBH)){
		#ifndef REMOTESERVQUIET
		fprintf(stderr,"RemoteServ err: SRLayer: SendDataSet:data set size is too small!\n");
		#endif
		return false;
	}

	//how many package in this data set
	if(bufcount%MAXDPBSIZE) 
		packagecount=bufcount/MAXDPBSIZE+1;
	else 
		packagecount=bufcount/MAXDPBSIZE;

	for(count=1;count<=packagecount;count++){
		//package: dest and src addr
		packageheader->destaddr=rdheader->destaddr;
		packageheader->srcaddr=rdheader->srcaddr;
		//package len
		sendlen=UNITVAL(packageheader->packagelen)=count<packagecount? MAXDPBSIZE: bufcount;
		UNITVAL(packageheader->packagelen)+=sizeof(package_header_t);
		//package flag
		if(count==1)
			UNITVAL(packageheader->packageflag)=packagecount==1? FIRSTANDLAST:FIRSTPACKAGE;
		else if(count==packagecount)
			UNITVAL(packageheader->packageflag)=LASTPACKAGE;
		else 
			UNITVAL(packageheader->packageflag)=DEFMIDPACKAGE;
		//package body
		memcpy(NetWorkCardBuf+sizeof(package_header_t),sendbuf,sendlen);
		//send this package by HALayer
		if(!SendPackage()) return false;
		//next package
		sendbuf+=sendlen;
		bufcount-=sendlen;
	}

	#ifdef DEBUGSR
	fprintf(stderr,"RemoteServ msg: SRLayer: SendDataSet:%d bytes is sent...\n",UNITVAL(rdheader->datasetlen));
	#endif
	return true;
}

bool addrChecking(RDH* rdheader, package_header_t* packageheader)
{
	if(UNITVAL(rdheader->srcaddr.addr)!=UNITVAL(packageheader->srcaddr.addr))
		goto failed;
	if(UNITVAL(rdheader->srcaddr.port)!=UNITVAL(packageheader->srcaddr.port))
		goto failed;
	if(UNITVAL(rdheader->destaddr.addr)!=UNITVAL(packageheader->destaddr.addr))
		goto failed;
	if(UNITVAL(rdheader->destaddr.port)!=UNITVAL(packageheader->destaddr.port))
		goto failed;
	return true;
failed:
	#ifndef REMOTESERVQUIET
	fprintf(stderr,"RemoteServ err: SRLayer: addrChecking:addr checking err!\n");
	#endif
	return false;
}
bool RecvDataSet(char** buf,char** originbuf,uint32* len)
{
	package_header_t* packageheader=(package_header_t*)NetWorkCardBuf;
	uint32 recvlen;
	RDH* rdheader;
	uint32 datasetlen;
	char* tempbuf;
	uint32 packagecount;
	uint32 count;

	if(*buf) destroybuffer(buf,originbuf,len);
	
	//get first package
	if(!RecvPackage()) return false;
	//some checks
	if((UNITVAL(packageheader->packageflag)!=FIRSTPACKAGE)&&
		(UNITVAL(packageheader->packageflag)!=FIRSTANDLAST)){
		#ifndef REMOTESERVQUIET
		fprintf(stderr,"RemoteServ err: SRLayer: RecvDataSet:expecting a first package but not!\n");
		#endif
		return false;
	}
	if(UNITVAL(packageheader->packagelen)<sizeof(package_header_t)+sizeof(RDH)+sizeof(RDBH)){
		#ifndef REMOTESERVQUIET
		fprintf(stderr,"RemoteServ err: SRLayer: RecvDataSet:the length of the first package is too small!\n");
		#endif
		return false;
	}
	rdheader=(RDH*)(NetWorkCardBuf+sizeof(package_header_t));
	//address checking
	if(!addrChecking(rdheader, packageheader)) return false;
	datasetlen=UNITVAL(rdheader->datasetlen);
	recvlen=UNITVAL(packageheader->packagelen)-sizeof(package_header_t);

	//get memory for request data set
	if(!newbuffer(buf,originbuf,len,datasetlen)) return false;
	tempbuf=(char*)(*buf);
	rdheader=(RDH*)(*buf);

	//copy the first package body to request buffer
	memcpy(tempbuf,NetWorkCardBuf+sizeof(package_header_t),recvlen);
	tempbuf+=recvlen;
	datasetlen-=recvlen;
	if(datasetlen<0){
		#ifndef REMOTESERVQUIET
		fprintf(stderr,"RemoteServ err: SRLayer: RecvDataSet:length error when receiving the request data set:0!\n");
		#endif
		return false;
	}
	if(UNITVAL(packageheader->packageflag)==FIRSTANDLAST){
		if(datasetlen!=0){
			#ifndef REMOTESERVQUIET
			fprintf(stderr,"RemoteServ err: SRLayer: RecvDataSet:length error when receiving the request data set:1!\n");
			#endif
			return false;
		}
		goto outok;
	}else{
		if(datasetlen==0){
			#ifndef REMOTESERVQUIET
			fprintf(stderr,"RemoteServ err: SRLayer: RecvDataSet:length error when receiving the request data set:2!\n");
			#endif
			return false;
		}
	}

	//receive other packages
	if(datasetlen%MAXDPBSIZE)
		packagecount=datasetlen/MAXDPBSIZE+1;
	else
		packagecount=datasetlen/MAXDPBSIZE;

	for(count=1;count<=packagecount;count++){
		//receive next package
		if(!RecvPackage()) return false;
		//flag checking
 		if((count<packagecount)&&(UNITVAL(packageheader->packageflag)!=DEFMIDPACKAGE)){
			#ifndef REMOTESERVQUIET
			fprintf(stderr,"RemoteServ err: SRLayer: RecvDataSet:expecting middle part package but not!\n");
			#endif
			return false;
 		}
		if((count==packagecount)&&(UNITVAL(packageheader->packageflag)!=LASTPACKAGE)){
			#ifndef REMOTESERVQUIET
			fprintf(stderr,"RemoteServ err: SRLayer: RecvDataSet: expecting last package but not!\n");
			#endif
			return false;
		}
		//address checking
		if(!addrChecking(rdheader, packageheader)) return false;
		//copying package body to data set
		recvlen=UNITVAL(packageheader->packagelen)-sizeof(package_header_t);
		memcpy(tempbuf,NetWorkCardBuf+sizeof(package_header_t),recvlen);
		tempbuf+=recvlen;
		datasetlen-=recvlen;
		if(datasetlen<0){
			#ifndef REMOTESERVQUIET
			fprintf(stderr,"RemoteServ err: SRLayer: RecvDataSet:length error when receiving the request data set:3!\n");
			#endif
			return false;
		}
	}	

	if(datasetlen!=0){
		#ifndef REMOTESERVQUIET
		fprintf(stderr,"RemoteServ err: SRLayer: RecvDataSet:length error when receiving the request data set:4!\n");
		#endif
		return false;
	}

outok:
	#ifdef DEBUGSR
	fprintf(stderr,"RemoteServ msg: SRLayer: RecvDataSet:%d bytes is received...\n",UNITVAL(rdheader->datasetlen));
	outputdataset("RecvDataSet",*buf);
	#endif
	
	return true;
}

